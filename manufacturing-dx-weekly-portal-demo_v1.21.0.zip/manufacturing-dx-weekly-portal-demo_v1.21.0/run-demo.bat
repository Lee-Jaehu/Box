@echo off
setlocal EnableExtensions DisableDelayedExpansion
title Manufacturing DX Weekly Portal Demo
cd /d "%~dp0"

echo.
echo ============================================================
echo  Manufacturing DX Weekly Portal Demo
echo ============================================================
echo  Working directory: %CD%
echo.

set "DEMO_PYTHON="
where py >nul 2>&1
if not errorlevel 1 (
  py -3 -c "import sys; assert sys.version_info.major == 3" >nul 2>&1
  if not errorlevel 1 set "DEMO_PYTHON=py -3"
)

if not defined DEMO_PYTHON (
  where python >nul 2>&1
  if not errorlevel 1 (
    python -c "import sys; assert sys.version_info.major == 3" >nul 2>&1
    if not errorlevel 1 set "DEMO_PYTHON=python"
  )
)

if not defined DEMO_PYTHON (
  where python3 >nul 2>&1
  if not errorlevel 1 (
    python3 -c "import sys; assert sys.version_info.major == 3" >nul 2>&1
    if not errorlevel 1 set "DEMO_PYTHON=python3"
  )
)

if defined DEMO_PYTHON goto :python_server

where powershell.exe >nul 2>&1
if errorlevel 1 goto :no_runtime

echo [INFO] Python 3 was not found.
echo [INFO] Starting the built-in Windows PowerShell server instead.
echo [INFO] Browser address: http://127.0.0.1:8080/
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0windows-portal-server.ps1" -Port 8080
if errorlevel 1 goto :server_error
goto :normal_end

:python_server
echo [INFO] Python command: %DEMO_PYTHON%
echo [INFO] Checking PPT export dependency (python-pptx)...
%DEMO_PYTHON% -c "import pptx" >nul 2>&1
if errorlevel 1 (
  echo [INFO] Installing python-pptx for the report PPT export feature...
  %DEMO_PYTHON% -m pip install --quiet -r requirements.txt
  if errorlevel 1 (
    echo [WARN] Could not install python-pptx automatically.
    echo [WARN] PPT download will not work until you run:
    echo [WARN]   %DEMO_PYTHON% -m pip install -r requirements.txt
  )
)
if not exist "%CD%\db\demo.db" (
  echo [INFO] Creating the sample database.
  %DEMO_PYTHON% build_db.py
  if errorlevel 1 goto :server_error
)
echo [INFO] Starting server at http://127.0.0.1:8080/
echo [INFO] Keep this window open while using the portal.
echo.
%DEMO_PYTHON% server.py --host 127.0.0.1 --port 8080 --open
if errorlevel 1 goto :server_error
goto :normal_end

:no_runtime
echo.
echo [ERROR] Python 3 and Windows PowerShell were not found.
echo [ACTION] Contact your PC administrator or install Python 3.
pause
exit /b 1

:server_error
echo.
echo [ERROR] The local portal server could not start.
echo [ACTION] Close another program using port 8080 and try again.
echo [ACTION] If the error continues, send a screenshot of this window.
pause
exit /b 1

:normal_end
echo.
echo The portal server has stopped.
pause
exit /b 0
