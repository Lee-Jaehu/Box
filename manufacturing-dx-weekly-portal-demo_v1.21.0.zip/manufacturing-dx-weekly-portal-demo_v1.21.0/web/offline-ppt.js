"use strict";

(function registerOfflinePpt(global) {
  const SWOOSH_IMAGE = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAtQAAAGECAYAAAAWS7eaAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAOw4AADsOAcy2oYMAAAw0SURBVHhe7d0hrB1VAsZxBKKiogKBQCBWIBAIRMU7dxCIFQjkCgRiJQJRUYEgWYFcgUAgEAgEorICMZm5TQjhdc4jNEEgEIgKBKKiArGbeX2v73LSe+nybfpmyO+XfNlNzrgi/pmcO++55wAAgKdWhvruZqz/mddt6xvtOQAAcICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgICgBgCAgKAGAICAoAYAgEAZphuPg7qvL7fnAADAAZuxfnIR1P2V9hwAADigDFM/x3QZp5/aMwAA4ID5jXQZ68PTN9TDdKs9BwAADph/hHh+3WO+S92eAwAAB2zG6d8XX/g4vt6eAwAAB5Rx+vns/vTP7RkAAHBAt53ePH87vRnrp+05AABwQBnq7YvrHidH7TkAALBHd6e+tvNjxL49BwAADihD/eri7bQ/Nw4AAE/taLz7j4u30/V2ew4AAOzR9d+8WMZ6/9GXPerDrq8vt88AAABP0PX982WYtjt3p2+2zwAAAHtsxumznaseX82B3T4DAAA8we5fRCzj9H3X37vaPgMAADS6vl7bDNOti5iu9+d71O1zAADAjq4/fqEM040yTr/+PqaPX2mfBQBgYeY3oPMfDjkaT94qQ33XntWmm5tx+nj3h4diGgBgBbq+v3I01rfnH72Vsf7Sxpxd7sQ0AMBCzfdzy1A/LOP0oI04W8bENADAAj36nnF9f/d+ri1vYhoAYIHO3krfbuPNljUxDQCwQHOglbH+0MabLWtiGgBggbrtyVFxV3rxE9MAAAskptcxMQ0AsEBieh0T0wAACySm1zExDQCwQGJ6HRPTAAALJKbXMTENALBAYnodK+P0s5gGAFgYMb2Ozd8C7/pvXmz//QAAuERieh0T0wAACySm1zExDQCwQGJ6HRPTAAALJKbXMTENALBAYnodE9MAAAskptexMkxVTAMALIyYXsmG+mXX37va/vsBAHCJxPTyV8b6sAzTzfbfDgCASYaml70y1t824/SZKx4AAAskppe7MtRvy1A/7PqTV9t/NwAAFmBfTJex/lKGabsZ6hfzm1F7NpvjuQzTP4/Gk7e8jQYAWLg2ps/+/0fdnbuvt88CAAA75mj+/Ztp93MBAOCpzOFcxnr/4p6ur0YAAMBTmb9dPP9BEDENAAB/wmaYPt+95tGeAwAAe3Tb6c2dz7F93fX98+0zAADAE3R9f6WM9cezT+L91vXHr7TPAAAAe5RhurHznemP2nMAAGCPs7fTp1/1mP93/mFi+wwAALBHGer7O3enP2jPAQCAA3buTj/s+nqtPQcAAPbo7tTXdu5Of9qeAwAAB2zG6V/nQd2Nd//engMAAAfM35t+dN1jejD/OLE9BwAA9jj7usfD0zfUw3SrPQcAAA7otsfXd77u8X57DgAAHHA01nce35/e1jfacwAA4IAy1A8fB3X/3UvtOQAAcMBmrJ+cB3V7BgAA/IHNOH129gdd7rdnAADAH7gI6umn9gwAAPgDghoAAAKCGgAAAoIaAAACghoAAAKCGgAAAoIaAAACghoAAAKCGgAAAoIaAAACghoAAAKCGgAAAoIaAAACghoAAAKCGgAAAoIaAAACghoAAAKCGgAAAoIaAAACghoAAAKCGgAAAoIaAAACghoAAAKCGgAAAoIaAAACghoAAAKCGgAAAoIaAAACghoAAAKCGgAAAoIaAAACghoAAAKCGgAAAoIaAAACghoAAAKCGgAAAoIaAAACghoAAAJlqLcFNQAA/EllrD+cBvVQv23PAACAA7q+v1LG+tsc1JuhftmeAwAAB3Tb4+unMf3oDfUH7TkAAHBAGaYb50Hdbac323MAAOCAMkz9ox8k1oddf+9qew4AAOzR9ccvXNyfnm615wAAwAFlqO+dX/c4Gus77TkAAHBAGeuPZ9+ffuC6BwAA/A+Oxvr2+dvpzTh93J4DAAB7dH3/fBmn7x9/3aO/+7f2GQAAYI/dT+VthvpFew4AAOzR9d+9NN+ZPrs7/WvXf/Ni+wwAAPAEp39mfKhf7/xlxPfaZwAAgD02w/T5RUxP/XyXun0GAAB4gjJMNx/H9Fh/6Pp6rX0GAABozG+h58/i7cT0fV/1AACAp9Btj6//7s70/AdctidH7XMAAMDp2+h6retPXp1/bFiG+tXjT+OJaS5Dt61v7P5HaGZmZrbWFTHNZRDUZmZm9ldYEdNcFkFtZmZma18R01wmQW1mZmZrXhHTXDZBbWZmZmtdEdMsgaA2MzOzNa6IaZZCUJuZmdnaVsQ0SyKozczMbE0rYpqlEdRmZma2lhUxzRIJajMzM1vDiphmqQS1mZmZLX1FTLNkgtrMzMyWvCKmWTpBbWZmZktdGev97s7d19t+gUUR1GZmZrbEncZ0f/xK2y6wOILazMzMljYxzaoIajMzM1vSxDSrI6jNzMxsKRPTrJKgNjMzsyVMTLNagtrMzMwue2KaVRPUZmZmdpkrw1S7vr7cNgqshqA2MzOzS9tQv+z6e1fbPoFVEdRmZmb2rDe/lT4a69ttl8AqCWozMzN7VivDtC1DfbftEVg1QW1mZmb/75VxelDG+mMZpn4z1k+PxvpO1x+/0HYI/BX8F1SEBK7DhU7DAAAAAElFTkSuQmCC";
  const LOGO_IMAGE = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJwAAAAYCAYAAAAPmZSDAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAOw4AADsOAcy2oYMAAAifSURBVGhD7Vt7iBVVGN8/6o6VkJBQRH9IRERE2MuZnhZsYCBhUPTAsGAhWbznm90iIhY2EAoqChIKMpIwsFgqQkKoxsnMtrJaa0NDi7U2ekpbbWUlMfE795xzv/nm3Jm5i0rC/cHH3jvnfc7vfq8z29dXA2nf0nlpEC1LGuH6JIh2Jo1oemsQZUkjmkoa0fjWIHoonRdeIdv10EPXSOeFKy3BqiQJwok0iPplHz30UIm0b+n8pBFusWTaedmd2f6Hn8t+/+zL7O/vD2Szu/YWCOeI1wjXp31Lj5N99tCDF+kJS85IgnAPyPPWyVdlXz/xQnZw/7fZ1IPPZp/edG+248zrCySTkjTCN0Ba2fexgtFVq+YR0SLI4ODg/HsGB0/D52azeYasWwXbFiLLqoCx+TxkuYUZ42ojpeOMjo4eZ/usEvQr29cBES2wfWAvZbmD1mxBtBOk+fDKgeyPz/dn3zz9crbtlGsKpKqSJIjGZP8cOLxYqSkrRBTLOmWIlVpNSo3FRJNEdJCUOqQ/KzWmlFpTulC0j+MbieiRWKkNRPTQULMZ2TIcXEyUQYjojlipVH9XagrlfO7oI9exgGtLlOWeVQjq6bHZPHIdM2AvWL3S+YAEtm6lmHlImH3T6+f7xsofYPO5WpY7bG2ET4Es7559gzadn9xwd4FI3UjSCO+TY1jIhWOSso4Puh07xE5CRN8ppQrBDIgYK/VKob5Sh4hoxIxRSrjc3JXaIMfg8BLOM18pqNcF4drrUWoCWkzWsZD7XiodCIc1s3lpQhHRJvaDmZLlBaSNS89JgvAQiDKz7aNsb/yoI85759/sPsPMQvtJcvkkCcKZdP5FC+VYgFx4HcLBrMRE03JjoOFipWYKz5XaJzcfmpSVa62YaxfH/UeacFirFTdvpWb4c1OvlHBmP9bl5t+S7ViHXDtQx6S6Pe6CcJxkXDoSLmlEG0ESEO3Aa+840nz12PMZ8MOLr+vv0H7w6SS5SmStHAuYC+Fg+kSbTUNDQ2fZcnyOm817DJGmh9esOSffg+5jj+sjji82z0ZYvxuHlLqFjVGbcNCo+jCYQNPaunweFvagSKmfZJmPcEZDrzb9ux8ZxiGiLWwduk8iGldKLbd9SlfGJ2b/OhOOaCMbdwWewbRaP9JHyByQa0uCcDY96XJtSnlg8HPygSbcn19Mz4lwSSPcJ8cDuiWcdoztRrQ24xVZxwKL7OTwam3Yaj9jn4F4fC5iXrUJxwniE1uPw82nNdYCUVYkXEtDORLrPVFqA9Zrytpas912Meuztkklpdbz+VhoDWrrKaXdJv2sTVr+Q/AQLoj6QY6J65qFlMf4uTfqlMj7F942J8JB0iByWshCLryKcEPN5jJR321iXeBA2EZp8gBaM3o23IxTm3Ddarjh4eGFfCzpgPsIB8RxPICDNuZ/Ado57UQUG+ItNnPPWRg+dwRY0pxy8UXGhR8+0bQ27d2Y1DeDaDWIMbX2mezbZ18tEIbLHAlXSAh3SzhEnrw+LyvzS6Qfw31Aq1FgFlzfSqU5P68Lwvng8+FcGYjDD0hobUk4QyLn5zE/0JkwM/9CHWv6xL7PSnMqhaeCjM/Y1m7tuY0PN5sX2D2PlXqclRUJlwThAyDG9JNjuWDBJ5JwuwfWaqL65IMltxvChQWHt1vCiUV8x8tkX6LfXF4qdzhEm82htgOHOB440kEDAO2GoMYzX5ce8hCu1GSXSt70OzNeJfZHix88ny/MLfd9dWqKaJPpvzwtYgmHAOFwEe6XHbt02ZEgHPe/ANmX6DdHOG0+PRGtrqvUTqMt6xOOaLt1lnW7OO6HubMaxUc4Y8K5pkCkOeu+G59MEs5nsmtLHA/Y8eGzWgJXiTWrSLewuWyylkOcy+Nmf8oJZ03q5K33HzaTimDD5vFw+S/HlCSpIhw3cxDuX+BwTP4H4jbG9FvIvJuxNyOKM3XgZ61jJraUcDrSY2P4BP4R6krCGQ3aDhSUGjMkX8F9I61ROvhw2p9tr7dKNAnEHnUlhuwriegpG9lzaFOv1JgN1CoJlzYuXQ5iIECQQYOUOoRDru7fg3+7aBc5PjnmHAjX9rNa9bUGkeBkMfUKhKtCFeEA9yxPMkSMcNy34CZD1sN3pdR5pp7Ou3Ef02iecZh4Q0Iv4fjzSmnfWnS0AlUiz0ZrNUNGXzaAEw7rleUuLQJy/HNgJtt++rICiboh3MfXDma/fbhbfz5caRGYIZEWmfBdXx0twtWFJBygtZlIgXBYR72EcLirdGbcJ66dUm+wNjKQaAUd7T3NJZ+Z5LQUX5Nvf80cdFsZtDng7hME+eK+ddmPLyUFEnHCQXvhNgJiAwMryOXBfwPpzDPv3Z4kHCI06T9YcdqimFWfRJJWaw2iReavTA4XNqQKR5pwdVFCuNyPqkxgBvO9FuHq11xfFeFqIT3+ssW42gJhfn1/0jn8UmAuQSYrb5/anyv/cuRJHe3is77aOvGSgsoFCoQrk7azvqCTw99J5rIh/ED1rcP/mXCtXF/hR2rFd9siwfqqtT5BuBE5JhfffbaDvbzH3SluHOremVoBAXEjYd8u6ebyvlTYRuh2Hv/JJwjjkX7Ij1wNfqAmMtTj4VpM1q0Cm+usLKsCJxwCBfaca7iucmk+uP0iGpdlPpi3dAr77ZWytFHr9aRwgpMHqRJoNUkuLtByeI0JphSBhyZbEG4uexGzm6jJ5nc4oHmQCzJpCUSZSCsgn7YZphf3hx39hwrYlATEvJOGNyEQDBTmUQXWdossqwJcCUsarqn0DUUXmr5KyzNy6oi2CubWZ1IS2ydVr0v1pUG4CP+vANJAU8E84k1f+Ha4+rImFIEF0h7Iuf31zQ+6HOa4pdmi7cfyC5g9HGXglSK8tWs12EfX3KXzc9B4ACJZBA4gIu5Z+etLSSPagKhX9tlDD5Xo/RNND0cdvX8T7OFw4T/8hn1myl7HWwAAAABJRU5ErkJggg==";

  const COLORS = { NAVY: "002060", GREEN: "006600", RED: "C00000", GRAY: "7F7F7F", TEXT: "262626" };
  const FONT = "Arial Narrow";

  function sectionColor(heading) {
    if (heading.includes("성과") || heading.includes("결과")) return COLORS.GREEN;
    if (heading.includes("리스크") || heading.includes("이슈")) return COLORS.RED;
    if (heading.includes("분석")) return COLORS.GRAY;
    return COLORS.NAVY;
  }

  function paginateBullets(bullets, lineBudget = 13) {
    const pages = [];
    let current = [];
    let usedLines = 0;
    (bullets || []).forEach((value) => {
      const text = String(value || "").trim();
      const paragraphCost = Math.max(1, Math.ceil(text.length / 55)) + 1;
      if (current.length && usedLines + paragraphCost > lineBudget) {
        pages.push(current);
        current = [];
        usedLines = 0;
      }
      current.push(text);
      usedLines += paragraphCost;
    });
    if (current.length) pages.push(current);
    return pages.length ? pages : [["표시할 내용이 없습니다."]];
  }

  function addCoverSlide(pptx, report, personaLabel, emphasisLabel) {
    const slide = pptx.addSlide();
    slide.background = { color: "FFFFFF" };
    slide.addImage({ data: SWOOSH_IMAGE, x: -0.013, y: 0.289, w: 9.638, h: 6.151 });
    slide.addImage({ data: LOGO_IMAGE, x: 0.528, y: 0.767, w: 2.536, h: 0.390 });
    slide.addText(report.title || "주간보고", {
      x: 0.703, y: 2.489, w: 7.511, h: 0.60,
      fontFace: FONT, fontSize: 29.5, bold: true, margin: 0, color: "000000", fit: "shrink",
    });
    slide.addText(`강조점: ${emphasisLabel}`, {
      x: 0.703, y: 3.04, w: 5.8, h: 0.22,
      fontFace: FONT, fontSize: 14, margin: 0, color: "404040", fit: "shrink",
    });
    slide.addText(personaLabel, {
      x: 7.739, y: 5.0, w: 1.479, h: 0.404,
      fontFace: FONT, fontSize: 18.5, bold: true, align: "center", margin: 0, color: "000000",
    });
    const headings = ["요약", ...(report.sections || []).map((section) => section.heading || "")];
    slide.addText(headings.map((heading, index) => `${index + 1}. ${heading}`).join("\n"), {
      x: 0.782, y: 3.285, w: 5.55, h: 1.52,
      fontFace: FONT, fontSize: 16.6, bold: true, breakLine: false,
      margin: 0, color: "000000", fit: "shrink", valign: "top",
    });
  }

  function addContentSlide(pptx, heading, bullets) {
    const slide = pptx.addSlide();
    const color = sectionColor(heading);
    slide.background = { color: "FFFFFF" };
    slide.addShape("rect", { x: 0, y: 0, w: 10, h: 1.05, fill: { color }, line: { color, transparency: 100 } });
    slide.addText(heading, {
      x: 0.30, y: 0.23, w: 9.2, h: 0.55,
      fontFace: FONT, fontSize: 22, bold: true, color: "FFFFFF", margin: 0, valign: "mid", fit: "shrink",
    });
    slide.addText((bullets || []).map((bullet) => `●  ${bullet}`).join("\n\n"), {
      x: 0.60, y: 1.50, w: 8.80, h: 5.55,
      fontFace: FONT, fontSize: 16, color: COLORS.TEXT, margin: 0,
      breakLine: false, valign: "top", fit: "shrink", paraSpaceAfterPt: 10,
    });
  }

  function createOfflineReportPresentation(report, personaLabel, emphasisLabel) {
    if (typeof global.PptxGenJS !== "function") throw new Error("오프라인 PPT 생성 모듈을 불러오지 못했습니다.");
    const pptx = new global.PptxGenJS();
    pptx.layout = "LAYOUT_4x3";
    pptx.author = "Manufacturing DX Weekly Portal Demo";
    pptx.subject = "보고서 Agent 오프라인 PPT";
    pptx.title = report.title || "주간보고";
    pptx.company = "LG Energy Solution";
    pptx.lang = "ko-KR";
    pptx.theme = {
      headFontFace: FONT,
      bodyFontFace: FONT,
      lang: "ko-KR",
    };

    addCoverSlide(pptx, report, personaLabel, emphasisLabel);
    const summary = String(report.summary || "").trim();
    if (summary) {
      paginateBullets([summary]).forEach((page, index) => addContentSlide(pptx, index ? "요약 (계속)" : "요약", page));
    }
    (report.sections || []).forEach((section) => {
      paginateBullets(section.bullets || []).forEach((page, index) => {
        addContentSlide(pptx, index ? `${section.heading} (계속)` : section.heading, page);
      });
    });
    if ((report.flagged_terms || []).length) {
      addContentSlide(pptx, "참고: 순화 처리된 표현", [report.flagged_terms.join(", ")]);
    }
    return pptx;
  }

  async function downloadOfflineReportPptx(report, personaLabel, emphasisLabel, fileName = "weekly_report.pptx") {
    const pptx = createOfflineReportPresentation(report, personaLabel, emphasisLabel);
    await pptx.writeFile({ fileName });
  }

  global.createOfflineReportPresentation = createOfflineReportPresentation;
  global.downloadOfflineReportPptx = downloadOfflineReportPptx;
})(window);
