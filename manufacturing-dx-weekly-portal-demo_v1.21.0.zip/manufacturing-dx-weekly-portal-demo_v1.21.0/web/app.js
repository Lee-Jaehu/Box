"use strict";

const $ = (selector, root = document) => root.querySelector(selector);

const state = {
  role: "MEMBER",
  data: null,
  screenIndex: 0,
  generatedDraft: null,
  pendingAction: null,
  lastAnswer: null,
  activeTaskCode: "WI-RSND-2026-031",
  reviewPageId: "leader-w35",
  reviewComments: [],
  reviewStatus: "검토 중",
  agent: {
    draft: null,
    pendingImport: null,
    conversationCount: 0,
    activePageId: null,
    attachment: null,
    messages: [],
    busy: false,
    demoStep: 0,
    demoPayload: null,
    sessionId: `portal-${Date.now()}-${Math.random().toString(16).slice(2)}`,
    engine: {
      mode: "DEMO",
      configured: true,
      provider: "portal_demo_agent",
      model: "시연 시나리오 v1.21.0",
      message: "외부 연결 없이 포털 샘플 데이터를 요약·반영합니다.",
    },
    launchUrl: "",
    lastOutboundPrompt: "",
  },
  activeAgentTab: "work",
  reportAgent: {
    persona: null,
    emphasis: null,
    length: "DEFAULT",
    weekRange: "CURRENT",
    selectedWorkItemIds: null,
    report: null,
    busy: false,
  },
};

const reportPersonaLabels = { CPO: "CPO", CDO: "CDO", HEAD: "그룹장", DEPT: "담당" };
const reportEmphasisLabels = { PERFORMANCE: "성과/실적", RISK: "리스크", DIRECTION: "방향성" };
const reportPersonaCards = {
  CPO: { detail_level: "low", avoid_terms: ["테스트 중입니다", "검토 예정입니다"] },
  CDO: { detail_level: "medium", avoid_terms: ["단순 자동화", "챗봇"] },
  HEAD: { detail_level: "medium-high", avoid_terms: [] },
  DEPT: { detail_level: "high", avoid_terms: ["요약하면"] },
};

const roleColors = {
  COMMON: "#53657d", MEMBER: "#2356a8", LEADER: "#7655a6", DEPT: "#8a5323",
  PLANNING: "#13706c", HEAD: "#9b3e55", DATA_OWNER: "#3c6f3d", ADMIN: "#4b5568",
};

const actionMap = {
  "DAT-04": "VALIDATE_SNAPSHOT", "DAT-06": "APPROVE_SNAPSHOT",
  "MBR-08": "SUBMIT_MEMBER", "LDR-05": "APPROVE_TEAM", "LDR-06": "APPROVE_TEAM", "LDR-07": "APPROVE_TEAM",
  "DPT-07": "APPROVE_DEPT", "PLN-02": "RESOLVE_QA", "PLN-06": "APPROVE_PLANNING",
  "HED-05": "RESOLVE_DECISION",
};

const confirmCopy = {
  VALIDATE_SNAPSHOT: ["PD Snapshot 재검증", "중복 Key를 보정한 것으로 가정하고 Rule Engine을 다시 실행합니다."],
  APPROVE_SNAPSHOT: ["Snapshot 승인·잠금", "검증을 통과한 PD Snapshot을 공식값으로 승인하고 변경 불가 상태로 잠급니다."],
  SUBMIT_MEMBER: ["팀원 보고 제출", "현재 Version과 Source Manifest를 고정하여 팀장에게 제출합니다."],
  APPROVE_TEAM: ["팀 보고 승인·제출", "서술형 보고 원문과 ID·근거 연결을 유지한 새 Version을 담당에게 제출합니다."],
  APPROVE_DEPT: ["담당 보고 승인·전송", "승인된 전체 보고파일과 코멘트 이력을 기획팀과 그룹장에게 함께 전송합니다."],
  RESOLVE_QA: ["QA Issue 시연 해소", "그룹 보고의 데모 QA Issue를 해소 상태로 전환합니다."],
  APPROVE_PLANNING: ["그룹장 보고 확정 요청", "BLOCK Issue가 없는지 확인한 뒤 그룹장 검토 상태로 전환합니다."],
  RESOLVE_DECISION: ["Decision 확정", "K12 검증 생산 일정을 우선 배정하고 후속 Action을 생성합니다."],
};

const navTargets = {
  "MBR-01": "MBR-04", "LDR-01": "LDR-02", "DPT-01": "DPT-02", "PLN-01": "PLN-02",
  "HED-01": "HED-02", "DAT-01": "DAT-02", "ADM-01": "ADM-06", "COM-03": "COM-04",
};

const agentSourceLabels = {
  CHAT: "대화 입력",
  WORK_HISTORY: "업무 이력",
  MAIL: "메일 발췌",
  FILE: "파일 내용",
};

const sourceBackedModel = {
  currentWeek: "W35",
  previousWeek: "W34",
  asOf: "2026-08-27",
  sourceNote: "KPI 목표 vF · 8월 월간 업무보고 · 자동보정담당 W31~W35",
  people: {
    member: "임가은",
    leader: "최도윤",
    departmentHead: "윤태성",
    groupHead: "한지훈",
    planning: "문서진",
    members: ["윤도현", "강민재", "오세진", "한유준", "서진우", "임가은", "조현우", "문서윤", "배지호", "유민석"],
  },
  departmentKpis: [
    { code: "AUTO-KPI-01", label: "매출", weight: 5, target: "30.05조원", actual: "8월 공식 실적 미제공", progress: null, status: "실적 대기", tone: "pending", basis: "official", source: "자동보정담당 KPI 목표 vF", detail: "경영 KPI는 월간 업무보고에 실적값이 없어 임의 산출하지 않습니다." },
    { code: "AUTO-KPI-02", label: "영업이익", weight: 5, target: "4,000억원", actual: "8월 공식 실적 미제공", progress: null, status: "실적 대기", tone: "pending", basis: "official", source: "자동보정담당 KPI 목표 vF", detail: "재무 확정 Snapshot 연결 후 달성률을 계산합니다." },
    { code: "AUTO-KPI-03", label: "제조운영 AX · BM/PD Loss", weight: 15, target: "'25년 대비 20% 개선", actual: "평균 28.4% 개선", progress: 142, status: "목표 초과", tone: "success", basis: "actual", source: "8월 자동보정담당 월간보고 p.2", detail: "R/P·NND, WA·OT·MI_HL NND 평균. 담당 월간보고에 기재된 범위 기준입니다." },
    { code: "AUTO-KPI-04", label: "북미 ESS 종합 수율", weight: 20, target: "94.3%", actual: "7월 누적 94.4%", progress: 100.1, status: "달성 수준", tone: "success", basis: "actual", source: "8월 자동보정담당 월간보고 p.2", detail: "ESMI·MI_LS·OT·HD 범위. 목표 대비 +0.1%p입니다." },
    { code: "AUTO-KPI-05", label: "유럽 ESS 종합 수율", weight: 5, target: "94.5%", actual: "7월 누적 92.2%", progress: 97.6, status: "보완 필요", tone: "danger", basis: "actual", source: "8월 자동보정담당 월간보고 p.2", detail: "ESWA 기준 목표 대비 -2.3%p입니다." },
    { code: "AUTO-KPI-06", label: "자동차 셀 수율", weight: 10, target: "97.8%", actual: "7월 누적 97.7%", progress: 99.9, status: "주의 관찰", tone: "warn", basis: "actual", source: "8월 자동보정담당 월간보고 p.2", detail: "ESWA·NA·NB·HM·MI·HG 범위, 목표 대비 -0.1%p입니다." },
    { code: "AUTO-KPI-07", label: "NFF 전극 수율·수동보정", weight: 5, target: "98.8% · 수동보정 60%↓", actual: "수율 98.8% · 수동보정 집계 대기", progress: 100, status: "부분 달성", tone: "warn", basis: "partial", source: "8월 자동보정담당 월간보고 p.2", detail: "전극 수율은 목표 수준이나 수동보정 감소율 공식 실적은 제공되지 않았습니다." },
    { code: "AUTO-KPI-08", label: "NFF 셀 수율", weight: 5, target: "97.7%", actual: "누적 97.4%", progress: 99.7, status: "보완 필요", tone: "danger", basis: "actual", source: "8월 자동보정담당 월간보고 p.2", detail: "목표 대비 -0.3%p입니다." },
    { code: "AUTO-KPI-09", label: "ESS 코터 자동보정 고도화", weight: 10, target: "재가동 불량 20%↓ · 5개 법인", actual: "Loss 7.73%↓ · 5개 법인 11대(45.5%)", progress: 38.7, status: "진행 중", tone: "warn", basis: "actual", source: "8월 자동보정담당 월간보고 p.3", detail: "막대는 재조건조정 Loss 개선률 7.73%/목표 20% 기준이며, 전개 범위는 별도 병기합니다." },
    { code: "AUTO-KPI-10", label: "재료비 저감", weight: 10, target: "15억원", actual: "확정 9.5억원", progress: 63.3, status: "진행 중", tone: "warn", basis: "actual", source: "8월 자동보정담당 월간보고 p.2", detail: "4Q 예상 27.4억원은 전망치이므로 달성률 계산에서 제외했습니다." },
    { code: "AUTO-KPI-11", label: "차세대 다이 자동보정", weight: 5, target: "초크바 Cpk≥2.5 · 분할다이 Cpk≥1.8", actual: "초크바 3.02 · 분할다이 4지표 ≥2.0", progress: 100, status: "목표 달성", tone: "success", basis: "actual", source: "8월 자동보정담당 월간보고 p.3", detail: "목표 문턱을 모두 충족한 것으로 보고되었으며 막대는 100%로 제한합니다." },
    { code: "AUTO-KPI-12", label: "AI Agent 업무 효율화", weight: 5, target: "이상분석 시간 60%↓", actual: "WA Lami·COT 개발 및 E2E 배포 완료", progress: 75, status: "실행 진척", tone: "proxy", basis: "proxy", source: "8월 자동보정담당 월간보고 p.3", detail: "분석시간 실측치가 없어 개발·UAT 마일스톤 진척만 표시합니다." },
  ],
  groupKpis: [
    { code: "GROUP-KPI-01", label: "매출", weight: 5, target: "30.05조원", actual: "공식 실적 대기", progress: null, status: "실적 대기", tone: "pending", basis: "official", source: "제조DX그룹장 KPI 목표 vF", detail: "재무 Snapshot 미제공" },
    { code: "GROUP-KPI-02", label: "영업이익", weight: 5, target: "4,000억원", actual: "공식 실적 대기", progress: null, status: "실적 대기", tone: "pending", basis: "official", source: "제조DX그룹장 KPI 목표 vF", detail: "재무 Snapshot 미제공" },
    { code: "GROUP-KPI-03", label: "제조운영 AX · BM/PD Loss", weight: 15, target: "'25년 대비 20% 개선", actual: "자동보정 28.4% · FDC 20.0%", progress: 100, status: "그룹 확정 대기", tone: "warn", basis: "reconcile", source: "8월 자동보정·FDC 월간보고", detail: "담당별 범위가 달라 단순 평균하지 않고 그룹 통합 Snapshot 확정을 기다립니다." },
    { code: "GROUP-KPI-04", label: "북미 ESS 종합 수율", weight: 20, target: "94.3%", actual: "7월 누적 94.4%", progress: 100.1, status: "달성 수준", tone: "success", basis: "actual", source: "8월 자동보정·솔루션·FDC 월간보고", detail: "세 보고서의 동일 범위 수치가 일치합니다." },
    { code: "GROUP-KPI-05", label: "유럽 ESS 종합 수율", weight: 5, target: "94.5%", actual: "7월 누적 92.2%", progress: 97.6, status: "보완 필요", tone: "danger", basis: "actual", source: "8월 자동보정·솔루션·FDC 월간보고", detail: "목표 대비 -2.3%p" },
    { code: "GROUP-KPI-06", label: "자동차 셀 수율", weight: 10, target: "97.8%", actual: "7월 누적 97.7%", progress: 99.9, status: "주의 관찰", tone: "warn", basis: "actual", source: "8월 자동보정·솔루션·FDC 월간보고", detail: "목표 대비 -0.1%p" },
    { code: "GROUP-KPI-07", label: "NFF 전극 수율·수동보정", weight: 5, target: "98.8% · 수동보정 60%↓", actual: "수율 98.8% · 수동보정 집계 대기", progress: 100, status: "부분 달성", tone: "warn", basis: "partial", source: "8월 자동보정 월간보고", detail: "수율은 목표 수준, 수동보정 감소율은 공식 집계 대기" },
    { code: "GROUP-KPI-08", label: "NFF 셀 수율", weight: 5, target: "97.7%", actual: "97.4%~97.66%", progress: 99.7, status: "범위 대조 필요", tone: "danger", basis: "reconcile", source: "8월 자동보정·FDC 월간보고", detail: "보고서별 집계 범위 차이로 97.4%와 97.66%가 함께 보고되어 통합 전 대조가 필요합니다." },
    { code: "GROUP-KPI-09", label: "ESS Safety Fast Track", weight: 10, target: "과검 15%↓ · 8억원 · L/T 17일↓", actual: "고객 AI Report·국내 확산 인프라 완료", progress: 68, status: "실행 진척", tone: "proxy", basis: "proxy", source: "8월 품질DX 월간보고 p.2", detail: "정량 실적이 없어 운영 데이터 수집·서비스 마일스톤으로 표시합니다." },
    { code: "GROUP-KPI-10", label: "재료비 저감", weight: 5, target: "15억원", actual: "확정 9.5억원", progress: 63.3, status: "진행 중", tone: "warn", basis: "actual", source: "8월 자동보정 월간보고 p.2", detail: "전망치 27.4억원은 제외" },
    { code: "GROUP-KPI-11", label: "수율 진단 솔루션", weight: 5, target: "ESHD Lami 위치불량 30%↓", actual: "조치 추천 Report 개발·8/4 설명회", progress: 72, status: "실행 진척", tone: "proxy", basis: "proxy", source: "8월 제조DX솔루션 월간보고 p.3", detail: "불량 개선 공식 실적 대신 개발·운영 마일스톤을 표시합니다." },
    { code: "GROUP-KPI-12", label: "업무 자동화", weight: 10, target: "79.2hr/일 · 9.9명", actual: "4개 자동화 과제 개발·검증 중", progress: 65, status: "실행 진척", tone: "proxy", basis: "proxy", source: "8월 품질DX 월간보고 p.2", detail: "절감시간 실측치가 없어 완료·검증 마일스톤만 표시합니다." },
  ],
  departmentCards: [
    { name: "자동보정담당", owner: "윤태성", status: "9/12 실적 연결", tone: "success", score: 85, headline: "BM/PD 28.4% 개선 · 북미 ESS 94.4%", watch: "유럽 ESS -2.3%p · NFF 셀 -0.3%p", source: "8월 자동보정담당 월간보고" },
    { name: "품질DX담당", owner: "서지훈", status: "월간보고 연계", tone: "warn", score: 72, headline: "DAP 96/96대 개통 · 생산 Loss 5.2억원", watch: "ESS Safety 정량 실적·업무절감 실측 대기", source: "8월 품질DX 월간보고" },
    { name: "제조DX솔루션담당", owner: "강도현", status: "핵심 6건 연계", tone: "warn", score: 78, headline: "북미 ESS 94.4% · L&S 개선 솔루션 확산", watch: "유럽 ESS 92.2% · 자동차 97.7%", source: "8월 제조DX솔루션 월간보고" },
    { name: "FDC DX담당", owner: "오민재", status: "핵심 7건 연계", tone: "warn", score: 76, headline: "BM/PD 20.0% · 분석 생산성 77% 개선", watch: "NFF 셀 7월 97.27% · 유럽 ESS -2.3%p", source: "8월 FDC DX 월간보고" },
  ],
  tasks: [
    {
      code: "WI-RSND-2026-031", title: "Roll Press 단선 자동조치 모드", objective: "단선 발생 시 대응을 표준화하고 두께 조건을 자동 조정해 PD Loss를 줄입니다.", owner: "임가은", kpi: "AUTO-KPI-03", progress: 85, status: "IN_PROGRESS", start: "2026-06-25", target: "2026-08-31", completed: null,
      plan: "OT·MI_HL 전개, WA 대표호기 검증, 4조 작업자 교육", actual: "OT·MI_HL 전개 완료 · WA4 CIS 7/17, PNT 7/24 · 교육 진행 중",
      weeks: [{ week: "W31", value: 65, text: "WA 수동 공유·작업자 교육 계획" }, { week: "W32", value: 72, text: "4조 교육 착수" }, { week: "W33", value: 77, text: "현장 교육·피드백 반영" }, { week: "W34", value: 82, text: "PNT·Single 운전 확인" }, { week: "W35", value: 85, text: "교육 진행, 8/31 완료 예정" }],
      resources: [{ id: "W35-S131", title: "W35 주간보고 p.131", description: "Tension 편차 자동보정 전개와 HD PLC 수정, 법인별 PD Loss 전후 비교" }, { id: "W31~W35-RP", title: "5주 업무이력", description: "대표호기 검증·수평전개·작업자 교육 이력을 주차별 연결" }, { id: "AUTO-KPI-03", title: "담당 KPI · BM/PD", description: "'25년 대비 BM/PD Loss 20% 개선 목표와 연결" }],
    },
    {
      code: "WI-RSND-2026-032", title: "NFF Roll Press 조건조정 Loss 개선", objective: "재가동 조건조정 로스를 줄이고 두께 안정화 시간을 단축합니다.", owner: "임가은", kpi: "AUTO-KPI-07", progress: 100, status: "COMPLETED", start: "2026-07-01", target: "2026-08-06", completed: "2026-08-06",
      plan: "OC9 음극 3호 대표 검증 후 동일 증상 호기 적용", actual: "조건조정 Loss율 1.1%→0.03% · 재조건조정 Loss 64.0m→24.1m(62.5%↓)",
      weeks: [{ week: "W31", value: 82, text: "대표 검증 7/23 완료" }, { week: "W32", value: 100, text: "성과 확인·완료 8/6" }, { week: "W33", value: 100, text: "특이사항 없음·유지" }, { week: "W34", value: 100, text: "모니터링" }, { week: "W35", value: 100, text: "성과 유지" }],
      resources: [{ id: "W35-S144", title: "W35 주간보고 p.144", description: "OC9 음극 3호 조건조정 로스율 1.1%→0.03% 및 로직 설명" }, { id: "W32-S134", title: "W32 주간보고 p.134", description: "재조건조정 Loss 64.0m→24.1m, 62.5% 개선 결과" }, { id: "AUTO-KPI-07", title: "담당 KPI · NFF 전극", description: "전극 수율과 수동보정 최소화 목표에 기여" }],
    },
    {
      code: "WI-RSND-2026-033", title: "다빈치 WF 활용률 관리", objective: "법인·공정별 자동보정 활용률과 자동·수동보정 횟수를 일관되게 관리합니다.", owner: "임가은", kpi: "AUTO-KPI-12", progress: 90, status: "IN_PROGRESS", start: "2026-06-30", target: "2026-09-04", completed: null,
      plan: "전 법인 WF 구축 후 이상동작 매뉴얼과 운영 기준 확정", actual: "APC Lot ID 수집 추가 8/10 · NJ Taping 활용률 이상동작 매뉴얼 신규 작성 중",
      weeks: [{ week: "W31", value: 72, text: "ESOC Slitter WF 적용" }, { week: "W32", value: 78, text: "ESNJ Taping WF 작성" }, { week: "W33", value: 86, text: "Lot ID 기반 간소화 8/10" }, { week: "W34", value: 88, text: "특이사항 없음" }, { week: "W35", value: 90, text: "NJ 매뉴얼 보완" }],
      resources: [{ id: "W35-S152", title: "W35 주간보고 p.152", description: "전 법인 WF 완료 현황, Lot ID 기반 매칭 간소화, NJ 매뉴얼 보완" }, { id: "DAVINCI-WF", title: "다빈치 활용률 WF", description: "활용률·자동보정·수동보정 횟수 대시보드" }, { id: "AUTO-KPI-12", title: "담당 KPI · 업무 효율화", description: "AI Agent 및 반복 분석업무 효율화 목표와 연결" }],
    },
    {
      code: "WI-RSND-2026-034", title: "패키지 주액량 자동보정 수평전개", objective: "패키지 주액량 자동보정 PLC 로직을 Global 법인에 표준 전개합니다.", owner: "임가은", kpi: "AUTO-KPI-06", progress: 88, status: "IN_PROGRESS", start: "2026-07-10", target: "2026-10-31", completed: null,
      plan: "ESWA·ESMI·ESHD·ESOT·ESMI_LS·ESHG 및 GM1·2 전개", actual: "6개 법인·GM2 완료 · GM1 VM/HMI 설계 공유, 생산 검증 대기",
      weeks: [{ week: "W31", value: 70, text: "Global 전개 현황 점검" }, { week: "W32", value: 76, text: "GM2 적용 확인" }, { week: "W33", value: 80, text: "GM1 사양 조율" }, { week: "W34", value: 85, text: "VM/HMI 설계 검토" }, { week: "W35", value: 88, text: "GM1 생산 검증 대기" }],
      resources: [{ id: "W35-S154", title: "W35 주간보고 p.154~155", description: "법인별 적용 현황과 GM1 생산 검증 잔여사항" }, { id: "PLC-SPEC-GM1", title: "GM1 VM/HMI 설계", description: "PLC Address·화면 설계·생산 검증 체크리스트" }, { id: "AUTO-KPI-06", title: "담당 KPI · 자동차 셀", description: "셀 공정 자동보정 Coverage 확대와 수율 목표 연결" }],
    },
    {
      code: "WI-RSND-2026-035", title: "DNS Dryer 자동보정 신규개발", objective: "온도 오버슈트를 줄이고 목표 온도 도달시간과 드라이 불량을 개선합니다.", owner: "임가은", kpi: "AUTO-KPI-09", progress: 62, status: "IN_PROGRESS", start: "2026-07-21", target: "2026-12-18", completed: null,
      plan: "±10℃·10초·불량 0% 목표, 대표라인 반복 검증 후 수평전개", actual: "초기 출력 패턴 분석 완료 · 목표온도 50% 시점부터 PID 제어하는 컨셉 협의 중",
      weeks: [{ week: "W31", value: 18, text: "과제 착수 전" }, { week: "W32", value: 32, text: "Base Data·I/F 확인" }, { week: "W33", value: 45, text: "제어 파라미터 초안" }, { week: "W34", value: 55, text: "반복 Test·데이터 정리" }, { week: "W35", value: 62, text: "오버슈트 원인·PID 컨셉 도출" }],
      resources: [{ id: "W35-S156", title: "W35 주간보고 p.156~157", description: "Preheat·초기출력과 오버슈트 원인 분석, PID 제어 컨셉" }, { id: "DNS-TEST", title: "DNS Dryer 반복 Test", description: "목표온도·도달시간·불량률 및 제어 파라미터 기록" }, { id: "AUTO-KPI-09", title: "담당 KPI · 코터 고도화", description: "재가동 불량 개선과 자동보정 고도화 목표에 연결" }],
    },
  ],
  reportPages: [
    { id: "leader-w35", type: "TEAM_LEADER", title: "RSND자동보정팀 W35 금주 보고", owner: "최도윤 팀장", subtitle: "팀장 작성본 · 이슈–해결과정–결과–후속계획", kpiImpact: true,
      summary: "금주는 Tension 편차 자동보정의 전사 성과를 유지하면서 현장 적용을 막는 설비 이슈를 분리했고, NFF·신규법인·DNC는 정량 효과를 확인했습니다. AX NND와 DNS Dryer는 운영 과정에서 확인된 취약점의 원인을 구체화해 보완 로직과 검증 일정을 확정했습니다.",
      highlights: [
        { label: "핵심 성과", value: "PD Loss 평균 36.71%↓", detail: "WA·OT·MI_HL 적용 범위" },
        { label: "해결 완료", value: "NFF 재조건 Loss 62.5%↓", detail: "64.0m → 24.1m" },
        { label: "집중 이슈", value: "WA 자동차 NND 악화", detail: "10.72% → 14.30%" },
        { label: "현장 전환", value: "25대 적용 · 12대 양산", detail: "잔여 13대 설비·생산조건 조치" },
      ],
      blocks: [
        { tag: "KPI", headline: "Tension 편차 자동보정은 평균 개선효과를 확인했으나 WA 자동차 NND 악화와 양산 적용률이 잔여 이슈입니다.",
          text: "WA·OT·MI_HL의 Tension 자동보정 적용 범위에서 평균 PD Loss가 적용 전 대비 36.71% 감소했습니다. 다만 전체 공정이 동일하게 개선된 것은 아니므로 법인·모델·공정별 편차를 분리해 관리하고 있습니다.",
          story: [
            { label: "이슈", value: "WA 자동차 NND는 PD Loss가 10.72%에서 14.30%로 33.40% 악화됐고, WA 25대 중 실제 양산 사용은 12대에 머물렀습니다." },
            { label: "확인·조치", value: "미사용 설비를 Tension Hunting, 센서 위치·Cable, Dancer Roll·Actuator, 생산 대기로 구분하고 HD PLC 수정과 FDC 수집 로직 보완을 병행했습니다." },
            { label: "결과", value: "WA 자동차 R/P 32.85%, WA ESS R/P 30.56%, OT ESS NND 89.51%, MI_HL ESS NND 81.71% 개선을 확인했습니다." },
            { label: "후속", value: "설비 조치가 필요한 13대는 원인별 담당과 생산 일정을 연결하고, 개선효과는 담당 공식 KPI 28.4%와 범위를 구분해 관리합니다." },
          ], impact: "AUTO-KPI-03", tooltip: "W35 p.131·133~138. 36.71%는 W35 법인·공정 비교 범위이며 담당 월간 KPI 28.4%와 집계 범위가 다릅니다." },
        { tag: "RESULT", headline: "단선 후 작업자 숙련도에 의존하던 조치를 2단계 자동화해 재단선과 조치시간 편차를 줄이는 방향으로 전환했습니다.",
          text: "단선 발생 후 PET·전극 연결, R/W 이동과 두께 안정화가 작업자별로 달라 재단선과 복구시간 편차가 발생했습니다. 이를 자동 이송과 두께 조건조정으로 분리해 표준 조치 모드로 구현했습니다.",
          story: [
            { label: "이슈", value: "수동 Gap 조정과 R/W 이동이 작업자 숙련도에 좌우돼 조치시간이 일정하지 않고 재단선 가능성이 남았습니다." },
            { label: "해결과정", value: "Step 1은 R/W까지 자동 이송, Step 2는 단선부 제거 후 두께 조건조정을 자동 수행하도록 구성하고 Main Roll 전·후단 단선 Case와 추가 Gap 보정을 검증했습니다." },
            { label: "결과", value: "OT·MI_HL 전개와 WA CIS·PNT 수평전개를 완료했으며 WA PNT·Single 대표호기 기능검증까지 마쳤습니다." },
            { label: "후속", value: "4개 Shift 작업자 교육을 8월 31일까지 완료하고 실제 생산에서 조치시간·재단선 발생을 확인합니다." },
          ], impact: "AUTO-KPI-03", tooltip: "W35 p.136~137. 단선 자동조치 Step 1·2 설계와 WA 대표호기·교육 이력." },
        { tag: "RESULT", headline: "NFF는 장기 부동과 재료 연결 시 발생하던 열변형 Loss를 역압·Roll Gap 보정으로 해소했습니다.",
          text: "주말 장기 부동 후 Main Roll 열변형과 재료 연결 정지로 재가동 조건조정 Loss가 반복됐습니다. 역압을 보조인자로 사용하고 Roll Gap·저속 안정화 조건을 함께 적용했습니다.",
          story: [
            { label: "이슈", value: "부동 후 재조건조정에 약 130m/회 Loss가 발생했고, 장기 부동 후 평균 조건조정 Loss는 57.9m였습니다." },
            { label: "해결과정", value: "부동 시간과 두께상태에 따라 역압·Roll Gap을 자동 조정하고, H19 장척 2word 생산과 재료 연결 후 저속 주행 조건까지 로직을 보완했습니다." },
            { label: "결과", value: "조건조정 Loss율 1.1%→0.03%, 재조건조정 Loss 64.0m→24.1m(62.5%↓), 재료 연결 구간 두께불량 10.3m/Lot→0m/Lot를 확인했습니다." },
            { label: "후속", value: "모델·호기별 장기 모니터링으로 역압 보정 효과의 지속성과 예외조건을 확인합니다." },
          ], impact: "AUTO-KPI-07", tooltip: "W35 p.144~146. 조건조정·장기 부동·재료 연결 구간의 문제와 개선 결과." },
        { tag: "ANALYSIS", headline: "AX NND는 서버 과부하와 초기해 불안정 문제를 해소했지만 OT 시뮬레이션에서 확인된 취약점 때문에 선별 적용이 필요합니다.",
          text: "실시간 최적화 운영 중 CPU·Memory 점유, Cold Start, 불필요한 반복학습과 제약 위반 Risk가 확인됐습니다. 운영 안정성을 먼저 확보한 뒤 법인별 대표호기로 적용 범위를 좁혔습니다.",
          story: [
            { label: "이슈", value: "최적화 Thread의 자원 과점유, 초기해 부재, 반복 탐색 비효율과 OT 예상효과 시뮬레이션 취약점이 확인됐습니다." },
            { label: "해결과정", value: "CPU·Memory 총 점유율을 50% 미만으로 제한하고 이전 최적값·기본 Parameter를 초기해로 사용했습니다. Early Stop, 탐색횟수 조정, Big M 패널티와 운영 로그도 추가했습니다." },
            { label: "현재판단", value: "전체 수평전개보다 효과가 확인되는 대표호기부터 적용하며, HD는 예측보정과 Feedback 동시 적용을 위한 PLC 수정이 선행돼야 합니다." },
            { label: "후속", value: "OT 버전업·기능·성능점검은 9월 18일까지, Hyper Parameter Benchmark는 9월 30일까지 완료합니다." },
          ], impact: "AUTO-KPI-12", tooltip: "W35 p.139~143. 자원 제한·Cold Start·Early Stop·Big M·OT 취약점과 재계획." },
        { tag: "KPI", headline: "북미 신규법인은 APC 초기 안정화와 설비별 로직 전환을 통해 Cpk·수동보정·두께 산포를 동시에 개선했습니다.",
          text: "신규법인은 PLC·설비 Maker와 공정구성이 달라 공통 로직을 그대로 적용하기 어려웠습니다. 로그 경량화, 역압 BIAS, PNT 설비용 프로그램 전환과 Gap 비례제어를 순차 적용했습니다.",
          story: [
            { label: "이슈", value: "ESAZ는 Roll Press·Slitter의 수동보정 의존도가 높았고, NJ는 VD 후 팬케이크 외곽–코어 두께 감소와 설비 Maker 차이가 있었습니다." },
            { label: "해결과정", value: "운영 로그 Level을 경량화하고 OT 역압 BIAS를 적용했습니다. NJ는 CIS 로직을 PNT용으로 전환해 Gap 비례제어와 역압 개별제어를 구성했습니다." },
            { label: "결과", value: "ESAZ R/P Cpk는 양극 1.10→1.71, 음극 1.35→1.80, 수동보정 60회→0회로 개선됐습니다. NJ 두께 Max–Min은 2.21㎛→1.76㎛(20.4%↓), 외경 산포는 0.200→0.175mm(12.5%↓)로 개선됐습니다." },
            { label: "유의·후속", value: "연간 3.31억원은 3개월 F-Cost 기반 기대효과로 확정 절감액과 구분하며, OC3·NA 등 VD 적용 법인으로 기능검증을 확대합니다." },
          ], impact: "AUTO-KPI-04 · AUTO-KPI-07 · AUTO-KPI-10", tooltip: "W35 p.147~150. 신규법인 APC와 NJ 다단압연 성과, 연간효과는 전망치." },
        { tag: "RISK", headline: "DaVinci WF와 패키지 주액량 자동보정은 운영 데이터 정합성과 법인별 PLC 차이를 보완하며 확산 중입니다.",
          text: "자동보정 기능이 적용돼도 Lot 매칭과 활용률 집계가 복잡하고, 일부 법인은 서버 용량·PLC 유형 차이로 운영 연계가 지연됐습니다.",
          story: [
            { label: "이슈", value: "NJ Taping 활용률 이상동작, ESMI FDC 서버 용량 부족, GM2 재가동 시 보정값 덮어쓰기 문제가 확인됐습니다." },
            { label: "해결과정", value: "APC에 Lot ID 수집을 추가해 생산이력 매칭을 단순화하고, 2초 연속변화·Enable·EPC 0.01mm 기준으로 보정횟수 산출 규칙을 정리했습니다. GM2는 PLC 수정으로 덮어쓰기 문제를 해결했습니다." },
            { label: "결과", value: "R/P·Slitter 법인별 WF와 MI·WA·OT·MI_LS·HD·HG NND/DNC WF를 연결했고, 6개 법인과 GM2 패키지 주액량 자동보정 적용을 완료했습니다." },
            { label: "후속", value: "NJ Taping 매뉴얼 신규 버전을 검증하고, GM1 20대는 기준정보·VM용 PLC/HMI 설계 후 양산 일정에 맞춰 기능을 검증합니다." },
          ], impact: "AUTO-KPI-06 · AUTO-KPI-12", tooltip: "W35 p.152~155. WF 운영규칙·서버 Risk·GM2 PLC 조치·GM1 잔여 계획." },
        { tag: "ANALYSIS", headline: "DNS Dryer는 재가동 출력 패턴이 온도 오버슈트를 만드는 경로를 확인해 PID 제어 시작점을 재설계했습니다.",
          text: "재가동 시 온도 Hunting ±20℃와 목표 도달 15초 때문에 두께·Crack·수분 NG Risk가 있었습니다. 9개 Cycle의 출력·온도 응답을 비교해 오버슈트 발생 구간을 좁혔습니다.",
          story: [
            { label: "원인분석", value: "Preheat 약 15% 후 초기 26% 출력을 주고 더 높은 등속 고정출력으로 전환하는 과정에서 온도가 과상승한 뒤 출력 감소와 함께 안정화되는 패턴을 확인했습니다." },
            { label: "해결과정", value: "이전 가동·부동시간과 램프·전극 온도 IN/MID/OUT를 추가 수집하고, 목표온도 50% 도달 시점부터 PID 제어를 시작하는 Concept을 공정기술팀과 협의했습니다." },
            { label: "목표", value: "Hunting ±10℃, 목표 도달 10초, 가속 불량률 0%를 기준으로 OC3 음극 10호와 OC9 음극 1~4호 반복 Test를 진행합니다." },
            { label: "유의", value: "2027 물동량 기준 약 35.3억원은 불량률 0.4%를 가정한 기대효과이며 실제 절감액으로 보고하지 않습니다." },
          ], impact: "AUTO-KPI-09 · AUTO-KPI-10", tooltip: "W35 p.156~157. 9개 Cycle 분석 기반 제어 Concept이며 성능은 반복 Test 전입니다." },
        { tag: "RESULT", headline: "DNC는 등속 즉시보정과 가속 FeedForward를 구분 적용해 불량률과 Spec-in 시간을 함께 개선했습니다.",
          text: "법인별 설비 구조와 X·Y축 제어 대상이 달라 동일 로직 적용이 어려웠습니다. 등속·가속 구간과 EPC·Mold Y 제어를 분리해 법인별 보정방식을 구성했습니다.",
          story: [
            { label: "이슈", value: "등속구간은 규격 이탈 후 보정이 늦고, 가속구간은 선속 변화에 따른 TS 불량이 발생했습니다. ESOC와 ESMI_LS는 설비 구조와 PLC 조건도 달랐습니다." },
            { label: "해결과정", value: "등속구간은 규격 이탈 시 즉시 Feedback 보정하고, 가속구간은 FeedForward를 적용했습니다. ESOC는 Y축을 LPC에서 Mold Y 위치 제어로 변경했습니다." },
            { label: "결과", value: "등속 TS 불량률 0.216%→0.133%, 가속 TS 불량률 1.86%→1.29%, Spec-in까지 필요한 Tab 수는 23% 단축했습니다." },
            { label: "후속", value: "ESOC PLC 수정은 8월 31일까지, ESMI_LS 7·8호기 FAT Test는 9월 14일까지 완료해 수평전개 기준에 반영합니다." },
          ], impact: "AUTO-KPI-06", tooltip: "W35 p.159~160. 등속·가속구간 보정방식과 정량 결과." },
        { tag: "PLAN", headline: "차주는 현장 미적용 설비 조치와 취약 알고리즘 검증을 우선하고, 전망치는 실제 KPI와 분리해 관리합니다.",
          text: "8월 31일까지 WA 4개 Shift 교육과 ESOC DNC PLC 수정을 마치고, 9월 4일까지 HD·HG 기능검증을 진행합니다. OT AX NND는 9월 18일까지 선별 적용 성능을 확인하고 9월 30일까지 최적화 Benchmark를 완료합니다. GM1·2 VM은 제작사양과 PLC Address를 기준으로 법인별 데이터 수집·모델링 일정에 연결합니다.",
          story: [
            { label: "관리 원칙", value: "공식 KPI, 주간 기여성과, 예상 재료비·절감효과를 서로 분리하고 범위·기준일·검증상태를 함께 표기합니다." },
            { label: "팀장 점검", value: "미적용 13대의 설비조치 Owner와 생산일정, OT 취약점 개선결과, DNS 반복 Test 결과를 다음 보고에서 우선 확인합니다." },
          ], impact: "AUTO-KPI-03 · AUTO-KPI-12", tooltip: "W35 전체 31페이지의 미완료 일정과 검증 필요사항을 팀장 관점에서 통합." },
      ] },
  ],
};

function rsndReportBlock(slide, tag, text, impact = "", detail = "") {
  return { tag, text, impact, tooltip: `W35 주간보고 p.${slide}${detail ? ` · ${detail}` : ""}` };
}

function rsndReportPage(slide, title, owner, summary, blocks, kpiImpact = true) {
  return {
    id: `rsnd-w35-${slide}`,
    type: "MEMBER",
    title,
    owner: `${owner} 책임`,
    subtitle: `RSND자동보정팀 원문 p.${slide} · 전체 보고파일`,
    kpiImpact,
    summary,
    blocks,
  };
}

const rsndW35FullReportPages = [
  rsndReportPage(131, "전사 PD Loss 개선 Summary", "한유준", "Tension 편차 자동보정의 법인별 PD Loss·생산가동률 효과와 확산 계획을 종합한 팀 Summary입니다.", [
    rsndReportBlock(131, "KPI", "WA·OT·MI_HL 3개 법인의 Tension 편차 자동보정 적용 범위에서 평균 PD Loss 36.71% 감소를 확인했습니다.", "AUTO-KPI-03", "담당 월간 KPI 28.4%와 집계 범위가 달라 대체하지 않습니다."),
    rsndReportBlock(131, "ANALYSIS", "세부 개선율은 WA 자동차 R/P 32.85%, WA ESS R/P 30.56%, OT ESS NND 89.51%, MI_HL ESS NND 81.71%이며 WA 자동차 NND는 -33.40%로 추가 원인 확인이 필요합니다.", "AUTO-KPI-03"),
    rsndReportBlock(131, "PLAN", "HD Tension 자동보정 PLC 수정과 MI_LS·EP2·AZ·HG 수평전개를 이어가고, 적용 후 생산가동률도 법인·공정별로 함께 모니터링합니다.", "AUTO-KPI-03"),
  ]),
  rsndReportPage(132, "Tension 편차 자동보정 배경·목표", "윤도현", "Roll Press OS·DS Tension 차이와 단선 위험을 연결해 수동 Gap 조치를 자동화하는 과제 정의 페이지입니다.", [
    rsndReportBlock(132, "BACKGROUND", "전극 FDC 분석에서 Roll Press OS·DS Tension 차이가 커질수록 단선 확률이 급격히 증가하는 패턴을 확인했습니다."),
    rsndReportBlock(132, "ANALYSIS", "현재는 OS·DS 차이가 20N에 도달하면 알람을 발생시키고 작업자가 수동으로 Gap을 낮추고 있습니다."),
    rsndReportBlock(132, "PLAN", "PD Loss 20% 개선 기여를 목표로 HD PLC 수정과 법인별 Tension 자동보정 확산을 진행합니다.", "AUTO-KPI-03"),
  ]),
  rsndReportPage(133, "MI_LS·HD·NFF Tension 자동보정", "서진우", "MI_LS·HD·NFF 법인의 자동조치·FDC 데이터 수집·성능 검증 현황입니다.", [
    rsndReportBlock(133, "RESULT", "MI_LS 적용 범위의 PD Loss는 6.07%에서 4.84%로 20.26% 개선됐고 Tension 편차 표준편차도 호기별 43~73% 감소했습니다.", "AUTO-KPI-03"),
    rsndReportBlock(133, "RESULT", "MI_HL·MI_LS·HD·OT의 Tension 자동보정 데이터를 FDC로 수집할 수 있도록 APC 알고리즘 수정을 완료했습니다."),
    rsndReportBlock(133, "PLAN", "HD 양극 Tandem 설비가 롤 1개만 사용하는 조건의 자동조치 동작을 9월 4일까지 확인하고, ESOC_NFF FDC 수집 수정은 8월 28일까지 완료합니다.", "AUTO-KPI-03"),
  ]),
  rsndReportPage(134, "HG·AZ Tension 자동보정 전개", "서진우", "HG·AZ의 APC 알고리즘·기준정보·데이터 스무딩을 준비하고 기능 검증으로 연결하는 페이지입니다.", [
    rsndReportBlock(134, "RESULT", "AZ는 Tension 자동보정 APC 알고리즘 수정·검증·적용을 완료했고, HG도 기준정보 CSR과 알고리즘 적용 및 상관계수 도출을 8월 25일 완료했습니다.", "AUTO-KPI-03"),
    rsndReportBlock(134, "PLAN", "HG 기준정보 반영 후 9월 4일까지 기능을 검증하고, HG·AZ의 FDC 데이터 수집 알고리즘 수정은 8월 28일까지 진행합니다.", "AUTO-KPI-03"),
  ]),
  rsndReportPage(135, "코터 로딩량 연계 Feedforward", "오세진", "코터 로딩량을 Roll Press Tension 예측과 선제 보정에 연결하는 데이터·모델·MES 연계 과제입니다.", [
    rsndReportBlock(135, "RESULT", "코터 Roll Map PLC와 Roll Press PLC에서 APC로 데이터 수집을 완료하고, Lot 정합·좌우 반전·예외처리를 포함한 전처리 프로그램과 MES 선별투입 송신 프로그램을 개발했습니다.", "AUTO-KPI-03"),
    rsndReportBlock(135, "ANALYSIS", "로딩량·두께·Moving EPC·Gap을 이용해 Tension을 예측하는 모델을 제조빅데이터분석2팀과 개발하고 있습니다."),
    rsndReportBlock(135, "PLAN", "8월 28일까지 예측값 기반 Feedforward 자동보정 로직과 설비별 기준정보를 확정하고, WA Total Dry 로딩데이터 수집 절차를 완료합니다.", "AUTO-KPI-03"),
  ]),
  rsndReportPage(136, "단선 자동조치 프로세스 설계", "윤도현·임가은", "작업자 숙련도에 따른 조치 편차와 재단선을 줄이기 위한 Step 1·2 자동화 설계입니다.", [
    rsndReportBlock(136, "BACKGROUND", "단선 후 PET·전극 연결과 R/W 이동, 두께 안정화 과정이 작업자 숙련도에 의존해 조치시간 편차와 재단선이 발생했습니다."),
    rsndReportBlock(136, "PLAN", "Step 1은 R/W까지 자동 이송하고 Step 2는 단선부 제거 후 두께 조건조정을 자동화해 표준 조치 프로세스로 통합합니다.", "AUTO-KPI-03"),
    rsndReportBlock(136, "RESULT", "OT·MI_HL 수평전개는 완료했고 WA는 대표호기 검증과 작업자 교육 단계로 진행했습니다.", "AUTO-KPI-03"),
  ]),
  rsndReportPage(137, "단선 자동조치 전개·작업자 교육", "윤도현·임가은", "WA 대표호기 검증과 CIS·PNT 수평전개, 4개 Shift 교육 현황입니다.", [
    rsndReportBlock(137, "RESULT", "WA 양극 7-1호에서 Main Roll 전·후단 단선 두 케이스와 추가 Gap 보정 기능을 검증했고, PNT·Single 대표호기 3-2호 기능검증도 완료했습니다.", "AUTO-KPI-03"),
    rsndReportBlock(137, "RESULT", "WA4 양극 Roll Press CIS는 7월 17일, PNT 설비는 7월 24일 수평전개를 완료했습니다.", "AUTO-KPI-03"),
    rsndReportBlock(137, "PLAN", "4개 Shift 작업자 교육을 8월 31일까지 마치고 실제 생산 적용 상태를 확인합니다.", "AUTO-KPI-03"),
  ]),
  rsndReportPage(138, "WA 전 호기 Tension 확산", "오세진", "WA 25개 호기의 로직 적용·양산 사용·설비 이슈를 호기별로 관리하는 전개 현황입니다.", [
    rsndReportBlock(138, "PROGRESS", "WA 전체 25개 호기에 자동보정 로직을 적용했고 현재 12개 호기가 양산에 적용 중입니다.", "AUTO-KPI-03"),
    rsndReportBlock(138, "ANALYSIS", "일부 호기는 Tension 헌팅, 센서 위치, Cable, Dancer Roll·Actuator, 생산대기 문제로 장기성능 검증 또는 설비조치가 필요합니다."),
    rsndReportBlock(138, "PLAN", "C8-1·C8-2를 포함한 미검증 호기의 생산 일정과 설비조치를 연결해 양산 적용 Coverage를 확대합니다.", "AUTO-KPI-03"),
  ]),
  rsndReportPage(139, "AX 기반 NND 파라미터 최적화 1/4", "조현우", "NND APC와 AX 실시간 최적화 알고리즘의 PLC 인터페이스 및 대표호기 적용 현황입니다.", [
    rsndReportBlock(139, "RESULT", "MI2 양·음극 인터페이스와 기능 테스트를 완료했고 WA5 금형 대표호기 PLC·알고리즘 적용을 진행했습니다.", "AUTO-KPI-12"),
    rsndReportBlock(139, "PROGRESS", "Siemens·Mitsubishi, Laser·Mold 유형별 대표호기 적용과 수평전개 상태를 법인·설비 유형별로 관리합니다.", "AUTO-KPI-12"),
    rsndReportBlock(139, "PLAN", "FeedForward와 Feedback 보정이 동시에 동작하도록 로직을 개선해 검증합니다.", "AUTO-KPI-12"),
  ]),
  rsndReportPage(140, "AX 기반 NND 수평전개 2/4", "조현우", "법인별 PLC 수정과 WA5 설비 Layout 유형별 순차 전개 현황입니다.", [
    rsndReportBlock(140, "RESULT", "OT·MI_LS·HD 대상 PLC 수정 설명회와 작업가이드를 배포했고 WA5 금형 대표호기의 통신 지연과 설비 특이사항을 보완했습니다.", "AUTO-KPI-12"),
    rsndReportBlock(140, "PROGRESS", "WA5의 모델·호기·Layout별 설비 파악, PLC 수정, APC 기준정보, 알고리즘 적용 단계를 각각 추적하고 있습니다.", "AUTO-KPI-12"),
    rsndReportBlock(140, "PLAN", "미완료 Layout 유형과 법인별 대표호기 적용 일정을 연결해 순차적으로 업데이트합니다.", "AUTO-KPI-12"),
  ]),
  rsndReportPage(141, "AX 기반 NND 적용 리스크·일정 3/4", "조현우", "OT 예상효과 검토에서 확인된 취약점과 HD 적용 선행조건을 반영한 재계획입니다.", [
    rsndReportBlock(141, "RISK", "OT 예상효과 시뮬레이션에서 취약점을 확인해 개선효과가 있는 대표호기만 적용하고 전체 수평전개는 보류했습니다.", "AUTO-KPI-12"),
    rsndReportBlock(141, "PLAN", "OT는 알고리즘 버전업·최적화 적용·기능·성능점검을 9월 18일까지 단계적으로 수행합니다.", "AUTO-KPI-12"),
    rsndReportBlock(141, "PLAN", "HD는 예측보정과 Feedback 보정 동시 적용을 위한 PLC 수정 후 기준정보·알고리즘·성능점검 일정을 다시 진행합니다.", "AUTO-KPI-12"),
  ]),
  rsndReportPage(142, "AX 기반 NND 알고리즘 고도화 4/4", "조현우·문서윤", "운영 중 확인된 CPU·Cold Start·학습효율·모니터링 문제의 개선 내용입니다.", [
    rsndReportBlock(142, "RESULT", "최적화 Thread의 CPU·메모리 총 점유율을 50% 미만으로 제한해 DC 서버 과부하 위험을 낮췄습니다.", "AUTO-KPI-12"),
    rsndReportBlock(142, "RESULT", "이전 최적값·기본 Parameter를 초기해로 사용하고 조기 종료, 재료교체 선보정 횟수 탐색, Big M 패널티를 적용해 학습 안정성과 효율을 높였습니다.", "AUTO-KPI-12"),
    rsndReportBlock(142, "PLAN", "최적화 로그와 전·후 NG율·Cpk 기록을 운영하고, 조기종료·탐색횟수·군집크기 Hyper Parameter Benchmark를 9월 30일까지 수행합니다.", "AUTO-KPI-12"),
  ]),
  rsndReportPage(143, "AX 기반 DNC 파라미터 최적화", "조현우·문서윤", "DNC 신규공정의 X·Y축 CTP·CTQ와 구간별 예측모델 범위를 정의한 기획 페이지입니다.", [
    rsndReportBlock(143, "BACKGROUND", "X축은 Feeding Roller 공급량 Offset과 EW·TS, Y축은 EPC 센서 위치와 TN·CH의 관계를 최적화 대상으로 정의했습니다.", "AUTO-KPI-12"),
    rsndReportBlock(143, "ANALYSIS", "등속·재료교체·과편향 구간은 공통 모델을 검토하고 가감속 구간은 별도 예측모델이 필요합니다."),
    rsndReportBlock(143, "PLAN", "Gain·Cycle·활용데이터·보정 Threshold 범위를 구체화하고 EP1과 MI_LS 수평전개 일정으로 연결합니다.", "AUTO-KPI-12"),
  ]),
  rsndReportPage(144, "NFF Roll Press 조건조정 Loss 개선 1/3", "강민재·임가은", "OC9 음극 Roll Press의 부동 후 재조건조정 Loss를 줄이는 역압·Roll Gap 보조 로직입니다.", [
    rsndReportBlock(144, "RESULT", "음극 3호 조건조정 고도화 로직 적용 후 평균 조건조정 Loss율을 1.1%에서 0.03%로 개선했습니다.", "AUTO-KPI-07"),
    rsndReportBlock(144, "RESULT", "부동 시 역압·Roll Gap 조정 로직을 적용해 기존 약 130m/회의 재조건조정 Loss가 발생하지 않도록 개선했습니다.", "AUTO-KPI-07"),
    rsndReportBlock(144, "PLAN", "재조건조정 후 저속 주행에서 두께가 정상화되면 설비를 가동하는 추가 보정 Concept을 구체화합니다.", "AUTO-KPI-07"),
  ]),
  rsndReportPage(145, "NFF 장기 부동 재가동 개선 2/3", "강민재·임가은", "주말 장기 부동 후 Main Roll 열변형과 조건조정 Loss를 역압 보조인자로 빠르게 안정화한 결과입니다.", [
    rsndReportBlock(145, "RESULT", "장기 부동 후 평균 57.9m이던 조건조정 Loss가 역압 보조인자 적용 후 약 10m 수준으로 감소했습니다.", "AUTO-KPI-07"),
    rsndReportBlock(145, "KPI", "재조건조정 고도화 전 평균 64.0m에서 24.1m로 62.5% 개선했습니다.", "AUTO-KPI-07"),
    rsndReportBlock(145, "RESULT", "H19 장척 모델의 2word 생산에서도 역압 자동보정이 정상 동작하도록 길이 조건 프로그램을 보완했습니다.", "AUTO-KPI-07"),
  ]),
  rsndReportPage(146, "NFF 재료 연결 구간 개선 3/3", "강민재·임가은", "재료 연결로 설비 정지가 길어질 때 발생하는 Main Roll 수축 불량을 자동보정에 연계한 결과입니다.", [
    rsndReportBlock(146, "RESULT", "재료 연결 후 재가동 시 재조건조정 자동보정이 동작하도록 대표호기 프로그램을 수정하고 8월 3일 수평전개를 완료했습니다.", "AUTO-KPI-07"),
    rsndReportBlock(146, "KPI", "재료 연결 구간 두께 불량을 적용 전 10.3m/Lot에서 적용 후 0m/Lot로 줄였습니다.", "AUTO-KPI-07"),
    rsndReportBlock(146, "PLAN", "장기 모니터링으로 모델·호기별 효과 지속성을 확인합니다.", "AUTO-KPI-07"),
  ]),
  rsndReportPage(147, "북미 신규법인 APC 적용 1/2", "유민석·서진우", "MI2·HD·OT·MI_LS·HG·AZ의 Roll Press·NND·Slitter APC 준비와 공통 알고리즘 개선 현황입니다.", [
    rsndReportBlock(147, "RESULT", "APC DC 서버 로그를 운영에 필요한 Level로 경량화해 MI_HL·MI_LS·HD·OT에 적용했습니다.", "AUTO-KPI-04"),
    rsndReportBlock(147, "RESULT", "OT 역압 BIAS 기능을 위한 APC 알고리즘 수정·검증·적용을 8월 21일 완료했습니다.", "AUTO-KPI-04"),
    rsndReportBlock(147, "PROGRESS", "대상 법인의 알고리즘·환경·데이터·정합성·PLC/HMI·적용 단계를 공정별로 완료 상태까지 연결했습니다.", "AUTO-KPI-04"),
  ]),
  rsndReportPage(148, "ESAZ Roll Press·Slitter 성능 2/2", "유민석·서진우", "ESAZ 신규법인의 재조건조정·등속·가감속 및 Slitter 자동보정 성능 검증 결과입니다.", [
    rsndReportBlock(148, "KPI", "Roll Press Cpk는 양극 1.10→1.71, 음극 1.35→1.80으로 개선됐고 롤당 수동보정은 60회에서 0회로 감소했습니다.", "AUTO-KPI-07"),
    rsndReportBlock(148, "KPI", "Slitter Cpk는 양극 1.11→1.85, 음극 1.66→2.13으로 개선됐고 수동보정은 10회에서 0회로 감소했습니다.", "AUTO-KPI-07"),
    rsndReportBlock(148, "RESULT", "재조건조정·Tension·Slitter 프로그램 적용과 데이터 전처리·분석을 연결해 양산 안정화 기반을 확보했습니다.", "AUTO-KPI-04"),
  ]),
  rsndReportPage(149, "NJ M53F 다단압연 자동보정 1/2", "임가은·강민재", "VD 후 팬케이크 외곽→코어의 두께 감소 경향을 생산길이별 Target 변경으로 보정한 결과입니다.", [
    rsndReportBlock(149, "KPI", "외곽–코어 두께 Max–Min을 2.21㎛에서 1.76㎛로 줄여 산포를 20.4% 개선했습니다.", "AUTO-KPI-07"),
    rsndReportBlock(149, "RESULT", "젤리롤 외경 Max–Min도 0.200mm에서 0.175mm로 12.5% 개선했습니다.", "AUTO-KPI-07"),
    rsndReportBlock(149, "PLAN", "NJ 대표호기 성과를 5-2동·8동과 VD 적용 법인으로 확산합니다.", "AUTO-KPI-07"),
  ]),
  rsndReportPage(150, "NJ 다단압연 확산·기대효과 2/2", "임가은·강민재", "설비 Maker 차이에 따른 프로그램 전환, Gap 비례제어와 Global 수평전개 현황입니다.", [
    rsndReportBlock(150, "ANALYSIS", "연간 331,326,630원은 3개월 F-Cost를 연환산하고 외경 하한 불량 비중을 적용한 기대효과로, 확정 절감액과 구분합니다.", "AUTO-KPI-10"),
    rsndReportBlock(150, "RESULT", "CIS 기반 NJ7동 로직을 PNT 설비용으로 전환하고 Gap 비례제어·역압 개별제어를 함께 개발했습니다.", "AUTO-KPI-07"),
    rsndReportBlock(150, "PLAN", "OC3·NA 등 VD 적용 Roll Press에서 기능검증과 추가 모니터링을 이어갑니다.", "AUTO-KPI-07"),
  ]),
  rsndReportPage(151, "WA 1차 Roll Loadcell 비율제어", "오세진", "1·2차 압연 하중 비율을 자동으로 유지해 JF1 주름과 Springback을 줄이는 신규 로직입니다.", [
    rsndReportBlock(151, "RESULT", "Gap·Tension 자동보정과 충돌하지 않는 초기 로직을 7월 17일 개발하고 음극 1-1호 기능검증을 7월 27일 완료했습니다.", "AUTO-KPI-03"),
    rsndReportBlock(151, "KPI", "전극기술팀 공유 기준 주름 불량률은 0.4%에서 0.1%로 감소했습니다.", "AUTO-KPI-03"),
    rsndReportBlock(151, "PLAN", "음극 3·4라인 적용과 검증을 8월 30일까지 진행합니다.", "AUTO-KPI-03"),
  ]),
  rsndReportPage(152, "DaVinci WF 운영 · RTS", "임가은·서진우", "Roll Press·Slitter·Taping의 활용률과 자동·수동보정 횟수 Workflow를 법인별로 관리합니다.", [
    rsndReportBlock(152, "RESULT", "Roll Press와 Slitter의 법인별 활용률·자동·수동보정 WF 적용을 완료하고, APC에 Lot ID 수집을 추가해 생산이력 매칭을 간소화했습니다.", "AUTO-KPI-12"),
    rsndReportBlock(152, "RESULT", "ESNJ Taping 활용률 WF를 작성했습니다.", "AUTO-KPI-12"),
    rsndReportBlock(152, "PLAN", "NJ Taping 활용률 이상동작 대응 매뉴얼의 신규 버전을 작성·검증합니다.", "AUTO-KPI-12"),
  ]),
  rsndReportPage(153, "DaVinci WF 운영 · NND/DNC", "조현우·문서윤", "NND·DNC의 활용률과 자동·수동보정 횟수 산출 규칙 및 법인 전개 현황입니다.", [
    rsndReportBlock(153, "ANALYSIS", "PV가 2초 이내 연속 변하면 1회 보정으로 묶고, Enable 상태로 자동·수동을 구분하며 EPC PV는 0.01mm 이상 변화만 보정으로 인식합니다."),
    rsndReportBlock(153, "RESULT", "MI·WA·OT·MI_LS·HD·HG에 활용률 및 보정횟수 WF를 전개했고 HG DNC의 CTQ 확대를 반영했습니다.", "AUTO-KPI-12"),
    rsndReportBlock(153, "RISK", "ESMI FDC 서버 용량 부족으로 증설 일정에 따라 일부 데이터 연계가 지연될 수 있습니다.", "AUTO-KPI-12"),
  ]),
  rsndReportPage(154, "패키지 주액량 PLC 수평전개 1/2", "임가은", "ESWA·ESMI의 PLC 유형·라인별 주액량 Auto Target 적용 현황입니다.", [
    rsndReportBlock(154, "RESULT", "ESWA 대표호기 18-1 Test와 APC HMI 설계를 완료하고 전 호기 Auto Target 기준정보를 갱신했습니다.", "AUTO-KPI-06"),
    rsndReportBlock(154, "PROGRESS", "ESWA·ESMI의 Mitsubishi·Omron·Siemens PLC 유형별 적용 여부와 신규개발 필요 라인을 구분해 관리합니다.", "AUTO-KPI-06"),
    rsndReportBlock(154, "PLAN", "ESMI 잔여 Siemens 대상과 생산 검증 일정을 법인 운영계획에 맞춰 진행합니다.", "AUTO-KPI-06"),
  ]),
  rsndReportPage(155, "패키지 주액량 PLC 수평전개 2/2", "임가은", "ESHD·ESOT·ESMI_LS·ESHG·GM1·GM2의 적용·검증 및 잔여 이슈입니다.", [
    rsndReportBlock(155, "RESULT", "ESHD·ESOT·ESMI_LS·ESHG와 GM2 적용·검증을 완료했고 GM2 재가동 시 보정값 덮어쓰기 문제도 PLC 수정으로 해결했습니다.", "AUTO-KPI-06"),
    rsndReportBlock(155, "PROGRESS", "GM1 전 호기 20대의 기준정보와 VM용 PLC·HMI 설계를 준비했습니다.", "AUTO-KPI-06"),
    rsndReportBlock(155, "PLAN", "GM1은 양산 일정에 맞춰 데이터 정합성과 자동보정 기능을 검증합니다.", "AUTO-KPI-06"),
  ]),
  rsndReportPage(156, "DNS Dryer 온도 자동보정 1/2", "임가은", "R2R Dryer 재가동 시 온도 Hunting과 도달시간을 줄이기 위한 목표·데이터·제어기획입니다.", [
    rsndReportBlock(156, "BACKGROUND", "가속 시 온도 Hunting ±20℃와 Target 도달 15초로 두께·Crack·수분 NG Risk가 발생합니다."),
    rsndReportBlock(156, "PLAN", "Hunting ±10℃, 도달시간 10초, 가속 불량률 0%를 목표로 OC3 음극 10호와 OC9 음극 1~4호를 검증합니다.", "AUTO-KPI-09"),
    rsndReportBlock(156, "ANALYSIS", "이전 가동·부동시간, 램프·전극 온도 IN/MID/OUT를 추가 수집했고 2027 물동량 기준 약 35.3억원은 불량률 0.4% 가정의 기대효과로 관리합니다.", "AUTO-KPI-10"),
  ]),
  rsndReportPage(157, "DNS Dryer 제어 Concept 2/2", "임가은", "재가동 출력과 온도 응답의 9개 Cycle 분석을 바탕으로 PID 제어 시점을 정의했습니다.", [
    rsndReportBlock(157, "ANALYSIS", "재가동 시 예열 약 15%, 초기 26% 출력 뒤 더 높은 등속 출력이 인가되면서 온도 Overshoot가 발생하고 이후 출력 감소와 함께 안정화됩니다."),
    rsndReportBlock(157, "PLAN", "Target 온도의 50%에 도달하는 시점부터 PID 제어를 적용하는 Concept을 공정기술팀과 협의하고 반복 Test로 Parameter를 확정합니다.", "AUTO-KPI-09"),
  ]),
  rsndReportPage(158, "동시 Slitter 자동보정", "임가은", "8개 Lane의 폭 편차를 작업자 수동 대응 없이 제어하는 EPC·LPC 자동보정 개발 및 고도화입니다.", [
    rsndReportBlock(158, "BACKGROUND", "무지부 12개와 유지부 16개, 총 28개 데이터를 동시에 판단해야 해 전체 Lane Cpk 1.33 이상 확보에는 자동보정이 필요합니다."),
    rsndReportBlock(158, "RESULT", "OC3 음극에서 EPC 자동보정 Cpk 1.98, LPC 자동보정 Cpk 1.43을 확인해 Sanding Roll 조건에서는 EPC가 우위임을 검증했습니다.", "AUTO-KPI-07"),
    rsndReportBlock(158, "PROGRESS", "OC2·OC3 설비 구조와 Roll Path 변화에 따라 EPC/LPC 제어 Unit을 조정하고 양·음극 방향 차이를 로직에 반영했습니다.", "AUTO-KPI-07"),
  ]),
  rsndReportPage(159, "DNC 신공법 자동보정 1/2", "배지호", "HG·EP1·MI_LS DNC의 등속·가속 X/Y축 보정방식과 법인별 개발 상태입니다.", [
    rsndReportBlock(159, "RESULT", "ESOC에서 Y축 보정을 LPC에서 Mold Y 위치로 변경하는 Test를 8월 24일 진행했고, ESMI_LS PLC 수정사항 협의를 완료했습니다.", "AUTO-KPI-06"),
    rsndReportBlock(159, "ANALYSIS", "X축은 전폭·Tab Side Feeding량, Y축은 EPC·Mold 위치를 제어하며 설비 선속과 구조에 따라 법인별 보정방식을 구분합니다."),
    rsndReportBlock(159, "PLAN", "ESOC PLC 로직은 8월 31일까지 수정하고 ESMI_LS 7·8호기 FAT Test는 9월 14일까지 진행합니다.", "AUTO-KPI-06"),
  ]),
  rsndReportPage(160, "DNC 신공법 자동보정 2/2", "배지호", "ESHG 등속·가속구간 보정 고도화의 정량 성과와 타 법인 후속 적용입니다.", [
    rsndReportBlock(160, "KPI", "등속구간 TS 불량률을 0.216%에서 0.133%로 낮췄습니다.", "AUTO-KPI-06"),
    rsndReportBlock(160, "RESULT", "규격 이탈 시 즉시 보정하도록 개선해 Spec-in까지 필요한 Tab 수를 23% 단축했고, 가속구간 TS 불량률도 1.86%에서 1.29%로 개선했습니다.", "AUTO-KPI-06"),
    rsndReportBlock(160, "PLAN", "ESOC Mold Y PLC 수정과 ESMI_LS FAT 검증 결과를 수평전개 기준에 반영합니다.", "AUTO-KPI-06"),
  ]),
  rsndReportPage(161, "GM1·2 VM 기반 자동보정 시스템", "강민재·서진우", "VM 기반 RP·NND 데이터 수집·제어 모델과 PLC·HMI 개발 일정을 연결한 구축 페이지입니다.", [
    rsndReportBlock(161, "RESULT", "RP·NND 기준정보와 제작사양서를 작성·공유했고 GM2 Siemens PLC·HMI 견적을 법인에 전달했습니다.", "AUTO-KPI-12"),
    rsndReportBlock(161, "PROGRESS", "GM1은 자동보정 항목별 PLC Address 할당과 프로그램 수정을 진행하고, VM·응용환경 Setup 후 데이터 수집·제어 모델링으로 연결합니다.", "AUTO-KPI-12"),
    rsndReportBlock(161, "PLAN", "GM1은 11월 30일, GM2는 10월 30일까지 모델링을 완료한 뒤 알고리즘 적용·검증을 시작합니다.", "AUTO-KPI-12"),
  ]),
];

sourceBackedModel.reportPages.push(...rsndW35FullReportPages);

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;").replaceAll("'", "&#039;");
}

function formatDate(value, withTime = false) {
  if (!value) return "—";
  const normalized = /T/.test(value) ? value : `${value}T00:00:00+09:00`;
  const date = new Date(normalized);
  if (Number.isNaN(date.getTime())) return escapeHtml(value);
  return new Intl.DateTimeFormat("ko-KR", {
    month: "2-digit", day: "2-digit", ...(withTime ? { hour: "2-digit", minute: "2-digit" } : {}),
  }).format(date);
}

function stateClass(value) {
  const text = String(value ?? "").toUpperCase();
  if (/LOCKED|VERIFIED|APPROVED|ACCEPTED|RESOLVED|REPORTED|CLEAN|SUCCEEDED|PASS|ACTIVE|ON|UP/.test(text)) return "success";
  if (/BLOCK|ERROR|DELAYED|RETURNED|FAILED|NEEDS/.test(text)) return "danger";
  if (/WARN|PROVISIONAL|REQUESTED|DRAFT|OPEN|IN_PROGRESS|READY|OFF|NOT_CONNECTED|DEMO/.test(text)) return "warn";
  return "";
}

function badge(value, label = value) {
  return `<span class="badge ${stateClass(value)}">${escapeHtml(label)}</span>`;
}

function table(headers, rows, empty = "표시할 데이터가 없습니다.") {
  if (!rows.length) return `<div class="empty-state">${escapeHtml(empty)}</div>`;
  return `<div class="table-wrap"><table><thead><tr>${headers.map((h) => `<th>${escapeHtml(h)}</th>`).join("")}</tr></thead><tbody>${rows.join("")}</tbody></table></div>`;
}

function card(title, content, extraClass = "") {
  return `<section class="card ${extraClass}"><h3>${escapeHtml(title)}</h3>${content}</section>`;
}

function metricCard(label, value, context, tone = "") {
  return `<article class="card metric ${tone}"><span class="metric-label">${escapeHtml(label)}</span><strong class="metric-value">${escapeHtml(value)}</strong><span class="metric-context">${escapeHtml(context)}</span></article>`;
}

function sourcePill(label) {
  return `<span class="evidence-source">${escapeHtml(label)}</span>`;
}

function progressBar(value, label = "", kind = "actual") {
  if (value == null) return `<div class="progress-track is-pending" aria-label="실적 대기"><span></span></div>`;
  const normalized = Math.max(0, Math.min(100, Number(value) || 0));
  return `<div class="progress-wrap"><div class="progress-track ${kind === "proxy" ? "is-proxy" : ""}" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${normalized}"><span style="width:${normalized}%"></span></div><b>${escapeHtml(label || `${Number(value).toFixed(Number(value) % 1 ? 1 : 0)}%`)}</b></div>`;
}

function kpiBasisLabel(basis) {
  return {
    actual: "월간 실적",
    partial: "부분 실적",
    proxy: "실행 진척",
    reconcile: "범위 대조",
    official: "공식 실적 대기",
  }[basis] || "근거 확인";
}

function renderKpiDashboard(title, subtitle, items, scopeLabel) {
  const connected = items.filter((item) => item.progress != null);
  const measuredWeight = connected.reduce((sum, item) => sum + Number(item.weight || 0), 0);
  const actualCount = items.filter((item) => ["actual", "partial"].includes(item.basis)).length;
  const proxyCount = items.filter((item) => item.basis === "proxy").length;
  const rows = items.map((item) => {
    const progressLabel = item.progress == null ? "실적 대기" : item.progress > 100 ? `${Number(item.progress).toFixed(1)}%` : `${Number(item.progress).toFixed(Number(item.progress) % 1 ? 1 : 0)}%`;
    return `<article class="kpi-progress-row tone-${escapeHtml(item.tone)}">
      <div class="kpi-identity"><code>${escapeHtml(item.code)}</code><strong>${escapeHtml(item.label)}</strong><span>가중치 ${escapeHtml(item.weight)}%</span></div>
      <div class="kpi-target"><span>목표</span><strong>${escapeHtml(item.target)}</strong></div>
      <div class="kpi-actual"><span>현재 근거</span><strong>${escapeHtml(item.actual)}</strong><small>${sourcePill(item.source)}</small></div>
      <div class="kpi-achievement">${progressBar(item.progress, progressLabel, item.basis)}<div><span class="kpi-state ${escapeHtml(item.tone)}">${escapeHtml(item.status)}</span><button type="button" class="info-hover" aria-label="${escapeHtml(item.label)} 산정 기준" data-tooltip="${escapeHtml(item.detail)}">i</button></div></div>
      <div class="kpi-basis">${escapeHtml(kpiBasisLabel(item.basis))}</div>
    </article>`;
  }).join("");
  return `<section class="card kpi-dashboard" data-kpi-scope="${escapeHtml(scopeLabel)}">
    <div class="kpi-dashboard-head"><div><span class="dashboard-common-label">${escapeHtml(scopeLabel)} 공통 Dashboard</span><h2>${escapeHtml(title)}</h2><p>${escapeHtml(subtitle)}</p></div><div class="source-cutoff"><span>실적 기준</span><strong>2026.08 월간 + W35</strong><small>목표와 실적 출처 분리</small></div></div>
    <div class="kpi-summary-strip"><div><span>전체 KPI</span><strong>${items.length}</strong><small>가중치 100%</small></div><div><span>실적 연결</span><strong>${connected.length}</strong><small>연결 가중치 ${measuredWeight}%</small></div><div><span>정량 실적</span><strong>${actualCount}</strong><small>목표 대비 산정</small></div><div><span>실행 진척</span><strong>${proxyCount}</strong><small>KPI 달성률 아님</small></div></div>
    <div class="kpi-legend"><span><i class="legend-dot actual"></i>월간보고 정량 실적</span><span><i class="legend-dot proxy"></i>실행 마일스톤</span><span><i class="legend-dot pending"></i>공식 실적 대기</span><span>막대는 100%에서 시각적으로 제한</span></div>
    <div class="kpi-progress-list">${rows}</div>
  </section>`;
}

function renderDepartmentKpiDashboard() {
  return renderKpiDashboard(
    "자동보정담당 KPI 진척",
    "담당 KPI 목표 vF와 8월 자동보정담당 월간보고의 실적을 연결했습니다.",
    sourceBackedModel.departmentKpis,
    "담당 KPI",
  );
}

function renderGroupKpiDashboard() {
  return renderKpiDashboard(
    "제조DX그룹장 KPI 진척",
    "그룹장 KPI 목표 vF를 4개 담당의 8월 월간보고와 대조했습니다. 범위가 다른 값은 합산하지 않습니다.",
    sourceBackedModel.groupKpis,
    "그룹장 KPI",
  );
}

function taskStatusLabel(status) {
  return status === "COMPLETED" ? "완료" : status === "IN_PROGRESS" ? "진행 중" : "계획";
}

function renderSourceTaskRows(compact = false) {
  return sourceBackedModel.tasks.map((item) => `<article class="source-task-row ${item.code === state.activeTaskCode ? "active" : ""}">
    <div class="task-title"><code>${escapeHtml(item.code)}</code><strong>${escapeHtml(item.title)}</strong><span>${escapeHtml(item.objective)}</span></div>
    <div class="task-plan-actual"><span>Plan</span><strong>${escapeHtml(item.plan)}</strong><span>Actual</span><strong>${escapeHtml(item.actual)}</strong></div>
    <div class="task-progress-cell">${progressBar(item.progress)}<span>${badge(item.status, taskStatusLabel(item.status))}</span></div>
    <div class="task-dates"><span>목표 ${escapeHtml(item.target)}</span><strong>${item.completed ? `완료 ${escapeHtml(item.completed)}` : "완료일 미정"}</strong></div>
    ${compact ? "" : `<button type="button" class="button secondary compact-button" data-task-code="${escapeHtml(item.code)}">상세</button>`}
  </article>`).join("");
}

function renderMemberSourceDashboard() {
  const complete = sourceBackedModel.tasks.filter((item) => item.status === "COMPLETED").length;
  const average = Math.round(sourceBackedModel.tasks.reduce((sum, item) => sum + item.progress, 0) / sourceBackedModel.tasks.length);
  return `<div class="hero-strip source-hero"><div><span class="eyebrow-text">2026 ${sourceBackedModel.currentWeek} · RSND자동보정팀</span><h2>임가은 책임 업무 공간</h2><p>W31~W35 실제 보고 이력을 과제별 Plan·Actual·완료일로 관리합니다.</p></div></div>
    <div class="metrics">${metricCard("담당 과제", sourceBackedModel.tasks.length, "5주 이력 연결")}${metricCard("완료", complete, "완료일 표시")}${metricCard("평균 진척", `${average}%`, "KPI 달성률과 구분")}</div>
    ${card("이번 주 우선 과제", `<div class="source-task-list compact">${renderSourceTaskRows(true)}</div>`)}
    ${card("금주 보고 근거", `<div class="source-summary-grid"><div><span>W35 핵심</span><strong>PD Loss 평균 36.71% 감소</strong><small>WA·OT·MI_HL Tension 자동보정 적용 범위</small></div><div><span>완료 성과</span><strong>NFF 조건조정 Loss 62.5% 감소</strong><small>64.0m → 24.1m</small></div><div><span>다음 마감</span><strong>8월 31일</strong><small>단선 자동조치 4조 교육</small></div></div><p class="small muted">${escapeHtml(sourceBackedModel.sourceNote)}</p>`)} `;
}

function renderLeaderSourceDashboard() {
  return `<div class="hero-strip source-hero"><div><span class="eyebrow-text">2026 W35 · 팀장</span><h2>RSND자동보정팀 보고 관제</h2><p>팀원 제출·금주 보고와 자동보정담당 KPI 영향을 한 화면에서 확인합니다.</p></div><div class="hero-code"><span>보고자</span><strong>${escapeHtml(sourceBackedModel.people.leader)}</strong><small>RSND자동보정팀 팀장</small></div></div>
    <div class="metrics">${metricCard("팀원 페이지", sourceBackedModel.reportPages.length - 1, "전체 연결")}${metricCard("KPI 영향 항목", 8, "W35 팀 보고")}${metricCard("보고 기준", "금주만", "작성 시 W34 비교")}</div>
    ${renderDepartmentKpiDashboard()}`;
}

function renderDepartmentSourceDashboard() {
  return `<div class="hero-strip source-hero"><div><span class="eyebrow-text">2026 W35 · 자동보정담당</span><h2>담당 KPI·보고 검토</h2><p>팀장이 작성한 페이지를 중심으로 전체 팀원 페이지를 검토하고, 수정은 코멘트로 팀장에게 요청합니다.</p></div><div class="hero-code"><span>담당</span><strong>${escapeHtml(sourceBackedModel.people.departmentHead)}</strong><small>직접 수정 금지</small></div></div>
    <div class="review-flow"><span class="done">팀원 제출</span><b>→</b><span class="done">팀장 금주본</span><b>→</b><span class="active">담당 검토·코멘트</span><b>→</b><span>기획팀·그룹장 전송</span></div>
    ${renderDepartmentKpiDashboard()}${renderGroupKpiDashboard()}`;
}

function renderDepartmentCards() {
  return `<div class="department-score-grid">${sourceBackedModel.departmentCards.map((item) => `<article class="department-score-card tone-${escapeHtml(item.tone)}"><header><div><span>담당 월간보고</span><h3>${escapeHtml(item.name)}</h3></div>${badge(item.tone === "success" ? "VERIFIED" : "IN_PROGRESS", item.status)}</header>${progressBar(item.score, `${item.score}%`, "proxy")}<dl><div><dt>핵심</dt><dd>${escapeHtml(item.headline)}</dd></div><div><dt>관찰</dt><dd>${escapeHtml(item.watch)}</dd></div><div><dt>담당</dt><dd>${escapeHtml(item.owner)}</dd></div></dl>${sourcePill(item.source)}</article>`).join("")}</div>`;
}

function renderHeadSourceDashboard() {
  return `<div class="hero-strip source-hero"><div><span class="eyebrow-text">2026 W35 · 제조DX그룹</span><h2>그룹 KPI·담당 보고 Overview</h2><p>담당별 월간보고의 KPI 영향과 팀장 핵심 페이지를 우선 검토합니다.</p></div><div class="hero-code"><span>그룹장</span><strong>${escapeHtml(sourceBackedModel.people.groupHead)}</strong><small>원문 변경 불가</small></div></div>
    ${card("담당별 8월 업무보고", renderDepartmentCards())}
    ${renderDepartmentKpiDashboard()}${renderGroupKpiDashboard()}`;
}

function renderDepartmentKpiMonitor() {
  const attention = sourceBackedModel.departmentKpis.filter((item) => ["danger", "warn"].includes(item.tone));
  const roleLabel = state.role === "LEADER" ? "팀장" : state.role === "HEAD" ? "그룹장" : "담당";
  return `<div class="hero-strip source-hero"><div><span class="eyebrow-text">2026 · 자동보정담당 KPI 문서</span><h2>자동보정담당 KPI 진척 모니터링</h2><p>${roleLabel} 권한에서 목표·8월 실적·W35 RSND 기여를 동일 정의로 확인합니다.</p></div><div class="hero-code"><span>기준일</span><strong>${escapeHtml(sourceBackedModel.asOf)}</strong><small>목표 vF · 8월 업무보고</small></div></div>
    ${card("우선 관리 KPI", `<div class="kpi-focus-grid">${attention.map((item) => `<article><code>${escapeHtml(item.code)}</code><strong>${escapeHtml(item.label)}</strong><span>${escapeHtml(item.actual)}</span><small>${escapeHtml(item.status)} · ${escapeHtml(item.detail)}</small></article>`).join("")}</div>`)}
    ${renderDepartmentKpiDashboard()}
    ${card("RSND W35 직접 기여", `<div class="source-summary-grid"><div><span>PD Loss</span><strong>평균 36.71% 감소</strong><small>W35 p.131 범위</small></div><div><span>NFF 조건조정</span><strong>64.0m → 24.1m</strong><small>62.5% 감소</small></div><div><span>신규법인 Cpk</span><strong>R/P 1.71·1.80</strong><small>수동보정 60회 → 0회</small></div></div><p class="small muted">주간 기여는 KPI 공식 달성률과 분리하며, 상세 근거는 전체 보고파일 31개 페이지에서 확인합니다.</p>`)}`;
}

function renderGroupKpiMonitor() {
  const attention = sourceBackedModel.groupKpis.filter((item) => ["danger", "warn"].includes(item.tone));
  return `<div class="hero-strip source-hero"><div><span class="eyebrow-text">2026 · 제조DX그룹장 KPI 문서</span><h2>제조DX그룹장 KPI 진척 모니터링</h2><p>그룹장 목표와 4개 담당의 8월 업무보고를 대조해 실적·실행진척·범위차이를 구분합니다.</p></div><div class="hero-code"><span>기준일</span><strong>${escapeHtml(sourceBackedModel.asOf)}</strong><small>그룹장 KPI 목표 vF</small></div></div>
    ${card("담당별 8월 업무보고", renderDepartmentCards())}
    ${card("그룹 우선 관리 KPI", `<div class="kpi-focus-grid">${attention.map((item) => `<article><code>${escapeHtml(item.code)}</code><strong>${escapeHtml(item.label)}</strong><span>${escapeHtml(item.actual)}</span><small>${escapeHtml(item.status)} · ${escapeHtml(item.detail)}</small></article>`).join("")}</div>`)}
    ${renderGroupKpiDashboard()}
    ${card("판단 기준", `<div class="notice"><strong>담당별 수치는 집계 범위가 같을 때만 통합합니다.</strong>BM/PD Loss와 NFF 셀처럼 범위가 다른 값은 단순 평균하지 않고 그룹 공식 Snapshot 확정 전까지 범위 대조 상태로 유지합니다.</div>`)}`;
}

function renderSourceWorklist() {
  return `${card("임가은 책임 · 과제별 Plan 대비 진척", `<div class="notice"><strong>진척률은 WorkItem 실행 진척입니다.</strong>KPI 달성률과 분리하며, 완료된 과제는 완료일을 고정합니다.</div><div class="source-task-list">${renderSourceTaskRows()}</div>`)}${card("RSND 전체 보고 연결", `<div class="kpi-legend"><span>W31~W35 주차별 이력</span><span>Plan 대비 Actual</span><span>목표일과 실제 완료일</span><span>W35 31개 원문 페이지</span></div><p class="small muted">선택한 책임의 과제는 MBR-02·03에서 관리하고, 팀 전체 31개 페이지는 팀장·담당·그룹장 보고파일에서 모두 탐색할 수 있습니다.</p>`)}`;
}

function renderSourceWorkDetail() {
  const item = sourceBackedModel.tasks.find((task) => task.code === state.activeTaskCode) || sourceBackedModel.tasks[0];
  const selectors = sourceBackedModel.tasks.map((task) => `<button type="button" class="task-selector ${task.code === item.code ? "active" : ""}" data-task-code="${escapeHtml(task.code)}"><span>${escapeHtml(task.code)}</span><strong>${escapeHtml(task.title)}</strong><small>${task.progress}% · ${escapeHtml(taskStatusLabel(task.status))}</small></button>`).join("");
  const weeks = item.weeks.map((week) => `<article class="week-progress"><header><strong>${escapeHtml(week.week)}</strong><span>${escapeHtml(week.value)}%</span></header>${progressBar(week.value)}<p>${escapeHtml(week.text)}</p></article>`).join("");
  const resources = item.resources.map((resource) => `<li><strong>${escapeHtml(resource.title)}</strong><span><code>${escapeHtml(resource.id)}</code>${escapeHtml(resource.description)}</span></li>`).join("");
  return `<div class="task-detail-layout"><aside class="card task-picker"><h3>과제 선택</h3>${selectors}</aside><section class="stack"><article class="card task-detail-card"><div class="card-top"><div><code>${escapeHtml(item.code)}</code><h2>${escapeHtml(item.title)}</h2><p>${escapeHtml(item.objective)}</p></div>${badge(item.status, taskStatusLabel(item.status))}</div><div class="task-big-progress"><div><span>Plan 대비 진척</span><strong>${item.progress}%</strong></div>${progressBar(item.progress)}</div><div class="plan-actual-grid"><div><span>Plan</span><p>${escapeHtml(item.plan)}</p></div><div><span>Actual</span><p>${escapeHtml(item.actual)}</p></div></div><dl class="detail-grid"><div><dt>Owner</dt><dd>${escapeHtml(item.owner)} 책임</dd></div><div><dt>연결 KPI</dt><dd><code>${escapeHtml(item.kpi)}</code></dd></div><div><dt>기간</dt><dd>${escapeHtml(item.start)} – ${escapeHtml(item.target)}</dd></div><div><dt>실제 완료일</dt><dd>${item.completed ? escapeHtml(item.completed) : "진행 중 · 완료 후 고정"}</dd></div></dl></article>${card("W31~W35 진척 이력", `<div class="five-week-track">${weeks}</div>`)}${card("연결 Resource", `<ul class="list resource-detail-list">${resources}</ul><div class="notice"><strong>ID뿐 아니라 연결 이유를 함께 표시합니다.</strong>보고 원문, KPI 목표, 상세 분석자료가 이 과제에 왜 연결되는지 바로 확인할 수 있습니다.</div>`)}</section></div>`;
}

function renderReportNarrative(block) {
  const story = Array.isArray(block.story) && block.story.length
    ? `<dl class="report-story">${block.story.map((item) => `<div><dt>${escapeHtml(item.label)}</dt><dd>${escapeHtml(item.value)}</dd></div>`).join("")}</dl>`
    : "";
  return `<div class="report-block-narrative">${block.headline ? `<h4>${escapeHtml(block.headline)}</h4>` : ""}<p>${escapeHtml(block.text)}</p>${story}</div>`;
}

function renderLeaderHighlights(page) {
  if (!Array.isArray(page.highlights) || !page.highlights.length) return "";
  return `<div class="leader-report-highlights">${page.highlights.map((item) => `<article><span>${escapeHtml(item.label)}</span><strong>${escapeHtml(item.value)}</strong><small>${escapeHtml(item.detail)}</small></article>`).join("")}</div>`;
}

function renderCurrentReportPage(page, compact = false) {
  const blocks = page.blocks.map((block) => `<article class="current-report-block"><div>${reportTag(block.tag)}${block.impact ? `<span class="kpi-impact-chip">KPI 영향 · ${escapeHtml(block.impact)}</span>` : ""}</div>${renderReportNarrative(block)}<button type="button" class="info-hover" aria-label="추가 정보" data-tooltip="${escapeHtml(block.tooltip || "추가 근거 없음")}">i</button></article>`).join("");
  return `<article class="current-report-page ${compact ? "compact" : ""} ${page.type === "TEAM_LEADER" ? "is-leader-report" : ""}"><header><div><span>${escapeHtml(page.type)}</span><h3>${escapeHtml(page.title)}</h3><p>${escapeHtml(page.subtitle)}</p></div><div>${page.kpiImpact ? `<span class="kpi-impact-chip">KPI 영향 있음</span>` : badge("REFERENCE", "참고")}</div></header><p class="report-page-summary">${escapeHtml(page.summary)}</p>${renderLeaderHighlights(page)}<div class="current-report-blocks">${blocks}</div></article>`;
}

function renderLeaderFinalReport() {
  const pages = sourceBackedModel.reportPages;
  return `<div class="current-only-banner"><div><span>REPORT VIEW</span><strong>W35 금주 내용만 보고</strong><p>W34는 LDR-05 작성 비교에서만 사용하며 담당·그룹장 보고본에는 포함하지 않습니다.</p></div><button type="button" class="button secondary" data-print-current-team>금주 보고 PDF</button></div>
    ${card("팀장 금주 보고본", `<div class="immutable-note">최도윤 팀장 작성 원문 · W35 · 담당 제출 전</div>${renderCurrentReportPage(pages[0])}`)}
    ${card("연결된 팀원 과제별 페이지", `<div class="linked-page-grid">${pages.slice(1).map((page) => renderCurrentReportPage(page, true)).join("")}</div>`)}
    ${card("담당 KPI 영향", `<div class="notice"><strong>W35 KPI 영향 4개</strong>BM/PD Loss, NFF 전극, 코터 자동보정, AI Agent 업무효율화에 직접 연결됩니다. 달성률은 월간보고의 KPI 대시보드에서 별도 확인합니다.</div>`)} `;
}

function renderReviewPage(page) {
  return `<article class="review-document ${page.type === "TEAM_LEADER" ? "is-leader-report" : ""}"><header><div><span>${escapeHtml(page.type)}</span><h2>${escapeHtml(page.title)}</h2><p>${escapeHtml(page.owner)} · ${escapeHtml(page.subtitle)}</p></div><div><span class="immutable-chip">원문 잠금</span>${page.kpiImpact ? `<span class="kpi-impact-chip">KPI 영향</span>` : ""}</div></header><div class="review-document-summary"><strong>Agent 이해보조</strong><p>${escapeHtml(page.summary)}</p><span>원문과 분리된 분석이며 팀장 작성 내용은 변경하지 않습니다.</span></div>${renderLeaderHighlights(page)}<div class="current-report-blocks">${page.blocks.map((block) => `<article class="current-report-block"><div>${reportTag(block.tag)}${block.impact ? `<span class="kpi-impact-chip">${escapeHtml(block.impact)}</span>` : ""}</div>${renderReportNarrative(block)}<button type="button" class="info-hover" aria-label="추가 정보" data-tooltip="${escapeHtml(block.tooltip || "연결된 상세 페이지에서 확인")}">i</button></article>`).join("")}</div></article>`;
}

function renderReviewComments() {
  if (!state.reviewComments.length) return `<div class="empty-state">등록된 코멘트가 없습니다.</div>`;
  return `<ul class="review-comment-list">${state.reviewComments.map((item) => `<li><header><strong>${escapeHtml(item.author)}</strong><span>${escapeHtml(item.pageTitle)}</span></header><p>${escapeHtml(item.text)}</p><small>${escapeHtml(item.recipient)} · ${escapeHtml(item.at)}</small></li>`).join("")}</ul>`;
}

function renderReportFileReview(mode) {
  const pages = sourceBackedModel.reportPages;
  const current = pages.find((page) => page.id === state.reviewPageId) || pages[0];
  const isDept = mode === "DEPT";
  const nav = pages.map((page, index) => `<button type="button" class="report-file-nav ${page.id === current.id ? "active" : ""}" data-review-page="${escapeHtml(page.id)}"><span>${String(index + 1).padStart(2, "0")}</span><div><strong>${escapeHtml(page.title)}</strong><small>${escapeHtml(page.owner)} · ${page.kpiImpact ? "KPI 영향" : "참고"}</small></div></button>`).join("");
  const analysis = isDept
    ? `<div class="notice"><strong>담당 검토 원칙</strong>내용 수정이 필요하면 원문을 직접 편집하지 않고 팀장에게 코멘트로 돌려보냅니다. 완료본은 기획팀과 그룹장에게 함께 전송합니다.</div>`
    : `<div class="ai-interpretation"><span>AI 정리·분석</span><strong>읽기 난이도 보정</strong><p>${escapeHtml(current.summary)}</p><ul><li>KPI 영향 문장은 별도 배지로 표시</li><li>정량값은 목표·월간실적·주간기여를 분리</li><li>추가 정보는 i 버튼에 마우스를 올려 확인</li></ul><small>팀장 원문은 변경하지 않습니다.</small></div>`;
  const recipient = isDept ? "최도윤 팀장" : "윤태성 담당·최도윤 팀장";
  return `<div class="report-file-layout"><aside class="card report-file-sidebar"><div class="card-top"><div><span class="small muted">RPT-AUTO-2026-W35</span><h3>전체 보고파일</h3></div>${badge(state.reviewStatus)}</div><p>팀장 페이지 1장 + 팀원 과제별 페이지 ${pages.length - 1}장</p><nav>${nav}</nav><div class="file-coverage"><span>현재 페이지</span><strong>${pages.findIndex((page) => page.id === current.id) + 1} / ${pages.length}</strong><small>모든 페이지 연결됨</small></div></aside><section class="stack">${renderReviewPage(current)}</section><aside class="stack review-aside">${card(isDept ? "검토 방식" : "이해보조 분석", analysis)}${card(isDept ? "팀장 수정 코멘트" : "검토 지시사항", `<label class="full review-comment-field"><span>${escapeHtml(recipient)}에게 전달</span><textarea id="review-comment-text" placeholder="수정 위치·사유·원하는 조치를 입력하세요"></textarea></label><div class="button-row"><button type="button" class="button primary" data-add-review-comment="${escapeHtml(mode)}">${isDept ? "팀장에게 코멘트" : "지시사항 등록"}</button></div>`)}${card("등록 이력", renderReviewComments())}${isDept ? card("검토 완료 후", `<div class="button-row vertical"><button type="button" class="button secondary" data-review-return>팀장 보완 요청</button><button type="button" class="button primary" data-review-send>기획팀·그룹장 전송</button></div><p class="small muted">전송 시 전체 보고파일과 코멘트 이력을 함께 고정합니다.</p>`) : ""}</aside></div>`;
}

async function api(path, options = {}) {
  if (window.location.protocol === "file:" && window.demoOfflineApi) {
    return window.demoOfflineApi(path, options);
  }
  try {
    const response = await fetch(path, { headers: { "Content-Type": "application/json", ...(options.headers || {}) }, ...options });
    let payload;
    try { payload = await response.json(); } catch { payload = { message: `HTTP ${response.status}` }; }
    if (!response.ok) throw new Error(payload.message || `HTTP ${response.status}`);
    return payload;
  } catch (error) {
    if (window.demoOfflineApi) {
      $("#runtime-label").textContent = "오프라인 샘플 데이터";
      return window.demoOfflineApi(path, options);
    }
    throw error;
  }
}

function renderAgentEngineStatus() {
  const engine = state.agent.engine || {};
  const mode = "DEMO";
  const badgeElement = $("#agent-engine-status");
  const dot = $("#agent-engine-dot");
  const detail = $("#agent-engine-detail");
  const welcome = $("#agent-engine-welcome");
  const caption = $("#agent-mode-caption");
  const composerHint = $("#agent-composer-hint");
  const labels = { DEMO: "PORTAL DEMO" };
  if (badgeElement) {
    badgeElement.textContent = labels[mode] || mode;
    badgeElement.className = `agent-engine-badge ${mode.toLowerCase()}`;
  }
  if (dot) dot.className = `agent-online-dot ${mode.toLowerCase()}`;
  if (detail) detail.textContent = engine.message || "로컬 Demo Agent 준비 완료";
  if (caption) caption.textContent = "외부 연결 없는 시연 전용 Agent · 요약·초안·반영";
  if (composerHint) composerHint.textContent = "내장 Agent의 결과는 미리보기에서 선택한 뒤 즉시 업무페이지에 반영됩니다.";
  if (welcome) welcome.textContent = "외부 Copilot이나 인터넷 연결을 사용하지 않는 시연용 Agent입니다.";
}

function setAgentDrawer(open) {
  const split = $("#content-split");
  const panel = $("#weekly-agent");
  const toggle = $("#toggle-agent");
  split?.classList.toggle("agent-hidden", !open);
  panel?.setAttribute("aria-hidden", String(!open));
  toggle?.setAttribute("aria-expanded", String(open));
  toggle?.setAttribute("aria-label", open ? "업무 Agent 열림" : "업무 Agent 열기");
  if (open) window.setTimeout(() => $("#close-agent")?.focus(), 80);
}

async function loadAgentStatus() {
  state.agent.engine = {
    ok: true,
    mode: "DEMO",
    configured: true,
    provider: "portal_demo_agent",
    model: "시연 시나리오 v1.21.0",
    message: "외부 연결 없이 포털 샘플 데이터를 요약·반영합니다.",
  };
  renderAgentEngineStatus();
  renderAgentContext();
}

function setActiveAgentTab(tab) {
  const isWork = tab === "work";
  state.activeAgentTab = tab;
  $("#tab-work-agent")?.classList.toggle("active", isWork);
  $("#tab-work-agent")?.setAttribute("aria-selected", String(isWork));
  $("#tab-report-agent")?.classList.toggle("active", !isWork);
  $("#tab-report-agent")?.setAttribute("aria-selected", String(!isWork));
  if ($("#agent-work-panel")) $("#agent-work-panel").hidden = !isWork;
  if ($("#agent-report-panel")) $("#agent-report-panel").hidden = isWork;
  if ($("#new-agent-chat")) $("#new-agent-chat").hidden = !isWork;
  if ($("#agent-panel-title")) $("#agent-panel-title").textContent = isWork ? "주간업무 Demo Agent" : "보고서 Agent";
}

function weekThreshold() {
  return state.reportAgent.weekRange === "FOUR_WEEK" ? "2026-07-27" : "2026-08-24";
}

function scopedWorkItemIdsForReport() {
  const selected = state.reportAgent.selectedWorkItemIds;
  return new Set((state.data?.work_items || [])
    .filter((item) => !selected || selected.has(item.id))
    .map((item) => item.id));
}

function renderReportSourceCount() {
  const threshold = weekThreshold();
  const scopedItemIds = scopedWorkItemIdsForReport();
  const count = (state.data?.worklogs || [])
    .filter((log) => scopedItemIds.has(log.work_item_id) && String(log.occurred_on) >= threshold).length;
  const chip = $("#report-agent-source-count");
  if (chip) chip.textContent = `${count}건 확인됨`;
}

function renderWorkItemChecklist() {
  const container = $("#work-item-checklist");
  if (!container) return;
  const items = state.data?.work_items || [];
  if (state.reportAgent.selectedWorkItemIds === null) {
    state.reportAgent.selectedWorkItemIds = new Set(items.map((item) => item.id));
  }
  container.innerHTML = items.length
    ? items.map((item) => `
      <label class="work-item-check">
        <input type="checkbox" value="${escapeHtml(item.id)}" ${state.reportAgent.selectedWorkItemIds.has(item.id) ? "checked" : ""}>
        <span>${escapeHtml(item.work_item_code)} · ${escapeHtml(item.title)}</span>
      </label>`).join("")
    : `<p class="hint-muted">선택 가능한 업무가 없습니다.</p>`;
}

function updateReportGenerateAvailability() {
  const ready = !!(state.reportAgent.persona && state.reportAgent.emphasis) && !state.reportAgent.busy;
  const generateButton = $("#report-generate");
  if (generateButton) generateButton.disabled = !ready;
  const hint = $("#report-agent-hint");
  if (hint) {
    hint.textContent = state.reportAgent.busy
      ? "생성 중입니다…"
      : ready
        ? "이 조합으로 보고서를 생성합니다."
        : "피보고자와 강조점을 선택하면 생성할 수 있습니다.";
  }
}

function resetReportAgentPanel() {
  state.reportAgent.persona = null;
  state.reportAgent.emphasis = null;
  state.reportAgent.length = "DEFAULT";
  state.reportAgent.weekRange = "CURRENT";
  state.reportAgent.selectedWorkItemIds = null;
  state.reportAgent.report = null;
  document.querySelectorAll("#persona-chip-row .chip-button, #emphasis-chip-row .chip-button")
    .forEach((button) => button.classList.remove("selected"));
  document.querySelectorAll("#length-chip-row .chip-button")
    .forEach((button) => button.classList.toggle("selected", button.dataset.length === "DEFAULT"));
  document.querySelectorAll("#week-chip-row .chip-button")
    .forEach((button) => button.classList.toggle("selected", button.dataset.week === "CURRENT"));
  const welcome = $("#report-agent-welcome");
  const output = $("#report-agent-output");
  const downloadBtn = $("#report-download-pptx");
  if (welcome) welcome.hidden = false;
  if (output) { output.hidden = true; output.innerHTML = ""; }
  if (downloadBtn) downloadBtn.hidden = true;
  clearReportDownloadError();
  renderWorkItemChecklist();
  renderReportSourceCount();
  updateReportGenerateAvailability();
}

function buildDemoReport(persona, emphasis) {
  const personaMeta = reportPersonaCards[persona] || {};
  const emphasisLabel = reportEmphasisLabels[emphasis] || emphasis;
  const threshold = weekThreshold();
  const periodLabel = state.reportAgent.weekRange === "FOUR_WEEK" ? "최근 4주" : "이번 주";
  const scopedItemIds = scopedWorkItemIdsForReport();
  const entries = (state.data?.worklogs || [])
    .filter((log) => scopedItemIds.has(log.work_item_id) && String(log.occurred_on) >= threshold);

  const byType = { RESULT: [], ANALYSIS: [], PLAN: [], RISK: [], FACT: [] };
  entries.forEach((log) => {
    const key = log.entry_type === "NEXT" ? "PLAN" : log.entry_type;
    (byType[key] || byType.FACT).push(log);
  });

  const emphasisOrder = {
    PERFORMANCE: ["RESULT", "FACT", "ANALYSIS", "PLAN", "RISK"],
    RISK: ["RISK", "ANALYSIS", "RESULT", "PLAN", "FACT"],
    DIRECTION: ["PLAN", "ANALYSIS", "RESULT", "RISK", "FACT"],
  }[emphasis] || ["RESULT", "RISK", "PLAN", "ANALYSIS", "FACT"];

  const flagged = [];
  const sanitize = (text) => {
    let out = text;
    (personaMeta.avoid_terms || []).forEach((term) => {
      if (out.includes(term)) {
        flagged.push(term);
        out = out.split(term).join("확정 전 검증 중");
      }
    });
    return out;
  };

  const lengthOverride = { COMPACT: 3, DETAILED: 15 }[state.reportAgent.length];
  const detailCap = lengthOverride
    || { low: 3, medium: 5, "medium-high": 7, high: 12 }[personaMeta.detail_level]
    || 5;

  const sectionDefs = [
    { key: "RESULT", heading: "성과/결과" },
    { key: "RISK", heading: "리스크/이슈" },
    { key: "PLAN", heading: "다음 계획" },
    { key: "ANALYSIS", heading: "분석" },
  ].sort((a, b) => emphasisOrder.indexOf(a.key) - emphasisOrder.indexOf(b.key));

  const sections = sectionDefs
    .map((def) => ({
      heading: def.heading,
      bullets: byType[def.key].slice(0, detailCap).map((log) => sanitize(log.narrative)),
    }))
    .filter((section) => section.bullets.length > 0);

  const totalEntries = entries.length;
  const summary = totalEntries
    ? `${periodLabel} ${scopedItemIds.size}개 업무에서 ${totalEntries}건의 기록이 확인되었습니다. ${emphasisLabel} 중심으로 정리했습니다.`
    : `${periodLabel} 확인된 Worklog가 없어 보고서를 생성할 근거가 부족합니다.`;

  return {
    title: `${state.data?.principal?.organization_name || "제조DX"} 주간보고 — ${reportPersonaLabels[persona]}용`,
    persona,
    emphasis,
    summary,
    sections: sections.length
      ? sections
      : [{ heading: "확인 필요", bullets: ["선택한 범위에 등록된 Worklog가 없습니다. 포함 기간이나 업무 선택을 확인해 주세요."] }],
    flagged_terms: [...new Set(flagged)],
  };
}

function renderReportOutput(report) {
  const output = $("#report-agent-output");
  if (!output) return;
  const personaLabel = reportPersonaLabels[report.persona] || report.persona;
  const emphasisLabel = reportEmphasisLabels[report.emphasis] || report.emphasis;
  const sections = (report.sections || [])
    .map((section) => `<div class="report-section"><h4>${escapeHtml(section.heading)}</h4><ul>${(section.bullets || []).map((bullet) => `<li>${escapeHtml(bullet)}</li>`).join("")}</ul></div>`)
    .join("");
  const flagged = (report.flagged_terms || []).length
    ? `<div class="report-flagged">순화 처리된 표현: ${report.flagged_terms.map(escapeHtml).join(", ")}</div>`
    : "";
  output.hidden = false;
  output.innerHTML = `<div class="report-output-card">
    <div class="report-output-meta"><span>${escapeHtml(personaLabel)}</span><span>${escapeHtml(emphasisLabel)}</span></div>
    <h3>${escapeHtml(report.title || "")}</h3>
    <p>${escapeHtml(report.summary || "")}</p>
    ${sections}
    ${flagged}
  </div>`;
}

async function handleReportGenerateSubmit(event) {
  event?.preventDefault();
  if (state.reportAgent.busy || !state.reportAgent.persona || !state.reportAgent.emphasis) return;
  state.reportAgent.busy = true;
  updateReportGenerateAvailability();
  if ($("#report-agent-welcome")) $("#report-agent-welcome").hidden = true;
  const output = $("#report-agent-output");
  if (output) {
    output.hidden = false;
    output.innerHTML = `<div class="report-output-card"><p>보고서를 생성하는 중입니다…</p></div>`;
  }
  await new Promise((resolve) => window.setTimeout(resolve, 350));
  try {
    const report = buildDemoReport(state.reportAgent.persona, state.reportAgent.emphasis);
    state.reportAgent.report = report;
    renderReportOutput(report);
    if ($("#report-download-pptx")) $("#report-download-pptx").hidden = false;
  } catch (error) {
    if (output) output.innerHTML = `<div class="report-output-card"><p>보고서를 생성하지 못했습니다: ${escapeHtml(error.message)}</p></div>`;
    showToast(error.message, true);
  } finally {
    state.reportAgent.busy = false;
    updateReportGenerateAvailability();
  }
}

async function downloadReportPptxFromServer(report) {
  const response = await fetch("/api/report-agent/export-pptx", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        persona_label: reportPersonaLabels[report.persona] || report.persona,
        emphasis_label: reportEmphasisLabels[report.emphasis] || report.emphasis,
        report,
      }),
  });
  if (!response.ok) {
    let message = `HTTP ${response.status}`;
    try {
      const payload = await response.json();
      message = payload.message || message;
    } catch { /* binary response */ }
    throw new Error(message);
  }
  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "weekly_report.pptx";
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

async function downloadReportPptxOffline(report) {
  if (typeof window.downloadOfflineReportPptx !== "function") {
    throw new Error("오프라인 PPT 생성 모듈을 불러오지 못했습니다.");
  }
  await window.downloadOfflineReportPptx(
    report,
    reportPersonaLabels[report.persona] || report.persona,
    reportEmphasisLabels[report.emphasis] || report.emphasis,
    "weekly_report.pptx",
  );
}

async function handleReportDownloadPptx() {
  const report = state.reportAgent.report;
  if (!report) return;
  const button = $("#report-download-pptx");
  const originalLabel = button?.textContent || "PPT 다운로드";
  if (button) { button.disabled = true; button.textContent = "PPT 생성 중…"; }
  clearReportDownloadError();
  try {
    if (window.location.protocol === "file:") {
      await downloadReportPptxOffline(report);
      showToast("서버 연결 없이 PPT를 생성했습니다.");
      return;
    }
    try {
      await downloadReportPptxFromServer(report);
    } catch (serverError) {
      await downloadReportPptxOffline(report);
      showToast("서버 API 대신 오프라인 방식으로 PPT를 생성했습니다.");
    }
  } catch (error) {
    showToast(error.message, true);
    showReportDownloadError(error.message);
  } finally {
    if (button) { button.disabled = false; button.textContent = originalLabel; }
  }
}

function showReportDownloadError(message) {
  const hint = $("#report-agent-hint");
  if (!hint) return;
  hint.textContent = `PPT 생성 실패: ${message}`;
  hint.classList.add("report-hint-error");
}

function clearReportDownloadError() {
  const hint = $("#report-agent-hint");
  if (hint) hint.classList.remove("report-hint-error");
}

function currentScreen() { return state.data?.screens?.[state.screenIndex] || null; }

async function loadRole(role, preferredScreenId = null) {
  const roleChanged = Boolean(state.data && state.role !== role);
  state.role = role;
  if (roleChanged) newAgentChat();
  state.generatedDraft = null;
  state.lastAnswer = null;
  $("#loading").hidden = false;
  $("#screen-body").innerHTML = "";
  try {
    const data = await api(`/api/bootstrap?role=${encodeURIComponent(role)}`);
    state.data = data;
    const target = data.screens.findIndex((screen) => screen.screen_id === preferredScreenId);
    state.screenIndex = target >= 0 ? target : 0;
    renderPrincipal(); renderNavigation(); renderScreen();
    await loadAgentStatus();
    resetReportAgentPanel();
  } catch (error) {
    $("#loading").textContent = `데이터를 불러오지 못했습니다: ${error.message}`;
    showToast(error.message, true);
  }
}

function renderPrincipal() {
  const p = state.data.principal;
  $("#principal-name").textContent = p.display_name;
  $("#principal-scope").textContent = `${p.role_label} · ${p.organization_name}`;
  $("#principal-avatar").textContent = p.display_name.slice(0, 1);
  $("#principal-avatar").style.background = roleColors[state.role] || roleColors.COMMON;
  $("#principal-avatar").style.color = "white";
  $("#screen-count").textContent = state.data.screens.length;
  $("#runtime-label").textContent = window.location.protocol === "file:" ? "오프라인 샘플 데이터" : "SQLite 연결됨";
}

function renderNavigation() {
  $("#screen-nav").innerHTML = state.data.screens.map((screen, index) => `
    <button type="button" class="nav-button ${index === state.screenIndex ? "active" : ""}" data-screen-index="${index}">
      <code>${escapeHtml(screen.screen_id)}</code><span>${escapeHtml(screen.title)}</span>
    </button>`).join("");
}

function renderScreen() {
  const screen = currentScreen();
  if (!screen) return;
  $("#loading").hidden = true;
  $("#screen-id").textContent = screen.screen_id;
  $("#screen-kind").textContent = screen.kind;
  $("#screen-title").textContent = screen.title;
  $("#screen-purpose").textContent = screen.purpose;
  const primary = $("#primary-action");
  primary.textContent = screen.primary_action;
  primary.hidden = screen.primary_action === "없음";
  primary.disabled = false;
  const pdfButton = $("#pdf-action");
  const memberPdf = state.role === "MEMBER" && ["detail", "memberEditor", "submission"].includes(screen.kind);
  const leaderPdf = state.role === "LEADER" && ["leaderEditor", "leaderFinal", "compareEvidence", "approve", "history"].includes(screen.kind);
  pdfButton.hidden = !(memberPdf || leaderPdf);
  pdfButton.textContent = memberPdf ? "과제별 PDF 출력" : "팀장보고 PDF 출력";
  pdfButton.dataset.pdfKind = memberPdf ? "MEMBER_PAGES" : leaderPdf ? "TEAM_REPORT" : "";
  $("#screen-body").innerHTML = renderByKind(screen);
  renderNavigation();
  bindScreenForms();
  renderAgentContext();
}

function renderDemoAgentFlow() {
  const flow = $("#demo-agent-flow");
  if (!flow) return;
  flow.querySelectorAll("[data-demo-step]").forEach((button) => {
    const step = Number(button.dataset.demoStep);
    button.classList.toggle("done", step < state.agent.demoStep || (state.agent.demoStep === 4 && step === 4));
    button.classList.toggle("active", step === Math.min(state.agent.demoStep + 1, 4) && state.agent.demoStep < 4);
    button.setAttribute("aria-current", step === state.agent.demoStep ? "step" : "false");
  });
}

function setDemoAgentStep(step) {
  state.agent.demoStep = Math.max(state.agent.demoStep, Math.min(4, Number(step) || 0));
  renderDemoAgentFlow();
  renderAgentContext();
}

function renderAgentContext() {
  if (!state.data) return;
  const screen = currentScreen();
  const screenLabel = screen ? `${screen.screen_id} · ${screen.title}` : "화면 선택 전";
  if ($("#agent-context-screen")) $("#agent-context-screen").textContent = screenLabel;
  const pages = state.data.work_pages || [];
  if (!pages.some((page) => page.id === state.agent.activePageId)) state.agent.activePageId = pages[0]?.id || null;
  const activePage = pages.find((page) => page.id === state.agent.activePageId);
  const pageChip = $("#agent-page-chip");
  if (pageChip) pageChip.textContent = activePage ? `▣ ${activePage.title}` : "Agent 자동분류";
  const pageMenu = $("#agent-page-menu");
  if (pageMenu) {
    pageMenu.innerHTML = pages.map((page) => `<button type="button" class="${page.id === state.agent.activePageId ? "active" : ""}" data-agent-page="${escapeHtml(page.id)}"><strong>${escapeHtml(page.title)}</strong><span>${escapeHtml(page.site_scope)} · ${escapeHtml(page.process_scope)}</span></button>`).join("");
  }
  const count = $("#agent-collected-count");
  if (count) count.textContent = `시연 단계 ${state.agent.demoStep}/4 · 대화 ${state.agent.conversationCount}건`;
  renderDemoAgentFlow();
}

function selectAgentPage(pageId, announce = true) {
  const page = (state.data?.work_pages || []).find((item) => item.id === pageId);
  if (!page) return;
  state.agent.activePageId = page.id;
  if (state.agent.draft) state.agent.draft.targetPageId = page.id;
  $("#agent-page-menu").hidden = true;
  $("#agent-page-chip").setAttribute("aria-expanded", "false");
  renderAgentContext();
  if (announce) appendAgentMessage("assistant", `대화의 기준 업무페이지를 ‘${page.title}’로 변경했습니다. 이후 “보고에 반영해줘”라고 하면 이 페이지에 New 문장으로 추가합니다.`);
}

function hasExplicitZeroValidationErrors(item) {
  return Boolean(item)
    && Object.prototype.hasOwnProperty.call(item, "validation_errors")
    && item.validation_errors !== null
    && item.validation_errors !== ""
    && Number(item.validation_errors) === 0;
}

function isEligibleMetricSnapshot(item) {
  return String(item?.status || "").toUpperCase() === "LOCKED"
    && String(item?.verification_state || "").toUpperCase() === "VERIFIED"
    && hasExplicitZeroValidationErrors(item);
}

function parseAgentResult(rawText) {
  const parseValue = (value, depth = 0) => {
    if (depth > 3) throw new Error("중첩된 Agent 응답이 너무 깊습니다.");
    let text = String(value || "").trim();
    const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
    if (fenced) text = fenced[1].trim();
    if (!text.startsWith("{")) {
      const first = text.indexOf("{");
      const last = text.lastIndexOf("}");
      if (first >= 0 && last > first) text = text.slice(first, last + 1);
    }
    const parsed = JSON.parse(text);
    if (typeof parsed.text === "string" && !parsed.pages) return parseValue(parsed.text, depth + 1);
    return parsed;
  };
  const payload = parseValue(rawText);
  if (!Array.isArray(payload.pages) && (payload.work_page_title || payload.segments)) {
    payload.pages = [{ target_page_id: payload.target_page_id, work_page_title: payload.work_page_title, segments: payload.segments || [] }];
  }
  return payload;
}

function resolveAgentPage(pageResult) {
  const pages = state.data?.work_pages || [];
  return pages.find((page) => page.id === String(pageResult.target_page_id || "").trim()) || null;
}

function validateAgentMetricSegment(segment) {
  const text = String(segment.text || "");
  const refs = Array.isArray(segment.source_refs) ? segment.source_refs.map(String) : [];
  const tag = String(segment.tag || "").toUpperCase();
  const snapshotRefs = refs.filter((ref) => /^SNP-/i.test(ref));
  const quantitative = tag === "KPI"
    || snapshotRefs.length > 0
    || /(?:수율|BM(?:\s*Loss)?|PD(?:\s*Loss)?|불량률|개선|감소|증가|%p|ppm|\d[\d,]*(?:\.\d+)?\s*(?:%|ppm|건|회))/i.test(text);
  if (!quantitative) return { state: "NOT_APPLICABLE", label: "정량 근거 불필요", blocked: false };
  if (String(segment.evidence_state || "").toUpperCase() !== "SNAPSHOT_VERIFIED") {
    return { state: "INVALID_EVIDENCE_STATE", label: "SNAPSHOT_VERIFIED 근거상태 필요", blocked: true };
  }
  if (!snapshotRefs.length) return { state: "MISSING_SNAPSHOT", label: "Snapshot 근거 없음", blocked: true };
  const snapshots = snapshotRefs.map((ref) => (state.data?.snapshots || []).find((item) => item.snapshot_code === ref)).filter(Boolean);
  if (snapshots.length !== snapshotRefs.length) return { state: "UNKNOWN_SNAPSHOT", label: "Snapshot ID 불일치", blocked: true };
  const approved = snapshots.filter(isEligibleMetricSnapshot);
  if (approved.length !== snapshots.length) return { state: "PROVISIONAL", label: "미승인 Snapshot", blocked: true };
  const scopeFields = ["site_scope", "process_scope", "line_scope", "product_scope", "cutoff_at", "unit"];
  const scopeMissing = approved.some((item) => scopeFields.some((field) => String(item[field] ?? "").trim() === ""));
  if (scopeMissing) return { state: "SCOPE_MISSING", label: "Snapshot 필수 범위·기준시각·단위 누락", blocked: true };
  const scopeAmbiguous = approved.some((item) => scopeFields.some((field) => String(item[field]).includes(",")));
  if (scopeAmbiguous) return { state: "SCOPE_AMBIGUOUS", label: "Snapshot 범위가 둘 이상으로 집계됨", blocked: true };
  if (approved.length > 1) {
    const scopeKeys = new Set(approved.map((item) => scopeFields.map((field) => String(item[field])).join("|")));
    if (scopeKeys.size !== 1) return { state: "SCOPE_MISMATCH", label: "Snapshot 비교범위 불일치", blocked: true };
  }
  const normalizeUnit = (value) => {
    const unit = String(value || "").trim();
    if (unit.toLowerCase() === "ppm") return "ppm";
    if (unit === "퍼센트") return "%";
    return unit;
  };
  const expectedValues = approved.flatMap((item) => {
    const current = Number(item.display_value);
    const previous = Number(item.previous_value);
    const target = Number(item.target_value);
    const unit = normalizeUnit(item.unit);
    const deltaUnit = unit === "%" ? "%p" : unit;
    return [
      { value: current, unit },
      { value: previous, unit },
      { value: target, unit },
      { value: Number.isFinite(current - previous) ? current - previous : NaN, unit: deltaUnit },
      { value: Number.isFinite(current - previous) ? Math.abs(current - previous) : NaN, unit: deltaUnit },
    ].filter((entry) => Number.isFinite(entry.value));
  });
  const escapeRegExp = (value) => value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const supportedUnits = [...new Set([
    "%p", "%", "퍼센트", "ppm", "건", "회",
    ...approved.map((item) => normalizeUnit(item.unit)),
  ].filter(Boolean))].sort((left, right) => right.length - left.length);
  const unitPattern = supportedUnits.map(escapeRegExp).join("|");
  const measurementPattern = unitPattern
    ? new RegExp(`(-?\\d[\\d,]*(?:\\.\\d+)?)\\s*(${unitPattern})`, "gi")
    : null;
  const mentioned = measurementPattern
    ? [...text.matchAll(measurementPattern)]
      .map((match) => ({ value: Number(match[1].replace(/,/g, "")), unit: normalizeUnit(match[2]) }))
    : [];
  const textWithoutIdentifiers = text
    .replace(/SNP-[A-Z0-9-]+/gi, " ")
    .replace(/\b(?:W|M|K|L|GM)\d+\b/gi, " ")
    .replace(/\b\d{4}-\d{1,2}-\d{1,2}\b/g, " ")
    .replace(measurementPattern || /$^/, " ");
  const hasUnqualifiedNumber = /-?\d[\d,]*(?:\.\d+)?/.test(textWithoutIdentifiers);
  if (!mentioned.length) {
    return { state: "VALUE_MISSING", label: "Snapshot에 대응하는 수치·단위 없음", blocked: true };
  }
  if (hasUnqualifiedNumber) {
    return { state: "VALUE_MISMATCH", label: "Snapshot 수치의 단위 누락 또는 불일치", blocked: true };
  }
  const numberMatches = (left, right) => Math.abs(left - right) <= Math.max(1e-6, Math.abs(right) * 1e-9);
  if (mentioned.some((entry) => !expectedValues.some((expected) => expected.unit === entry.unit && numberMatches(entry.value, expected.value)))) {
    return { state: "VALUE_MISMATCH", label: "Snapshot 수치 또는 단위 불일치", blocked: true };
  }
  return { state: "VERIFIED", label: `승인 Snapshot ${snapshotRefs.length}건`, blocked: false };
}

function stageAgentResult(rawText) {
  const payload = parseAgentResult(rawText);
  const questions = (Array.isArray(payload.questions) ? payload.questions : []).filter(Boolean).slice(0, 3);
  const warnings = (Array.isArray(payload.warnings) ? payload.warnings : []).filter(Boolean);
  const errors = [];
  const allowedTags = new Set(["FACT", "KPI", "RESULT", "ANALYSIS", "PLAN", "RISK", "DECISION"]);
  const pageMap = new Map();
  if (payload.ready_for_review !== true) errors.push("ready_for_review가 true인 최종 응답이 필요합니다.");
  if (questions.length) errors.push("확인 질문에 답한 뒤 최종 응답을 다시 가져오십시오.");
  const pageResults = Array.isArray(payload.pages) ? payload.pages : [];
  if (!pageResults.length) errors.push("반영할 업무페이지 결과가 없습니다.");
  pageResults.slice(0, 10).forEach((pageResult, pageIndex) => {
    const page = resolveAgentPage(pageResult);
    if (!page) {
      errors.push(`${pageIndex + 1}번째 결과의 target_page_id가 포털에 존재하지 않습니다.`);
      return;
    }
    if (!pageMap.has(page.id)) pageMap.set(page.id, { page, included: true, segments: [], keys: new Set() });
    const bucket = pageMap.get(page.id);
    (Array.isArray(pageResult.segments) ? pageResult.segments : []).slice(0, 30).forEach((segment, segmentIndex) => {
      const tag = String(segment.tag || "").toUpperCase();
      const text = formalizeAgentNarrative(String(segment.text || segment.body || "").trim(), tag);
      if (!allowedTags.has(tag)) {
        warnings.push(`${page.title}의 ${segmentIndex + 1}번째 문장은 지원하지 않는 태그(${tag || "없음"})라 제외됩니다.`);
        return;
      }
      if (!text || text.length > 560) {
        warnings.push(`${page.title}의 ${segmentIndex + 1}번째 문장은 비어 있거나 560자를 초과하여 제외됩니다.`);
        return;
      }
      const key = `${tag}|${text}`;
      if (bucket.keys.has(key)) return;
      bucket.keys.add(key);
      const normalized = {
        id: `${page.id}-${bucket.segments.length + 1}`,
        sequence: Number(segment.sequence || bucket.segments.length + 1),
        tag,
        text,
        change_type: ["NEW", "UPDATED"].includes(String(segment.change_type || "").toUpperCase()) ? String(segment.change_type).toUpperCase() : "NEW",
        evidence_state: String(segment.evidence_state || "USER_INPUT").toUpperCase(),
        source_refs: Array.isArray(segment.source_refs) ? [...new Set(segment.source_refs.map(String))] : [],
        included: true,
      };
      normalized.metric = validateAgentMetricSegment(normalized);
      if (normalized.metric.blocked) warnings.push(`‘${page.title}’ ${tag} 문장: ${normalized.metric.label}. 해당 문장을 제외하거나 Snapshot 근거를 보완하십시오.`);
      bucket.segments.push(normalized);
    });
  });
  const pages = [...pageMap.values()].map((item) => {
    delete item.keys;
    if (!item.segments.length) errors.push(`‘${item.page.title}’에 반영 가능한 문장이 없습니다.`);
    return item;
  });
  const hasBlockedMetric = pages.some((page) => page.segments.some((segment) => segment.included && segment.metric.blocked));
  return {
    payload,
    questions,
    warnings,
    errors,
    pages,
    canApply: errors.length === 0 && !hasBlockedMetric && pages.some((page) => page.segments.length),
  };
}

function renderAgentResultPreview(staged) {
  const preview = $("#agent-result-preview");
  const applyButton = $("#apply-agent-result");
  const status = $("#agent-import-status");
  if (!preview || !applyButton || !status) return;
  const pageCards = staged.pages.map(({ page, segments, included }) => `
    <article class="agent-preview-page" data-review-page="${escapeHtml(page.id)}">
      <header><label><input type="checkbox" data-review-page-check ${included ? "checked" : ""}><span><code>${escapeHtml(page.page_code)}</code><strong>${escapeHtml(page.title)}</strong></span></label><small>${segments.length}개 문장</small></header>
      <div class="agent-preview-segments">${segments.map((segment) => `
        <div class="agent-preview-segment" data-review-segment="${escapeHtml(segment.id)}">
          <input type="checkbox" data-review-segment-check ${segment.included ? "checked" : ""} aria-label="문장 포함">
          <div>${reportTag(segment.tag)}${reportTag(segment.change_type)}</div>
          <textarea data-review-segment-text aria-label="${escapeHtml(segment.tag)} 문장">${escapeHtml(segment.text)}</textarea>
          <div class="agent-preview-segment-meta"><span class="agent-metric-state ${segment.metric.blocked ? "blocked" : segment.metric.state === "VERIFIED" ? "verified" : ""}">${escapeHtml(segment.metric.label)}</span><span>${escapeHtml(segment.evidence_state)}</span><span>${escapeHtml(segment.source_refs.join(", ") || "직접 입력")}</span></div>
        </div>`).join("")}</div>
    </article>`).join("");
  const issues = [
    ...staged.errors.map((item) => `<li class="error">${escapeHtml(item)}</li>`),
    ...staged.warnings.map((item) => `<li class="warning">${escapeHtml(item)}</li>`),
    ...staged.questions.map((item) => `<li class="question">${escapeHtml(item)}</li>`),
  ].join("");
  preview.innerHTML = `${pageCards || '<div class="empty-state">미리볼 변경사항이 없습니다.</div>'}${issues ? `<section class="agent-preview-issues"><strong>확인 사항</strong><ul>${issues}</ul></section>` : ""}`;
  preview.hidden = false;
  applyButton.disabled = !staged.canApply;
  status.textContent = staged.canApply
    ? `${staged.pages.length}개 업무페이지를 찾았습니다. 포함 여부와 문장을 확인한 뒤 반영하십시오.`
    : "오류 또는 확인 질문이 남아 있어 반영할 수 없습니다.";
}

function extractVisibleAgentReply(rawText) {
  const withoutCode = String(rawText || "").replace(/```(?:json)?[\s\S]*?```/gi, "").trim();
  return withoutCode && !/^\s*\{[\s\S]*\}\s*$/.test(withoutCode)
    ? withoutCode.slice(0, 1800)
    : "Demo Agent의 구조화 결과를 준비했습니다. 아래 미리보기에서 업무페이지와 문장을 확인해 주세요.";
}

function previewAgentResult() {
  const raw = $("#agent-result-json")?.value || "";
  state.agent.pendingImport = null;
  $("#apply-agent-result").disabled = true;
  if (!raw.trim()) { showToast("검토할 Demo Agent 결과가 없습니다.", true); return; }
  try {
    const staged = stageAgentResult(raw);
    state.agent.pendingImport = staged;
    renderAgentResultPreview(staged);
    appendAgentMessage("assistant", extractVisibleAgentReply(raw), { record: false });
    if (!staged.canApply) showToast("확인 질문 또는 수치 근거 오류가 남아 있습니다.", true);
  } catch (error) {
    const preview = $("#agent-result-preview");
    preview.hidden = false;
    preview.innerHTML = `<div class="agent-preview-invalid"><strong>응답의 JSON을 해석하지 못했습니다.</strong><p>${escapeHtml(error.message)}</p></div>`;
    $("#agent-import-status").textContent = "Agent 응답에서 JSON 코드블록 전체를 복사해 다시 시도하십시오.";
    showToast(`JSON 형식을 확인하십시오: ${error.message}`, true);
  }
}

function stageDirectAgentResult(rawText) {
  const staged = stageAgentResult(rawText);
  state.agent.pendingImport = staged;
  const input = $("#agent-result-json");
  if (input) input.value = rawText;
  renderAgentResultPreview(staged);
  return staged;
}

function collectAgentReviewSelection(staged) {
  const selectedPages = [];
  staged.errors = staged.errors.filter((item) => !String(item).startsWith("수정 후 검증:"));
  staged.pages.forEach((pageEntry) => {
    const pageElement = $(`[data-review-page="${pageEntry.page.id}"]`);
    const pageIncluded = Boolean($("[data-review-page-check]", pageElement)?.checked);
    if (!pageIncluded) return;
    const segments = [];
    pageEntry.segments.forEach((segment) => {
      const segmentElement = $(`[data-review-segment="${segment.id}"]`, pageElement);
      if (!$("[data-review-segment-check]", segmentElement)?.checked) return;
      const text = formalizeAgentNarrative($("[data-review-segment-text]", segmentElement)?.value || "", segment.tag);
      const reviewed = { ...segment, text };
      reviewed.metric = validateAgentMetricSegment(reviewed);
      if (!text) staged.errors.push("수정 후 검증: 빈 문장은 반영할 수 없습니다.");
      if (reviewed.metric.blocked) staged.errors.push(`수정 후 검증: ‘${pageEntry.page.title}’ ${reviewed.metric.label}`);
      segments.push(reviewed);
    });
    if (segments.length) selectedPages.push({ target_page_id: pageEntry.page.id, segments });
  });
  staged.canApply = staged.errors.length === 0 && selectedPages.length > 0;
  return selectedPages;
}

function updateAgentReviewReadiness() {
  const staged = state.agent.pendingImport;
  if (!staged) return;
  const selectedPages = collectAgentReviewSelection(staged);
  const applyButton = $("#apply-agent-result");
  const status = $("#agent-import-status");
  if (applyButton) applyButton.disabled = !staged.canApply;
  if (status) status.textContent = staged.canApply
    ? `${selectedPages.length}개 업무페이지의 선택 문장을 반영할 수 있습니다.`
    : "선택한 문장에 확인 질문 또는 수치 근거 오류가 남아 있습니다.";
}

async function applyAgentResultReview() {
  const staged = state.agent.pendingImport;
  if (!staged) { showToast("먼저 변경 미리보기를 실행하십시오.", true); return; }
  if (state.role !== "MEMBER") { showToast("현재 버전의 업무 Agent 반영은 팀원 역할에서만 가능합니다.", true); return; }
  const button = $("#apply-agent-result");
  try {
    const pages = collectAgentReviewSelection(staged);
    if (!staged.canApply) {
      renderAgentResultPreview(staged);
      throw new Error("선택 문장 또는 수치 근거를 다시 확인하십시오.");
    }
    button.disabled = true;
    button.textContent = "반영 중…";
    const requestId = `agent-${Date.now()}-${Math.random().toString(16).slice(2)}`;
    const applied = await api("/api/agent/apply-result", {
      method: "POST",
      headers: { "Idempotency-Key": requestId },
      body: JSON.stringify({ role: state.role, pages, questions: [], warnings: staged.warnings, ready_for_review: true, request_id: requestId }),
    });
    state.generatedDraft = applied.content;
    state.agent.pendingImport = null;
    $("#agent-result-dialog")?.close();
    await refreshCurrent();
    navigateTo("MBR-07");
    setDemoAgentStep(4);
    appendAgentMessage("assistant", `${applied.message || "검토한 문장을 반영하였습니다."}\n왼쪽 MBR-07에서 업무페이지별 파란색 New 문장을 바로 확인할 수 있습니다.`, { record: false });
    showToast(applied.message || "선택한 Agent 결과를 반영하였습니다.");
  } catch (error) {
    showToast(error.message, true);
  } finally {
    button.textContent = "선택 내용 바로 반영";
    button.disabled = !state.agent.pendingImport?.canApply;
  }
}

async function readAgentClipboard() {
  const input = $("#agent-result-json");
  if (!navigator.clipboard?.readText) { input.focus(); showToast("클립보드 읽기를 지원하지 않습니다. 응답을 직접 붙여넣으세요.", true); return; }
  try {
    input.value = await navigator.clipboard.readText();
    state.agent.pendingImport = null;
    previewAgentResult();
  } catch {
    input.focus();
    showToast("클립보드 권한을 허용하거나 응답을 직접 붙여넣으세요.", true);
  }
}

function openAgentResultDialog() {
  const dialog = $("#agent-result-dialog");
  if (!dialog?.open) dialog?.showModal();
  if (state.agent.pendingImport) {
    $("#agent-result-preview [data-review-page-check]")?.focus();
  } else {
    $("#agent-result-json")?.focus();
  }
}

function appendAgentMessage(role, text, options = {}) {
  const messages = $("#agent-messages");
  if (!messages) return;
  const welcome = $("#agent-welcome");
  if (welcome) welcome.hidden = true;
  const article = document.createElement("article");
  article.className = `agent-message-row ${role}`;
  const avatar = document.createElement("div");
  avatar.className = "agent-message-avatar";
  avatar.textContent = role === "user" ? (state.data?.principal?.display_name || "나").slice(0, 1) : "AI";
  const content = document.createElement("div");
  content.className = "agent-message-content";
  const label = document.createElement("strong");
  label.textContent = role === "user" ? (state.data?.principal?.display_name || "나") : "Demo Agent";
  const copy = document.createElement("div");
  copy.className = "agent-message-copy";
  copy.textContent = text;
  content.append(label, copy);
  if (options.attachment) {
    const file = document.createElement("div");
    file.className = "agent-inline-file";
    file.textContent = `▤ ${options.attachment.name}`;
    content.appendChild(file);
  }
  if (options.draft) content.insertAdjacentHTML("beforeend", renderAgentCandidate(options.draft));
  if (options.suggestions?.length) {
    const suggestions = document.createElement("div");
    suggestions.className = "agent-followups";
    suggestions.innerHTML = options.suggestions.map((suggestion) => `<button type="button" data-agent-prompt="${escapeHtml(suggestion)}">${escapeHtml(suggestion)}</button>`).join("");
    content.appendChild(suggestions);
  }
  if (options.portalTransfer) {
    const staged = options.portalTransfer;
    const segmentCount = staged.pages.reduce((total, page) => total + page.segments.length, 0);
    const transfer = document.createElement("section");
    transfer.className = "agent-transfer-ready";
    transfer.innerHTML = `
      <div><strong>포털 반영 초안이 준비되었습니다.</strong><span>${staged.pages.length}개 업무페이지 · ${segmentCount}개 문장</span></div>
      <p>${staged.canApply ? "업무페이지와 문장을 확인한 뒤 즉시 New로 반영할 수 있습니다." : "확인 질문 또는 수치 근거를 보완해야 합니다."}</p>
      <button type="button" class="primary" data-open-agent-preview>초안 확인·바로 반영</button>`;
    content.appendChild(transfer);
  }
  article.append(avatar, content);
  messages.appendChild(article);
  messages.scrollTop = messages.scrollHeight;
  if (options.record !== false && ["user", "assistant"].includes(role) && text) {
    state.agent.messages.push({ role, content: String(text) });
    state.agent.messages = state.agent.messages.slice(-16);
  }
}

function renderAgentCandidate(draft) {
  const page = (state.data?.work_pages || []).find((item) => item.id === draft.targetPageId);
  return `<section class="agent-candidate"><div class="agent-candidate-top"><div>${reportTag(draft.tag)}${reportTag("NEW")}</div><span>${escapeHtml(page?.title || "Agent 분류 대기")}</span></div><p>${escapeHtml(draft.body)}</p><div class="agent-candidate-source"><span>근거</span><strong>${escapeHtml(agentSourceLabels[draft.sourceMode] || draft.sourceMode)} · ${escapeHtml(draft.sourceTitle)}</strong></div><div class="agent-candidate-actions"><button type="button" data-agent-prompt="더 간결하게 다듬어줘">더 간결하게</button><button type="button" data-agent-prompt="Plan 문장으로 바꿔줘">Plan으로 변경</button><button type="button" class="primary" data-agent-apply-chat>보고에 반영</button></div></section>`;
}

function cleanAgentSource(text, mode) {
  let value = String(text || "").replace(/\r/g, "").trim();
  if (mode === "MAIL") {
    value = value
      .split("\n")
      .filter((line) => !/^\s*(아래|이|다음).*메일.*(?:추출|정리|요약|추가|작성).*$/i.test(line))
      .filter((line) => !/^\s*(보낸 사람|받는 사람|참조|보낸 날짜|제목|from|to|cc|sent|subject)\s*:/i.test(line))
      .filter((line) => !/^\s*(감사합니다|고맙습니다|best regards)[.!\s]*$/i.test(line))
      .join("\n");
  }
  return value
    .replace(/^[-•·]\s*/gm, "")
    .replace(/\n{2,}/g, "\n")
    .replace(/[ \t]+/g, " ")
    .trim();
}

function inferAgentTag(text) {
  const value = String(text || "");
  if (/지연|미확정|불가|우려|위험|리스크|차질/.test(value)) return "RISK";
  if (/분석|원인|영향|상관|가설|추정|가능성/.test(value)) return "ANALYSIS";
  if (/예정|계획|까지|추진|진행할|확정 후|차주|W3[5-9]/i.test(value)) return "PLAN";
  if (/완료|확인|검증|적용|개선|협의/.test(value)) return "RESULT";
  return "FACT";
}

function formalizeAgentNarrative(text, tag) {
  let value = String(text || "")
    .replace(/확인함(?=[.\s]|$)/g, "확인하였습니다")
    .replace(/완료함(?=[.\s]|$)/g, "완료하였습니다")
    .replace(/진행하였다(?=[.\s]|$)/g, "진행하였습니다")
    .replace(/확인하였다(?=[.\s]|$)/g, "확인하였습니다")
    .replace(/검토하였다(?=[.\s]|$)/g, "검토하였습니다")
    .replace(/진행 예정임(?=[.\s]|$)/g, "진행할 예정입니다")
    .replace(/필요함(?=[.\s]|$)/g, "필요합니다")
    .replace(/검토 부탁드립니다[.!]?/g, "검토가 필요합니다.")
    .trim();
  const lines = value.split("\n").map((line) => line.trim()).filter(Boolean);
  value = lines.join(" ");
  if (value.length > 560) value = `${value.slice(0, 557).trim()}…`;
  if (value && !/[.!?。]$/.test(value)) value += ".";
  if (tag === "PLAN" && !/예정|계획|진행|확정|추진|완료하겠습니다/.test(value)) {
    value = `${value.replace(/[.]$/, "")}를 차주 계획에 반영하겠습니다.`;
  }
  return value;
}

function agentPageFromPrompt(prompt) {
  const pages = state.data?.work_pages || [];
  if (/GM1|GM2|VM|NND/i.test(prompt)) return pages.find((page) => page.id === "pg_vm");
  if (/로딩|Feedforward|코터|Coater/i.test(prompt)) return pages.find((page) => page.id === "pg_loading");
  if (/Tension|K12|Jamming|M08|M11|MI_LS|장력/i.test(prompt)) return pages.find((page) => page.id === "pg_tension");
  return pages.find((page) => prompt.includes(page.title)) || null;
}

function currentMemberDraftContent() {
  if (state.generatedDraft) return state.generatedDraft;
  const submission = state.data?.submissions?.find((item) => item.member_user_id === state.data?.principal?.id) || state.data?.submissions?.[0];
  return state.data?.submission_versions?.find((item) => item.submission_id === submission?.id)?.content || "";
}

function workHistoryForPage(page) {
  const itemIds = String(page?.work_item_ids || "").split(",").filter(Boolean);
  return (state.data?.worklogs || [])
    .filter((item) => itemIds.includes(item.work_item_id))
    .slice()
    .sort((left, right) => String(right.occurred_on).localeCompare(String(left.occurred_on)))
    .slice(0, 5);
}

function setAgentDraft(draft) {
  state.agent.draft = draft;
  state.agent.activePageId = draft.targetPageId;
  renderAgentContext();
  return draft;
}

function modifyAgentDraft(prompt) {
  const draft = { ...state.agent.draft };
  if (/Plan|계획/i.test(prompt)) draft.tag = "PLAN";
  else if (/Analysis|분석/i.test(prompt)) draft.tag = "ANALYSIS";
  else if (/Risk|리스크|위험/i.test(prompt)) draft.tag = "RISK";
  else if (/Result|결과/i.test(prompt)) draft.tag = "RESULT";
  else if (/Fact|사실/i.test(prompt)) draft.tag = "FACT";
  if (/간결|짧게|줄여/.test(prompt)) {
    const sentences = draft.body.match(/[^.!?]+[.!?]?/g) || [draft.body];
    draft.body = sentences.slice(0, 2).join(" ").trim();
  }
  if (/자세|구체|근거.*추가/.test(prompt)) {
    draft.body = `${draft.body.replace(/[.]$/, "")} 적용 대상·검증 조건·완료 기준은 Evidence와 동일한 기준으로 확인하고, 미확정 항목은 차주 계획으로 분리하겠습니다.`;
  }
  const page = agentPageFromPrompt(prompt);
  if (page && /페이지|업무|반영|이쪽|여기/.test(prompt)) draft.targetPageId = page.id;
  return setAgentDraft(draft);
}

function demoWeeklyWorklogs() {
  const pageItemIds = new Set((state.data?.work_pages || []).flatMap((page) => pageWorkItemIds(page)));
  return (state.data?.worklogs || []).filter((item) => pageItemIds.has(item.work_item_id) && String(item.occurred_on) >= "2026-08-24");
}

function demoSourceInventoryMessage() {
  const logs = demoWeeklyWorklogs();
  const evidence = (state.data?.evidence || []).filter((item) => (state.data?.work_items || []).some((work) => work.id === item.work_item_id));
  const approved = (state.data?.snapshots || []).filter(isEligibleMetricSnapshot);
  return `시연용 업무자료를 불러왔습니다.\n\n• 업무페이지 ${(state.data?.work_pages || []).length}개\n• 금주 Worklog ${logs.length}건\n• 최근 4주 이력 ${(state.data?.worklogs || []).length}건\n• Evidence ${evidence.length}건\n• 승인·잠금 KPI Snapshot ${approved.length}건\n\n업무페이지를 보고 단위로 유지하고, 공동작성 기록과 최근 4주 서술을 함께 사용하겠습니다.`;
}

function demoWeeklySummaryMessage() {
  const summaries = (state.data?.work_pages || []).map((page) => {
    const pageIds = new Set(pageWorkItemIds(page));
    const logs = demoWeeklyWorklogs().filter((item) => pageIds.has(item.work_item_id));
    const latest = logs.slice().sort((left, right) => String(right.occurred_on).localeCompare(String(left.occurred_on))).slice(0, 2);
    const detail = latest.length
      ? latest.map((item) => `${item.entry_type} · ${formalizeAgentNarrative(item.narrative, item.entry_type === "NEXT" ? "PLAN" : item.entry_type)}`).join(" / ")
      : "금주 변경 없음";
    return `• ${page.title}\n  ${detail}`;
  });
  return `이번 주 업무를 3개 업무페이지 기준으로 정리했습니다.\n\n${summaries.join("\n\n")}\n\n기존 4주 이력은 유지하고, 위 금주 변경분만 파란색 New 후보로 만들 수 있습니다.`;
}

function demoKpiValidationMessage() {
  const approved = (state.data?.snapshots || []).filter(isEligibleMetricSnapshot);
  const blocked = (state.data?.snapshots || []).filter((item) => !isEligibleMetricSnapshot(item));
  const approvedRows = approved.map((item) => `• 사용 가능 · ${item.metric_name} ${Number(item.display_value).toFixed(1)}${item.unit} · ${item.snapshot_code}`).join("\n");
  const blockedRows = blocked.map((item) => `• 제외 · ${item.metric_name} ${Number(item.display_value).toFixed(1)}${item.unit} · ${item.verification_state}`).join("\n");
  return `KPI Snapshot 검증을 완료했습니다.\n\n${approvedRows}\n${blockedRows ? `\n${blockedRows}` : ""}\n\n초안에는 승인·잠금·검증완료 조건을 모두 충족한 수율 Snapshot만 사용하고, PD Loss 잠정값은 제외하겠습니다.`;
}

function buildDemoPortalTransfer() {
  return {
    pages: [
      {
        target_page_id: "pg_tension",
        segments: [
          { tag: "RESULT", text: "M08·M11 반복시험에서 제품별 보정 방향이 일관되게 나타나는 것을 확인하였습니다.", change_type: "NEW", evidence_state: "SOURCE_REFERENCED", source_refs: ["EVD-RSND-2026-W35-028"] },
          { tag: "ANALYSIS", text: "K12는 생산조건 차이의 영향을 분리하기 위해 동일 조건 재현성 검증이 추가로 필요합니다.", change_type: "NEW", evidence_state: "SOURCE_REFERENCED", source_refs: ["EVD-RSND-2026-W35-029"] },
          { tag: "RISK", text: "K12 검증용 생산 일정이 확정되지 않아 제품별 적용조건 확정 일정이 지연될 가능성이 있습니다.", change_type: "NEW", evidence_state: "USER_INPUT", source_refs: [] },
          { tag: "PLAN", text: "8월 27일까지 K12 재현성 검증을 완료하고 제품별 상·하한과 예외조건을 확정할 예정입니다.", change_type: "NEW", evidence_state: "SOURCE_REFERENCED", source_refs: ["EVD-RSND-2026-W35-029"] },
          { tag: "KPI", text: "W35 수율은 92.4%로 전주 91.8% 대비 0.6%p 증가하였습니다.", change_type: "NEW", evidence_state: "SNAPSHOT_VERIFIED", source_refs: ["SNP-YIELD-2026-W35-003"] },
        ],
      },
      {
        target_page_id: "pg_loading",
        segments: [
          { tag: "RESULT", text: "코터 로딩량과 Roll Press Tension 데이터의 전처리 및 예측모델 연계 가능성을 확인하였습니다.", change_type: "NEW", evidence_state: "SOURCE_REFERENCED", source_refs: [] },
          { tag: "PLAN", text: "8월 28일까지 Feedforward 자동보정 로직과 설비별 기준정보를 확정할 예정입니다.", change_type: "NEW", evidence_state: "USER_INPUT", source_refs: [] },
        ],
      },
      {
        target_page_id: "pg_vm",
        segments: [
          { tag: "RESULT", text: "RP·NND 기준정보 표준화와 VM 제작사양서 초안 작성을 완료하였습니다.", change_type: "NEW", evidence_state: "SOURCE_REFERENCED", source_refs: [] },
          { tag: "PLAN", text: "8월 28일까지 VM·응용 환경 설정 범위와 제작사양서를 확정하고 데이터 수집 일정을 연결할 예정입니다.", change_type: "NEW", evidence_state: "USER_INPUT", source_refs: [] },
        ],
      },
    ],
    questions: [],
    warnings: ["PD Loss Snapshot은 승인 조건 미충족으로 수치 문장에서 제외하였습니다."],
    ready_for_review: true,
  };
}

function createAgentResponse(prompt, attachment = null) {
  const page = agentPageFromPrompt(prompt);
  if (page) state.agent.activePageId = page.id;
  const compact = prompt.replace(/\s+/g, " ").trim();

  if (/시연 시작|업무.*불러|자료.*확인/.test(compact)) {
    setDemoAgentStep(1);
    return { message: demoSourceInventoryMessage(), suggestions: ["이번 주 업무를 업무페이지별로 요약해 주세요."] };
  }
  if (/이번 주 업무.*요약|한 주간 업무|업무페이지별로 (?:정리|요약)/.test(compact)) {
    setDemoAgentStep(2);
    return { message: demoWeeklySummaryMessage(), suggestions: ["최근 4주 서술은 유지하고 금주 신규·변경분으로 주간보고 초안을 작성해 주세요."] };
  }
  if (/주간보고 초안|초안.*작성|초안.*만들/.test(compact)) {
    const payload = buildDemoPortalTransfer();
    const staged = stageDirectAgentResult(JSON.stringify(payload));
    state.agent.demoPayload = payload;
    setDemoAgentStep(3);
    return {
      message: "3개 업무페이지에 금주 New 초안을 만들었습니다. Result·Analysis·Risk·Plan과 승인 KPI를 분리했고, 미승인 PD Loss는 제외했습니다.",
      portalTransfer: staged,
      suggestions: ["승인된 KPI Snapshot만 사용 가능한지 확인해 주세요."],
    };
  }
  if (/개선.*수치|KPI.*(?:확인|검증)|Snapshot/.test(compact)) {
    return { message: demoKpiValidationMessage(), suggestions: ["만든 초안을 확인하고 포털에 바로 반영해 주세요."] };
  }
  if (/바로 반영|확인하고.*반영|포털.*반영/.test(compact) && state.agent.pendingImport) {
    return { message: "반영 전 검토 화면을 열었습니다. 업무페이지와 문장을 확인한 뒤 ‘선택 내용 바로 반영’을 누르십시오.", openPreview: true };
  }

  if (/할 수 있|사용법|어떻게 써|도와줄 수/.test(compact)) {
    return { message: "이 Demo Agent는 포털 안의 시연 데이터만 사용합니다. ① 업무 불러오기 ② 업무페이지별 요약 ③ New 초안 생성 ④ 사용자 확인 후 즉시 반영 순서로 동작합니다.", suggestions: ["시연 시작 · 이번 주 업무를 불러와 주세요."] };
  }
  if (/안녕|반가워/.test(compact)) {
    return { message: "안녕하세요. 업무이력이나 메일 내용을 그대로 입력해 주세요. 필요한 보고문장을 만들고 대화로 수정한 뒤 왼쪽 업무페이지에 반영하겠습니다.", suggestions: ["내 최근 업무이력을 정리해줘", "메일 내용에서 보고사항을 추출해줘"] };
  }
  if (state.agent.draft && /반영해|추가해|보고에 넣|업무페이지에 넣|이대로 저장/.test(compact)) return { apply: true };
  if (state.agent.draft && /간결|짧게|줄여|자세|구체|Plan|계획|Analysis|분석|Risk|리스크|Result|결과|Fact|사실|페이지로/i.test(compact)) {
    const draft = modifyAgentDraft(compact);
    return { message: "요청한 방식으로 보고문장을 다시 구성했습니다. 추가 수정도 대화로 요청할 수 있습니다.", draft, suggestions: ["조금 더 자세히 써줘", "이 내용을 보고에 반영해줘"] };
  }
  if (/최근.*업무|업무이력|Worklog|지난.*작성|이번 주.*한 일/i.test(compact)) {
    if (!page) {
      const pageSummaries = (state.data?.work_pages || []).map((item) => {
        const latest = workHistoryForPage(item)[0];
        return `• ${item.title}: ${latest ? `${latest.occurred_on} · ${latest.entry_type} · ${latest.narrative}` : "최근 기록 없음"}`;
      }).join("\n");
      return { message: `전체 업무페이지의 최근 이력을 확인했습니다.\n\n${pageSummaries}\n\n보고문장을 만들 대상이 명확하지 않습니다. 아래 중 어느 업무에 대한 금주 내용을 작성할까요?\n1. Tension·Jamming 자동보정\n2. 로딩량 연계 Feedforward 자동보정\n3. GM1·2 VM 기반 자동보정`, suggestions: ["M08·M11 Tension 업무로 정리해줘", "로딩량 연계 업무로 정리해줘", "GM1·2 VM 업무로 정리해줘"] };
    }
    const history = workHistoryForPage(page);
    if (!history.length) return { message: `‘${page.title}’에 조회할 업무이력이 없습니다. 업무내용을 직접 입력해 주세요.` };
    const listing = history.map((item) => `• ${item.occurred_on} · ${item.entry_type}: ${item.narrative}`).join("\n");
    const candidate = history[0];
    const tag = candidate.entry_type === "NEXT" ? "PLAN" : candidate.entry_type;
    const draft = setAgentDraft({ sourceMode: "WORK_HISTORY", sourceTitle: `${page.title} 최근 업무이력`, targetPageId: page.id, tag, body: formalizeAgentNarrative(candidate.narrative, tag) });
    return { message: `입력 내용을 ‘${page.title}’ 업무페이지로 분류했습니다. 최근 이력은 다음과 같습니다.\n\n${listing}\n\n가장 최근 기록을 기준으로 금주 보고 후보를 만들었습니다.`, draft, suggestions: ["최근 2건을 합쳐서 더 자세히 써줘", "Plan 문장으로 바꿔줘", "이 내용을 보고에 반영해줘"] };
  }
  if (/현재.*초안|초안.*빠|보완점|누락/.test(compact)) {
    const content = currentMemberDraftContent();
    const missing = [];
    if (!content.includes("[RISK]")) missing.push("Risk");
    if (!content.includes("[PLAN]")) missing.push("Plan");
    if (!content.includes("[ANALYSIS]")) missing.push("Analysis");
    const answer = missing.length ? `${missing.join("·")} 항목이 부족합니다.` : "Result·Analysis·Plan·Risk가 모두 포함되어 있습니다.";
    return { message: `${answer} 현재 초안은 4주 이력과 금주 New를 유지하고 있으므로, 확정되지 않은 효과와 차주 검증 일정을 우선 보완하는 것이 좋습니다.`, suggestions: ["K12 검증 계획을 Plan으로 작성해줘", "현재 문장을 더 구체적으로 만들어줘"] };
  }

  let sourceMode = "CHAT";
  let sourceTitle = "업무 Agent 대화 입력";
  let sourceText = compact;
  if (attachment) {
    sourceMode = "FILE";
    sourceTitle = attachment.name;
    if (!attachment.text && /파일.*요약|첨부.*분석|내용.*정리/.test(compact)) {
      return { message: `‘${attachment.name}’ 파일을 첨부했습니다. 이 시연에서는 파일명과 텍스트 발췌를 처리합니다. 실제 사내 GPT 연결 시 파일 본문을 직접 읽게 되며, 현재는 보고에 넣을 핵심 내용을 메시지에 함께 적어 주세요.`, suggestions: ["K12 검증 일정과 반복시험 결과를 보고문장으로 작성해줘"] };
    }
    sourceText = attachment.text ? `${attachment.text}\n${compact}` : compact;
  } else if (/메일|보낸 사람|받는 사람|제목\s*:|from\s*:|subject\s*:/i.test(compact)) {
    sourceMode = "MAIL";
    sourceTitle = compact.match(/(?:제목|subject)\s*:\s*([^\n]+)/i)?.[1]?.trim() || "사용자 선택 메일 발췌";
  }
  const cleaned = cleanAgentSource(sourceText, sourceMode);
  if (!cleaned) return { message: "분석할 내용을 입력하거나 파일을 첨부해 주세요." };
  if (!page) {
    return { message: "입력 내용만으로 대상 업무페이지를 확정하기 어렵습니다. 임의로 배치하지 않겠습니다.\n\n1. 어느 법인·공정 또는 프로젝트의 업무입니까?\n2. Tension·Jamming, 로딩량 연계, GM1·2 VM 중 어느 업무와 가장 관련됩니까?\n3. 여러 업무에 공통이라면 각 업무페이지에 나누어 반영할 내용을 알려주시겠습니까?", suggestions: ["M08·M11 Tension 업무입니다", "로딩량 연계 Feedforward 업무입니다", "GM1·2 VM 업무입니다"] };
  }
  const tag = inferAgentTag(cleaned);
  const draft = setAgentDraft({ sourceMode, sourceTitle, targetPageId: page?.id, tag, body: formalizeAgentNarrative(cleaned, tag) });
  const sourceLabel = agentSourceLabels[sourceMode];
  return { message: `${sourceLabel}에서 주간보고에 필요한 내용을 추출했습니다. 확정 사실과 계획을 임의로 합치지 않고 가장 적합한 문장 성격으로 분류했습니다.`, draft, suggestions: ["더 간결하게 다듬어줘", "Analysis 문장으로 바꿔줘", "이 내용을 보고에 반영해줘"] };
}

function showAgentTyping() {
  const messages = $("#agent-messages");
  const article = document.createElement("article");
  article.id = "agent-typing";
  article.className = "agent-message-row assistant typing";
  article.innerHTML = `<div class="agent-message-avatar">AI</div><div class="agent-message-content"><strong>업무 Agent</strong><div class="typing-dots"><i></i><i></i><i></i></div></div>`;
  messages.appendChild(article);
  messages.scrollTop = messages.scrollHeight;
}

function hideAgentTyping() { $("#agent-typing")?.remove(); }

function setAgentBusy(busy) {
  state.agent.busy = busy;
  const send = $("#agent-send");
  const input = $("#agent-chat-input");
  if (send) send.disabled = busy;
  if (input) input.disabled = busy;
}

function autoResizeAgentInput() {
  const input = $("#agent-chat-input");
  if (!input) return;
  input.style.height = "auto";
  input.style.height = `${Math.min(input.scrollHeight, 150)}px`;
}

async function handleAgentChatSubmit(event) {
  event?.preventDefault();
  if (state.agent.busy) return;
  const input = $("#agent-chat-input");
  const attachment = state.agent.attachment;
  const prompt = input.value.trim() || (attachment ? "첨부 파일에서 주간보고에 반영할 내용을 정리해줘" : "");
  if (!prompt) return;
  appendAgentMessage("user", prompt, { attachment });
  state.agent.conversationCount += 1;
  input.value = "";
  autoResizeAgentInput();
  state.agent.attachment = null;
  renderAgentAttachment();
  renderAgentContext();
  showAgentTyping();
  setAgentBusy(true);
  try {
    await new Promise((resolve) => setTimeout(resolve, 380));
    const response = createAgentResponse(prompt, attachment);
    if (response.portalTransfer) {
      appendAgentMessage("assistant", response.message, { portalTransfer: response.portalTransfer, suggestions: response.suggestions, record: false });
      if (!response.portalTransfer.canApply) showToast("확인 질문 또는 수치 근거 오류가 남아 있습니다.", true);
      return;
    }
    if (response.openPreview) {
      appendAgentMessage("assistant", response.message, { record: false });
      openAgentResultDialog();
      return;
    }
    if (response.apply) {
      hideAgentTyping();
      await applyAgentDraft();
      return;
    }
    appendAgentMessage("assistant", response.message, { draft: response.draft, suggestions: response.suggestions });
  } catch (error) {
    appendAgentMessage("assistant", `Demo Agent 처리를 완료하지 못했습니다. ${error.message}`);
    showToast(error.message, true);
  } finally {
    hideAgentTyping();
    setAgentBusy(false);
    $("#agent-chat-input")?.focus();
  }
}

async function applyAgentDraft() {
  const draft = state.agent.draft;
  if (!draft?.body) { appendAgentMessage("assistant", "먼저 업무이력·메일·파일에서 보고문장을 만들어 주세요."); return; }
  try {
    if (state.role !== "MEMBER") {
      $("#role-select").value = "MEMBER";
      await loadRole("MEMBER", "MBR-07");
    }
    const page = (state.data.work_pages || []).find((item) => item.id === draft.targetPageId);
    if (!page) throw new Error("Agent가 대상 업무페이지를 확정하지 못했습니다. 확인 질문에 답한 후 다시 반영하세요.");
    const pageItemIds = String(page.work_item_ids || "").split(",").filter(Boolean);
    const workItem = state.data.work_items.find((item) => pageItemIds.includes(item.id));
    if (!workItem) throw new Error("업무페이지에 연결된 본인 WorkItem이 없습니다.");

    const includedPages = new Set((state.data.submission_pages || [])
      .filter((item) => item.submission_id === "sub_member1" && Number(item.included) === 1)
      .map((item) => item.work_page_id));
    includedPages.add(page.id);
    await api("/api/submission/items", {
      method: "POST",
      body: JSON.stringify({ role: "MEMBER", work_page_ids: [...includedPages] }),
    });
    await api("/api/worklogs", {
      method: "POST",
      body: JSON.stringify({
        role: "MEMBER",
        work_item_id: workItem.id,
        entry_type: draft.tag,
        occurred_on: "2026-08-24",
        narrative: draft.body,
      }),
    });
    if (["MAIL", "FILE"].includes(draft.sourceMode)) {
      const extension = draft.sourceMode === "MAIL" ? ".eml" : ".txt";
      const safeTitle = draft.sourceTitle.replace(/[\\/:*?"<>|]/g, "_").slice(0, 60) || agentSourceLabels[draft.sourceMode];
      await api("/api/evidence", {
        method: "POST",
        body: JSON.stringify({
          role: "MEMBER",
          work_item_id: workItem.id,
          file_name: `${safeTitle}${/\.[a-z0-9]+$/i.test(safeTitle) ? "" : extension}`,
          locator: `업무 Agent 수집 · ${agentSourceLabels[draft.sourceMode]} · 사용자 선택 발췌`,
          security_label: "CONFIDENTIAL",
        }),
      });
    }
    const generated = await api("/api/agent/draft", { method: "POST", body: JSON.stringify({ role: "MEMBER", screen_id: "MBR-07" }) });
    state.generatedDraft = generated.content;
    await refreshCurrent();
    navigateTo("MBR-07");
    appendAgentMessage("assistant", `완료했습니다. ‘${page.title}’ 업무페이지의 W35 마지막에 ${draft.tag} 문장을 파란색 New로 반영했습니다. 왼쪽 초안에서 바로 확인할 수 있습니다.`, { suggestions: ["반영된 초안을 다시 검토해줘", "다른 업무페이지의 이력도 정리해줘"] });
    state.agent.draft = null;
    showToast(`업무 Agent 문장을 ${page.page_code}에 New로 추가했습니다.`);
  } catch (error) {
    showToast(error.message, true);
  }
}

function setAgentPrompt(prompt) {
  const input = $("#agent-chat-input");
  let value = prompt;
  if (/아래 메일|메일 예시/.test(prompt)) {
    value = "아래 메일에서 주간보고에 추가할 내용만 추출해줘.\n\n보낸 사람: ESWA 생산팀\n받는 사람: RSND자동보정팀\n제목: K12 검증 생산 일정 협의\n\nK12 검증 생산은 W35 수요일 우선 배정이 가능합니다. M08·M11과 동일 조건으로 시험하려면 제품 전환 전까지 조건표를 전달해주시기 바랍니다. 시험 완료 후 결과를 공동 확인할 예정입니다.";
  }
  input.value = value;
  autoResizeAgentInput();
  input.focus();
}

function renderAgentAttachment() {
  const tray = $("#agent-attachment-tray");
  const attachment = state.agent.attachment;
  tray.hidden = !attachment;
  tray.innerHTML = attachment ? `<div class="agent-attachment-card"><div>▤</div><span><strong>${escapeHtml(attachment.name)}</strong><small>${escapeHtml(attachment.type || "업무파일")}</small></span><button type="button" data-agent-remove-file aria-label="첨부 삭제">×</button></div>` : "";
}

async function handleAgentFile(event) {
  const file = event.target.files?.[0];
  if (!file) return;
  const textLike = /\.(txt|md|csv|eml|log)$/i.test(file.name) || /^text\//.test(file.type);
  state.agent.attachment = { name: file.name, type: file.type || "업무파일", text: textLike && file.size <= 2_000_000 ? await file.text() : "" };
  renderAgentAttachment();
  $("#agent-chat-input").focus();
  event.target.value = "";
}

function newAgentChat() {
  $("#agent-messages").querySelectorAll(".agent-message-row").forEach((item) => item.remove());
  $("#agent-welcome").hidden = false;
  state.agent.draft = null;
  state.agent.pendingImport = null;
  state.agent.attachment = null;
  state.agent.lastOutboundPrompt = "";
  state.agent.conversationCount = 0;
  state.agent.demoStep = 0;
  state.agent.demoPayload = null;
  state.agent.messages = [];
  state.agent.sessionId = `portal-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  renderAgentAttachment();
  renderAgentContext();
  renderDemoAgentFlow();
  $("#agent-chat-input").value = "";
  autoResizeAgentInput();
}

function bindScreenForms() {
  const questionForm = $("#question-form");
  if (questionForm) questionForm.addEventListener("submit", handleQuestion);
  const searchForm = $("#search-form");
  if (searchForm) searchForm.addEventListener("submit", (event) => {
    event.preventDefault();
    $("#search-results")?.removeAttribute("hidden");
    showToast("권한 범위 안에서 WorkItem·KPI·보고서를 검색했습니다.");
  });
  const reportEditor = $("#structured-report-editor");
  if (reportEditor) {
    reportEditor.addEventListener("input", syncStructuredReportEditor);
    reportEditor.addEventListener("change", (event) => {
      const select = event.target.closest(".block-tag-select");
      if (select) {
        const block = select.closest(".structured-edit-block");
        const tagPreview = $(".block-tag-preview", block);
        const statuses = ($(".block-status-tags", block)?.value || "").split(",").filter(Boolean);
        if (tagPreview) tagPreview.innerHTML = reportTag(select.value) + statuses.map(reportTag).join("");
        block.dataset.tag = select.value.toLowerCase();
      }
      syncStructuredReportEditor();
    });
  }
  const comparisonEditor = $("#team-comparison-editor");
  if (comparisonEditor) {
    comparisonEditor.addEventListener("input", syncTeamComparisonEditor);
    comparisonEditor.addEventListener("change", syncTeamComparisonEditor);
  }
  const workPageEditor = $("#work-page-editor");
  if (workPageEditor) {
    workPageEditor.addEventListener("input", syncWorkPageEditor);
    workPageEditor.addEventListener("change", (event) => {
      const select = event.target.closest(".block-tag-select");
      if (select) {
        const block = select.closest(".structured-edit-block");
        const statuses = ($(".block-status-tags", block)?.value || "").split(",").filter(Boolean);
        const tagPreview = $(".block-tag-preview", block);
        if (tagPreview) tagPreview.innerHTML = reportTag(select.value) + statuses.map(reportTag).join("");
        block.dataset.tag = select.value.toLowerCase();
      }
      syncWorkPageEditor();
    });
  }
}

function renderByKind(screen) {
  const renderers = {
    dashboard: () => renderDashboard(screen), login: renderLogin, context: renderContext,
    inbox: renderInbox, search: renderSearch, notifications: renderNotifications,
    worklist: renderWorklist, detail: renderWorkDetail, entry: renderEntry,
    uploadEvidence: renderEvidenceUpload, selection: () => renderSelection(false),
    memberEditor: () => renderEditor("TEAM_MEMBER"), submission: renderSubmission,
    submissionMatrix: renderSubmissionMatrix, memberDetail: renderMemberDetail,
    selectionLeader: () => renderSelection(true), leaderEditor: () => renderEditor("TEAM"),
    leaderFinal: renderLeaderFinalReport, compareEvidence: renderEvidenceCompare, approve: renderApproval, history: renderHistory,
    departmentReview: () => renderReportFileReview("DEPT"), groupReview: () => renderReportFileReview("HEAD"),
    departmentKpi: renderDepartmentKpiMonitor, groupKpi: renderGroupKpiMonitor,
    teamMatrix: renderTeamMatrix, collaboration: renderCollaboration, conflict: renderConflict,
    deptEditor: () => renderEditor("DEPARTMENT"), decisionRegister: renderDecisionRegister,
    qa: renderQa, groupEditor: () => renderEditor("GROUP"), redaction: renderRedaction,
    export: renderExport, evidence: renderEvidenceTrace, question: renderQuestion,
    decision: renderDecision, trend: renderTrend, snapshotUpload: renderSnapshotUpload,
    mapping: renderMapping, validation: renderValidation, snapshotCompare: renderSnapshotCompare,
    snapshotApprove: renderSnapshotApprove, catalog: renderMetricCatalog, iam: renderIam,
    calendar: renderCalendar, release: renderRelease, policy: renderPolicy,
    audit: renderAudit, health: renderHealth,
  };
  return (renderers[screen.kind] || (() => renderGeneric(screen)))();
}

function renderWorkflow(activeIndex) {
  const stages = ["팀원 작성", "팀장 검토", "담당 승인", "기획 QA", "그룹장 보고"];
  return `<div class="steps">${stages.map((label, index) => `<div class="step ${index < activeIndex ? "done" : index === activeIndex ? "active" : ""}"><strong>${index + 1}</strong><span>${label}</span></div>`).join("")}</div>`;
}

function renderKpis() {
  return `<div class="metrics kpi-metrics">${state.data.snapshots.slice(0, 4).map((item) => {
    const value = `${Number(item.display_value).toFixed(1)}${item.unit}`;
    const delta = item.previous_value == null ? "전주 없음" : `전주 ${Number(item.previous_value).toFixed(1)}${item.unit}`;
    return metricCard(item.metric_name, value, `${delta} · ${item.verification_state}`, stateClass(item.verification_state));
  }).join("")}</div>`;
}

function reportByLevel(level) {
  return state.data.reports.find((report) => report.report_level === level && report.report_code.includes("W35"));
}

function renderDashboard() {
  const d = state.data;
  const role = state.role;
  if (role === "MEMBER") return renderMemberSourceDashboard();
  if (role === "LEADER") return renderLeaderSourceDashboard();
  if (role === "DEPT") return renderDepartmentSourceDashboard();
  if (role === "HEAD") return renderHeadSourceDashboard();
  let summary;
  let activeStage = 0;
  if (role === "MEMBER") {
    const submission = d.submissions.find((item) => item.member_name === d.principal.display_name);
    summary = [["내 업무페이지", d.counts.work_pages || 0, "법인·공정·프로젝트별"], ["금주 Worklog", d.worklogs.filter((item) => d.work_items.some((work) => work.id === item.work_item_id) && String(item.occurred_on) >= "2026-08-24").length, "공동작성 기록 포함"], ["제출 상태", submission?.status || "미작성", `Version ${submission?.version || 0}`]];
  } else if (role === "LEADER") {
    summary = [["팀원 제출", `${d.counts.submitted_members}/${d.counts.members_total}`, "금주 제출 현황"], ["검토 업무페이지", d.counts.work_pages || 0, "페이지 단위 선택"], ["팀 보고", reportByLevel("TEAM")?.status || "DRAFT", "서술형 원문 유지"]]; activeStage = 1;
  } else if (role === "DEPT") {
    summary = [["하위 팀", 4, "자동보정담당"], ["협업 안건", d.collaborations.length, "중복은 1회 집계"], ["미결 Decision", d.counts.open_decisions, "Owner·Due 확인"]]; activeStage = 2;
  } else if (role === "PLANNING") {
    summary = [["담당 보고", 4, "승인본 기준"], ["Open QA", d.counts.open_qa, "BLOCK 우선"], ["그룹 보고", reportByLevel("GROUP")?.status || "DRAFT", "그룹장 관점 재구성"]]; activeStage = 3;
  } else if (role === "HEAD") {
    summary = [["대표 KPI", d.snapshots.length, "기준시각·상태 표시"], ["결정 요청", d.counts.open_decisions, "이번 주 검토"], ["지연 Action", d.action_items.filter((item) => item.status === "DELAYED").length, "담당 확인 필요"]]; activeStage = 4;
  } else if (role === "DATA_OWNER") {
    summary = [["공식 Snapshot", `${d.counts.snapshots_locked}/${d.counts.snapshots_total}`, "승인·잠금"], ["검증 오류", d.qa_issues.filter((item) => item.resource_type === "METRIC_SNAPSHOT" && item.status === "OPEN").length, "PD 파일 확인"], ["Cut-off", "08/23", "23:59 기준"]];
  } else if (role === "ADMIN") {
    summary = [["Portal", "정상", "127.0.0.1"], ["SQLite", "정상", "Foreign key ON"], ["감사 이벤트", d.audit_events.length, "최근 50건"]];
  } else {
    summary = [["처리할 업무", 5, "역할 범위 기준"], ["알림", 3, "마감·반려·오류"], ["보고 주차", "W35", "진행 중"]];
  }
  const itemRows = d.work_items.slice(0, 5).map((item) => `<tr><td><code>${escapeHtml(item.work_item_code)}</code><br><span class="small muted">${escapeHtml(item.organization_name)}</span></td><td>${escapeHtml(item.title)}</td><td>${badge(item.state)}</td><td>${formatDate(item.target_date)}</td></tr>`);
  return `<div class="hero-strip"><div><span class="eyebrow-text">2026 W35</span><h2>${escapeHtml(d.principal.role_label)} 업무 공간</h2><p>${escapeHtml(d.principal.organization_name)} 범위의 기준 데이터와 승인 상태입니다.</p></div><div class="hero-code"><span>Portal 기준</span><strong>${escapeHtml(d.cycle.cycle_code)}</strong><small>${escapeHtml(d.cycle.state)}</small></div></div><div class="metrics">${summary.map(([a, b, c]) => metricCard(a, b, c)).join("")}</div>${role !== "ADMIN" ? renderKpis() : ""}${card("주간보고 진행 단계", renderWorkflow(activeStage))}${card("우선 검토 업무", table(["Code / 조직", "업무", "상태", "목표일"], itemRows))}`;
}

function renderLogin() {
  return `<div class="login-layout"><section class="login-panel"><div class="brand-mark large">DX</div><h2>Manufacturing DX Weekly</h2><p>회사 계정으로 로그인하면 역할·조직·보고주차에 맞는 업무 공간을 생성합니다.</p><button class="button primary wide" data-demo="login">회사 SSO로 로그인</button><div class="small muted">시연에서는 인증을 생략하고 역할 선택기로 전환합니다.</div></section>${card("인증 통제", `<ul class="list"><li><strong>OIDC Claim 검증</strong><span>Issuer · Audience · MFA · 계정 활성 여부</span></li><li><strong>Principal 생성</strong><span>User · RoleAssignment · Organization Scope</span></li><li><strong>Deny by default</strong><span>권한이 없는 보고·파일·AI 도구는 노출하지 않음</span></li></ul>`)}</div>`;
}

function renderContext() {
  const options = [["팀원", "RSND자동보정팀", "본인 WorkItem 작성·제출"], ["팀장", "RSND자동보정팀", "팀원 검토·팀 보고 승인"], ["담당", "자동보정담당", "4개 팀 종합·기획팀·그룹장 전송"]];
  return `${card("현재 업무 범위 선택", `<div class="context-grid">${options.map(([r, o, x], i) => `<label class="context-card"><input type="radio" name="context" ${i === 0 ? "checked" : ""}><span>${badge(r)}<strong>${escapeHtml(o)}</strong><small>${escapeHtml(x)}</small></span></label>`).join("")}</div><div class="button-row"><button class="button primary" data-demo="context">선택 범위로 시작</button></div>`)}${card("적용 원칙", `<div class="notice"><strong>역할과 조직 범위는 모든 조회·Agent 검색·승인의 기준입니다.</strong>복수 역할 사용자는 업무 시작 전에 하나의 Context를 명시적으로 선택합니다.</div>`)}`;
}

function renderInbox() {
  const tasks = [["KPI 검증 오류", "SNP-PD-2026-W35-004", "오늘 10:00", "BLOCK"], ["팀원 제출 검토", "SUB-RSND-2026-W35-002", "오늘 12:00", "OPEN"], ["Decision 요청", "DEC-RSND-2026-0008", "08/25", "REQUESTED"], ["지연 Action", "ACT-SOL-2026-0031", "08/26", "DELAYED"]];
  return `${card("내가 처리할 업무", table(["업무", "Resource", "마감", "상태"], tasks.map((row) => `<tr><td><strong>${escapeHtml(row[0])}</strong></td><td><code>${escapeHtml(row[1])}</code></td><td>${escapeHtml(row[2])}</td><td>${badge(row[3])}</td></tr>`)))}${card("Agent 우선순위 설명", `<div class="notice"><strong>1순위: 보고를 차단하는 KPI 중복 Key</strong>마감 영향, BLOCK 여부, 후속 단계 수를 기준으로 정렬했습니다. Agent는 상태를 자동 변경하지 않습니다.</div>`)}`;
}

function renderSearch() {
  const rows = state.data.work_items.slice(0, 4).map((item) => `<tr><td>${badge("WorkItem", "WORK")}</td><td><code>${escapeHtml(item.work_item_code)}</code></td><td>${escapeHtml(item.title)}</td><td>${escapeHtml(item.organization_name)}</td></tr>`);
  return `${card("권한 기반 통합 검색", `<form id="search-form" class="inline search-bar"><input class="grow" value="Jamming 자동보정 PD Loss" aria-label="검색어"><button class="button primary">검색</button></form><p class="small muted">자연어를 WorkItem·KPI·Evidence·Report ID와 연결합니다. 권한 밖 문서는 존재 여부도 노출하지 않습니다.</p>`)}<section id="search-results" class="card"><h3>검색 결과</h3>${table(["구분", "Code", "제목", "조직"], rows)}<div class="source-chips">${state.data.snapshots.slice(0, 2).map((s) => `<span class="source-chip">${escapeHtml(s.snapshot_code)}</span>`).join("")}</div></section>`;
}

function renderNotifications() {
  const list = [["BLOCK", "PD Snapshot 중복 Key 1건", "Data Owner · 8분 전"], ["DUE", "팀원 제출 마감까지 1일", "2026-08-25 17:00"], ["RETURN", "수치 근거 보완 요청", "기획팀 · 어제"], ["ACTION", "ACT-SOL-2026-0031 지연", "목표 08/26"]];
  return card("알림·마감", `<ul class="notification-list">${list.map(([type, title, meta], i) => `<li class="${i === 0 ? "unread" : ""}">${badge(type)}<div><strong>${escapeHtml(title)}</strong><span>${escapeHtml(meta)}</span></div><button class="button secondary" data-demo="notification">열기</button></li>`).join("")}</ul>`);
}

function renderWorklist() {
  if (state.role === "MEMBER") return renderSourceWorklist();
  const rows = state.data.work_items.map((item) => `<tr><td><input class="row-check" type="checkbox" aria-label="${escapeHtml(item.work_item_code)} 선택"></td><td><code>${escapeHtml(item.work_item_code)}</code></td><td><strong>${escapeHtml(item.title)}</strong><br><span class="small muted">${escapeHtml(item.objective)}</span></td><td>${badge(item.state)}</td><td>${escapeHtml(item.metric_code || "—")}</td><td>${escapeHtml(item.collaboration_code || "—")}</td><td>${formatDate(item.target_date)}</td></tr>`);
  return `${card("내 업무 Portfolio", `<div class="toolbar"><div class="inline"><select><option>전체 상태</option><option>진행 중</option><option>계획</option></select><input placeholder="Code 또는 업무명"></div><span class="muted small">${rows.length}건</span></div>${table(["", "WorkItem ID", "업무·목표", "상태", "KPI", "Collaboration", "목표일"], rows)}`)}${card("Code 작성 가이드", `<div class="code-guide"><code>WI-RSND-2026-0032</code><span><b>WI</b> 업무 레코드</span><span><b>RSND</b> 소유 팀</span><span><b>2026</b> 생성 연도</span><span><b>0032</b> 순번</span></div>`)}`;
}

function renderWorkDetail() {
  if (state.role === "MEMBER") return renderSourceWorkDetail();
  const item = state.data.work_items[0];
  const logs = state.data.worklogs.filter((log) => log.work_item_id === item.id);
  const ev = state.data.evidence.filter((evidence) => evidence.work_item_id === item.id);
  return `<div class="grid-2"><section class="card"><div class="card-top"><div><code>${escapeHtml(item.work_item_code)}</code><h2>${escapeHtml(item.title)}</h2></div>${badge(item.state)}</div><dl class="detail-grid"><div><dt>업무 목표</dt><dd>${escapeHtml(item.objective)}</dd></div><div><dt>Owner</dt><dd>${escapeHtml(item.owner_name)} · ${escapeHtml(item.organization_name)}</dd></div><div><dt>KPI</dt><dd>${escapeHtml(item.metric_code)}</dd></div><div><dt>Collaboration</dt><dd>${escapeHtml(item.collaboration_code)}</dd></div><div><dt>기간</dt><dd>${formatDate(item.start_date)} – ${formatDate(item.target_date)}</dd></div><div><dt>보안등급</dt><dd>${badge(item.security_label)}</dd></div></dl></section>${card("연결 Resource", `<ul class="list"><li><strong>공통 KPI Snapshot</strong><span>SNP-PD-2026-W35-004 · PROVISIONAL</span></li>${ev.map((x) => `<li><strong>${escapeHtml(x.evidence_code)}</strong><span>${escapeHtml(x.file_name)} · ${escapeHtml(x.locator)}</span></li>`).join("")}<li><strong>협업 안건</strong><span>${escapeHtml(item.collaboration_code)}</span></li></ul>`)}</div>${card("업무 이력", `<div class="timeline">${logs.map((log) => `<article><span>${formatDate(log.occurred_on)}</span><div>${badge(log.entry_type)}<p>${escapeHtml(log.narrative)}</p></div></article>`).join("")}</div>`)}`;
}

const reportTagLabels = {
  BACKGROUND: "Background", FACT: "Fact", KPI: "KPI", RESULT: "Result",
  ANALYSIS: "Analysis", PLAN: "Plan", NEXT: "Plan", RISK: "Risk",
  DECISION: "Decision", PROVISIONAL: "Provisional", VERIFIED: "Verified",
  NEW: "New", DELETED: "Deleted",
};

const reportPrimaryTags = ["BACKGROUND", "FACT", "RESULT", "KPI", "ANALYSIS", "RISK", "PLAN", "DECISION"];
const reportStateTags = ["PROVISIONAL", "VERIFIED", "NEW", "DELETED"];
const reportTagDescriptions = {
  BACKGROUND: "배경·목표", FACT: "확인된 사실", RESULT: "수행·확인 결과", KPI: "공통 Snapshot 수치",
  ANALYSIS: "해석·원인 가설", RISK: "일정·품질 위험", PLAN: "차주 실행계획", DECISION: "결정·지원 요청",
  NEW: "금주 추가·변경 내용", DELETED: "금주 보고에서 삭제",
};

function isResourceCode(token) {
  return /^(WI|RPG|SNP|COL|EVD|DEC|ACT|RPT|MET)-/i.test(String(token || ""));
}

function reportTag(token) {
  const normalized = String(token || "").toUpperCase();
  if (reportTagLabels[normalized]) {
    return `<span class="report-tag tag-${normalized.toLowerCase()}">${escapeHtml(reportTagLabels[normalized])}</span>`;
  }
  return `<code class="report-code">${escapeHtml(token)}</code>`;
}

function parseReportBlocks(content) {
  if (!String(content || "").trim()) return [];
  return String(content).trim().split(/\n\s*\n/).map((paragraph) => {
    const tokens = [...paragraph.matchAll(/\[([^\]]+)\]/g)].map((item) => item[1]);
    const normalized = tokens.map((token) => String(token).toUpperCase() === "NEXT" ? "PLAN" : String(token).toUpperCase());
    const tag = normalized.find((token) => reportPrimaryTags.includes(token)) || "RESULT";
    const statusTags = [...new Set(normalized.filter((token) => reportStateTags.includes(token)))];
    const resources = [...new Set(tokens.filter(isResourceCode))];
    const owner = tokens.find((token) => /^MEMBER:/i.test(token))?.split(":").slice(1).join(":").trim() || "";
    const compareId = tokens.find((token) => /^COMPARE:/i.test(token))?.split(":").slice(1).join(":").trim() || "";
    const comparisonTitle = tokens.find((token) => /^TITLE:/i.test(token))?.split(":").slice(1).join(":").trim() || "";
    const removable = [...new Set([
      ...tokens.filter(isResourceCode),
      ...tokens.filter((token) => reportPrimaryTags.includes(String(token).toUpperCase()) || String(token).toUpperCase() === "NEXT"),
      ...tokens.filter((token) => reportStateTags.includes(String(token).toUpperCase())),
      ...tokens.filter((token) => /^(MEMBER|COMPARE|TITLE):/i.test(token)),
    ])];
    let body = paragraph;
    removable.forEach((token) => { body = body.split(`[${token}]`).join(""); });
    body = body.replace(/^[ \t]+/gm, "").replace(/[ \t]+$/gm, "").trim();
    return { tag, statusTags, resources, body, owner, compareId, comparisonTitle };
  });
}

function renderTaggedReport(content) {
  const blocks = parseReportBlocks(content);
  if (!blocks.length) return `<div class="empty-state">초안을 생성하면 Tag가 적용된 보고서가 표시됩니다.</div>`;
  return blocks.map((block) => `<article class="tagged-report-block ${block.statusTags.includes("NEW") ? "is-new" : ""} ${block.statusTags.includes("DELETED") ? "is-deleted" : ""}"><div class="report-tag-row">${reportTag(block.tag)}${block.statusTags.map(reportTag).join("")}${block.owner ? `<span class="report-member-chip">${escapeHtml(block.owner)}</span>` : ""}</div><div class="tagged-report-copy">${escapeHtml(block.body).replaceAll("\n", "<br>")}</div>${block.resources.length ? `<div class="report-resource-row"><span>자동 연결 근거</span>${block.resources.map(reportTag).join("")}</div>` : ""}</article>`).join("");
}

function parseReportPages(content) {
  const pages = [];
  const pattern = /@@PAGE\|([^\n]+)@@\n([\s\S]*?)\n@@ENDPAGE@@/g;
  for (const match of String(content || "").matchAll(pattern)) {
    const fields = match[1].split("|", 6);
    if (fields.length !== 6) continue;
    const [pageCode, title, siteScope, processScope, projectScope, authors] = fields;
    pages.push({ pageCode, title, siteScope, processScope, projectScope, authors, blocks: parseReportBlocks(match[2]) });
  }
  return pages;
}

function renderReportPage(page, compact = false) {
  const lines = page.blocks.map((block) => {
    const isNew = block.statusTags.includes("NEW");
    return `<section class="weekly-page-line ${isNew ? "is-new" : ""}"><div class="weekly-page-line-meta">${reportTag(block.tag)}${block.statusTags.map(reportTag).join("")}</div><p class="weekly-page-copy">${escapeHtml(block.body).replaceAll("\n", "<br>")}</p></section>`;
  }).join("");
  const printButton = compact ? "" : `<button type="button" class="button secondary work-page-pdf" data-print-work-page="${escapeHtml(page.pageCode)}">이 과제 PDF</button>`;
  return `<article class="weekly-report-page ${compact ? "compact-page" : ""}"><header class="weekly-page-header"><div><span class="weekly-page-code">${escapeHtml(page.pageCode)}</span><h3>${escapeHtml(page.title)}</h3><p>${escapeHtml(page.projectScope)}</p></div><div class="weekly-page-meta"><span><b>법인</b>${escapeHtml(page.siteScope)}</span><span><b>공정</b>${escapeHtml(page.processScope)}</span><span><b>작성</b>${escapeHtml(page.authors)}</span>${printButton}</div></header><div class="weekly-page-retention"><span>최근 4주 이력 유지</span><span class="blue-rule">파란색 = 금주 신규·업데이트</span></div><div class="weekly-page-body">${lines || `<div class="empty-state">표시할 업무 내용이 없습니다.</div>`}</div></article>`;
}

function renderReportPages(content, compact = false) {
  const pages = parseReportPages(content);
  if (!pages.length) return renderTaggedReport(content);
  return `<div class="weekly-page-stack">${pages.map((page) => renderReportPage(page, compact)).join("")}</div>`;
}

function printStyles() {
  return `
    @page { size: A4; margin: 15mm 14mm 16mm; }
    * { box-sizing: border-box; }
    body { margin: 0; color: #172033; background: #fff; font-family: "Malgun Gothic", "Noto Sans KR", Arial, sans-serif; font-size: 10.5pt; line-height: 1.55; }
    .print-page { min-height: 255mm; page-break-after: always; break-after: page; }
    .print-page:last-child { page-break-after: auto; break-after: auto; }
    .print-masthead { display: flex; justify-content: space-between; gap: 16px; align-items: flex-start; padding-bottom: 12px; border-bottom: 2px solid #2356a8; }
    .print-brand { display: flex; gap: 10px; align-items: center; }
    .print-mark { width: 34px; height: 34px; display: grid; place-items: center; border-radius: 8px; color: #fff; background: #2356a8; font-size: 9pt; font-weight: 800; }
    .print-brand strong { display: block; font-size: 13pt; }
    .print-brand span, .print-meta { color: #657087; font-size: 8.5pt; }
    .print-meta { text-align: right; }
    h1 { margin: 20px 0 5px; font-size: 21pt; line-height: 1.25; }
    .print-subtitle { margin: 0 0 17px; color: #657087; }
    .page-facts { display: grid; grid-template-columns: repeat(2, 1fr); gap: 0; margin-bottom: 15px; border: 1px solid #dfe4ec; border-radius: 8px; overflow: hidden; }
    .page-facts div { padding: 8px 10px; border-bottom: 1px solid #dfe4ec; }
    .page-facts div:nth-child(odd) { border-right: 1px solid #dfe4ec; }
    .page-facts div:nth-last-child(-n+2) { border-bottom: 0; }
    .page-facts b { display: block; margin-bottom: 2px; color: #657087; font-size: 7.5pt; }
    .retention { display: flex; justify-content: space-between; padding: 7px 9px; border-radius: 7px; background: #eaf1fc; color: #194584; font-size: 8pt; font-weight: 700; }
    .print-lines { margin-top: 8px; }
    .print-line { display: grid; grid-template-columns: 31mm 1fr; gap: 9px; padding: 9px 0; border-bottom: 1px dotted #cbd3df; break-inside: avoid; }
    .print-line p { margin: 0; }
    .print-line.is-new p { color: #0000ff; font-weight: 650; }
    .task-print-progress { margin: 12px 0; padding: 10px; border-radius: 8px; background: #eef4ff; }
    .task-print-progress strong { display: block; font-size: 18pt; color: #2356a8; }
    .task-print-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin: 12px 0; }
    .task-print-grid div { padding: 10px; border: 1px solid #dfe4ec; border-radius: 8px; }
    .task-print-grid b { display: block; margin-bottom: 5px; color: #657087; font-size: 8pt; }
    .print-report-summary { margin: 0 0 12px; padding: 10px 11px; border-left: 3px solid #2356a8; background: #f3f7fd; }
    .print-highlight-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 7px; margin: 0 0 12px; }
    .print-highlight-grid > div { display: grid; gap: 2px; padding: 8px 9px; border: 1px solid #dfe4ec; border-radius: 7px; }
    .print-highlight-grid b, .print-highlight-grid span { color: #657087; font-size: 7.5pt; }
    .print-highlight-grid strong { color: #173f7a; font-size: 11pt; }
    .print-current-block { position: relative; padding: 11px 0; border-bottom: 1px solid #dfe4ec; break-inside: avoid; }
    .print-current-block h2 { margin: 6px 0 4px; color: #172033; font-size: 11pt; line-height: 1.45; }
    .print-current-block p { margin: 5px 0 0; }
    .print-story { display: grid; gap: 4px; margin-top: 7px; }
    .print-story > div { display: grid; grid-template-columns: 20mm 1fr; gap: 7px; padding: 5px 7px; border-radius: 5px; background: #f7f9fc; }
    .print-story b { color: #2356a8; font-size: 7.5pt; }
    .print-story span { font-size: 8.5pt; }
    .print-kpi-impact { display: inline-block; margin-left: 5px; padding: 2px 6px; border-radius: 999px; color: #174a9c; background: #e8f0ff; font-size: 7pt; font-weight: 800; }
    .report-tag { display: inline-block; margin: 0 3px 3px 0; padding: 2px 6px; border-radius: 999px; color: #334155; background: #eef2f7; font-size: 7pt; font-weight: 800; }
    .tag-new { color: #1646c5; background: #e7eeff; }
    .tag-risk { color: #a01f2d; background: #fdecee; }
    .tag-plan { color: #775100; background: #fff5dc; }
    .tag-kpi, .tag-result { color: #126a52; background: #e8f7f0; }
    .team-block { padding: 11px 0; border-bottom: 1px solid #dfe4ec; break-inside: avoid; }
    .team-block p { margin: 7px 0 0; }
    .team-block.is-new p { color: #0000ff; font-weight: 650; }
    .print-member-group { margin-top: 14px; }
    .print-member-heading { display: flex; justify-content: space-between; align-items: center; padding: 7px 9px; border-radius: 7px; color: #173f7a; background: #eaf1fc; }
    .print-member-heading span { color: #657087; font-size: 8pt; }
    .print-compare-row { margin-top: 8px; border: 1px solid #dfe4ec; border-radius: 7px; overflow: hidden; break-inside: avoid; }
    .print-compare-meta { display: grid; grid-template-columns: 1fr auto; gap: 8px; padding: 6px 8px; background: #f6f8fb; font-size: 8pt; }
    .print-change-status { padding: 1px 6px; border-radius: 999px; font-weight: 800; }
    .print-change-status.status-retained { color: #52606f; background: #edf1f5; }
    .print-change-status.status-updated, .print-change-status.status-new { color: #0000cc; background: #e8ecff; }
    .print-change-status.status-deleted { color: #a01f2d; background: #fdecee; }
    .print-compare-columns { display: grid; grid-template-columns: 1fr 1fr; }
    .print-week-pane { min-height: 32mm; padding: 8px; }
    .print-week-pane + .print-week-pane { border-left: 1px solid #dfe4ec; }
    .print-week-pane b { display: block; margin-bottom: 5px; color: #657087; font-size: 7.5pt; }
    .print-week-pane p { margin: 0; }
    .print-compare-row.status-updated .print-current p, .print-compare-row.status-new .print-current p { color: #0000ff; font-weight: 650; }
    .print-compare-row.status-deleted .print-current p { color: #a01f2d; font-weight: 700; }
    .print-footer { margin-top: 18px; padding-top: 8px; display: flex; justify-content: space-between; border-top: 1px solid #dfe4ec; color: #657087; font-size: 7.5pt; }
    @media screen { body { padding: 14mm; background: #eef2f7; } .print-page { width: 210mm; margin: 0 auto 12px; padding: 15mm 14mm 16mm; background: #fff; box-shadow: 0 8px 30px rgba(23,32,51,.15); } }
    @media print { .print-page { padding: 0; } }
  `;
}

function printMasthead(label) {
  return `<header class="print-masthead"><div class="print-brand"><span class="print-mark">DX</span><div><strong>Manufacturing DX Weekly</strong><span>${escapeHtml(label)}</span></div></div><div class="print-meta">2026 W35<br>${escapeHtml(state.data?.principal?.organization_name || "RSND자동보정팀")}</div></header>`;
}

function printMemberPageMarkup(page) {
  const lines = page.blocks.map((block) => `<section class="print-line ${block.statusTags.includes("NEW") ? "is-new" : ""}"><div>${reportTag(block.tag)}${block.statusTags.map(reportTag).join("")}</div><p>${escapeHtml(block.body).replaceAll("\n", "<br>")}</p></section>`).join("");
  return `<article class="print-page">${printMasthead("팀원 과제별 업무페이지")}<h1>${escapeHtml(page.title)}</h1><p class="print-subtitle">${escapeHtml(page.pageCode)} · ${escapeHtml(page.projectScope)}</p><section class="page-facts"><div><b>법인</b>${escapeHtml(page.siteScope)}</div><div><b>공정</b>${escapeHtml(page.processScope)}</div><div><b>작성자</b>${escapeHtml(page.authors)}</div><div><b>보고 주차</b>2026 W35</div></section><div class="retention"><span>최근 4주 이력 유지</span><span>파란색 = 금주 신규·업데이트</span></div><div class="print-lines">${lines}</div><footer class="print-footer"><span>출력 단위: 업무페이지</span><span>Manufacturing DX Weekly Portal</span></footer></article>`;
}

function printSourceTaskMarkup(task) {
  const weekRows = task.weeks.map((week) => `<section class="print-line"><div><strong>${escapeHtml(week.week)}</strong><br>${escapeHtml(week.value)}%</div><p>${escapeHtml(week.text)}</p></section>`).join("");
  return `<article class="print-page">${printMasthead("팀원 과제별 진척 페이지")}<h1>${escapeHtml(task.title)}</h1><p class="print-subtitle">${escapeHtml(task.code)} · ${escapeHtml(task.owner)} 책임 · ${escapeHtml(task.kpi)}</p><section class="page-facts"><div><b>상태</b>${escapeHtml(taskStatusLabel(task.status))}</div><div><b>진척</b>${escapeHtml(task.progress)}%</div><div><b>목표일</b>${escapeHtml(task.target)}</div><div><b>완료일</b>${task.completed ? escapeHtml(task.completed) : "진행 중"}</div></section><div class="task-print-progress"><span>Plan 대비 진척</span><strong>${escapeHtml(task.progress)}%</strong><p>${escapeHtml(task.objective)}</p></div><div class="task-print-grid"><div><b>PLAN</b>${escapeHtml(task.plan)}</div><div><b>ACTUAL</b>${escapeHtml(task.actual)}</div></div><div class="retention"><span>W31~W35 진척 이력</span><span>KPI 달성률과 분리</span></div><div class="print-lines">${weekRows}</div><footer class="print-footer"><span>출력 단위: WorkItem</span><span>Manufacturing DX Weekly Portal</span></footer></article>`;
}

function printTeamReportMarkup() {
  const report = reportByLevel("TEAM");
  const page = sourceBackedModel.reportPages[0];
  const highlights = (page.highlights || []).map((item) => `<div><b>${escapeHtml(item.label)}</b><strong>${escapeHtml(item.value)}</strong><span>${escapeHtml(item.detail)}</span></div>`).join("");
  const body = page.blocks.map((block) => {
    const story = (block.story || []).map((item) => `<div><b>${escapeHtml(item.label)}</b><span>${escapeHtml(item.value)}</span></div>`).join("");
    return `<section class="print-current-block"><div>${reportTag(block.tag)}${block.impact ? `<span class="print-kpi-impact">KPI 영향 · ${escapeHtml(block.impact)}</span>` : ""}</div>${block.headline ? `<h2>${escapeHtml(block.headline)}</h2>` : ""}<p>${escapeHtml(block.text)}</p>${story ? `<div class="print-story">${story}</div>` : ""}</section>`;
  }).join("");
  return `<article class="print-page">${printMasthead("팀장 주간보고 · 금주 보고본")}<h1>RSND자동보정팀 W35 주간보고</h1><p class="print-subtitle">${escapeHtml(report?.report_code || "RPT-TEAM-RSND-2026-W35")} · Version ${escapeHtml(report?.current_version || 1)} · ${escapeHtml(report?.status || "DRAFT")}</p><section class="page-facts"><div><b>보고 조직</b>RSND자동보정팀</div><div><b>보고 주차</b>2026 W35</div><div><b>보고자</b>${escapeHtml(sourceBackedModel.people.leader)} 팀장</div><div><b>포함 팀원</b>${escapeHtml(sourceBackedModel.people.members.join(" · "))}</div></section><p class="print-report-summary">${escapeHtml(page.summary)}</p>${highlights ? `<div class="print-highlight-grid">${highlights}</div>` : ""}<div class="retention"><span>금주 W35 내용만 출력</span><span>이슈·해결과정·결과·후속계획 포함</span></div><div class="print-lines">${body}</div><footer class="print-footer"><span>팀장보고 금주 PDF</span><span>Manufacturing DX Weekly Portal</span></footer></article>`;
}

function openPdfPrintView(kind, pageCode = "") {
  let body = "";
  let title = "Manufacturing_DX_Weekly";
  if (kind === "MEMBER_PAGES") {
    let tasks = sourceBackedModel.tasks;
    if (pageCode) tasks = tasks.filter((task) => task.code === pageCode);
    if (!tasks.length) tasks = sourceBackedModel.tasks;
    body = tasks.map(printSourceTaskMarkup).join("");
    title = pageCode ? `${pageCode}_2026W35` : "팀원_과제별_업무페이지_2026W35";
  } else {
    body = printTeamReportMarkup();
    title = "RSND자동보정팀_팀장보고_2026W35";
  }
  const popup = window.open("", "_blank");
  if (!popup) { showToast("PDF 출력 창이 차단되었습니다. 이 포털의 팝업을 허용해 주세요.", true); return; }
  try { popup.opener = null; } catch { /* 브라우저 보안 정책에 따름 */ }
  popup.document.open();
  popup.document.write(`<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapeHtml(title)}</title><style>${printStyles()}</style></head><body>${body}</body></html>`);
  popup.document.close();
  popup.setTimeout(() => { popup.focus(); popup.print(); }, 350);
  showToast("인쇄 대화상자에서 ‘PDF로 저장’을 선택하십시오.");
}

function reportTagOptions(selected) {
  return reportPrimaryTags.map((tag) => `<option value="${tag}" ${tag === selected ? "selected" : ""}>${reportTagLabels[tag]} · ${reportTagDescriptions[tag]}</option>`).join("");
}

function renderStructuredReportBlock(block) {
  const tag = reportPrimaryTags.includes(block.tag) ? block.tag : "RESULT";
  const resources = [...new Set(block.resources || [])];
  const statusTags = [...new Set(block.statusTags || [])].filter((item) => reportStateTags.includes(item));
  return `<article class="structured-edit-block ${statusTags.includes("NEW") ? "is-new" : ""}" data-tag="${tag.toLowerCase()}"><div class="structured-block-top"><div class="block-tag-preview">${reportTag(tag)}${statusTags.map(reportTag).join("")}</div><label class="block-tag-control"><span>문단 유형</span><select class="block-tag-select">${reportTagOptions(tag)}</select></label><button type="button" class="button ghost compact-button" data-remove-report-block>문단 삭제</button></div><textarea class="block-body" spellcheck="false" aria-label="${escapeHtml(reportTagLabels[tag])} 문단 내용">${escapeHtml(block.body || "")}</textarea><input type="hidden" class="block-resources" value="${escapeHtml(resources.join(","))}"><input type="hidden" class="block-status-tags" value="${escapeHtml(statusTags.join(","))}"><div class="linked-resource-row"><span>AI 자동 연결</span>${resources.length ? resources.map(reportTag).join("") : `<em>현재 보고서의 업무 맥락에서 저장 시 연결</em>`}</div></article>`;
}

function defaultReportResourceCode() {
  return state.data?.work_items?.[0]?.work_item_code || "";
}

function renderStructuredReportEditor(content) {
  const blocks = parseReportBlocks(content);
  const editorBlocks = blocks.length ? blocks : [{ tag: "RESULT", statusTags: [], resources: [defaultReportResourceCode()].filter(Boolean), body: "" }];
  return `<div id="structured-report-editor" class="structured-report-editor">${editorBlocks.map(renderStructuredReportBlock).join("")}</div><div class="structured-editor-footer"><button type="button" class="button secondary" data-add-report-block>+ 문단 추가</button><span>전주 문장은 유지되고, 금주 추가 문단에는 New가 자동 표시됩니다.</span></div>`;
}

const teamComparisonCatalog = [
  {
    id: "kim_vm_background", owner: "임가은", code: "WI-RSND-2026-0052", title: "GM1·2 VM 기반 자동보정 시스템 구축", tag: "BACKGROUND",
    resources: ["WI-RSND-2026-0052"],
    previous: "GM1·2의 자동보정 고도화와 수평전개를 위해 VM 서버 기반 자동보정 시스템을 구축합니다.",
    current: "GM1·2의 자동보정 고도화와 수평전개를 위해 VM 서버 기반 자동보정 시스템을 구축합니다.",
  },
  {
    id: "kim_tension_result", owner: "임가은", code: "WI-RSND-2026-0032", title: "Lami Jamming 자동보정 조건 검증", tag: "RESULT",
    resources: ["WI-RSND-2026-0032", "EVD-RSND-2026-W35-028", "EVD-RSND-2026-W35-029"],
    previous: "ESWA L07 제품별 Jamming 자동보정 적용조건 기준안을 수립하고 M08·M11 초기 시험에서 유사 경향을 확인했습니다.",
    current: "M08·M11 반복 시험에서 동일 경향을 재확인해 대상 3개 제품 중 2개 제품의 재현성 근거를 확보했습니다. K12는 생산조건을 분리한 추가 시험 대상으로 남겼습니다.",
  },
  {
    id: "kim_tension_analysis", owner: "임가은", code: "WI-RSND-2026-0032", title: "Lami Jamming 자동보정 조건 검증", tag: "ANALYSIS",
    resources: ["WI-RSND-2026-0032", "COL-YIELD-2026-0014"],
    previous: "제품별 생산조건 차이가 재현성에 영향을 줄 수 있어 K12는 별도 조건으로 검증하기로 했습니다.",
    current: "M08·M11 결과는 제품별 상·하한 기준을 구체화하는 근거로 사용할 수 있으나, K12 결과가 없어 전체 제품군의 공통 조건으로 확정할 단계는 아닙니다.",
  },
  {
    id: "kim_tension_risk", owner: "임가은", code: "WI-RSND-2026-0032", title: "Lami Jamming 자동보정 조건 검증", tag: "RISK",
    resources: ["WI-RSND-2026-0032"], previous: "",
    current: "K12 검증용 생산 일정이 미확정되어 제품별 적용조건 확정과 수평전개 판단이 지연될 수 있습니다.",
  },
  {
    id: "kim_tension_plan", owner: "임가은", code: "WI-RSND-2026-0032", title: "Lami Jamming 자동보정 조건 검증", tag: "PLAN",
    resources: ["WI-RSND-2026-0032"],
    previous: "K12 생산 일정 확보 후 동일 조건 재현성 검증을 진행하고 제품별 상·하한을 확정할 예정입니다.",
    current: "8월 27일까지 K12 재현성 검증을 진행하고 제품별 상·하한 및 예외조건을 확정하겠습니다. FDC 이상구간과 자동보정 동작이력도 동일 시간축으로 정렬합니다.",
  },
  {
    id: "kim_loading_result", owner: "임가은", code: "WI-RSND-2026-0048", title: "로딩량 연계 Feedforward 자동보정", tag: "RESULT",
    resources: ["WI-RSND-2026-0048"],
    previous: "코터 롤맵 PLC와 Roll Press PLC의 데이터 수집 및 하프 슬리팅 방향을 고려한 전처리 프로그램 개발을 완료했습니다.",
    current: "코터 로딩량 데이터와 Roll Press Tension 전처리 흐름을 연결해 Feedforward 예측 입력 구성을 확정했습니다.",
  },
  {
    id: "kim_loading_plan", owner: "임가은", code: "WI-RSND-2026-0048", title: "로딩량 연계 Feedforward 자동보정", tag: "PLAN",
    resources: ["WI-RSND-2026-0048"], previous: "",
    current: "8월 28일까지 Tension 예측값을 활용한 Feedforward 자동보정 로직과 설비별 기준정보를 확정하고 반복 시험 조건을 고정하겠습니다.",
  },
  {
    id: "kim_vm_result", owner: "임가은", code: "WI-RSND-2026-0052", title: "GM1·2 VM 기반 자동보정 시스템 구축", tag: "RESULT",
    resources: ["WI-RSND-2026-0052"],
    previous: "GM1·2 RP와 NND 기준정보 표준화 범위를 합의하고 VM 제작사양서 초안을 준비했습니다.",
    current: "GM1·2 RP·NND 기준정보 표준화안을 정리하고 VM 제작사양서 초안을 완성했습니다. 법인별 네트워크·권한·데이터 수집 주기를 최종 확인 중입니다.",
  },
  {
    id: "kim_vm_plan", owner: "임가은", code: "WI-RSND-2026-0052", title: "GM1·2 VM 기반 자동보정 시스템 구축", tag: "PLAN",
    resources: ["WI-RSND-2026-0052"], previous: "",
    current: "8월 28일까지 VM·응용 환경 설정 범위와 RP·NND 제작사양서를 확정하고 법인별 데이터 수집 일정을 연결하겠습니다.",
  },
  {
    id: "park_pd_result", owner: "강민재", code: "WI-RSND-2026-0038", title: "ESWA L07 PD Loss 개선 로직 적용", tag: "RESULT",
    resources: ["WI-RSND-2026-0038", "EVD-RSND-2026-W35-031"],
    previous: "ESWA L07 자동보정 적용 전 기준구간과 제품 Mix를 정리하고 반복 검증 조건을 정의했습니다.",
    current: "ESWA L07 자동보정 적용 구간에서 PD Loss 감소 방향성을 확인했습니다. 단기 결과이므로 적용 전후 생산량과 제품 Mix를 동일 기준으로 재정렬해 검증하고 있습니다.",
  },
  {
    id: "park_pd_plan", owner: "강민재", code: "WI-RSND-2026-0038", title: "ESWA L07 PD Loss 개선 로직 적용", tag: "PLAN",
    resources: ["WI-RSND-2026-0038"],
    previous: "동일 조건 반복 시험을 통해 효과 산출 기준과 장기 모니터링 범위를 확정할 계획입니다.",
    current: "8월 28일까지 동일 조건 반복 검증을 완료하고 장기간 효과 산출 범위를 확정하겠습니다.",
  },
  {
    id: "park_monthly_share", owner: "강민재", code: "WI-RSND-2026-0038", title: "ESWA L07 단기결과 월말 공유", tag: "PLAN",
    resources: ["WI-RSND-2026-0038"],
    previous: "단기 적용결과를 월말 실적회의에 별도 안건으로 공유할 예정입니다.", current: "",
  },
  {
    id: "lee_fdc_analysis", owner: "배지호", code: "WI-RSND-2026-0041", title: "FDC 진단 결과 연계", tag: "ANALYSIS",
    resources: ["WI-RSND-2026-0041", "EVD-RSND-2026-W35-033"],
    previous: "FDC 장력 편차 구간과 Jamming 발생 시점을 같은 시간축으로 비교하는 분석 기준을 설계했습니다.",
    current: "FDC 장력 편차 구간과 Jamming 발생 시점에서 일부 방향성을 확인했습니다. 현재는 상관 후보이며 원인으로 확정하지 않고 Roll·제품·설비조건을 분리해 추가 검증합니다.",
  },
  {
    id: "lee_fdc_plan", owner: "배지호", code: "COL-YIELD-2026-0014", title: "FDC–자동보정 공동 검증", tag: "PLAN",
    resources: ["COL-YIELD-2026-0014", "WI-RSND-2026-0041"],
    previous: "FDC 이상구간과 자동보정 동작이력을 결합하는 공동 검증 절차를 협의했습니다.",
    current: "8월 31일까지 FDC 이상구간과 자동보정 동작이력을 동일 시간축으로 정렬하고 Roll·제품·설비조건별 공동 검증을 완료하겠습니다.",
  },
  {
    id: "team_yield_kpi", owner: "팀 공통", code: "SNP-YIELD-2026-W35-003", title: "승인 KPI Snapshot", tag: "KPI",
    resources: ["SNP-YIELD-2026-W35-003"], previous: "W34 수율은 91.8%였습니다.",
    current: "W35 수율은 92.4%로 전주 대비 0.6%p 상승했습니다. 목표 94.0%까지 잔여 차이는 1.6%p이며 자동보정 단독 기여도로 확대 해석하지 않습니다.",
  },
  {
    id: "team_k12_decision", owner: "팀 공통", code: "DEC-RSND-2026-0008", title: "K12 검증 생산 일정", tag: "DECISION",
    resources: ["DEC-RSND-2026-0008", "WI-RSND-2026-0032"], previous: "",
    current: "K12 검증 생산 일정을 8월 27일 이전 우선 배정해 주시기 바랍니다. 결정 지연 시 W35 수평전개 판단 일정도 함께 조정해야 합니다.",
  },
];

const teamComparisonOwners = ["윤도현", "강민재", "오세진", "한유준", "서진우", "임가은", "조현우", "문서윤", "배지호", "유민석", "팀 공통"];

const sourceTeamComparisonCatalog = [
  {
    id: "jung_break_action", owner: "임가은", code: "WI-RSND-2026-031", title: "Roll Press 단선 자동조치 모드", tag: "RESULT",
    resources: ["WI-RSND-2026-031", "W35-S131"],
    previous: "OT·MI_HL 전개와 WA 대표호기 PNT·Single 기능 검증을 완료하고 4조 작업자 교육을 진행했습니다.",
    current: "단선 후 R/W 이동과 두께 안정화가 작업자 숙련도에 의존해 조치시간 편차와 재단선 Risk가 있었습니다. Step 1 자동 이송과 Step 2 두께 조건조정으로 로직을 분리해 OT·MI_HL 전개 및 WA Main Roll 전·후단, PNT·Single 대표호기 검증을 완료했습니다. 4개 Shift 교육은 8월 31일까지 마치고 생산 적용 결과를 확인합니다.",
  },
  {
    id: "jung_nff_loss", owner: "임가은", code: "WI-RSND-2026-032", title: "NFF Roll Press 조건조정 Loss 개선", tag: "RESULT",
    resources: ["WI-RSND-2026-032", "W35-S144", "W32-S134"],
    previous: "OC9 음극 3호 조건조정 로스율 1.1%→0.03%, 재조건조정 Loss 64.0m→24.1m(62.5%↓) 성과를 확인했습니다.",
    current: "주말 장기 부동과 재료 연결 후 Main Roll 열변형으로 약 130m/회의 재조건조정 Loss가 발생했습니다. 역압·Roll Gap 자동조정과 저속 안정화 조건을 적용해 조건조정 Loss율 1.1%→0.03%, 재조건조정 Loss 64.0m→24.1m(62.5%↓), 재료 연결 구간 10.3m/Lot→0m/Lot를 확인했습니다. 모델·호기별 예외조건은 장기 모니터링합니다.",
  },
  {
    id: "jung_davinci", owner: "임가은", code: "WI-RSND-2026-033", title: "다빈치 WF 활용률 관리", tag: "RESULT",
    resources: ["WI-RSND-2026-033", "W35-S152"],
    previous: "APC에 Lot ID 수집을 추가해 생산이력 매칭 프로세스를 간소화했습니다.",
    current: "생산이력 매칭이 수작업이고 NJ Taping 활용률이 비정상 집계되는 이슈가 있었습니다. APC에 Lot ID 수집을 추가하고 2초 연속변화·Enable·EPC 0.01mm 기준으로 보정횟수 산출 규칙을 정리했습니다. Lot 매칭은 간소화됐으며 NJ 이상동작 매뉴얼 신규 버전을 검증 중입니다.",
  },
  {
    id: "jung_package", owner: "임가은", code: "WI-RSND-2026-034", title: "패키지 주액량 자동보정 수평전개", tag: "PLAN",
    resources: ["WI-RSND-2026-034", "W35-S154"],
    previous: "6개 법인과 GM2 적용을 완료하고 GM1 VM·HMI 설계를 공유했습니다.",
    current: "법인별 PLC 유형 차이와 GM2 재가동 시 보정값 덮어쓰기 이슈를 확인했습니다. GM2는 PLC 수정으로 문제를 해결하고 6개 법인 적용 상태를 유지하고 있습니다. GM1은 20대 기준정보와 VM용 PLC·HMI 설계를 마친 뒤 양산 일정에 맞춰 데이터 정합성과 자동보정 기능을 검증합니다.",
  },
  {
    id: "jung_dns", owner: "임가은", code: "WI-RSND-2026-035", title: "DNS Dryer 자동보정 신규개발", tag: "ANALYSIS",
    resources: ["WI-RSND-2026-035", "W35-S156"],
    previous: "대표라인 제어 파라미터 초안과 반복 Test 데이터를 정리했습니다.",
    current: "재가동 시 온도 Hunting ±20℃와 목표 도달 15초로 두께·Crack·수분 NG Risk가 있었습니다. 9개 Cycle을 분석한 결과 Preheat 15%→초기 26%→상향 고정출력 전환 구간이 오버슈트에 영향을 주는 패턴을 확인했습니다. 목표온도 50% 시점부터 PID 제어하는 Concept을 협의하고 ±10℃·10초·불량 0% 기준으로 반복 Test합니다.",
  },
  {
    id: "park_esaz", owner: "강민재", code: "WI-RSND-2026-041", title: "ESAZ R/P·Slitter APC 성능 검증", tag: "RESULT",
    resources: ["WI-RSND-2026-041", "W35-S148"], previous: "",
    current: "신규법인의 수동보정 의존도와 설비별 초기 안정화가 이슈였습니다. 로그 Level 경량화와 APC 기준정보·전처리·프로그램을 순차 적용한 결과 Roll Press Cpk는 양극 1.10→1.71, 음극 1.35→1.80, 수동보정은 60회→0회로 개선했습니다. Slitter도 양극 1.11→1.85, 음극 1.66→2.13, 수동보정 10회→0회를 확인했습니다.",
  },
  {
    id: "park_nj", owner: "강민재", code: "WI-RSND-2026-042", title: "NJ M53F 다단압연 자동보정", tag: "RESULT",
    resources: ["WI-RSND-2026-042", "W35-S149"], previous: "",
    current: "VD 후 팬케이크 외곽에서 코어로 갈수록 두께가 감소하고 설비 Maker별 제어방식이 달랐습니다. 생산길이별 Target 변경과 PNT용 Gap 비례·역압 개별제어를 적용해 두께 Max–Min 2.21㎛→1.76㎛(20.4%↓), 외경 산포 0.200→0.175mm(12.5%↓)를 확인했습니다. 연간효과는 전망치로 분리합니다.",
  },
  {
    id: "parktae_wf", owner: "서진우", code: "WI-RSND-2026-043", title: "법인별 자동보정 WF 운영", tag: "PLAN",
    resources: ["WI-RSND-2026-043", "W35-S152"],
    previous: "법인별 활용률·자동·수동보정 횟수 WF 완료 현황을 정리했습니다.",
    current: "법인별 활용률과 자동·수동보정 횟수 산출기준이 달라 운영 비교가 어려웠습니다. Lot ID와 보정횟수 판정 규칙을 표준화했고, NJ Taping 이상동작 Case를 반영한 매뉴얼 신규 버전을 임가은 책임과 검증해 운영자 배포 기준을 확정합니다.",
  },
  {
    id: "cha_dnc", owner: "배지호", code: "WI-RSND-2026-044", title: "DNC 신공법 자동보정 고도화", tag: "RESULT",
    resources: ["WI-RSND-2026-044", "W35-S160"],
    previous: "등속구간 즉시보정과 가속구간 FeedForward 로직의 대표 기능 검증을 완료했습니다.",
    current: "등속구간은 규격 이탈 후 보정이 늦고 가속구간은 선속 변화에 따른 TS 불량이 발생했습니다. 등속 즉시 Feedback과 가속 FeedForward를 분리 적용해 TS 불량률을 0.216%→0.133%, 가속구간은 1.86%→1.29%로 낮추고 Spec-in Tab 수를 23% 단축했습니다. ESOC PLC 수정은 8월 31일까지 완료합니다.",
  },
  {
    id: "yoon_tension", owner: "윤도현", code: "WI-RSND-2026-045", title: "Tension 편차 자동보정 및 단선 자동조치", tag: "RESULT",
    resources: ["WI-RSND-2026-045", "W35-S132", "W35-S138"],
    previous: "WA·OT·MI_HL 법인별 Tension 편차 자동보정 기준정보와 대표호기 적용 범위를 점검했습니다.",
    current: "WA 25대에 로직은 적용했지만 Tension Hunting, 센서·Cable, Dancer Roll·Actuator와 생산대기 때문에 실제 양산 사용은 12대에 그쳤습니다. 미사용 13대를 원인별로 분류해 설비조치 Owner와 생산일정을 연결하고, HD PLC 및 FDC 수집 로직 보완을 병행했습니다.",
  },
  {
    id: "oh_wa_loadcell", owner: "오세진", code: "WI-RSND-2026-046", title: "WA Tension·Loadcell 비율 제어", tag: "RESULT",
    resources: ["WI-RSND-2026-046", "W35-S151"], previous: "WA 대표호기 Loadcell 비율제어 로직의 시험조건을 정리했습니다.",
    current: "1·2차 압연 하중 불균형과 Springback으로 JF1 Wrinkle이 반복됐습니다. 기존 Gap·Tension 자동보정과 충돌하지 않도록 Loadcell 비율제어 로직을 분리해 음극 1-1호에서 검증했고 Wrinkle 불량률을 0.4%→0.1%로 낮췄습니다. 음극 3·4라인 적용은 8월 30일까지 진행합니다.",
  },
  {
    id: "han_summary", owner: "한유준", code: "WI-RSND-2026-047", title: "W35 자동보정 성과 종합", tag: "ANALYSIS",
    resources: ["WI-RSND-2026-047", "W35-S131"], previous: "법인별 자동보정 성과를 동일 기준으로 비교하기 위한 범위와 기준시점을 정리했습니다.",
    current: "WA·OT·MI_HL Tension 자동보정 범위의 평균 PD Loss는 36.71% 감소했으나 WA 자동차 NND는 10.72%→14.30%로 악화됐습니다. 개선·악화 공정을 함께 표기하고, W35 주간 범위와 담당 월간 공식 KPI 28.4%의 집계범위가 달라 대체값으로 사용하지 않습니다.",
  },
  {
    id: "jo_ax_nnd", owner: "조현우", code: "WI-RSND-2026-048", title: "AX NND 파라미터 최적화", tag: "PLAN",
    resources: ["WI-RSND-2026-048", "W35-S139", "W35-S143"], previous: "AX NND 최적화 알고리즘의 자원 사용량과 시험 시나리오를 설계했습니다.",
    current: "실시간 최적화에서 서버 자원 과점유, Cold Start, 반복탐색 비효율과 OT 시뮬레이션 취약점이 확인됐습니다. CPU·Memory 50% 미만 제한, 이전 최적값 초기해, Early Stop, Big M 패널티와 운영로그를 반영했습니다. OT는 효과가 확인되는 대표호기부터 선별 적용하고 9월 30일까지 Hyper Parameter Benchmark를 완료합니다.",
  },
  {
    id: "moon_davinci", owner: "문서윤", code: "WI-RSND-2026-049", title: "AX DNC·DaVinci WF 운영", tag: "RESULT",
    resources: ["WI-RSND-2026-049", "W35-S152", "W35-S159"], previous: "DNC 자동보정과 DaVinci WF의 법인별 운영상태를 확인했습니다.",
    current: "DaVinci는 Lot 매칭과 활용률 판정규칙이 복잡했고 DNC는 등속·가속구간의 제어특성이 달랐습니다. Lot ID·Enable·변화량 기준을 표준화하고 DNC는 즉시 Feedback과 FeedForward로 분리했습니다. 운영 WF에서 성과와 이상동작을 같은 시간축으로 추적하도록 연결했습니다.",
  },
  {
    id: "yu_na_apc", owner: "유민석", code: "WI-RSND-2026-050", title: "북미 신설법인 APC 전개", tag: "RESULT",
    resources: ["WI-RSND-2026-050", "W35-S147", "W35-S150"], previous: "북미 신설법인 Roll Press·Slitter APC 적용계획과 검증 항목을 정리했습니다.",
    current: "북미 신설법인은 PLC·Maker·공정구성이 달라 공통 로직을 그대로 적용하기 어려웠습니다. 로그 경량화, 역압 BIAS, PNT용 프로그램 전환과 Gap 비례제어를 순차 적용해 ESAZ Cpk 개선·수동보정 0회, NJ 두께 산포 20.4% 개선을 확인했습니다. 연간 3.31억원은 기대효과로 실제 절감액과 구분합니다.",
  },
  {
    id: "team_pd_impact", owner: "팀 공통", code: "AUTO-KPI-03", title: "W35 PD Loss KPI 영향", tag: "KPI",
    resources: ["AUTO-KPI-03", "W35-S131"],
    previous: "8월 월간보고에서 R/P·NND, WA·OT·MI_HL NND 평균 PD Loss 28.4% 개선을 보고했습니다.",
    current: "W35 주간보고의 WA·OT·MI_HL Tension 자동보정 범위에서 적용 전 대비 평균 PD Loss 36.71% 감소를 확인했습니다. WA 자동차 NND 악화와 미적용 설비를 별도 Risk로 관리하며, 법인·공정·기준일이 다른 담당 공식 KPI 28.4%를 대체하지 않습니다.",
  },
];

const sourceTeamComparisonOwners = ["윤도현", "강민재", "오세진", "한유준", "서진우", "임가은", "조현우", "문서윤", "배지호", "유민석", "팀 공통"];

const sourceTeamOwnerScopes = {
  윤도현: "Tension·단선 자동조치",
  강민재: "ESAZ·NJ·NFF",
  오세진: "WA Tension·Loadcell",
  한유준: "성과 종합·KPI 범위",
  서진우: "다빈치 WF 운영",
  임가은: "단선·NFF·WF·DNS",
  조현우: "AX NND 최적화",
  문서윤: "AX DNC·DaVinci WF",
  배지호: "DNC 신공법 자동보정",
  유민석: "북미 신설법인 APC",
  "팀 공통": "담당 KPI 영향",
};

function normalizeComparisonText(value) {
  return String(value || "").replace(/^\s*\(W(?:33 유지|34 신규)\)\s*/i, "").replace(/\s+/g, " ").trim();
}

function deriveComparisonStatus(previous, current) {
  const before = normalizeComparisonText(previous);
  const after = normalizeComparisonText(current);
  if (!before && !after) return "NEW";
  if (before && !after) return "DELETED";
  if (!before && after) return "NEW";
  if (before === after) return "RETAINED";
  return "UPDATED";
}

function comparisonStatusLabel(status) {
  return { RETAINED: "유지", UPDATED: "수정", NEW: "신규", DELETED: "삭제" }[status] || status;
}

function inferComparisonOwner(block) {
  if (block.owner) return block.owner;
  const codes = new Set(block.resources || []);
  if (codes.has("WI-RSND-2026-0038")) return "강민재";
  if (codes.has("WI-RSND-2026-0041")) return "배지호";
  if (codes.has("SNP-YIELD-2026-W35-003") || codes.has("DEC-RSND-2026-0008")) return "팀 공통";
  return "임가은";
}

function buildTeamComparisonRows(content) {
  const blocks = parseReportBlocks(content);
  const hasComparisonMetadata = blocks.some((block) => block.compareId);
  const used = new Set();
  const rows = sourceTeamComparisonCatalog.map((seed) => {
    const exactIndex = blocks.findIndex((block, index) => !used.has(index) && block.compareId === seed.id);
    const candidates = blocks.map((block, index) => ({ block, index })).filter(({ block, index }) => (
      !used.has(index) && block.tag === seed.tag && block.resources.includes(seed.code) && (!block.owner || block.owner === seed.owner)
    ));
    const fallback = candidates.find(({ block }) => block.statusTags.includes("NEW")) || candidates.at(-1);
    const matchIndex = exactIndex >= 0 ? exactIndex : fallback?.index;
    const match = Number.isInteger(matchIndex) ? blocks[matchIndex] : null;
    if (match) used.add(matchIndex);
    const current = match
      ? (match.statusTags.includes("DELETED") ? "" : normalizeComparisonText(match.body))
      : (hasComparisonMetadata ? "" : seed.current);
    return {
      ...seed,
      owner: match?.owner || seed.owner,
      title: match?.comparisonTitle || seed.title,
      resources: [...new Set([...(seed.resources || []), ...(match?.resources || [])])],
      current,
    };
  });
  blocks.forEach((block, index) => {
    if (used.has(index) || !block.compareId || block.statusTags.includes("DELETED")) return;
    rows.push({
      id: block.compareId,
      owner: inferComparisonOwner(block),
      code: block.resources[0] || defaultReportResourceCode(),
      title: block.comparisonTitle || "팀장 신규 작성 항목",
      tag: block.tag,
      resources: block.resources,
      previous: "",
      current: normalizeComparisonText(block.body),
    });
  });
  return rows;
}

function renderComparisonStatus(status) {
  return `<span class="comparison-status status-${status.toLowerCase()}" data-comparison-status>${comparisonStatusLabel(status)}</span>`;
}

function renderTeamComparisonRow(row) {
  const status = deriveComparisonStatus(row.previous, row.current);
  const newRow = !row.previous;
  return `<article class="team-compare-row status-${status.toLowerCase()}" data-comparison-id="${escapeHtml(row.id)}" data-owner="${escapeHtml(row.owner)}">
    <header class="team-compare-row-header">
      <div class="member-identity"><span class="member-avatar">${escapeHtml(row.owner === "팀 공통" ? "공" : row.owner.slice(0, 1))}</span><div><strong>${escapeHtml(row.owner)}</strong><code>${escapeHtml(row.code)}</code></div></div>
      <label class="comparison-title-field"><span>과제·항목</span><input class="comparison-title" value="${escapeHtml(row.title)}" aria-label="과제 또는 항목명"></label>
      <label class="comparison-tag-field"><span>유형</span><select class="comparison-tag">${reportTagOptions(row.tag)}</select></label>
      ${renderComparisonStatus(status)}
    </header>
    <div class="team-compare-columns">
      <section class="week-compare-pane previous-week"><div class="week-pane-label"><strong>지난주 · W34</strong><span>승인 원문 · 수정 불가</span></div><p class="comparison-previous-copy">${row.previous ? escapeHtml(row.previous) : "지난주 대응 항목 없음"}</p><textarea class="comparison-previous-value" hidden>${escapeHtml(row.previous || "")}</textarea></section>
      <section class="week-compare-pane current-week"><div class="week-pane-label"><strong>금주 · W35</strong><span>${status === "DELETED" ? "삭제 처리됨" : "팀장 편집 가능"}</span></div><textarea class="comparison-current-value" spellcheck="false" placeholder="금주 내용을 입력하십시오.">${escapeHtml(row.current || "")}</textarea></section>
    </div>
    <input type="hidden" class="comparison-code" value="${escapeHtml(row.code)}"><input type="hidden" class="comparison-resources" value="${escapeHtml((row.resources || []).join(","))}">
    <footer class="team-compare-row-actions">${row.previous ? `<button type="button" class="button ghost compact-button" data-keep-comparison>지난주 내용 유지</button>` : ""}<button type="button" class="button ${newRow ? "ghost" : "danger"} compact-button" data-delete-comparison>${newRow ? "신규 항목 제거" : "금주 내용 삭제"}</button><span>저장 시 상태와 New 표시가 자동 계산됩니다.</span></footer>
  </article>`;
}

function comparisonCounts(rows) {
  return rows.reduce((counts, row) => {
    const status = deriveComparisonStatus(row.previous, row.current);
    counts[status] += 1;
    return counts;
  }, { RETAINED: 0, UPDATED: 0, NEW: 0, DELETED: 0 });
}

function renderTeamComparisonSummary(rows) {
  const counts = comparisonCounts(rows);
  return `<div class="team-comparison-summary"><div><span>참여 팀원</span><strong>${sourceBackedModel.people.members.length}</strong><small>RSND자동보정팀 전체</small></div><div><span>유지</span><strong id="comparison-count-retained">${counts.RETAINED}</strong><small>지난주와 동일</small></div><div class="is-updated"><span>수정</span><strong id="comparison-count-updated">${counts.UPDATED}</strong><small>내용 변경</small></div><div class="is-new"><span>신규</span><strong id="comparison-count-new">${counts.NEW}</strong><small>지난주 항목 없음</small></div><div class="is-deleted"><span>삭제</span><strong id="comparison-count-deleted">${counts.DELETED}</strong><small>금주 보고 제외</small></div></div>`;
}

function renderTeamComparisonEditor(content) {
  const rows = buildTeamComparisonRows(content);
  const groups = sourceTeamComparisonOwners.map((owner) => {
    const ownerRows = rows.filter((row) => row.owner === owner);
    if (!ownerRows.length) return "";
    const descriptor = sourceTeamOwnerScopes[owner] || "RSND자동보정 업무";
    return `<section class="team-member-comparison" data-comparison-owner="${escapeHtml(owner)}"><header><div><span class="member-avatar large">${escapeHtml(owner === "팀 공통" ? "공" : owner.slice(0, 1))}</span><div><h3>${escapeHtml(owner)}</h3><p>${escapeHtml(descriptor)}</p></div></div><button type="button" class="button secondary compact-button" data-add-comparison="${escapeHtml(owner)}">+ 금주 신규 항목</button></header><div class="team-member-comparison-rows">${ownerRows.map(renderTeamComparisonRow).join("")}</div></section>`;
  }).join("");
  return `<div id="team-comparison-editor" class="team-comparison-editor"><div class="comparison-column-guide"><span>팀원·과제</span><strong>지난주 · W34</strong><strong>금주 · W35</strong><span>변경상태</span></div>${groups}</div>`;
}

function collectTeamComparisonRowsFromDom() {
  return [...document.querySelectorAll(".team-compare-row")].map((row) => ({
    id: row.dataset.comparisonId || `custom_${Date.now()}`,
    owner: row.dataset.owner || "팀 공통",
    code: $(".comparison-code", row)?.value.trim() || defaultReportResourceCode(),
    title: $(".comparison-title", row)?.value.trim() || "팀장 신규 작성 항목",
    tag: $(".comparison-tag", row)?.value || "RESULT",
    resources: ($(".comparison-resources", row)?.value || "").split(",").map((item) => item.trim()).filter(Boolean),
    previous: $(".comparison-previous-value", row)?.value.trim() || "",
    current: $(".comparison-current-value", row)?.value.trim() || "",
  }));
}

function safeComparisonMeta(value) {
  return String(value || "").replace(/[\[\]\n\r]/g, " ").trim();
}

function composeTeamComparisonContent() {
  return collectTeamComparisonRowsFromDom().map((row) => {
    const status = deriveComparisonStatus(row.previous, row.current);
    if (!row.previous && !row.current) return "";
    const resources = [...new Set([row.code, ...(row.resources || [])].filter(Boolean))];
    const meta = `[MEMBER:${safeComparisonMeta(row.owner)}][COMPARE:${safeComparisonMeta(row.id)}][TITLE:${safeComparisonMeta(row.title)}]`;
    const stateTag = status === "DELETED" ? "[DELETED]" : status === "NEW" || status === "UPDATED" ? "[NEW]" : "";
    const body = status === "DELETED" ? `금주 보고에서 삭제된 항목입니다. 지난주 원문: ${row.previous}` : row.current;
    return `${meta}${resources.map((item) => `[${item}]`).join("")}[${row.tag}]${stateTag} ${body}`;
  }).filter(Boolean).join("\n\n");
}

function syncTeamComparisonEditor() {
  const rows = collectTeamComparisonRowsFromDom();
  rows.forEach((row, index) => {
    const element = document.querySelectorAll(".team-compare-row")[index];
    const status = deriveComparisonStatus(row.previous, row.current);
    element.classList.remove("status-retained", "status-updated", "status-new", "status-deleted");
    element.classList.add(`status-${status.toLowerCase()}`);
    const badgeElement = $("[data-comparison-status]", element);
    if (badgeElement) {
      badgeElement.className = `comparison-status status-${status.toLowerCase()}`;
      badgeElement.textContent = comparisonStatusLabel(status);
    }
    const currentMeta = $(".current-week .week-pane-label span", element);
    if (currentMeta) currentMeta.textContent = status === "DELETED" ? "삭제 처리됨" : "팀장 편집 가능";
  });
  const counts = comparisonCounts(rows);
  Object.entries(counts).forEach(([status, value]) => {
    const counter = $(`#comparison-count-${status.toLowerCase()}`);
    if (counter) counter.textContent = value;
  });
  const machinePreview = $("#machine-record-preview");
  if (machinePreview) machinePreview.textContent = composeTeamComparisonContent();
}

function renderWorkPageEditor(page) {
  const blocks = page.blocks.length ? page.blocks : [{ tag: "RESULT", statusTags: ["NEW"], resources: [page.pageCode], body: "" }];
  return `<article class="work-page-editor" data-page-code="${escapeHtml(page.pageCode)}" data-page-title="${escapeHtml(page.title)}" data-page-site="${escapeHtml(page.siteScope)}" data-page-process="${escapeHtml(page.processScope)}" data-page-project="${escapeHtml(page.projectScope)}" data-page-authors="${escapeHtml(page.authors)}"><header class="work-page-editor-header"><div><span>${escapeHtml(page.pageCode)}</span><strong>${escapeHtml(page.title)}</strong></div><small>${escapeHtml(page.siteScope)} · ${escapeHtml(page.processScope)} · ${escapeHtml(page.authors)}</small></header><div class="work-page-edit-sections">${blocks.map(renderStructuredReportBlock).join("")}</div><div class="work-page-editor-actions"><button type="button" class="button secondary" data-add-page-section>+ 금주 문장 추가</button><span>새 문장은 이 페이지의 마지막에 추가되고 파란색 New로 표시됩니다.</span></div></article>`;
}

function renderWorkPagesEditor(content) {
  const pages = parseReportPages(content);
  if (!pages.length) return renderStructuredReportEditor(content);
  return `<div id="work-page-editor" class="work-pages-editor">${pages.map(renderWorkPageEditor).join("")}</div>`;
}

function composeStructuredReportContent() {
  const blocks = [...document.querySelectorAll(".structured-edit-block")].map((block) => {
    const tag = $(".block-tag-select", block)?.value || "RESULT";
    const body = $(".block-body", block)?.value.trim() || "";
    const resources = ($(".block-resources", block)?.value || "").split(",").map((item) => item.trim()).filter(Boolean);
    const statusTags = ($(".block-status-tags", block)?.value || "").split(",").map((item) => item.trim()).filter((item) => reportStateTags.includes(item));
    if (!body) return "";
    const tokens = [...new Set(resources)].map((item) => `[${item}]`).join("") + `[${tag}]` + [...new Set(statusTags)].map((item) => `[${item}]`).join("");
    return `${tokens} ${body}`;
  }).filter(Boolean);
  return blocks.join("\n\n");
}

function composeWorkPageContent() {
  const pages = [...document.querySelectorAll(".work-page-editor")].map((page) => {
    const blocks = [...page.querySelectorAll(".structured-edit-block")].map((block) => {
      const tag = $(".block-tag-select", block)?.value || "RESULT";
      const body = $(".block-body", block)?.value.trim() || "";
      const resources = ($(".block-resources", block)?.value || "").split(",").map((item) => item.trim()).filter(Boolean);
      const statusTags = ($(".block-status-tags", block)?.value || "").split(",").map((item) => item.trim()).filter((item) => reportStateTags.includes(item));
      if (!body) return "";
      const tokens = [...new Set(resources)].map((item) => `[${item}]`).join("") + `[${tag}]` + [...new Set(statusTags)].map((item) => `[${item}]`).join("");
      return `${tokens} ${body}`;
    }).filter(Boolean);
    if (!blocks.length) return "";
    const header = [page.dataset.pageCode, page.dataset.pageTitle, page.dataset.pageSite, page.dataset.pageProcess, page.dataset.pageProject, page.dataset.pageAuthors].join("|");
    return `@@PAGE|${header}@@\n${blocks.join("\n\n")}\n@@ENDPAGE@@`;
  }).filter(Boolean);
  return pages.join("\n\n");
}

function syncWorkPageEditor() {
  const content = composeWorkPageContent();
  const preview = $("#formatted-report-preview");
  const machinePreview = $("#machine-record-preview");
  if (preview) preview.innerHTML = renderReportPages(content);
  if (machinePreview) machinePreview.textContent = content;
}

function syncStructuredReportEditor() {
  const content = composeStructuredReportContent();
  const preview = $("#formatted-report-preview");
  const machinePreview = $("#machine-record-preview");
  if (preview) preview.innerHTML = renderTaggedReport(content);
  if (machinePreview) machinePreview.textContent = content;
}

function renderEntry() {
  const recent = state.data.worklogs
    .filter((log) => state.data.work_items.some((item) => item.id === log.work_item_id))
    .slice()
    .sort((left, right) => String(right.occurred_on).localeCompare(String(left.occurred_on)))
    .slice(0, 5);
  const options = state.data.work_items.map((item) => `<option value="${escapeHtml(item.id)}">${escapeHtml(item.work_item_code)} · ${escapeHtml(item.title)}</option>`).join("");
  return `<div class="grid-2">${card("Worklog 추가 작성", `<div class="notice"><strong>여기에 저장한 내용은 다음 화면부터 계속 사용됩니다.</strong>Evidence 연결, AI 업무분류 확인, 개인 초안과 팀장 검토 화면에 동일 Record가 표시됩니다.</div><div class="form-grid"><label class="full">WorkItem<select id="worklog-workitem">${options}</select></label><label>기록 유형<select id="worklog-type"><option value="RESULT">RESULT · 수행 결과</option><option value="FACT">FACT · 확인된 사실</option><option value="ANALYSIS">ANALYSIS · 분석/가설</option><option value="PLAN" selected>PLAN · 차주 계획</option><option value="RISK">RISK · 위험</option></select></label><label>발생일<input id="worklog-date" type="date" value="2026-08-24"></label><label class="full">추가 작성<textarea id="worklog-narrative">K12 검증용 생산 일정을 W35 우선 배정한 후, 제품별 상·하한 및 예외조건을 확정하고 동일 조건 기준으로 PD Loss 효과를 재산출하겠습니다.</textarea></label></div><div class="button-row"><button class="button secondary" data-demo="apply-suggestion">AI 문장 다듬기</button><button class="button primary" data-save-worklog>저장하고 다음 화면으로</button></div>`)}${card("최근 작성 이력", `<div class="timeline compact-timeline">${recent.map((log) => `<article><span>${formatDate(log.occurred_on)}</span><div>${reportTag(log.entry_type)} <code>${escapeHtml(log.work_item_code)}</code><p>${escapeHtml(log.narrative)}</p></div></article>`).join("")}</div>`)}</div>`;
}

function renderEvidenceUpload() {
  const rows = state.data.evidence.map((item) => `<tr><td><code>${escapeHtml(item.evidence_code)}</code></td><td>${escapeHtml(item.file_name)}</td><td>${escapeHtml(item.locator || "—")}</td><td>${badge(item.scan_status)}</td><td>${badge(item.security_label)}</td></tr>`);
  const options = state.data.work_items.map((item) => `<option value="${escapeHtml(item.id)}">${escapeHtml(item.work_item_code)} · ${escapeHtml(item.title)}</option>`).join("");
  const latestLog = state.data.worklogs.find((log) => state.data.work_items.some((item) => item.id === log.work_item_id));
  return `${card("업무파일 등록", `<div class="continuity-banner"><span>직전 작성</span><strong>${latestLog ? escapeHtml(latestLog.narrative) : "추가 기록 없음"}</strong></div><div class="dropzone compact-dropzone"><div class="upload-icon">⇧</div><strong>파일명과 원문 위치를 등록하십시오</strong><span>시연에서는 파일 Metadata와 연결관계를 저장합니다.</span></div><div class="form-grid compact"><label>연결 WorkItem<select id="evidence-workitem">${options}</select></label><label>보안등급<select id="evidence-security"><option>CONFIDENTIAL</option><option>INTERNAL</option></select></label><label class="full">파일명<input id="evidence-file-name" value="K12_추가검증_결과.xlsx"></label><label class="full">원문 위치·범위<input id="evidence-locator" value="Result!B4:H18"></label></div><div class="button-row"><button class="button primary" data-save-evidence>등록하고 AI 업무분류 확인으로</button></div>`)}${card("등록된 Evidence", table(["Evidence ID", "파일", "Locator", "검사", "등급"], rows))}`;
}

function pageContributorsLabel(page) {
  return String(page.contributors || "").split(",").filter(Boolean).map((entry) => {
    const [name, role] = entry.split(":");
    return `${name}${role === "PRIMARY" ? "(주)" : "(공동)"}`;
  }).join(" · ") || page.primary_owner_name || "—";
}

function pageWorkItemIds(page) {
  return String(page.work_item_ids || "").split(",").filter(Boolean);
}

function renderSelection(leaderMode) {
  const selection = new Map((state.data.submission_pages || []).filter((item) => item.submission_id === "sub_member1").map((item) => [item.work_page_id, Boolean(item.included)]));
  const rows = (state.data.work_pages || []).map((page, index) => {
    const itemIds = pageWorkItemIds(page);
    const logs = state.data.worklogs.filter((log) => itemIds.includes(log.work_item_id) && String(log.occurred_on) >= "2026-07-27");
    const newLogs = logs.filter((log) => String(log.occurred_on) >= "2026-08-24");
    const evidenceCount = state.data.evidence.filter((evidence) => itemIds.includes(evidence.work_item_id)).length;
    const checked = leaderMode ? index < 3 : (selection.has(page.id) ? selection.get(page.id) : logs.length > 0);
    return `<tr><td><input class="row-check" type="checkbox" data-page-select="${escapeHtml(page.id)}" ${checked ? "checked" : ""} ${leaderMode ? "" : "disabled"}></td><td><code>${escapeHtml(page.page_code)}</code><br><strong>${escapeHtml(page.title)}</strong><br><span class="small muted">${escapeHtml(page.project_scope)}</span></td><td>${escapeHtml(page.site_scope)}<br><span class="small muted">${escapeHtml(page.process_scope)}</span></td><td>${escapeHtml(pageContributorsLabel(page))}</td><td>${badge("RETAINED", `${page.retention_weeks || 4}주 · ${logs.length}건`)}</td><td>${newLogs.length ? `${reportTag("NEW")} ${newLogs.length}건` : badge("NO_CHANGE", "변경 없음")}</td><td>${evidenceCount ? badge("EVIDENCE", `근거 ${evidenceCount}건`) : badge("NO_EVIDENCE", "근거 없음")}</td></tr>`;
  });
  const title = leaderMode ? "팀 보고 업무페이지 포함·제외" : "AI 업무분류 확인";
  const notice = leaderMode
    ? `<div class="notice"><strong>제출 단위는 개별 문장이 아니라 업무페이지입니다.</strong>팀장은 포함·제외 여부를 최종 확인합니다.</div>`
    : `<div class="notice"><strong>업무 Agent가 전체 업무이력과 입력 내용을 업무페이지별로 자동 분류했습니다.</strong>분류가 불명확한 내용은 Agent가 먼저 질문하며, 팀원은 과제를 사전에 선택하지 않습니다.</div>`;
  return `${card(title, `${notice}${table([leaderMode ? "포함" : "AI 분류", "업무페이지", "법인·공정", "작성자", "유지 이력", "금주 변경", "Evidence"], rows)}<div class="button-row"><button class="button primary" data-generate-draft>${leaderMode ? "선택 페이지로 팀 초안 생성" : "자동분류 결과로 개인 초안 생성"}</button></div>`)}${card("다음 화면 반영 원칙", `<ul class="list"><li><strong>Agent 자동분류</strong><span>내용·법인·공정·프로젝트 맥락으로 대상 업무페이지 판단</span></li><li><strong>불명확 시 질문</strong><span>임의 배치하지 않고 최대 3개의 확인 질문 후 확정</span></li><li><strong>최근 4주</strong><span>기존 서술을 삭제하지 않고 최소 4주간 유지</span></li><li><strong>금주 변경</strong><span>신규·수정 문장만 파란색 New로 표시</span></li></ul>`)}`;
}

function editorLevel(level) {
  if (level === "TEAM_MEMBER") {
    const submission = state.data.submissions.find((item) => item.member_user_id === state.data.principal.id) || state.data.submissions[0];
    const version = (state.data.submission_versions || []).find((item) => item.submission_id === submission?.id);
    return { title: "팀원 주간실적", report: null, reportCode: submission?.submission_code, status: submission?.status, content: version?.content, sourceManifest: version?.source_manifest };
  }
  if (level === "TEAM") return { title: "RSND자동보정팀 팀장 주차 비교 보고", report: reportByLevel("TEAM") };
  if (level === "DEPARTMENT") return { title: "자동보정담당 주간보고", report: reportByLevel("DEPARTMENT") };
  return { title: "제조DX그룹 주간보고", report: reportByLevel("GROUP") };
}

function renderTeamLeaderComparisonScreen(config, content, sources, reportCode, status) {
  const rows = buildTeamComparisonRows(content);
  const counts = comparisonCounts(rows);
  const editor = renderTeamComparisonEditor(content);
  const checks = `<ul class="check-list"><li class="pass">✓ 팀원 보고 ${sourceBackedModel.people.members.length}명 통합 · W35 전체 31페이지 연결</li><li class="pass">✓ 과제·유형별 W34↔W35 정렬</li><li class="pass">✓ 수정 ${counts.UPDATED}건 · 신규 ${counts.NEW}건</li><li class="pass">✓ 삭제 ${counts.DELETED}건 별도 표시</li><li class="pass">✓ KPI 목표·월간실적·주간기여 분리</li><li class="pass">✓ PDF는 W35 금주 내용만 출력</li></ul>`;
  const memberSummary = `<ul class="leader-member-list">${sourceTeamComparisonOwners.filter((owner) => owner !== "팀 공통").map((owner) => `<li><span class="member-avatar">${escapeHtml(owner.slice(0, 1))}</span><div><strong>${escapeHtml(owner)}</strong><small>${escapeHtml(sourceTeamOwnerScopes[owner])}</small></div><b>${rows.filter((row) => row.owner === owner).length}개</b></li>`).join("")}</ul>`;
  return `<div class="editor-layout comparison-editor-layout"><section class="card editor-main team-leader-editor"><div class="card-top"><div><span class="small muted">${escapeHtml(reportCode)}</span><h2>${escapeHtml(config.title)} · 주차 비교 편집</h2></div>${badge(status)}</div><div class="notice"><strong>작성할 때만 같은 과제의 지난주와 금주를 좌우 비교합니다.</strong>왼쪽 W34는 승인 원문으로 고정되고, 오른쪽 W35에서 유지·수정·삭제하거나 신규 항목을 작성할 수 있습니다. 최종 보고본과 PDF에는 W35 금주 내용만 포함됩니다.</div>${renderTeamComparisonSummary(rows)}<div class="comparison-workspace-heading"><div><strong>팀원별 과제 비교</strong><span>왼쪽은 지난주 원문, 오른쪽 파란 영역은 금주 편집본입니다.</span></div><div class="comparison-legend"><span class="status-retained">유지</span><span class="status-updated">수정</span><span class="status-new">신규</span><span class="status-deleted">삭제</span></div></div>${editor}<details class="machine-record"><summary>AI 저장 구조 확인</summary><pre id="machine-record-preview">${escapeHtml(composeTeamComparisonSeedContent(rows))}</pre></details><div class="button-row"><button class="button secondary" data-generate-draft>팀원 최신 제출로 다시 생성</button><button class="button primary" data-save-version>비교 편집본 저장하고 금주 보고본으로</button></div></section><aside class="stack">${card("포함된 팀원", memberSummary)}${card("비교·편집 원칙", `<ul class="list"><li><strong>유지</strong><span>지난주 문장을 금주에도 그대로 사용</span></li><li><strong>수정</strong><span>같은 항목의 금주 변경분을 파란색 표시</span></li><li><strong>삭제</strong><span>지난주 원문은 보존하고 금주 보고에서만 제외</span></li><li><strong>신규</strong><span>지난주 대응 항목 없이 금주에 새로 작성</span></li></ul>`)}${card("AI Readable 검사", checks)}${card("Source Manifest", `<div>${sources.map((source) => `<span class="source-chip">${escapeHtml(source)}</span>`).join("") || "생성 후 표시"}</div><p class="small muted">비교 편집본과 함께 Version으로 저장됩니다.</p>`)}</aside></div>`;
}

function composeTeamComparisonSeedContent(rows) {
  return rows.map((row) => {
    const status = deriveComparisonStatus(row.previous, row.current);
    if (!row.previous && !row.current) return "";
    const meta = `[MEMBER:${safeComparisonMeta(row.owner)}][COMPARE:${safeComparisonMeta(row.id)}][TITLE:${safeComparisonMeta(row.title)}]`;
    const stateTag = status === "DELETED" ? "[DELETED]" : status === "NEW" || status === "UPDATED" ? "[NEW]" : "";
    const body = status === "DELETED" ? `금주 보고에서 삭제된 항목입니다. 지난주 원문: ${row.previous}` : row.current;
    return `${meta}${[...new Set([row.code, ...(row.resources || [])].filter(Boolean))].map((item) => `[${item}]`).join("")}[${row.tag}]${stateTag} ${body}`;
  }).filter(Boolean).join("\n\n");
}

function renderEditor(level) {
  const config = editorLevel(level);
  const teamLeaderMode = level === "TEAM";
  const content = teamLeaderMode ? (state.generatedDraft || "") : state.generatedDraft || config.content || config.report?.content || "선택한 업무를 기준으로 Agent 초안을 생성하십시오.";
  const manifest = teamLeaderMode ? "자동보정담당 W31~W35,8월 자동보정담당 월간보고,자동보정담당 KPI 목표 vF" : config.sourceManifest || config.report?.source_manifest || "";
  const sources = String(manifest).split(",").filter(Boolean);
  const reportCode = config.reportCode || config.report?.report_code || "SUB-RSND-2026-W35-001";
  const status = config.status || config.report?.status || "AI_DRAFTED";
  const memberPageMode = level === "TEAM_MEMBER" && parseReportPages(content).length > 0;
  if (teamLeaderMode) return renderTeamLeaderComparisonScreen(config, content, sources, reportCode, status);
  const reportBlocks = parseReportBlocks(content);
  const newBlockCount = reportBlocks.filter((block) => block.statusTags.includes("NEW")).length;
  const retainedBlockCount = reportBlocks.length - newBlockCount;
  const preview = memberPageMode ? renderReportPages(content) : renderTaggedReport(content);
  const editor = memberPageMode ? renderWorkPagesEditor(content) : renderStructuredReportEditor(content);
  const notice = teamLeaderMode
    ? `<div class="notice"><strong>지난주 보고와 W35 변경분을 함께 보여줍니다.</strong>기본색 ${retainedBlockCount}건은 지난주 유지 내용, 파란색 ${newBlockCount}건은 이번 주 신규·변경 내용입니다. Agent가 다시 생성해도 같은 기준으로 구분됩니다.</div>`
    : memberPageMode
    ? `<div class="notice"><strong>업무페이지가 팀장 제출의 최소 단위입니다.</strong>법인·공정·프로젝트별로 최근 4주 서술을 유지하고 금주 신규·수정 문장만 파란색 New로 표시합니다. 공동작성자의 기록도 같은 페이지에 합쳐집니다.</div>`
    : `<div class="notice"><strong>Code를 직접 입력하지 않아도 됩니다.</strong>문단 Tag와 서술을 수정하면 ID와 근거는 내부에서 연결됩니다.</div>`;
  const checks = teamLeaderMode
    ? `<ul class="check-list"><li class="pass">✓ 지난주 유지 ${retainedBlockCount}건</li><li class="pass">✓ W35 신규·변경 ${newBlockCount}건</li><li class="pass">✓ 승인·잠금 수율 Snapshot 사용</li><li class="pass">✓ Result·Analysis·Risk·Plan·Decision 구성</li><li class="pass">✓ 신규 문장 파란색 표시</li><li class="pass">✓ PDF 색상 구분 유지</li></ul>`
    : memberPageMode
    ? `<ul class="check-list"><li class="pass">✓ 업무페이지 3개 구성</li><li class="pass">✓ 최근 4주 이력 유지</li><li class="pass">✓ 금주 변경 파란색 표시</li><li class="pass">✓ 대표·공동 작성자 연결</li><li class="pass">✓ 페이지 단위 팀장 제출</li><li class="warn">! 잠정 KPI 상태 확인</li></ul>`
    : `<ul class="check-list"><li class="pass">✓ 서술형 원문 유지</li><li class="pass">✓ 문단 유형 Tag</li><li class="pass">✓ ID·Code 자동 연결</li><li class="pass">✓ 숫자·단위 대조</li><li class="warn">! 잠정 KPI 상태 확인</li></ul>`;
  const changeSummary = teamLeaderMode ? `<div class="weekly-change-summary"><div><span>지난주 유지</span><strong>${retainedBlockCount}</strong><small>기본색 문단</small></div><div class="is-new"><span>W35 신규·변경</span><strong>${newBlockCount}</strong><small>파란색 문단</small></div><div><span>전체 구성</span><strong>${reportBlocks.length}</strong><small>팀장 보고 문단</small></div></div>` : "";
  return `<div class="editor-layout"><section class="card editor-main"><div class="card-top"><div><span class="small muted">${escapeHtml(reportCode)}</span><h2>${escapeHtml(config.title)}</h2></div>${badge(status)}</div>${notice}${changeSummary}<div class="report-preview-heading"><strong>${memberPageMode ? "업무페이지 미리보기" : teamLeaderMode ? "지난주 대비 팀 보고 미리보기" : "보고서 미리보기"}</strong><span>${memberPageMode ? "팀장에게 이 페이지 단위로 전달됩니다." : teamLeaderMode ? "파란색 문단이 이번 주 신규·변경 내용입니다." : "아래 문단을 수정하면 즉시 반영됩니다."}</span></div><div id="formatted-report-preview" class="formatted-report-preview">${preview}</div><div class="structured-editor-heading"><strong>${memberPageMode ? "업무페이지별 내용 편집" : "보고서 문단 편집"}</strong><span>${memberPageMode ? "기존 4주 이력 유지 + 금주 문장 추가" : teamLeaderMode ? "지난주 유지 + W35 New 편집" : "Tag 선택 + 일반 문장 입력"}</span></div>${editor}<details class="machine-record"><summary>AI 저장 구조 확인</summary><pre id="machine-record-preview">${escapeHtml(content)}</pre></details><div class="button-row"><button class="button secondary" data-generate-draft>추가 기록으로 다시 생성</button><button class="button primary" data-save-version>수정본 저장하고 다음 화면으로</button></div></section><aside class="stack">${card("표시 가이드", `<div class="tag-guide">${["BACKGROUND", "RESULT", "ANALYSIS", "PLAN", "RISK", "KPI", "DECISION", "NEW"].map((tag) => `${reportTag(tag)}<span>${reportTagDescriptions[tag]}</span>`).join("")}</div>`)}${card("AI Readable 검사", checks)}${card("Source Manifest", `<div>${sources.map((source) => `<span class="source-chip">${escapeHtml(source)}</span>`).join("") || "생성 후 표시"}</div><p class="small muted">페이지 Version과 함께 불변 저장됩니다.</p>`)}</aside></div>`;
}

function renderSubmission() {
  const mine = state.data.submissions.find((item) => item.member_name === state.data.principal.display_name) || state.data.submissions[0];
  const version = (state.data.submission_versions || []).find((item) => item.submission_id === mine.id);
  const content = version?.content || state.generatedDraft || "";
  const pageCount = parseReportPages(content).length;
  return `${card("제출 상태", `<div class="submission-hero"><div><span class="small muted">${escapeHtml(mine.submission_code)}</span><h2>${escapeHtml(mine.member_name)} · W35</h2><p>현재 Version ${mine.version} · 업무페이지 ${pageCount || 1}장 · ${mine.submitted_at ? formatDate(mine.submitted_at, true) : "아직 제출하지 않음"}</p></div>${badge(mine.status)}</div>${renderWorkflow(mine.status === "SUBMITTED" ? 1 : 0)}<div class="notice"><strong>팀장에게는 아래 업무페이지 전체가 전달됩니다.</strong>Result·Analysis·Plan 문장을 별도 제출하지 않고 페이지의 연속된 글과 작성자 정보를 함께 고정합니다.</div><div class="button-row"><button class="button primary" data-action="SUBMIT_MEMBER">업무페이지 ${pageCount || 1}장을 팀장에게 제출</button></div>`)}${card("팀장에게 전달될 업무페이지", `<div class="formatted-report-preview compact-preview">${renderReportPages(content, true)}</div>`)}${card("Version 이력", table(["Version", "생성 주체", "단위", "상태", "시각"], [`<tr><td>v${mine.version}</td><td>MEMBER + AGENT</td><td>업무페이지 ${pageCount || 1}장</td><td>${badge(mine.status)}</td><td>${mine.submitted_at ? formatDate(mine.submitted_at, true) : "임시 저장"}</td></tr>`, `<tr><td>v1</td><td>MEMBER</td><td>업무페이지</td><td>${badge("DRAFT")}</td><td>08.23 16:42</td></tr>`]))}`;
}

function renderSubmissionMatrix() {
  const rows = state.data.submissions.map((item) => `<tr><td><strong>${escapeHtml(item.member_name)}</strong><br><span class="small muted">${escapeHtml(item.organization_name)}</span></td><td><code>${escapeHtml(item.submission_code)}</code></td><td>${badge(item.status)}</td><td>v${item.version}</td><td>${item.submitted_at ? formatDate(item.submitted_at, true) : "—"}</td><td><button class="button secondary" data-demo="open-submission">검토</button></td></tr>`);
  return `${card("RSND자동보정팀 제출 현황", `<div class="metrics compact-metrics">${metricCard("제출 완료", state.data.counts.submitted_members, `전체 ${state.data.counts.members_total}명`)}${metricCard("미검토", 2, "오늘 12:00까지")}${metricCard("반려", 0, "보완 요청 없음")}</div>${table(["팀원", "Submission", "상태", "Version", "제출시각", ""], rows)}`)}${card("검토 순서 제안", `<div class="notice"><strong>1. 임가은 — 잠정 KPI와 Decision 요청 포함</strong>2. 강민재 — 정량 효과 근거 확인<br>3. 배지호 — 협업 가설이 확정 사실과 분리됐는지 확인</div>`)}`;
}

function renderMemberDetail() {
  const sub = state.data.submissions[0];
  const version = (state.data.submission_versions || []).find((item) => item.submission_id === sub.id);
  const sources = String(version?.source_manifest || "").split(",").filter(Boolean);
  const content = version?.content || "";
  const pageCount = parseReportPages(content).length;
  return `<div class="grid-2 member-review-grid">${card("팀원 제출 업무페이지", `<div class="card-top"><div><code>${escapeHtml(sub.submission_code)}</code><h2>${escapeHtml(sub.member_name)} · ${pageCount || 1}개 페이지</h2></div>${badge(sub.status)}</div><div class="formatted-report-preview compact-preview">${renderReportPages(content, true)}</div><div class="button-row"><button class="button danger" data-demo="return">페이지 보완 요청</button><button class="button primary" data-demo="include">선택 페이지를 팀 보고에 포함</button></div>`)}${card("페이지 검토 기준", `<div>${sources.map((source) => `<span class="source-chip">${escapeHtml(source)}</span>`).join("")}</div><ul class="list"><li><strong>보고 단위</strong><span>문장이 아니라 법인·공정·프로젝트 업무페이지 단위로 검토</span></li><li><strong>4주 유지</strong><span>W31~W35 기존 서술의 누락 여부 확인</span></li><li><strong>금주 변경</strong><span>파란색 New 문장만 신규·업데이트로 식별</span></li><li><strong>공동작성</strong><span>대표 작성자와 공동 작성자의 기여가 한 페이지에 통합됨</span></li><li><strong>Evidence</strong><span>파일명·원문 위치·Hash를 Source Manifest로 연결</span></li></ul>`)}</div>`;
}

function renderEvidenceCompare() {
  const report = reportByLevel("TEAM");
  return `${card("문장–근거 대조", `<div class="compare-grid"><div><span class="pane-title">보고 문장</span><p><mark>W35 PD Loss는 1.2%</mark>로 전주 1.5% 대비 감소했으나 Data Owner 승인 전 잠정값이다.</p></div><div><span class="pane-title">공식 Resource</span><dl class="detail-grid"><div><dt>Snapshot</dt><dd>SNP-PD-2026-W35-004</dd></div><div><dt>값</dt><dd>1.2%</dd></div><div><dt>전주</dt><dd>1.5%</dd></div><div><dt>상태</dt><dd>${badge("PROVISIONAL")}</dd></div><div><dt>Cut-off</dt><dd>2026-08-23 23:59</dd></div><div><dt>일치</dt><dd>${badge("MATCH", "일치")}</dd></div></dl></div></div>`)}${card("검사 결과", `<div class="metrics compact-metrics">${metricCard("숫자", "4/4", "Exact match")}${metricCard("Citation", "4/4", "Resource 존재")}${metricCard("주의", "1", "잠정 상태 유지")}</div><div class="source-chips">${String(report?.source_manifest || "").split(",").map((x) => `<span class="source-chip">${escapeHtml(x)}</span>`).join("")}</div>`)}`;
}

function renderApproval() {
  const role = state.role;
  const level = role === "LEADER" ? "TEAM" : role === "DEPT" ? "DEPARTMENT" : "GROUP";
  const report = reportByLevel(level);
  const next = role === "LEADER" ? "자동보정담당" : role === "DEPT" ? "제조DX기획팀 · 그룹장" : "그룹장";
  return `${card("승인 Action Preview", `<div class="approval-preview"><div><span>대상 Report</span><strong>${escapeHtml(report?.report_code || "RPT-GROUP-DX-2026-W35")}</strong></div><div><span>현재 상태</span><strong>${badge(report?.status || "DRAFT")}</strong></div><div><span>다음 수신</span><strong>${escapeHtml(next)}</strong></div><div><span>고정 Version</span><strong>v${report?.current_version || 1}</strong></div></div><div class="notice warn"><strong>승인 후 원문을 덮어쓰지 않습니다.</strong>정정이 필요하면 새 Version을 만들고 승인 이력을 다시 남깁니다.</div><div class="button-row"><button class="button danger" data-demo="return-report">반려·보완 요청</button><button class="button primary" data-action="${escapeHtml(actionMap[currentScreen().screen_id] || "APPROVE_TEAM")}">${escapeHtml(currentScreen().primary_action)}</button></div>`)}${card("승인 체크", `<ul class="check-list"><li class="pass">✓ 하위 제출·승인 상태 확인</li><li class="pass">✓ 숫자와 Snapshot 일치</li><li class="pass">✓ Evidence 연결</li><li class="warn">! 잠정 KPI 라벨 유지</li><li class="pass">✓ Owner·Due 누락 없음</li></ul>`)}`;
}

function renderHistory() {
  const report = reportByLevel("TEAM");
  return `${card("Report Version 비교", `<div class="version-tabs"><button class="active">v${report?.current_version || 1} · 현재</button><button>v1 · Agent</button><button>원문</button></div><div class="diff-view"><div><span class="pane-title">이전 Version</span><p>Jamming 보정조건 검증 완료. K12 추가 확인 필요.</p></div><div><span class="pane-title">현재 승인 후보</span><p><ins>[WI-RSND-2026-0032][RESULT]</ins> Jamming 자동보정 조건을 검증하였다. 대상 3개 제품 중 2개는 반복 경향을 확인했고 <ins>K12는 추가 검증이 필요하다.</ins></p></div></div>`)}${card("변경 이력", table(["Version", "생성 주체", "변경 요약", "시각"], [`<tr><td>v2</td><td>팀장</td><td>ID·잠정상태·Decision 보강</td><td>08.24 10:12</td></tr>`, `<tr><td>v1</td><td>LEADER_AGENT</td><td>팀원 제출 3건 종합</td><td>08.24 09:40</td></tr>`]))}`;
}

function renderTeamMatrix() {
  const teams = [["RSND자동보정팀", "RPT-TEAM-RSND-2026-W35", "DRAFT", "3/3", "PD Loss · Jamming"], ["전극자동보정팀", "RPT-TEAM-ELC-2026-W35", "TEAM_APPROVED", "4/4", "BM Loss · 로딩량"], ["조립자동보정팀", "RPT-TEAM-ASM-2026-W35", "TEAM_APPROVED", "5/5", "PD Loss · 주액기"], ["활성화자동보정팀", "RPT-TEAM-ACT-2026-W35", "NEEDS_EVIDENCE", "3/4", "CTQ · Evidence 누락"]];
  return `${card("팀 보고 Matrix", table(["팀", "Report", "상태", "제출", "핵심 안건"], teams.map((r) => `<tr><td><strong>${r[0]}</strong></td><td><code>${r[1]}</code></td><td>${badge(r[2])}</td><td>${r[3]}</td><td>${r[4]}</td></tr>`)))}${card("담당 관점 Agent 요약", `<div class="notice"><strong>우선 검토: 활성화자동보정팀 Evidence 누락</strong>미승인 팀 원문은 담당 보고의 확정 사실로 집계하지 않습니다. RSND·FDC의 Jamming 안건은 Collaboration ID로 한 번만 묶습니다.</div>`)}`;
}

function renderCollaboration() {
  const participants = state.data.participants;
  return `<div class="collab-grid">${state.data.collaborations.map((c) => {
    const people = participants.filter((p) => p.collaboration_id === c.id);
    return `<section class="card"><div class="card-top"><code>${escapeHtml(c.collaboration_code)}</code>${badge(c.status)}</div><h2>${escapeHtml(c.title)}</h2><p>${escapeHtml(c.goal)}</p><div class="collab-flow"><span>${escapeHtml(c.lead_organization)} · 주관</span>${people.map((p) => `<span>${escapeHtml(p.organization_name)}</span>`).join("")}</div><ul class="list">${people.map((p) => `<li><strong>${escapeHtml(p.organization_name)}</strong><span>${escapeHtml(p.contribution)}</span></li>`).join("")}</ul><p class="small muted">목표일 ${formatDate(c.target_date)}</p></section>`;
  }).join("")}</div>`;
}

function renderConflict() {
  return `${card("KPI·주장 충돌", `<div class="conflict-row"><div>${badge("PROVISIONAL")}<h3>PD Loss 값 상태</h3><p>팀 보고는 1.2%를 확정값처럼 기술했으나 Snapshot은 Data Owner 승인 전입니다.</p></div><div class="conflict-arrow">→</div><div><strong>권고 처리</strong><p>값은 유지하고 문장에 <code>[PROVISIONAL]</code>과 Cut-off를 표시합니다.</p><button class="button secondary" data-demo="conflict">권고 적용</button></div></div><div class="conflict-row"><div>${badge("ANALYSIS")}<h3>Jamming 원인 해석</h3><p>FDC 장력 편차와 발생 시점의 상관성을 원인으로 표현한 팀이 있습니다.</p></div><div class="conflict-arrow">→</div><div><strong>권고 처리</strong><p>팀별 가설을 병렬 유지하고 공동 검증 중으로 표시합니다.</p><button class="button secondary" data-demo="conflict">병렬 표기</button></div></div>`)}${card("충돌 처리 원칙", `<ol class="principles"><li>최신값을 임의 선택하지 않습니다.</li><li>Snapshot Version·집계범위·기준시각을 먼저 대조합니다.</li><li>확정 사실과 팀별 분석·가설을 분리합니다.</li><li>해결 방식과 승인자를 감사 이력에 남깁니다.</li></ol>`)}`;
}

function renderDecisionRegister() {
  const decisions = state.data.decisions.map((d) => `<tr><td><code>${escapeHtml(d.decision_code)}</code></td><td><strong>${escapeHtml(d.title)}</strong><br><span class="small muted">${escapeHtml(d.request)}</span></td><td>${escapeHtml(d.decision_maker || "미지정")}</td><td>${formatDate(d.due_date)}</td><td>${badge(d.status)}</td></tr>`);
  const actions = state.data.action_items.map((a) => `<tr><td><code>${escapeHtml(a.action_code)}</code></td><td>${escapeHtml(a.title)}</td><td>${escapeHtml(a.owner_name || "미지정")}</td><td>${formatDate(a.due_date)}</td><td>${badge(a.status)}</td></tr>`);
  return `${card("Decision 요청", table(["Decision ID", "요청", "결정자", "기한", "상태"], decisions))}${card("후속 Action", table(["Action ID", "조치", "Owner", "Due", "상태"], actions))}`;
}

function issueRows(resourceType = null) {
  return state.data.qa_issues.filter((item) => !resourceType || item.resource_type === resourceType).map((item) => `<article class="qa-item"><span>${badge(item.severity)}</span><div><strong>${escapeHtml(item.rule_code)} · ${escapeHtml(item.message)}</strong><p>${escapeHtml(item.remediation)}</p><code>${escapeHtml(item.resource_id)}</code></div>${badge(item.status)}</article>`).join("") || `<div class="empty-state">열린 Issue가 없습니다.</div>`;
}

function renderQa() {
  const open = state.data.qa_issues.filter((item) => item.status === "OPEN");
  const blocks = open.filter((item) => item.severity === "BLOCK").length;
  return `${renderKpis()}${card("그룹 보고 QA Issue", `<div class="metrics compact-metrics">${metricCard("OPEN", open.length, "전체 미해소")}${metricCard("BLOCK", blocks, "확정 차단")}${metricCard("WARN", open.length - blocks, "사유 확인")}</div><div class="stack">${issueRows()}</div><div class="button-row"><button class="button primary" data-action="RESOLVE_QA">Issue 해소 요청</button></div>`)}${card("결정적 검사 → LLM 설명", `<div class="notice"><strong>Pass/Fail은 Rule Engine이 판단합니다.</strong>LLM은 오류의 의미, 영향 문장, 수정 위치를 사람이 이해하기 쉽게 설명합니다.</div>`)}`;
}

function renderRedaction() {
  const rows = [["설비 상세번호 ESWA-L07-03", "CONFIDENTIAL", "내부 그룹 보고", "유지"], ["제품 K12 시험조건", "CONFIDENTIAL", "외부 공유", "제외 후보"], ["PD Loss 1.2%", "INTERNAL", "외부 공유", "승인 필요"], ["WorkItem·Snapshot Code", "INTERNAL", "내부 그룹 보고", "유지"]];
  return `${card("민감정보 제외 후보", table(["항목", "등급", "대상", "처리"], rows.map((r) => `<tr><td>${escapeHtml(r[0])}</td><td>${badge(r[1])}</td><td>${escapeHtml(r[2])}</td><td>${badge(r[3], r[3])}</td></tr>`)))}${card("공유 Version 원칙", `<div class="notice warn"><strong>Agent가 원본을 자동 삭제하지 않습니다.</strong>원본 Version을 보존하고, 승인된 Redaction 규칙으로 별도 공유 Version을 생성합니다.</div><div class="button-row"><button class="button secondary" data-demo="redaction">제외안 미리보기</button><button class="button primary" data-demo="redaction">공유 Version 생성</button></div>`)}`;
}

function renderExport() {
  const rows = state.data.reports.map((r) => `<tr><td><code>${escapeHtml(r.report_code)}</code></td><td>${escapeHtml(r.report_level)}</td><td>${badge(r.status)}</td><td>v${r.current_version}</td><td><button class="button secondary" data-demo="export">PPTX</button> <button class="button secondary" data-demo="export">JSON</button></td></tr>`);
  return `${card("확정본·산출물", table(["Report", "Level", "상태", "Version", "Export"], rows))}${card("재현 가능한 Export", `<ul class="list"><li><strong>Human-readable</strong><span>PPTX · PDF · 포털 화면</span></li><li><strong>Machine companion</strong><span>JSON · Source Manifest · Citation</span></li><li><strong>감사 정보</strong><span>Template · Prompt · Model · 생성시각 · 승인 Version</span></li></ul>`)}`;
}

function renderEvidenceTrace() {
  const evidence = state.data.evidence[0];
  return `<section class="trace-map card"><h3>문장부터 원천까지 추적</h3><div class="trace-node"><span>보고 문장</span><strong>대상 3개 제품 중 2개 제품에서 동일 경향 확인</strong></div><div class="trace-arrow">↓ Citation</div><div class="trace-node"><span>WorkItem</span><strong>WI-RSND-2026-0032</strong></div><div class="trace-arrow">↓ Evidence</div><div class="trace-node"><span>파일·위치</span><strong>${escapeHtml(evidence.file_name)} · ${escapeHtml(evidence.locator)}</strong></div><div class="trace-arrow">↓ Integrity</div><div class="trace-node"><span>Hash·검사</span><strong>${escapeHtml(evidence.sha256.slice(0, 16))}… · ${escapeHtml(evidence.scan_status)}</strong></div></section>${card("신뢰 상태", `<div class="metrics compact-metrics">${metricCard("원문 Hash", "일치", "SHA-256")}${metricCard("보안 범위", evidence.security_label, "현재 사용자 조회 가능")}${metricCard("Freshness", "W35", "08/23 23:59")}</div>`)}`;
}

function renderQuestion() {
  const answer = state.lastAnswer;
  return `<div class="question-layout"><section class="card"><h3>근거 기반 질문</h3><form id="question-form"><textarea id="question-input" aria-label="질문">자동보정 적용으로 PD Loss가 개선됐다고 확정할 수 있어?</textarea><div class="question-suggestions"><button type="button" data-question="K12 검증이 지연되면 어떤 영향이 있어?">K12 검증 지연 영향</button><button type="button" data-question="이번 주 가장 중요한 Decision은 무엇이야?">중요 Decision</button></div><div class="button-row"><button class="button primary">보고 Q&A Agent에 질문</button></div></form></section><section class="card"><h3>Agent 답변</h3>${answer ? renderAnswer(answer) : `<div class="empty-state">질문하면 승인된 보고와 Citation 범위 안에서 답변합니다.</div>`}</section></div>`;
}

function renderAnswer(answer) {
  return `<div class="answer"><p>${escapeHtml(answer.answer)}</p><div class="notice warn"><strong>불확실성</strong>동일 제품·동일 조건의 적용 전후 승인 데이터가 추가로 필요합니다.</div><h4>근거</h4>${answer.citations.map((c) => `<div class="citation"><code>${escapeHtml(c.code)}</code><span>${escapeHtml(c.detail)}</span></div>`).join("")}<p class="small muted">Freshness ${escapeHtml(answer.freshness)} · Trace ${escapeHtml(answer.trace_id)}</p></div>`;
}

function renderDecision() {
  const rows = state.data.decisions.map((d) => `<section class="card decision-card"><div class="card-top"><code>${escapeHtml(d.decision_code)}</code>${badge(d.status)}</div><h2>${escapeHtml(d.title)}</h2><p>${escapeHtml(d.request)}</p><dl class="detail-grid"><div><dt>결정자</dt><dd>${escapeHtml(d.decision_maker || "그룹장")}</dd></div><div><dt>기한</dt><dd>${formatDate(d.due_date)}</dd></div><div><dt>선택지 A</dt><dd>W35 생산 일정 우선 배정</dd></div><div><dt>선택지 B</dt><dd>W36 정규 일정 수행</dd></div></dl>${d.status === "RESOLVED" ? `<div class="notice"><strong>확정 결과</strong>${escapeHtml(d.resolution)}</div>` : `<div class="button-row"><button class="button secondary" data-demo="decision-detail">추가 근거 요청</button><button class="button primary" data-action="RESOLVE_DECISION">결정·Action 확정</button></div>`}</section>`).join("");
  return `<div class="stack">${rows}</div>`;
}

function renderTrend() {
  const series = [["W30", 1.8], ["W31", 1.7], ["W32", 1.6], ["W34", 1.5], ["W35", 1.2]];
  const chart = `<div class="bar-chart" role="img" aria-label="PD Loss W30부터 W35 추이">${series.map(([week, value]) => `<div class="bar-col"><span>${value}%</span><div class="bar" style="height:${value * 75}px"></div><strong>${week}</strong></div>`).join("")}</div>`;
  const actions = state.data.action_items.map((a) => `<tr><td><code>${escapeHtml(a.action_code)}</code></td><td>${escapeHtml(a.title)}</td><td>${escapeHtml(a.owner_name || "—")}</td><td>${formatDate(a.due_date)}</td><td>${badge(a.status)}</td></tr>`);
  return `<div class="grid-2">${card("PD Loss 주차 Trend", `${chart}<p class="small muted">동일 Metric 정의 v4 기준. W35는 승인 전 Snapshot일 수 있습니다.</p>`)}${card("추이 해석", `<div class="notice"><strong>W30 1.8% → W35 1.2%</strong>감소 경향은 관찰되지만 자동보정 단독 효과를 확정하려면 적용 전후 통제 데이터가 필요합니다.</div><ul class="list"><li><strong>질문 제안</strong><span>제품·라인별 개선 폭은 동일한가?</span></li><li><strong>확인 항목</strong><span>K12 추가 검증 후 경향 유지 여부</span></li></ul>`)}</div>${card("Action 추적", table(["Action", "조치", "Owner", "Due", "상태"], actions))}`;
}

function renderSnapshotUpload() {
  return `<div class="grid-2">${card("KPI 원천파일 업로드", `<div class="dropzone"><div class="upload-icon">⇧</div><strong>정기 다운로드 파일을 업로드</strong><span>메일·분석시스템 API 연계 전 운영 방식</span><button class="button primary" data-demo="snapshot-upload">PD_Loss_2026W35_0823.xlsx 선택</button></div><div class="form-grid compact"><label>Metric<select><option>PD_LOSS · PD Loss</option></select></label><label>기준시각<input value="2026-08-23 23:59"></label><label>보고주차<select><option>2026-W35</option></select></label><label>Source System<input value="분석시스템"></label></div>`)}${card("자동 추출 Preview", `<dl class="detail-grid"><div><dt>파일명 계약</dt><dd>${badge("PASS")}</dd></div><div><dt>SHA-256</dt><dd><code>8ae1…bd42</code></dd></div><div><dt>Sheet</dt><dd>Weekly_Result</dd></div><div><dt>Rows</dt><dd>1,284</dd></div><div><dt>예상 Metric</dt><dd>PD_LOSS · 96%</dd></div><div><dt>상태</dt><dd>UPLOADED 예정</dd></div></dl><div class="notice warn"><strong>96% 제안은 자동확정하지 않습니다.</strong>Data Owner가 Metric과 Cut-off를 확인합니다.</div>`)}</div>`;
}

function renderMapping() {
  const mappings = [["SITE_CD", "site", "ESWA", "100%"], ["PROC_NM", "process", "조립", "98%"], ["LINE_ID", "line", "L07", "100%"], ["MODEL", "product", "M08", "94%"], ["PD_LOSS_RT", "value", "2.4", "99%"], ["BASE_DT", "cutoff_at", "2026-08-23", "92%"]];
  return `${card("Source → 표준 Dimension 매핑", table(["원천 Header", "표준 Field", "Sample", "Confidence"], mappings.map((r) => `<tr><td><code>${r[0]}</code></td><td><select><option>${r[1]}</option></select></td><td>${r[2]}</td><td>${Number(r[3].replace("%", "")) < 95 ? badge("WARN", r[3]) : badge("PASS", r[3])}</td></tr>`)))}${card("Mapping Version", `<div class="approval-preview"><div><span>Metric</span><strong>PD_LOSS v4</strong></div><div><span>File Contract</span><strong>FC-PD-2026-02</strong></div><div><span>현재 Mapping</span><strong>MAP-PD-v7</strong></div><div><span>변경 예정</span><strong>MAP-PD-v8</strong></div></div><div class="button-row"><button class="button primary" data-demo="mapping">매핑 저장·검증</button></div>`)}`;
}

function renderValidation() {
  const snapshot = state.data.snapshots.find((item) => item.id === "snp_pd_w35");
  return `<div class="metrics">${metricCard("검사 상태", snapshot.status, snapshot.snapshot_code)}${metricCard("BLOCK", snapshot.validation_errors, "중복 Key")}${metricCard("WARN", snapshot.validation_warnings, "급변값")}</div>${card("Validation Issue", `<div class="stack">${issueRows("METRIC_SNAPSHOT")}</div><div class="button-row"><button class="button secondary" data-demo="source-row">원본 행 보기</button><button class="button primary" data-action="VALIDATE_SNAPSHOT">재검증</button></div>`)}${card("Rule 실행 순서", `<div class="pipeline"><span>Schema</span><b>→</b><span>Key 중복</span><b>→</b><span>누락</span><b>→</b><span>단위</span><b>→</b><span>급변</span><b>→</b><span>집계 대조</span></div>`)}`;
}

function renderSnapshotCompare() {
  const rows = [["전체", "ALL", "ALL", 1.5, 1.2, -0.3, "정상"], ["조립", "L07", "M08", 0.8, 2.4, 1.6, "급변"], ["조립", "L03", "K12", 1.2, 1.1, -0.1, "중복 Key"]];
  return `${card("W34 ↔ W35 Snapshot 비교", table(["공정", "Line", "제품", "W34", "W35", "차이(%p)", "Flag"], rows.map((r) => `<tr><td>${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td><td class="numeric">${r[3]}%</td><td class="numeric">${r[4]}%</td><td class="numeric">${r[5] > 0 ? "+" : ""}${r[5]}</td><td>${badge(r[6], r[6])}</td></tr>`)))}${card("변동 사유", `<div class="form-grid"><label class="full">ESWA L07 M08 급변 사유<textarea>제품 전환 직후 초기 구간 값이 포함되었는지 원천 파일과 집계 범위를 확인 중.</textarea></label></div><div class="button-row"><button class="button primary" data-demo="save-reason">변동 사유 기록</button></div>`)}`;
}

function renderSnapshotApprove() {
  const s = state.data.snapshots.find((item) => item.id === "snp_pd_w35");
  const canApprove = Number(s.validation_errors) === 0;
  return `${card("PD Loss Snapshot 승인", `<div class="snapshot-header"><div><code>${escapeHtml(s.snapshot_code)}</code><h2>${escapeHtml(s.metric_name)} · ${Number(s.display_value).toFixed(1)}${escapeHtml(s.unit)}</h2><p>Cut-off ${escapeHtml(s.cutoff_at)} · Source ${escapeHtml(s.source_file)}</p></div>${badge(s.status)}</div><div class="approval-preview"><div><span>Verification</span><strong>${badge(s.verification_state)}</strong></div><div><span>Version</span><strong>v${s.version}</strong></div><div><span>BLOCK</span><strong>${s.validation_errors}</strong></div><div><span>WARN</span><strong>${s.validation_warnings}</strong></div></div>${!canApprove ? `<div class="notice danger"><strong>승인 차단</strong>Validation의 BLOCK 오류를 먼저 해소하십시오.</div>` : `<div class="notice"><strong>승인 가능</strong>승인하면 공식 Snapshot으로 잠기며 정정은 새 Version으로만 가능합니다.</div>`}<div class="button-row"><button class="button primary" ${canApprove ? "" : "disabled"} data-action="APPROVE_SNAPSHOT">Snapshot 승인·잠금</button></div>`)}${card("영향 범위", `<ul class="list"><li><strong>팀원 초안</strong><span>잠정 → 검증됨 상태로 표시 변경</span></li><li><strong>팀·담당·그룹 보고</strong><span>동일 Snapshot ID를 참조하는 문장 재검사</span></li><li><strong>Audit</strong><span>Data Owner · 승인시각 · Trace ID 기록</span></li></ul>`)}`;
}

function renderMetricCatalog() {
  const definitions = [["YIELD_RATE", "수율", "정상품 수량 / 전체 투입 수량", "%", "분석시스템", "v3"], ["BM_LOSS", "BM Loss", "설비 기인 Loss 비율", "%", "분석시스템", "v2"], ["PD_LOSS", "PD Loss", "공정 기인 Loss 비율", "%", "분석시스템", "v4"], ["DEFECT_RATE", "불량률", "검사 불량 수량 / 전체 검사 수량", "%", "분석시스템", "v2"]];
  return `${card("Metric Catalog", table(["Metric Code", "표시명", "공식 정의", "단위", "원천", "Version"], definitions.map((r) => `<tr><td><code>${r[0]}</code></td><td><strong>${r[1]}</strong></td><td>${r[2]}</td><td>${r[3]}</td><td>${r[4]}</td><td>${badge(r[5])}</td></tr>`)))}${card("약어 관리 원칙", `<div class="notice"><strong>BM·PD라는 표시명만으로 데이터를 연결하지 않습니다.</strong>Metric Code, 공식 산식, 집계 차원, Owner, Version을 함께 저장합니다.</div>`)}`;
}

function renderIam() {
  const rows = [["임가은", "D1001", "MEMBER", "RSND자동보정팀", "활성"], ["최도윤", "D1100", "LEADER", "RSND자동보정팀", "활성"], ["윤태성", "D1200", "DEPT", "자동보정담당", "활성"], ["문서진", "D1300", "PLANNING", "제조DX그룹", "활성"], ["한지훈", "D1400", "HEAD", "제조DX그룹", "활성"]];
  return `${card("조직·사용자·역할", table(["사용자", "사번", "Role", "Scope", "상태"], rows.map((r) => `<tr><td><strong>${r[0]}</strong></td><td>${r[1]}</td><td>${badge(r[2])}</td><td>${r[3]}</td><td>${badge("ACTIVE", r[4])}</td></tr>`)))}${card("권한 변경 통제", `<div class="notice warn"><strong>역할과 조직 범위 변경은 승인·기간·사유가 필요합니다.</strong>작성과 최종 승인 등 상충 역할은 SoD 규칙으로 경고합니다.</div>`)}`;
}

function renderCalendar() {
  const c = state.data.cycle;
  const dates = [["Snapshot", c.snapshot_due_at, "Data Owner"], ["팀원 제출", c.member_due_at, "팀원"], ["팀장 승인", c.leader_due_at, "팀장"], ["담당 승인", c.department_due_at, "담당"], ["기획 QA", c.planning_due_at, "기획팀"]];
  return `${card("2026 W35 보고 Calendar", `<div class="calendar-strip">${dates.map(([name, date, owner], index) => `<article class="${index === 0 ? "done" : index === 1 ? "active" : ""}"><span>${formatDate(date, true)}</span><strong>${name}</strong><small>${owner}</small></article>`).join("")}</div>`)}${card("주차 개시 설정", `<div class="form-grid"><label>Cycle Code<input value="2026-W35"></label><label>개시일<input type="date" value="2026-08-24"></label><label>휴일 예외<select><option>없음</option></select></label><label>이전주 복사<select><option>마감 규칙만 복사</option></select></label></div><div class="button-row"><button class="button primary" data-demo="calendar">보고주차 개시</button></div>`)}`;
}

function renderRelease() {
  const rows = [["PROMPT-LEADER", "팀장 서술형 초안", "v1.4", "Sonnet 4.5", "PASS", "활성"], ["PROMPT-PLANNING", "그룹 보고 구성", "v2.1", "Opus", "PASS", "활성"], ["TPL-WEEKLY-PPT", "내부 보고 PPT", "v3.2", "—", "PASS", "활성"], ["POLICY-CITATION", "Citation 검사", "v1.7", "Rule", "PASS", "활성"]];
  return `${card("Template · Prompt · Model Release", table(["Artifact", "용도", "Version", "Model", "Eval", "상태"], rows.map((r) => `<tr><td><code>${r[0]}</code></td><td>${r[1]}</td><td>${r[2]}</td><td>${r[3]}</td><td>${badge(r[4])}</td><td>${badge("ACTIVE", r[5])}</td></tr>`)))}${card("배포 Gate", `<div class="pipeline"><span>변경 제안</span><b>→</b><span>Golden Set</span><b>→</b><span>Regression</span><b>→</b><span>2인 검토</span><b>→</b><span>배포</span><b>→</b><span>Rollback</span></div>`)}`;
}

function renderPolicy() {
  const policies = [["POL-ACL-001", "권한 밖 Resource 검색 금지", "ENFORCED"], ["POL-LLM-003", "승인·결정 Tool 자동실행 금지", "ENFORCED"], ["POL-DATA-007", "Snapshot 잠금 후 덮어쓰기 금지", "ENFORCED"], ["POL-EXPORT-004", "외부공유 민감정보 검토", "ENFORCED"]];
  return `${card("권한·보안 Policy", table(["Policy", "규칙", "상태"], policies.map((r) => `<tr><td><code>${r[0]}</code></td><td>${r[1]}</td><td>${badge(r[2])}</td></tr>`)))}${card("Agent Tool Allowlist", `<div class="permission-grid"><div><strong>읽기 허용</strong><span>WorkItem · 승인 Report · Snapshot · Evidence metadata</span></div><div><strong>초안 허용</strong><span>요약 · Citation · QA 설명 · 질문 제안</span></div><div><strong>사람 확인 필수</strong><span>제출 · 승인 · Decision · 권한 변경 · 외부 공유</span></div><div><strong>차단</strong><span>권한 밖 검색 · 원본 삭제 · Snapshot 덮어쓰기</span></div></div>`)}`;
}

function renderAudit() {
  const rows = state.data.audit_events.map((a) => `<tr><td>${formatDate(a.occurred_at, true)}</td><td><code>${escapeHtml(a.trace_id)}</code></td><td>${escapeHtml(a.actor_name || "SYSTEM")}<br><span class="small muted">${escapeHtml(a.actor_role)}</span></td><td>${escapeHtml(a.action)}</td><td>${escapeHtml(a.resource_type)}<br><code>${escapeHtml(a.resource_id || "—")}</code></td><td>${badge(a.result)}</td><td>${escapeHtml(a.detail || "—")}</td></tr>`);
  return card("Audit Log", `<div class="toolbar"><div class="inline"><input placeholder="Trace · Actor · Resource"><select><option>전체 결과</option><option>SUCCEEDED</option><option>WARN</option></select></div><button class="button secondary" data-demo="audit-export">CSV Export</button></div>${table(["시각", "Trace", "Actor", "Action", "Resource", "결과", "상세"], rows)}`);
}

function renderHealth() {
  const services = [["Portal Web", "UP", "18 ms", "Local demo server"], ["SQLite DB", "UP", "4 ms", "Foreign key enabled"], ["LLM Agent", "DEMO", "결정적 응답", "외부 호출 없음"], ["Company Copilot", "NOT_CONNECTED", "—", "향후 사내 연동"], ["Data Analysis API", "NOT_CONNECTED", "—", "정기 파일 업로드 대체"]];
  return `${card("System Health", `<div class="health-grid">${services.map((r) => `<article><span class="status-dot ${r[1] !== "UP" ? "muted-dot" : ""}"></span><div><strong>${r[0]}</strong><span>${r[3]}</span></div><div>${badge(r[1])}<small>${r[2]}</small></div></article>`).join("")}</div>`)}${card("Feature Flag · Fallback", `<div class="permission-grid"><div><strong>agent.draft.enabled</strong><span>${badge("ON")}</span></div><div><strong>copilot.connector.enabled</strong><span>${badge("OFF")}</span></div><div><strong>manual.workflow.enabled</strong><span>${badge("ON")}</span></div><div><strong>snapshot.api.enabled</strong><span>${badge("OFF")}</span></div></div><div class="notice"><strong>Agent 장애 시에도 수동 작성·제출·승인 Workflow는 유지합니다.</strong></div>`)}`;
}

function renderGeneric(screen) {
  return `${card(screen.title, `<div class="empty-state"><strong>${escapeHtml(screen.screen_id)} 시연 화면</strong><p>${escapeHtml(screen.purpose)}</p><button class="button primary" data-demo="generic">${escapeHtml(screen.primary_action)}</button></div>`)}${card("화면 정의", `<dl class="detail-grid"><div><dt>주요 데이터</dt><dd>${escapeHtml(screen.main_data)}</dd></div><div><dt>AI 기능</dt><dd>${escapeHtml(screen.ai_function)}</dd></div><div><dt>검증·통제</dt><dd>${escapeHtml(screen.control_rule)}</dd></div><div><dt>완료조건</dt><dd>${escapeHtml(screen.done_condition)}</dd></div></dl>`)}`;
}

async function saveWorklog() {
  const workItemId = $("#worklog-workitem")?.value;
  const entryType = $("#worklog-type")?.value;
  const occurredOn = $("#worklog-date")?.value;
  const narrative = $("#worklog-narrative")?.value.trim();
  if (!narrative) { showToast("추가 작성 내용을 입력하십시오.", true); return; }
  showToast("Worklog를 저장하고 다음 화면에 연결하고 있습니다.");
  try {
    const result = await api("/api/worklogs", { method: "POST", body: JSON.stringify({ role: state.role, work_item_id: workItemId, entry_type: entryType, occurred_on: occurredOn, narrative }) });
    state.generatedDraft = null;
    await refreshCurrent();
    navigateTo("MBR-05");
    showToast(`${result.message} · ${result.trace_id}`);
  } catch (error) { showToast(error.message, true); }
}

async function saveEvidence() {
  const workItemId = $("#evidence-workitem")?.value;
  const fileName = $("#evidence-file-name")?.value.trim();
  const locator = $("#evidence-locator")?.value.trim();
  const securityLabel = $("#evidence-security")?.value;
  if (!fileName) { showToast("등록할 파일명을 입력하십시오.", true); return; }
  showToast("Evidence Metadata를 저장하고 금주 실적에 연결하고 있습니다.");
  try {
    const result = await api("/api/evidence", { method: "POST", body: JSON.stringify({ role: state.role, work_item_id: workItemId, file_name: fileName, locator, security_label: securityLabel }) });
    state.generatedDraft = null;
    await refreshCurrent();
    navigateTo("MBR-06");
    showToast(`${result.message} · ${result.record.evidence_code}`);
  } catch (error) { showToast(error.message, true); }
}

async function saveSelection(generateAfter = false) {
  const workPageIds = [...document.querySelectorAll("[data-page-select]:checked")].map((input) => input.dataset.pageSelect);
  if (!workPageIds.length) { showToast("보고서에 포함할 업무페이지를 한 건 이상 선택하십시오.", true); return; }
  try {
    const result = await api("/api/submission/items", { method: "POST", body: JSON.stringify({ role: state.role, work_page_ids: workPageIds }) });
    state.generatedDraft = null;
    await refreshCurrent();
    showToast(result.message);
    if (generateAfter) await generateDraft();
  } catch (error) { showToast(error.message, true); }
}

async function saveReportVersion() {
  const content = $("#team-comparison-editor") ? composeTeamComparisonContent() : $("#work-page-editor") ? composeWorkPageContent() : composeStructuredReportContent();
  if (!content) { showToast("저장할 보고서 내용을 입력하십시오.", true); return; }
  showToast("수정본 Version을 저장하고 다음 화면에 연결하고 있습니다.");
  try {
    const result = await api("/api/draft/version", { method: "POST", body: JSON.stringify({ role: state.role, content }) });
    state.generatedDraft = content;
    await refreshCurrent();
    const nextScreen = { MEMBER: "MBR-08", LEADER: "LDR-06", DEPT: "DPT-06", PLANNING: "PLN-04" }[state.role];
    if (nextScreen) navigateTo(nextScreen);
    showToast(`${result.message} · ${result.trace_id}`);
  } catch (error) { showToast(error.message, true); }
}

async function generateDraft() {
  const button = $("#primary-action");
  if (button) button.disabled = true;
  showToast(state.role === "MEMBER" ? "Agent가 자동분류한 업무페이지의 최근 4주 기록과 금주 변경을 조합하고 있습니다." : "승인된 업무와 근거로 초안을 생성 중입니다.");
  try {
    const result = await api("/api/agent/draft", { method: "POST", body: JSON.stringify({ role: state.role, screen_id: currentScreen().screen_id }) });
    state.generatedDraft = result.content;
    await refreshCurrent();
    if (state.role === "MEMBER" && currentScreen().screen_id === "MBR-06") navigateTo("MBR-07");
    if (state.role === "LEADER" && currentScreen().screen_id === "LDR-04") navigateTo("LDR-05");
    showToast(`AI 초안을 생성했습니다. Citation ${result.citations.length}건 · ${result.trace_id}`);
  } catch (error) { showToast(error.message, true); }
  finally { if (button) button.disabled = false; }
}

async function handleQuestion(event) {
  event.preventDefault();
  const question = $("#question-input").value.trim();
  if (!question) return;
  showToast("승인 보고와 근거를 검색하고 있습니다.");
  try {
    state.lastAnswer = await api("/api/agent/ask", { method: "POST", body: JSON.stringify({ role: state.role, question }) });
    renderScreen();
  } catch (error) { showToast(error.message, true); }
}

function openConfirmation(action) {
  const [title, message] = confirmCopy[action] || ["상태 변경 확인", "선택한 동작을 실행합니다."];
  state.pendingAction = action;
  $("#confirm-title").textContent = title;
  $("#confirm-message").textContent = message;
  $("#confirm-role").textContent = `${state.data.principal.role_label} · ${state.data.principal.display_name}`;
  $("#confirm-screen").textContent = `${currentScreen().screen_id} · ${currentScreen().title}`;
  $("#confirm-dialog").showModal();
}

async function executePendingAction() {
  const action = state.pendingAction;
  if (!action) return;
  state.pendingAction = null;
  $("#confirm-dialog").close();
  showToast("상태 변경과 감사 기록을 처리 중입니다.");
  try {
    const result = await api("/api/action", { method: "POST", body: JSON.stringify({ action, role: state.role }) });
    await refreshCurrent();
    showToast(`${result.message} · ${result.trace_id}`);
  } catch (error) { showToast(error.message, true); }
}

async function refreshCurrent() {
  const screenId = currentScreen()?.screen_id;
  const draft = state.generatedDraft;
  const answer = state.lastAnswer;
  const data = await api(`/api/bootstrap?role=${encodeURIComponent(state.role)}`);
  state.data = data;
  state.screenIndex = Math.max(0, data.screens.findIndex((screen) => screen.screen_id === screenId));
  state.generatedDraft = draft;
  state.lastAnswer = answer;
  renderPrincipal(); renderScreen();
}

function showToast(message, error = false) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.toggle("error", error);
  toast.hidden = false;
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => { toast.hidden = true; }, 4300);
}

function openSpec() {
  const screen = currentScreen();
  $("#spec-id").textContent = screen.screen_id;
  $("#spec-title").textContent = screen.title;
  $("#spec-purpose").textContent = screen.purpose;
  $("#spec-data").textContent = screen.main_data;
  $("#spec-ai").textContent = screen.ai_function;
  $("#spec-rule").textContent = screen.control_rule;
  $("#spec-done").textContent = screen.done_condition;
  $("#spec-dialog").showModal();
}

function navigateTo(screenId) {
  const index = state.data.screens.findIndex((screen) => screen.screen_id === screenId);
  if (index < 0) return false;
  state.screenIndex = index;
  renderScreen();
  window.scrollTo({ top: 0, behavior: "smooth" });
  return true;
}

function handlePrimaryAction() {
  const screen = currentScreen();
  if (screen.screen_id === "MBR-04") { saveWorklog(); return; }
  if (screen.screen_id === "MBR-05") { saveEvidence(); return; }
  if (screen.screen_id === "MBR-06") { saveSelection(true); return; }
  if (screen.screen_id === "MBR-07") { saveReportVersion(); return; }
  if (actionMap[screen.screen_id]) { openConfirmation(actionMap[screen.screen_id]); return; }
  if (navTargets[screen.screen_id] && navigateTo(navTargets[screen.screen_id])) return;
  showToast(`${screen.primary_action}: 시연용 화면에서 입력·미리보기를 확인했습니다.`);
}

$("#screen-nav").addEventListener("click", (event) => {
  const button = event.target.closest("[data-screen-index]");
  if (!button) return;
  state.screenIndex = Number(button.dataset.screenIndex);
  state.lastAnswer = null;
  renderScreen();
  window.scrollTo({ top: 0, behavior: "smooth" });
});

$("#screen-body").addEventListener("click", (event) => {
  const taskButton = event.target.closest("[data-task-code]");
  if (taskButton) {
    state.activeTaskCode = taskButton.dataset.taskCode;
    if (currentScreen()?.screen_id !== "MBR-03") navigateTo("MBR-03");
    else renderScreen();
    return;
  }
  const reviewPageButton = event.target.closest("[data-review-page]");
  if (reviewPageButton) {
    state.reviewPageId = reviewPageButton.dataset.reviewPage;
    renderScreen();
    return;
  }
  const reviewCommentButton = event.target.closest("[data-add-review-comment]");
  if (reviewCommentButton) {
    const input = $("#review-comment-text");
    const textValue = input?.value.trim();
    if (!textValue) { showToast("코멘트 내용을 입력하십시오.", true); return; }
    const mode = reviewCommentButton.dataset.addReviewComment;
    const page = sourceBackedModel.reportPages.find((item) => item.id === state.reviewPageId) || sourceBackedModel.reportPages[0];
    state.reviewComments.push({
      author: mode === "DEPT" ? `${sourceBackedModel.people.departmentHead} 담당` : `${sourceBackedModel.people.groupHead} 그룹장`,
      recipient: mode === "DEPT" ? `${sourceBackedModel.people.leader} 팀장` : `${sourceBackedModel.people.departmentHead} 담당·${sourceBackedModel.people.leader} 팀장`,
      pageTitle: page.title,
      text: textValue,
      at: "2026-08-27 17:30",
    });
    state.reviewStatus = "코멘트 등록";
    renderScreen();
    showToast(mode === "DEPT" ? "팀장에게 수정 코멘트를 등록했습니다. 원문은 변경하지 않았습니다." : "그룹장 지시사항을 등록했습니다. 원문은 변경하지 않았습니다.");
    return;
  }
  if (event.target.closest("[data-review-return]")) {
    state.reviewStatus = "팀장 보완 요청";
    renderScreen();
    showToast("팀장에게 보완을 요청했습니다. 담당이 직접 수정하지 않습니다.");
    return;
  }
  if (event.target.closest("[data-review-send]")) {
    state.reviewStatus = "기획팀·그룹장 전송 완료";
    renderScreen();
    showToast("전체 보고파일을 기획팀과 그룹장에게 전송했습니다.");
    return;
  }
  if (event.target.closest("[data-print-current-team]")) {
    openPdfPrintView("TEAM_REPORT");
    return;
  }
  const pagePdfButton = event.target.closest("[data-print-work-page]");
  if (pagePdfButton) {
    openPdfPrintView("MEMBER_PAGES", pagePdfButton.dataset.printWorkPage);
    return;
  }
  const addComparisonButton = event.target.closest("[data-add-comparison]");
  if (addComparisonButton) {
    const owner = addComparisonButton.dataset.addComparison || "팀 공통";
    const group = addComparisonButton.closest(".team-member-comparison");
    const rows = $(".team-member-comparison-rows", group);
    const defaults = {
      임가은: ["WI-RSND-2026-031", "자동보정 신규 항목"],
      강민재: ["WI-RSND-2026-041", "NFF·신규법인 신규 항목"],
      서진우: ["WI-RSND-2026-043", "다빈치 WF 신규 항목"],
      배지호: ["WI-RSND-2026-044", "DNC 신규 항목"],
      "팀 공통": ["AUTO-KPI-03", "팀 공통 KPI 항목"],
    }[owner] || [defaultReportResourceCode(), "팀장 신규 작성 항목"];
    const newRow = { id: `custom_${Date.now()}`, owner, code: defaults[0], title: defaults[1], tag: "RESULT", resources: [defaults[0]], previous: "", current: "" };
    rows?.insertAdjacentHTML("beforeend", renderTeamComparisonRow(newRow));
    rows?.lastElementChild?.querySelector(".comparison-current-value")?.focus();
    syncTeamComparisonEditor();
    return;
  }
  const keepComparisonButton = event.target.closest("[data-keep-comparison]");
  if (keepComparisonButton) {
    const row = keepComparisonButton.closest(".team-compare-row");
    const previous = $(".comparison-previous-value", row)?.value || "";
    const current = $(".comparison-current-value", row);
    if (current) current.value = previous;
    syncTeamComparisonEditor();
    showToast("지난주 원문을 금주 내용으로 유지했습니다.");
    return;
  }
  const deleteComparisonButton = event.target.closest("[data-delete-comparison]");
  if (deleteComparisonButton) {
    const row = deleteComparisonButton.closest(".team-compare-row");
    const previous = $(".comparison-previous-value", row)?.value.trim() || "";
    if (!previous) row?.remove();
    else {
      const current = $(".comparison-current-value", row);
      if (current) current.value = "";
    }
    syncTeamComparisonEditor();
    showToast(previous ? "지난주 원문은 보존하고 금주 보고에서 삭제 표시했습니다." : "신규 작성 항목을 제거했습니다.");
    return;
  }
  const addPageSectionButton = event.target.closest("[data-add-page-section]");
  if (addPageSectionButton) {
    const page = addPageSectionButton.closest(".work-page-editor");
    const sections = $(".work-page-edit-sections", page);
    if (sections) {
      sections.insertAdjacentHTML("beforeend", renderStructuredReportBlock({ tag: "PLAN", statusTags: ["NEW"], resources: [page.dataset.pageCode].filter(Boolean), body: "" }));
      sections.lastElementChild?.querySelector(".block-body")?.focus();
      syncWorkPageEditor();
    }
    return;
  }
  const addReportBlockButton = event.target.closest("[data-add-report-block]");
  if (addReportBlockButton) {
    const editor = $("#structured-report-editor");
    if (editor) {
      editor.insertAdjacentHTML("beforeend", renderStructuredReportBlock({ tag: "PLAN", statusTags: state.role === "MEMBER" ? ["NEW"] : [], resources: [defaultReportResourceCode()].filter(Boolean), body: "" }));
      const addedBody = editor.lastElementChild?.querySelector(".block-body");
      addedBody?.focus();
      syncStructuredReportEditor();
    }
    return;
  }
  const removeReportBlockButton = event.target.closest("[data-remove-report-block]");
  if (removeReportBlockButton) {
    const page = removeReportBlockButton.closest(".work-page-editor");
    const blocks = page ? page.querySelectorAll(".structured-edit-block") : document.querySelectorAll(".structured-edit-block");
    if (blocks.length <= 1) { showToast(page ? "업무페이지에는 한 개 이상의 문장이 필요합니다." : "보고서에는 한 개 이상의 문단이 필요합니다.", true); return; }
    removeReportBlockButton.closest(".structured-edit-block")?.remove();
    if (page) syncWorkPageEditor(); else syncStructuredReportEditor();
    return;
  }
  const worklogButton = event.target.closest("[data-save-worklog]");
  if (worklogButton) { saveWorklog(); return; }
  const evidenceButton = event.target.closest("[data-save-evidence]");
  if (evidenceButton) { saveEvidence(); return; }
  const selectionButton = event.target.closest("[data-save-selection]");
  if (selectionButton) { saveSelection(false); return; }
  const versionButton = event.target.closest("[data-save-version]");
  if (versionButton) { saveReportVersion(); return; }
  const draftButton = event.target.closest("[data-generate-draft]");
  if (draftButton) {
    if (state.role === "MEMBER" && currentScreen()?.screen_id === "MBR-06") saveSelection(true);
    else generateDraft();
    return;
  }
  const actionButton = event.target.closest("[data-action]");
  if (actionButton && !actionButton.disabled) { openConfirmation(actionButton.dataset.action); return; }
  const questionButton = event.target.closest("[data-question]");
  if (questionButton) { const input = $("#question-input"); if (input) input.value = questionButton.dataset.question; return; }
  const demoButton = event.target.closest("[data-demo]");
  if (demoButton) showToast("시연 입력을 반영했습니다. 실제 운영에서는 저장 전 Schema·권한·보안 검사를 수행합니다.");
});

$("#role-select").addEventListener("change", (event) => loadRole(event.target.value));
$("#home-brand").addEventListener("click", () => {
  state.screenIndex = 0;
  state.lastAnswer = null;
  renderScreen();
  window.scrollTo({ top: 0, behavior: "smooth" });
  showToast(`${state.data?.principal?.role_label || "현재 역할"} 초기화면으로 이동했습니다.`);
});
$("#pdf-action").addEventListener("click", (event) => openPdfPrintView(event.currentTarget.dataset.pdfKind));
$("#open-spec").addEventListener("click", openSpec);
$("#primary-action").addEventListener("click", handlePrimaryAction);
$("#confirm-submit").addEventListener("click", (event) => { event.preventDefault(); executePendingAction(); });
$("#toggle-agent").addEventListener("click", () => {
  const open = $("#content-split").classList.contains("agent-hidden");
  setAgentDrawer(open);
});
$("#close-agent").addEventListener("click", () => setAgentDrawer(false));
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !$("#content-split").classList.contains("agent-hidden")) {
    setAgentDrawer(false);
    $("#toggle-agent")?.focus();
  }
});
$("#new-agent-chat").addEventListener("click", newAgentChat);
$("#tab-work-agent").addEventListener("click", () => setActiveAgentTab("work"));
$("#tab-report-agent").addEventListener("click", () => setActiveAgentTab("report"));
$("#persona-chip-row").addEventListener("click", (event) => {
  const chip = event.target.closest("[data-persona]");
  if (!chip) return;
  state.reportAgent.persona = chip.dataset.persona;
  $("#persona-chip-row").querySelectorAll(".chip-button").forEach((button) => button.classList.toggle("selected", button === chip));
  updateReportGenerateAvailability();
});
$("#emphasis-chip-row").addEventListener("click", (event) => {
  const chip = event.target.closest("[data-emphasis]");
  if (!chip) return;
  state.reportAgent.emphasis = chip.dataset.emphasis;
  $("#emphasis-chip-row").querySelectorAll(".chip-button").forEach((button) => button.classList.toggle("selected", button === chip));
  updateReportGenerateAvailability();
});
$("#length-chip-row").addEventListener("click", (event) => {
  const chip = event.target.closest("[data-length]");
  if (!chip) return;
  state.reportAgent.length = chip.dataset.length;
  $("#length-chip-row").querySelectorAll(".chip-button").forEach((button) => button.classList.toggle("selected", button === chip));
});
$("#week-chip-row").addEventListener("click", (event) => {
  const chip = event.target.closest("[data-week]");
  if (!chip) return;
  state.reportAgent.weekRange = chip.dataset.week;
  $("#week-chip-row").querySelectorAll(".chip-button").forEach((button) => button.classList.toggle("selected", button === chip));
  renderReportSourceCount();
});
$("#work-item-checklist").addEventListener("change", (event) => {
  const checkbox = event.target.closest("input[type=checkbox]");
  if (!checkbox) return;
  if (checkbox.checked) state.reportAgent.selectedWorkItemIds.add(checkbox.value);
  else state.reportAgent.selectedWorkItemIds.delete(checkbox.value);
  renderReportSourceCount();
});
$("#report-composer").addEventListener("submit", handleReportGenerateSubmit);
$("#report-download-pptx").addEventListener("click", handleReportDownloadPptx);
$("#agent-composer").addEventListener("submit", handleAgentChatSubmit);
$("#agent-chat-input").addEventListener("input", autoResizeAgentInput);
$("#agent-chat-input").addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey && !event.isComposing) {
    event.preventDefault();
    handleAgentChatSubmit();
  }
});
$("#agent-attach").addEventListener("click", () => $("#agent-source-file").click());
$("#agent-tools").addEventListener("click", () => {
  setAgentPrompt("업무 Agent가 할 수 있는 일을 알려줘");
  handleAgentChatSubmit();
});
$("#agent-source-file").addEventListener("change", handleAgentFile);
$("#read-agent-clipboard").addEventListener("click", readAgentClipboard);
$("#preview-agent-result").addEventListener("click", previewAgentResult);
$("#apply-agent-result").addEventListener("click", applyAgentResultReview);
$("#agent-result-json").addEventListener("input", () => {
  state.agent.pendingImport = null;
  $("#apply-agent-result").disabled = true;
  $("#agent-result-preview").hidden = true;
  $("#agent-import-status").textContent = "붙여넣은 응답은 아직 포털 데이터에 반영되지 않았습니다.";
});
$("#agent-result-preview").addEventListener("input", updateAgentReviewReadiness);
$("#agent-result-preview").addEventListener("change", updateAgentReviewReadiness);
$("#agent-page-chip").addEventListener("click", () => {
  const menu = $("#agent-page-menu");
  menu.hidden = !menu.hidden;
  $("#agent-page-chip").setAttribute("aria-expanded", String(!menu.hidden));
});
$("#agent-page-menu").addEventListener("click", (event) => {
  const button = event.target.closest("[data-agent-page]");
  if (button) selectAgentPage(button.dataset.agentPage);
});
$("#weekly-agent").addEventListener("click", (event) => {
  const demoStepButton = event.target.closest("[data-demo-step-prompt]");
  if (demoStepButton) {
    setAgentPrompt(demoStepButton.dataset.demoStepPrompt);
    handleAgentChatSubmit();
    return;
  }
  if (event.target.closest("[data-open-agent-preview]")) {
    openAgentResultDialog();
    return;
  }
  const promptButton = event.target.closest("[data-agent-prompt]");
  if (promptButton) {
    setAgentPrompt(promptButton.dataset.agentPrompt);
    handleAgentChatSubmit();
    return;
  }
  if (event.target.closest("[data-agent-attach]")) {
    $("#agent-source-file").click();
    return;
  }
  if (event.target.closest("[data-agent-remove-file]")) {
    state.agent.attachment = null;
    renderAgentAttachment();
    return;
  }
  if (event.target.closest("[data-agent-apply-chat]")) applyAgentDraft();
});
$("#reset-demo").addEventListener("click", async () => {
  if (!window.confirm("모든 시연 데이터를 최초 상태로 되돌릴까요?")) return;
  try {
    const result = await api("/api/reset", { method: "POST", body: "{}" });
    state.generatedDraft = null; state.lastAnswer = null;
    state.agent.draft = null; state.agent.attachment = null; state.agent.conversationCount = 0;
    newAgentChat();
    await loadRole(state.role, currentScreen()?.screen_id);
    showToast(result.message);
  } catch (error) { showToast(error.message, true); }
});

loadRole(state.role);
