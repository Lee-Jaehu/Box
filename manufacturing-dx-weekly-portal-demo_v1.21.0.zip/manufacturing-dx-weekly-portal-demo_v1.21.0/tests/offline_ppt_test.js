"use strict";

const fs = require("fs");
const path = require("path");
const vm = require("vm");

async function main() {
  const webRoot = path.join(__dirname, "..", "web");
  const context = {
    console, Blob, Promise, TextEncoder, TextDecoder, Uint8Array, ArrayBuffer, DataView,
    setTimeout, clearTimeout, setImmediate, clearImmediate, URL,
  };
  context.window = context;
  context.self = context;
  context.global = context;
  vm.createContext(context);
  vm.runInContext(fs.readFileSync(path.join(webRoot, "vendor", "pptxgen.bundle.js"), "utf8"), context);
  vm.runInContext(fs.readFileSync(path.join(webRoot, "offline-ppt.js"), "utf8"), context);

  const report = {
    title: "오프라인 PPT 테스트",
    summary: "서버 연결 없이 브라우저에서 PPT를 생성합니다.",
    sections: [
      { heading: "주요 성과", bullets: ["W35 수율 92.4% 달성", "검증 항목 완료"] },
      { heading: "리스크", bullets: ["K12 재현성 확인 필요"] },
      { heading: "차주 계획", bullets: ["제품별 예외조건 확정"] },
    ],
    flagged_terms: [],
  };
  const pptx = context.createOfflineReportPresentation(report, "팀장", "핵심 성과");
  const output = await pptx.write({ outputType: "arraybuffer" });
  const bytes = new Uint8Array(output);
  if (bytes.length < 10000 || bytes[0] !== 0x50 || bytes[1] !== 0x4b) {
    throw new Error("offline PPTX output is not a valid ZIP package");
  }
  console.log(`PASS: browser-only PPTX generated (${bytes.length} bytes)`);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
