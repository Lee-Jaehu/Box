#!/usr/bin/env python3
"""End-to-end smoke test for the dependency-free local demo server."""

from __future__ import annotations

import io
import json
import sys
import zipfile
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen


BASE_URL = sys.argv[1].rstrip("/") if len(sys.argv) > 1 else "http://127.0.0.1:8765"


def request_json(path: str, payload: dict | None = None) -> dict | list:
    body = None if payload is None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
    request = Request(
        BASE_URL + path,
        data=body,
        headers={"Content-Type": "application/json"},
        method="GET" if payload is None else "POST",
    )
    try:
        with urlopen(request, timeout=5) as response:
            return json.loads(response.read().decode("utf-8"))
    except HTTPError as error:
        detail = error.read().decode("utf-8")
        raise AssertionError(f"{path}: HTTP {error.code} {detail}") from error


def request_text(path: str) -> str:
    with urlopen(BASE_URL + path, timeout=5) as response:
        return response.read().decode("utf-8")


def request_binary(path: str, payload: dict) -> tuple[bytes, str]:
    request = Request(
        BASE_URL + path,
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urlopen(request, timeout=15) as response:
        return response.read(), response.headers.get("Content-Type", "")


def request_error(path: str, payload: dict) -> tuple[int, dict]:
    request = Request(
        BASE_URL + path,
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urlopen(request, timeout=5) as response:
            raise AssertionError(f"{path}: expected rejection, got HTTP {response.status}")
    except HTTPError as error:
        return error.code, json.loads(error.read().decode("utf-8"))


def assert_equal(actual: object, expected: object, label: str) -> None:
    if actual != expected:
        raise AssertionError(f"{label}: expected {expected!r}, got {actual!r}")


def main() -> None:
    expected_screens = {
        "COMMON": 5,
        "MEMBER": 8,
        "LEADER": 9,
        "DEPT": 9,
        "PLANNING": 7,
        "HEAD": 8,
        "DATA_OWNER": 7,
        "ADMIN": 7,
    }

    health = request_json("/api/health")
    assert health["ok"] and health["database"], "health check failed"

    index_html = request_text("/")
    styles = request_text("/styles.css")
    app_script = request_text("/app.js")
    offline_ppt_script = request_text("/offline-ppt.js")
    pptx_bundle = request_text("/vendor/pptxgen.bundle.js")
    assert 'id="weekly-agent"' in index_html and 'id="agent-chat-input"' in index_html
    assert 'id="agent-page-chip"' in index_html and 'id="agent-attach"' in index_html
    assert 'id="agent-engine-status"' in index_html and 'id="agent-engine-detail"' in index_html
    assert 'id="demo-agent-flow"' in index_html and 'PORTAL DEMO' in index_html
    assert 'id="pdf-action"' in index_html and 'id="agent-result-dialog"' in index_html
    assert 'id="home-brand"' in index_html and '$("#home-brand").addEventListener' in app_script
    assert 'id="tab-report-agent"' in index_html and 'id="report-download-pptx"' in index_html
    assert 'id="persona-chip-row"' in index_html and 'id="emphasis-chip-row"' in index_html
    assert "buildDemoReport" in app_script and "handleReportDownloadPptx" in app_script
    assert "/api/report-agent/export-pptx" in app_script
    assert 'vendor/pptxgen.bundle.js' in index_html and 'offline-ppt.js' in index_html
    assert "downloadReportPptxOffline" in app_script and "서버 연결 없이 PPT를 생성했습니다" in app_script
    assert "createOfflineReportPresentation" in offline_ppt_script and "LAYOUT_4x3" in offline_ppt_script
    assert "PptxGenJS" in pptx_bundle
    assert ".agent-tabs" in styles and ".report-controls" in styles
    assert 'id="read-agent-clipboard"' in index_html and 'id="preview-agent-result"' in index_html
    assert 'id="apply-agent-result"' in index_html and "disabled" in index_html
    assert "<iframe" not in index_html.lower()
    assert "업무 Agent" in index_html
    assert "--agent-drawer-width: 570px" in styles
    assert "margin-right: calc(var(--agent-drawer-width)" in styles
    assert 'class="content-split agent-hidden"' in index_html
    assert "height: 100dvh" in styles and ".main-content" in styles and "overflow-y: auto" in styles
    assert "handleAgentChatSubmit" in app_script and "createAgentResponse" in app_script
    assert "liveAgentApi" not in app_script and "/api/agent/chat" not in app_script and "loadAgentStatus" in app_script
    assert "buildDemoPortalTransfer" in app_script and "stageDirectAgentResult" in app_script
    assert "applyAgentDraft" in app_script and "data-agent-apply-chat" in app_script
    assert "readAgentClipboard" in app_script and "setDemoAgentStep" in app_script
    assert "applyAgentResultReview" in app_script and "parseAgentResult" in app_script
    assert "previewAgentResult" in app_script and "openCopilotWindow" not in app_script
    assert "openPdfPrintView" in app_script and "@page { size: A4" in app_script
    assert "과제별 PDF 출력" in app_script and "팀장보고 PDF 출력" in app_script
    assert 'tagged-report-block ${block.statusTags.includes("NEW") ? "is-new" : ""}' in app_script
    assert ".tagged-report-block.is-new .tagged-report-copy { color: #0000ff" in styles
    assert ".structured-edit-block.is-new .block-body { color: #0000ff" in styles
    assert "teamComparisonCatalog" in app_script and "renderTeamComparisonEditor" in app_script
    assert "composeTeamComparisonContent" in app_script and "collectTeamComparisonRowsFromDom" in app_script
    assert ".team-compare-columns { display: grid; grid-template-columns:" in styles
    assert ".comparison-current-value" in styles and "print-compare-columns" in app_script
    assert "data-keep-comparison" in app_script and "data-delete-comparison" in app_script
    assert "data-add-comparison" in app_script
    assert "renderDepartmentKpiDashboard" in app_script and "renderGroupKpiDashboard" in app_script
    assert "renderDepartmentKpiMonitor" in app_script and "renderGroupKpiMonitor" in app_script
    assert '"담당 KPI"' in app_script and '"그룹장 KPI"' in app_script
    assert "renderSourceWorkDetail" in app_script and "Plan 대비 진척" in app_script
    assert all(code in app_script for code in ["WI-RSND-2026-031", "WI-RSND-2026-032", "WI-RSND-2026-033", "WI-RSND-2026-034", "WI-RSND-2026-035"])
    assert "renderReportFileReview" in app_script and "data-add-review-comment" in app_script
    assert "renderReportNarrative" in app_script and "report-story" in app_script
    assert "이슈–해결과정–결과–후속계획" in app_script
    assert "WA 자동차 NND" in app_script and "OT 시뮬레이션" in app_script
    assert "print-story" in app_script and "이슈·해결과정·결과·후속계획 포함" in app_script
    assert "W35 금주 내용만 보고" in app_script and "data-print-current-team" in app_script
    print_team_slice = app_script[app_script.index("function printTeamReportMarkup"):app_script.index("function openPdfPrintView")]
    assert "지난주" not in print_team_slice and "W34" not in print_team_slice
    for visible_name in ["윤도현", "강민재", "오세진", "한유준", "서진우", "임가은", "조현우", "문서윤", "배지호", "유민석", "최도윤", "윤태성", "한지훈", "문서진"]:
        assert visible_name in app_script
    for source_name in ["정대영", "박상하", "김치완", "이상용", "박홍준", "정소영", "백승민", "김하람", "차영은", "박세용", "송무강", "김민수"]:
        assert source_name not in app_script and source_name not in index_html
    for removed_copy in ["검수용 익명화", "가운데 글자 치환", "첫·끝 글자 유지"]:
        assert removed_copy not in app_script and removed_copy not in index_html
    for slide in range(131, 162):
        assert f"rsndReportPage({slide}," in app_script, f"W35 RSND source page missing: {slide}"
    assert "copilotStudioEmbedUrl" not in app_script and "copilot-agent-frame" not in app_script
    assert "reloadCopilotFrame" not in app_script and "reload-copilot-frame" not in app_script
    assert "setAgentDrawer" in app_script
    root = Path(__file__).resolve().parents[1]
    assert (root / "windows-portal-server.ps1").exists(), "Windows PowerShell fallback server is missing"
    assert (root / "report_export.py").exists(), "Report Agent PPT exporter is missing"
    assert (root / "assets" / "company_template.pptx").exists(), "Company PPT template is missing"
    assert "python-pptx" in (root / "requirements.txt").read_text(encoding="utf-8")
    for batch_name in ("run-demo.bat",):
        batch_bytes = (root / batch_name).read_bytes()
        assert all(byte < 128 for byte in batch_bytes), f"{batch_name} must remain ASCII-safe"
        assert b"\r\n" in batch_bytes, f"{batch_name} must use Windows CRLF line endings"
    agent_status = request_json("/api/agent/status")
    assert_equal(agent_status["mode"], "DEMO", "default agent mode")
    assert agent_status["configured"], "built-in Demo Agent must be ready"
    assert_equal(agent_status["provider"], "portal_demo_agent", "demo agent provider")

    ppt_payload = {
        "persona_label": "CDO",
        "emphasis_label": "성과/실적",
        "report": {
            "title": "자동보정담당 주간보고 — CDO용",
            "summary": "W35 주요 실행성과와 리스크를 요약했습니다.",
            "sections": [
                {"heading": "성과/결과", "bullets": ["대표호기 자동보정 적용과 기준정보 등록을 완료했습니다."]},
                {"heading": "리스크/이슈", "bullets": ["K12 생산조건 재현성 검증이 추가로 필요합니다."]},
                {"heading": "다음 계획", "bullets": ["제품별 상·하한과 예외조건을 확정합니다."]},
            ],
            "flagged_terms": [],
        },
    }
    ppt_data, ppt_type = request_binary("/api/report-agent/export-pptx", ppt_payload)
    assert ppt_data.startswith(b"PK"), "PPTX response is not an Office ZIP package"
    assert "presentationml.presentation" in ppt_type, "PPTX content type mismatch"
    with zipfile.ZipFile(io.BytesIO(ppt_data)) as archive:
        names = set(archive.namelist())
        assert "ppt/slides/slide1.xml" in names and "ppt/slides/slide5.xml" in names
        assert any(name.startswith("ppt/media/") for name in names), "company template media missing"

    catalog = request_json("/api/screen-catalog")
    assert_equal(len(catalog), 60, "screen catalog count")
    assert_equal(len({screen["screen_id"] for screen in catalog}), 60, "unique screen IDs")

    for role, count in expected_screens.items():
        bootstrap = request_json(f"/api/bootstrap?role={role}")
        assert_equal(len(bootstrap["screens"]), count, f"{role} screen count")
        assert_equal(bootstrap["principal"]["role_code"], role, f"{role} principal")
        assert bootstrap["cycle"]["cycle_code"] == "2026-W35"
        assert_equal(bootstrap["cycle"]["week"], 35, f"{role} cycle week")

    leader_screens = request_json("/api/bootstrap?role=LEADER")["screens"]
    dept_screens = request_json("/api/bootstrap?role=DEPT")["screens"]
    head_screens = request_json("/api/bootstrap?role=HEAD")["screens"]
    assert next(item for item in leader_screens if item["screen_id"] == "LDR-06")["kind"] == "leaderFinal"
    assert next(item for item in leader_screens if item["screen_id"] == "LDR-09")["kind"] == "departmentKpi"
    assert next(item for item in dept_screens if item["screen_id"] == "DPT-02")["kind"] == "departmentReview"
    assert next(item for item in dept_screens if item["screen_id"] == "DPT-08")["kind"] == "departmentKpi"
    assert next(item for item in dept_screens if item["screen_id"] == "DPT-09")["kind"] == "groupKpi"
    assert next(item for item in head_screens if item["screen_id"] == "HED-02")["kind"] == "groupReview"
    assert next(item for item in head_screens if item["screen_id"] == "HED-07")["kind"] == "departmentKpi"
    assert next(item for item in head_screens if item["screen_id"] == "HED-08")["kind"] == "groupKpi"

    leader_initial = request_json("/api/bootstrap?role=LEADER")
    initial_team_report = next(item for item in leader_initial["reports"] if item["id"] == "rpt_team")
    assert_equal(initial_team_report["content"].count("[NEW]"), 15, "initial team report W35 New blocks")
    assert_equal(initial_team_report["content"].count("(W34 유지)"), 3, "initial team report retained W34 blocks")
    assert "[SNP-YIELD-2026-W35-003][KPI][VERIFIED][NEW]" in initial_team_report["content"]
    assert "[MEMBER:강민재]" in initial_team_report["content"] and "[MEMBER:배지호]" in initial_team_report["content"]

    member_initial = request_json("/api/bootstrap?role=MEMBER")
    assert_equal(len(member_initial["work_pages"]), 3, "member work page count")
    assert all(page["contributors"] for page in member_initial["work_pages"]), "work page contributors missing"
    eligible_snapshots = [
        item for item in member_initial["snapshots"]
        if item["status"] == "LOCKED"
        and item["verification_state"] == "VERIFIED"
        and int(item["validation_errors"]) == 0
    ]
    assert_equal(len(eligible_snapshots), 3, "eligible snapshot count")
    assert not any(item["id"] == "snp_pd_w35" for item in eligible_snapshots), "invalid PD snapshot became eligible"

    demo_agent_payload = {
        "role": "MEMBER", "request_id": "built-in-demo-flow-1", "ready_for_review": True, "questions": [],
        "warnings": ["PD Loss Snapshot은 승인 조건 미충족으로 수치 문장에서 제외하였습니다."],
        "pages": [
            {"target_page_id": "pg_tension", "segments": [
                {"tag": "RESULT", "text": "M08·M11 반복시험에서 제품별 보정 방향이 일관되게 나타나는 것을 확인하였습니다.", "evidence_state": "SOURCE_REFERENCED", "source_refs": ["EVD-RSND-2026-W35-028"]},
                {"tag": "ANALYSIS", "text": "K12는 생산조건 차이의 영향을 분리하기 위해 동일 조건 재현성 검증이 추가로 필요합니다.", "evidence_state": "SOURCE_REFERENCED", "source_refs": ["EVD-RSND-2026-W35-029"]},
                {"tag": "RISK", "text": "K12 검증용 생산 일정이 확정되지 않아 제품별 적용조건 확정 일정이 지연될 가능성이 있습니다.", "evidence_state": "USER_INPUT", "source_refs": []},
                {"tag": "PLAN", "text": "8월 27일까지 K12 재현성 검증을 완료하고 제품별 상·하한과 예외조건을 확정할 예정입니다.", "evidence_state": "SOURCE_REFERENCED", "source_refs": ["EVD-RSND-2026-W35-029"]},
                {"tag": "KPI", "text": "W35 수율은 92.4%로 전주 91.8% 대비 0.6%p 증가하였습니다.", "evidence_state": "SNAPSHOT_VERIFIED", "source_refs": ["SNP-YIELD-2026-W35-003"]},
            ]},
            {"target_page_id": "pg_loading", "segments": [
                {"tag": "RESULT", "text": "코터 로딩량과 Roll Press Tension 데이터의 전처리 및 예측모델 연계 가능성을 확인하였습니다.", "evidence_state": "SOURCE_REFERENCED", "source_refs": []},
                {"tag": "PLAN", "text": "8월 28일까지 Feedforward 자동보정 로직과 설비별 기준정보를 확정할 예정입니다.", "evidence_state": "USER_INPUT", "source_refs": []},
            ]},
            {"target_page_id": "pg_vm", "segments": [
                {"tag": "RESULT", "text": "RP·NND 기준정보 표준화와 VM 제작사양서 초안 작성을 완료하였습니다.", "evidence_state": "SOURCE_REFERENCED", "source_refs": []},
                {"tag": "PLAN", "text": "8월 28일까지 VM·응용 환경 설정 범위와 제작사양서를 확정하고 데이터 수집 일정을 연결할 예정입니다.", "evidence_state": "USER_INPUT", "source_refs": []},
            ]},
        ],
    }
    demo_applied = request_json("/api/agent/apply-result", demo_agent_payload)
    assert demo_applied["ok"] and len(demo_applied["applied"]) == 9, "built-in Demo Agent apply failed"
    assert_equal(demo_applied["content"].count("@@PAGE|"), 3, "Demo Agent page count")
    assert "[KPI][NEW]" in demo_applied["content"] and "92.4%" in demo_applied["content"]

    verified_quantitative = {
        "role": "MEMBER", "request_id": "server-verified-quant-1", "ready_for_review": True, "questions": [],
        "pages": [{"target_page_id": "pg_tension", "segments": [{
            "tag": "KPI", "evidence_state": "SNAPSHOT_VERIFIED",
            "text": "W35 수율은 92.4%이며 전주 91.8% 대비 0.6%p 증가했고, BM Loss는 6.8%입니다.",
            "source_refs": ["SNP-YIELD-2026-W35-003", "SNP-BM-2026-W35-002"],
        }]}],
    }
    applied_quantitative = request_json("/api/agent/apply-result", verified_quantitative)
    assert applied_quantitative["ok"] and len(applied_quantitative["applied"]) == 1
    repeated_quantitative = request_json("/api/agent/apply-result", verified_quantitative)
    assert_equal(repeated_quantitative["trace_id"], applied_quantitative["trace_id"], "request_id idempotency")

    before_atomic = len(request_json("/api/bootstrap?role=MEMBER")["worklogs"])
    atomic_payload = {
        "role": "MEMBER", "request_id": "server-atomic-reject-1", "ready_for_review": True, "questions": [],
        "pages": [
            {"target_page_id": "pg_loading", "segments": [{"tag": "RESULT", "text": "원자성 검증용 정상 문장입니다.", "source_refs": []}]},
            {"target_page_id": "pg_vm", "segments": [{"tag": "KPI", "evidence_state": "SNAPSHOT_VERIFIED", "text": "수율은 99.9%입니다.", "source_refs": ["SNP-YIELD-2026-W35-003"]}]},
        ],
    }
    status, rejected = request_error("/api/agent/apply-result", atomic_payload)
    assert status == 409 and "정량 값·단위" in rejected["message"]
    after_atomic = len(request_json("/api/bootstrap?role=MEMBER")["worklogs"])
    assert_equal(after_atomic, before_atomic, "rejected multi-page atomicity")

    status, rejected = request_error("/api/agent/apply-result", {
        "role": "MEMBER", "ready_for_review": True, "questions": [],
        "pages": [{"target_page_id": "pg_vm", "segments": [{"tag": "KPI", "text": "수율은 92.4%입니다.", "source_refs": ["SNP-YIELD-2026-W35-003"]}]}],
    })
    assert status == 409 and "evidence_state" in rejected["message"]

    status, rejected = request_error("/api/agent/apply-result", {
        "role": "MEMBER", "ready_for_review": True, "questions": [],
        "pages": [{"target_page_id": "pg_vm", "segments": [{"tag": "KPI", "evidence_state": "SNAPSHOT_VERIFIED", "text": "수율은 92.4건입니다.", "source_refs": ["SNP-YIELD-2026-W35-003"]}]}],
    })
    assert status == 409 and "정량 값·단위" in rejected["message"]

    status, rejected = request_error("/api/agent/apply-result", {
        "role": "MEMBER", "ready_for_review": True, "questions": [],
        "pages": [{"target_page_id": "pg_vm", "segments": [{"tag": "KPI", "evidence_state": "SNAPSHOT_VERIFIED", "text": "수율은 92.4%이며 미분류 대상은 3입니다.", "source_refs": ["SNP-YIELD-2026-W35-003"]}]}],
    })
    assert status == 409 and "정량 값·단위" in rejected["message"]

    status, rejected = request_error("/api/agent/apply-result", {
        "role": "MEMBER", "ready_for_review": True, "questions": [],
        "pages": [{"target_page_id": "pg_vm", "segments": [{"tag": "KPI", "evidence_state": "SNAPSHOT_VERIFIED", "text": "PD Loss는 1.2%입니다.", "source_refs": ["SNP-PD-2026-W35-004"]}]}],
    })
    assert status == 409 and "범위가 단일하지 않거나" in rejected["message"]

    added_plan = "K12 검증 결과를 반영해 제품별 예외조건을 W35에 확정하겠습니다."
    worklog = request_json("/api/worklogs", {
        "role": "MEMBER",
        "work_item_id": "wi_rsnd_32",
        "entry_type": "PLAN",
        "occurred_on": "2026-08-24",
        "narrative": added_plan,
    })
    assert worklog["ok"] and worklog["record"]["entry_type"] == "PLAN"

    evidence = request_json("/api/evidence", {
        "role": "MEMBER",
        "work_item_id": "wi_rsnd_32",
        "file_name": "K12_W35_검증계획.xlsx",
        "locator": "Plan!A1:F12",
        "security_label": "CONFIDENTIAL",
    })
    assert evidence["ok"] and evidence["record"]["evidence_code"].startswith("EVD-RSND-2026-W35-")

    selection = request_json("/api/submission/items", {
        "role": "MEMBER",
        "work_page_ids": ["pg_tension", "pg_loading", "pg_vm"],
    })
    assert selection["ok"] and set(selection["work_page_ids"]) == {"pg_tension", "pg_loading", "pg_vm"}

    draft = request_json("/api/agent/draft", {"role": "MEMBER"})
    assert draft["ok"] and len(draft["citations"]) >= 4
    assert_equal(draft["content"].count("@@PAGE|"), 3, "draft work page count")
    assert "RPG-RSND-2026-0001" in draft["content"]
    assert "RPG-RSND-2026-0002" in draft["content"]
    assert "RPG-RSND-2026-0003" in draft["content"]
    assert "임가은(주)" in draft["content"] and "배지호(공동)" in draft["content"]
    assert "(W31)" in draft["content"] and "(W32)" in draft["content"]
    assert "(W34)" in draft["content"] and "(W35)" in draft["content"]
    assert "WI-RSND-2026-0032" in draft["content"]
    assert "[PLAN]" in draft["content"] and added_plan in draft["content"]
    assert "적용조건 기준안을 수립" in draft["content"], "previous-week narrative was not carried forward"
    assert "[RESULT][NEW]" in draft["content"] and "[PLAN][NEW]" in draft["content"]
    assert draft["content"].count("[NEW]") >= 5, "current-week additions were not marked New"
    assert draft["content"].index("적용조건 기준안을 수립") < draft["content"].index("M08과 M11 제품 반복 시험")
    edited_note = "[WI-RSND-2026-0032][PLAN][NEW] (W35) 팀원 확인 후 K12 시험 순서를 M08·M11 결과와 동일 조건으로 조정하겠습니다."
    edited_content = draft["content"].replace("@@ENDPAGE@@", edited_note + "\n@@ENDPAGE@@", 1)
    saved_version = request_json("/api/draft/version", {"role": "MEMBER", "content": edited_content})
    assert saved_version["ok"] and saved_version["version"] >= 4
    member_data = request_json("/api/bootstrap?role=MEMBER")
    assert any(item["narrative"] == added_plan for item in member_data["worklogs"])
    assert any(item["file_name"] == "K12_W35_검증계획.xlsx" for item in member_data["evidence"])
    assert added_plan in member_data["submission_versions"][0]["content"]
    assert edited_note in member_data["submission_versions"][0]["content"]

    leader_draft = request_json("/api/agent/draft", {"role": "LEADER"})
    assert leader_draft["ok"] and edited_note in leader_draft["content"]
    assert "[ANALYSIS]" in leader_draft["content"] and "[PLAN]" in leader_draft["content"]
    assert "[SNP-YIELD-2026-W35-003][KPI][VERIFIED][NEW]" in leader_draft["content"]
    assert leader_draft["content"].count("[NEW]") >= 10
    assert "[MEMBER:강민재]" in leader_draft["content"] and "[MEMBER:배지호]" in leader_draft["content"]
    leader_edit_note = "[WI-RSND-2026-0032][PLAN] 팀장 검토 의견: K12 검증 완료 후 제품별 수평전개 기준을 담당과 협의하겠습니다."
    leader_version = request_json("/api/draft/version", {"role": "LEADER", "content": leader_draft["content"] + "\n\n" + leader_edit_note})
    assert leader_version["ok"]
    leader_data = request_json("/api/bootstrap?role=LEADER")
    team_report = next(item for item in leader_data["reports"] if item["id"] == "rpt_team")
    assert leader_edit_note in team_report["content"]

    answer = request_json("/api/agent/ask", {"role": "HEAD", "question": "자동보정 효과를 확정할 수 있어?"})
    assert answer["ok"] and len(answer["citations"]) == 3
    assert "확정할 수 없습니다" in answer["answer"]

    workflow = [
        ("DATA_OWNER", "VALIDATE_SNAPSHOT"),
        ("DATA_OWNER", "APPROVE_SNAPSHOT"),
        ("MEMBER", "SUBMIT_MEMBER"),
        ("LEADER", "APPROVE_TEAM"),
        ("DEPT", "APPROVE_DEPT"),
        ("PLANNING", "RESOLVE_QA"),
        ("PLANNING", "APPROVE_PLANNING"),
        ("HEAD", "RESOLVE_DECISION"),
    ]
    for role, action in workflow:
        result = request_json("/api/action", {"role": role, "action": action})
        assert result["ok"] and result["trace_id"].startswith("TRACE-DEMO-")

    final_data = request_json("/api/bootstrap?role=HEAD")
    pd_snapshot = next(item for item in final_data["snapshots"] if item["id"] == "snp_pd_w35")
    assert_equal(pd_snapshot["status"], "LOCKED", "PD snapshot lock")
    decision = next(item for item in final_data["decisions"] if item["id"] == "dec1")
    assert_equal(decision["status"], "RESOLVED", "decision state")
    assert any(item["action_code"] == "ACT-RSND-2026-0052" for item in final_data["action_items"])

    reset = request_json("/api/reset", {})
    assert reset["ok"]
    reset_data = request_json("/api/bootstrap?role=DATA_OWNER")
    reset_pd = next(item for item in reset_data["snapshots"] if item["id"] == "snp_pd_w35")
    assert_equal(reset_pd["verification_state"], "PROVISIONAL", "reset snapshot state")
    assert_equal(len(reset_data["audit_events"]), 3, "reset audit count")

    print("PASS: rich issue-resolution leader report, W35 full 31-page RSND report, 10 fictional members, KPI dashboards, current-only PDF, 60 screens, workflow, reset")


if __name__ == "__main__":
    main()
