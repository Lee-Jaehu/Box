"use strict";

const fs = require("fs");
const path = require("path");

global.window = {};
require("../web/demo-data.js");

async function main() {
  const api = global.window.demoOfflineApi;
  if (typeof api !== "function") throw new Error("offline API was not registered");

  const webRoot = path.join(__dirname, "..", "web");
  const indexHtml = fs.readFileSync(path.join(webRoot, "index.html"), "utf8");
  const styles = fs.readFileSync(path.join(webRoot, "styles.css"), "utf8");
  const appScript = fs.readFileSync(path.join(webRoot, "app.js"), "utf8");
  const offlinePptScript = fs.readFileSync(path.join(webRoot, "offline-ppt.js"), "utf8");
  if (!indexHtml.includes('id="weekly-agent"') || !indexHtml.includes('id="agent-chat-input"')) throw new Error("offline Agent chat markup missing");
  if (!indexHtml.includes('id="agent-page-chip"') || !indexHtml.includes('id="agent-attach"') || !indexHtml.includes("업무 Agent")) throw new Error("offline Agent controls missing");
  if (!indexHtml.includes('id="agent-engine-status"') || !indexHtml.includes('id="agent-engine-detail"')) throw new Error("offline Agent status UI missing");
  if (!indexHtml.includes('id="demo-agent-flow"') || !indexHtml.includes('PORTAL DEMO') || !indexHtml.includes('id="pdf-action"')) throw new Error("built-in Demo Agent controls missing");
  if (/<iframe\b/i.test(indexHtml) || /copilotStudioEmbedUrl|copilot-agent-frame|reload-copilot-frame/.test(indexHtml + appScript)) throw new Error("legacy Copilot iframe bridge must be removed");
  if (!styles.includes("--agent-drawer-width: 570px")) throw new Error("1.5x Agent drawer width missing");
  if (!styles.includes("margin-right: calc(var(--agent-drawer-width)")) throw new Error("Portal push layout missing");
  if (!indexHtml.includes('id="toggle-agent" class="agent-orb"') || !indexHtml.includes('class="agent-orb-sphere"') || !styles.includes(".agent-orb-sphere")) throw new Error("spherical floating Agent menu missing");
  if (!indexHtml.includes("AI ASSISTANT") || !indexHtml.includes("<b>AI</b>") || !styles.includes("position: relative;\n  z-index: 46;\n  flex: 0 0 auto")) throw new Error("recognizable non-overlapping header Agent control missing");
  if (!styles.includes(".page-heading h1 { margin: 6px 0 4px; font-size: 18px") || !styles.includes(".metric-value { font-size: 20px")) throw new Error("compact dashboard typography missing");
  if (!indexHtml.includes('id="reset-demo" class="button ghost utility-quiet"') || !indexHtml.includes('id="open-spec" class="button ghost utility-quiet"') || !styles.includes(".utility-quiet")) throw new Error("quiet utility controls missing");
  if (!indexHtml.includes('id="home-brand"') || !appScript.includes('$("#home-brand").addEventListener')) throw new Error("clickable home brand missing");
  if (!indexHtml.includes('id="tab-report-agent"') || !indexHtml.includes('id="report-download-pptx"')) throw new Error("report Agent or PPT download controls missing");
  if (!indexHtml.includes('id="persona-chip-row"') || !indexHtml.includes('id="emphasis-chip-row"')) throw new Error("report Agent selection controls missing");
  if (!appScript.includes("buildDemoReport") || !appScript.includes("handleReportDownloadPptx") || !appScript.includes("/api/report-agent/export-pptx")) throw new Error("report Agent PPT workflow missing");
  if (!indexHtml.includes('vendor/pptxgen.bundle.js') || !indexHtml.includes('offline-ppt.js')) throw new Error("offline PPT browser scripts missing");
  if (!appScript.includes("downloadReportPptxOffline") || !appScript.includes("서버 연결 없이 PPT를 생성했습니다")) throw new Error("offline PPT fallback workflow missing");
  if (!offlinePptScript.includes("createOfflineReportPresentation") || !offlinePptScript.includes("LAYOUT_4x3")) throw new Error("offline PPT generator missing");
  if (!styles.includes(".agent-tabs") || !styles.includes(".report-controls")) throw new Error("report Agent visual styling missing");
  if (!styles.includes("--primary: #a50034") || !styles.includes("background: var(--surface);\n  color: var(--text);\n  border-right: 1px solid var(--line)")) throw new Error("conversational AI visual system missing");
  if (!indexHtml.includes('class="content-split agent-hidden"')) throw new Error("Agent drawer must be closed initially");
  if (!appScript.includes("handleAgentChatSubmit") || !appScript.includes("createAgentResponse") || !appScript.includes("buildDemoPortalTransfer") || !appScript.includes("stageDirectAgentResult") || !appScript.includes("applyAgentResultReview") || !appScript.includes("openPdfPrintView")) throw new Error("offline Demo Agent or PDF workflow missing");
  if (!appScript.includes('tagged-report-block ${block.statusTags.includes("NEW") ? "is-new" : ""}') || !styles.includes(".tagged-report-block.is-new .tagged-report-copy { color: #0000ff") || !styles.includes(".structured-edit-block.is-new .block-body { color: #0000ff")) throw new Error("team leader New blue rendering missing");
  if (!appScript.includes("teamComparisonCatalog") || !appScript.includes("renderTeamComparisonEditor") || !appScript.includes("composeTeamComparisonContent")) throw new Error("team leader comparison editor missing");
  if (!styles.includes(".team-compare-columns { display: grid; grid-template-columns:") || !styles.includes(".comparison-current-value") || !appScript.includes("print-compare-columns")) throw new Error("team leader side-by-side screen or PDF missing");
  if (!appScript.includes("data-keep-comparison") || !appScript.includes("data-delete-comparison") || !appScript.includes("data-add-comparison")) throw new Error("team leader retain/delete/new actions missing");
  if (!appScript.includes("renderDepartmentKpiDashboard") || !appScript.includes("renderGroupKpiDashboard") || !appScript.includes("renderDepartmentKpiMonitor") || !appScript.includes("renderGroupKpiMonitor") || !appScript.includes('"담당 KPI"') || !appScript.includes('"그룹장 KPI"')) throw new Error("shared or dedicated KPI dashboards missing");
  if (!appScript.includes("renderSourceWorkDetail") || !appScript.includes("Plan 대비 진척") || !appScript.includes("연결 Resource")) throw new Error("source-backed member progress screen missing");
  if (!appScript.includes("renderReportFileReview") || !appScript.includes("담당이 직접 수정하지 않습니다") || !appScript.includes("팀장 원문은 변경하지 않습니다")) throw new Error("department/head immutable review flow missing");
  if (!appScript.includes("renderReportNarrative") || !appScript.includes("report-story") || !appScript.includes("이슈–해결과정–결과–후속계획") || !appScript.includes("WA 자동차 NND") || !appScript.includes("OT 시뮬레이션")) throw new Error("rich leader issue-resolution narrative missing");
  if (!appScript.includes("print-story") || !appScript.includes("이슈·해결과정·결과·후속계획 포함")) throw new Error("rich leader PDF narrative missing");
  if (!appScript.includes("W35 금주 내용만 보고") || !appScript.includes("data-print-current-team")) throw new Error("current-week-only leader report missing");
  const printTeamSlice = appScript.slice(appScript.indexOf("function printTeamReportMarkup"), appScript.indexOf("function openPdfPrintView"));
  if (printTeamSlice.includes("지난주") || printTeamSlice.includes("W34")) throw new Error("leader PDF must not include previous-week content");
  for (const visibleName of ["윤도현", "강민재", "오세진", "한유준", "서진우", "임가은", "조현우", "문서윤", "배지호", "유민석", "최도윤", "윤태성", "한지훈", "문서진"]) {
    if (!appScript.includes(visibleName) && !indexHtml.includes(visibleName)) throw new Error(`anonymized demo name missing: ${visibleName}`);
  }
  for (const sourceName of ["정대영", "박상하", "김치완", "이상용", "박홍준", "정소영", "백승민", "김하람", "차영은", "박세용", "송무강", "김민수"]) {
    if (appScript.includes(sourceName) || indexHtml.includes(sourceName)) throw new Error(`source person name leaked: ${sourceName}`);
  }
  for (const removedCopy of ["검수용 익명화", "가운데 글자 치환", "첫·끝 글자 유지"]) {
    if (appScript.includes(removedCopy) || indexHtml.includes(removedCopy)) throw new Error(`removed anonymization UI leaked: ${removedCopy}`);
  }
  for (let slide = 131; slide <= 161; slide += 1) {
    if (!appScript.includes(`rsndReportPage(${slide},`)) throw new Error(`W35 RSND source page missing: ${slide}`);
  }
  if (appScript.includes("liveAgentApi") || appScript.includes('/api/agent/chat')) throw new Error("external Agent call path must not exist in demo UI");

  const agentStatus = await api("/api/agent/status");
  if (agentStatus.mode !== "DEMO" || !agentStatus.configured || agentStatus.provider !== "portal_demo_agent") throw new Error("direct HTML must load the built-in Demo Agent");

  const expected = { COMMON: 5, MEMBER: 8, LEADER: 9, DEPT: 9, PLANNING: 7, HEAD: 8, DATA_OWNER: 7, ADMIN: 7 };
  const catalog = await api("/api/screen-catalog");
  if (catalog.length !== 60) throw new Error(`expected 60 screens, got ${catalog.length}`);

  for (const [role, count] of Object.entries(expected)) {
    const data = await api(`/api/bootstrap?role=${role}`);
    if (data.screens.length !== count) throw new Error(`${role}: expected ${count} screens, got ${data.screens.length}`);
    if (data.principal.role_code !== role) throw new Error(`${role}: principal mismatch`);
  }

  const leaderInitial = await api("/api/bootstrap?role=LEADER");
  if (leaderInitial.screens.find((item) => item.screen_id === "LDR-06")?.kind !== "leaderFinal") throw new Error("leader current-only screen kind missing");
  if (leaderInitial.screens.find((item) => item.screen_id === "LDR-09")?.kind !== "departmentKpi") throw new Error("leader department KPI screen kind missing");
  const deptInitial = await api("/api/bootstrap?role=DEPT");
  if (deptInitial.screens.find((item) => item.screen_id === "DPT-02")?.kind !== "departmentReview") throw new Error("department full-file review screen kind missing");
  if (deptInitial.screens.find((item) => item.screen_id === "DPT-08")?.kind !== "departmentKpi" || deptInitial.screens.find((item) => item.screen_id === "DPT-09")?.kind !== "groupKpi") throw new Error("department KPI monitor screens missing");
  const headInitial = await api("/api/bootstrap?role=HEAD");
  if (headInitial.screens.find((item) => item.screen_id === "HED-02")?.kind !== "groupReview") throw new Error("group-head report review screen kind missing");
  if (headInitial.screens.find((item) => item.screen_id === "HED-07")?.kind !== "departmentKpi" || headInitial.screens.find((item) => item.screen_id === "HED-08")?.kind !== "groupKpi") throw new Error("group-head KPI monitor screens missing");
  const initialTeamReport = leaderInitial.reports.find((item) => item.id === "rpt_team");
  if (!initialTeamReport || (initialTeamReport.content.match(/\[NEW\]/g) || []).length !== 15) throw new Error("initial team report must have 15 W35 New blocks");
  if ((initialTeamReport.content.match(/\(W34 유지\)/g) || []).length !== 3) throw new Error("initial team report must have 3 retained W34 blocks");
  if (!initialTeamReport.content.includes("[MEMBER:강민재]") || !initialTeamReport.content.includes("[MEMBER:배지호]")) throw new Error("other team member reports missing");
  if (!initialTeamReport.content.includes("[SNP-YIELD-2026-W35-003][KPI][VERIFIED][NEW]") || initialTeamReport.content.includes("[SNP-PD-2026-W35-004][KPI]")) throw new Error("initial team report KPI policy failed");

  const memberInitial = await api("/api/bootstrap?role=MEMBER");
  if (memberInitial.work_pages.length !== 3) throw new Error("offline member work page count failed");
  if (!memberInitial.work_pages.every((page) => page.contributors)) throw new Error("offline work page contributors missing");
  const eligibleSnapshots = memberInitial.snapshots.filter((item) => item.status === "LOCKED" && item.verification_state === "VERIFIED" && Number(item.validation_errors) === 0);
  if (eligibleSnapshots.length !== 3) throw new Error(`expected 3 eligible snapshots, got ${eligibleSnapshots.length}`);
  if (eligibleSnapshots.some((item) => item.id === "snp_pd_w35")) throw new Error("validation-failed PD snapshot must not be eligible");

  const verifiedQuantitative = {
    role: "MEMBER", request_id: "offline-verified-quant-1", ready_for_review: true, questions: [],
    pages: [{ target_page_id: "pg_tension", segments: [{
      tag: "KPI", evidence_state: "SNAPSHOT_VERIFIED",
      text: "W35 수율은 92.4%이며 전주 91.8% 대비 0.6%p 증가했고, BM Loss는 6.8%입니다.",
      source_refs: ["SNP-YIELD-2026-W35-003", "SNP-BM-2026-W35-002"],
    }] }],
  };
  const appliedQuantitative = await api("/api/agent/apply-result", { body: JSON.stringify(verifiedQuantitative) });
  if (!appliedQuantitative.ok || appliedQuantitative.applied.length !== 1) throw new Error("offline verified quantitative apply failed");
  const repeatedQuantitative = await api("/api/agent/apply-result", { body: JSON.stringify(verifiedQuantitative) });
  if (repeatedQuantitative.trace_id !== appliedQuantitative.trace_id) throw new Error("offline request_id idempotency failed");

  async function expectApplyReject(payload, phrase) {
    let rejected = false;
    try {
      await api("/api/agent/apply-result", { body: JSON.stringify(payload) });
    } catch (error) {
      rejected = true;
      if (!String(error.message).includes(phrase)) throw error;
    }
    if (!rejected) throw new Error(`expected rejection: ${phrase}`);
  }
  const beforeAtomic = (await api("/api/bootstrap?role=MEMBER")).worklogs.length;
  await expectApplyReject({
    role: "MEMBER", request_id: "offline-atomic-reject-1", ready_for_review: true, questions: [],
    pages: [
      { target_page_id: "pg_loading", segments: [{ tag: "RESULT", text: "원자성 검증용 정상 문장입니다.", source_refs: [] }] },
      { target_page_id: "pg_vm", segments: [{ tag: "KPI", evidence_state: "SNAPSHOT_VERIFIED", text: "수율은 99.9%입니다.", source_refs: ["SNP-YIELD-2026-W35-003"] }] },
    ],
  }, "정량 값·단위");
  const afterAtomic = (await api("/api/bootstrap?role=MEMBER")).worklogs.length;
  if (afterAtomic !== beforeAtomic) throw new Error("offline rejected multi-page request was not atomic");
  await expectApplyReject({
    role: "MEMBER", ready_for_review: true, questions: [],
    pages: [{ target_page_id: "pg_vm", segments: [{ tag: "KPI", text: "수율은 92.4%입니다.", source_refs: ["SNP-YIELD-2026-W35-003"] }] }],
  }, "evidence_state");
  await expectApplyReject({
    role: "MEMBER", ready_for_review: true, questions: [],
    pages: [{ target_page_id: "pg_vm", segments: [{ tag: "KPI", evidence_state: "SNAPSHOT_VERIFIED", text: "수율은 92.4건입니다.", source_refs: ["SNP-YIELD-2026-W35-003"] }] }],
  }, "정량 값·단위");
  await expectApplyReject({
    role: "MEMBER", ready_for_review: true, questions: [],
    pages: [{ target_page_id: "pg_vm", segments: [{ tag: "KPI", evidence_state: "SNAPSHOT_VERIFIED", text: "수율은 92.4%이며 미분류 대상은 3입니다.", source_refs: ["SNP-YIELD-2026-W35-003"] }] }],
  }, "정량 값·단위");
  await expectApplyReject({
    role: "MEMBER", ready_for_review: true, questions: [],
    pages: [{ target_page_id: "pg_vm", segments: [{ tag: "KPI", evidence_state: "SNAPSHOT_VERIFIED", text: "PD Loss는 1.2%입니다.", source_refs: ["SNP-PD-2026-W35-004"] }] }],
  }, "범위가 단일하지 않거나");

  const addedPlan = "K12 검증 결과를 반영해 제품별 예외조건을 W35에 확정하겠습니다.";
  const worklog = await api("/api/worklogs", { body: JSON.stringify({ role: "MEMBER", work_item_id: "wi_rsnd_32", entry_type: "PLAN", occurred_on: "2026-08-24", narrative: addedPlan }) });
  if (!worklog.ok || worklog.record.entry_type !== "PLAN") throw new Error("offline worklog save failed");

  const evidence = await api("/api/evidence", { body: JSON.stringify({ role: "MEMBER", work_item_id: "wi_rsnd_32", file_name: "K12_W35_검증계획.xlsx", locator: "Plan!A1:F12", security_label: "CONFIDENTIAL" }) });
  if (!evidence.ok || !evidence.record.evidence_code.startsWith("EVD-RSND-2026-W35-")) throw new Error("offline evidence save failed");

  const selection = await api("/api/submission/items", { body: JSON.stringify({ role: "MEMBER", work_page_ids: ["pg_tension", "pg_loading", "pg_vm"] }) });
  if (!selection.ok || selection.work_page_ids.length !== 3) throw new Error("offline page selection save failed");

  const draft = await api("/api/agent/draft", { body: JSON.stringify({ role: "MEMBER" }) });
  if ((draft.content.match(/@@PAGE\|/g) || []).length !== 3) throw new Error("offline draft work page count failed");
  for (const code of ["RPG-RSND-2026-0001", "RPG-RSND-2026-0002", "RPG-RSND-2026-0003"]) {
    if (!draft.content.includes(code)) throw new Error(`offline missing work page ${code}`);
  }
  if (!draft.content.includes("임가은(주)") || !draft.content.includes("배지호(공동)")) throw new Error("offline coauthor header failed");
  for (const week of ["(W31)", "(W32)", "(W34)", "(W35)"]) {
    if (!draft.content.includes(week)) throw new Error(`offline missing retained week ${week}`);
  }
  if (!draft.content.includes("WI-RSND-2026-0032") || !draft.content.includes("[PLAN]") || !draft.content.includes(addedPlan)) throw new Error("offline dynamic draft failed");
  if (!draft.content.includes("적용조건 기준안을 수립")) throw new Error("offline previous-week carryover failed");
  if (!draft.content.includes("[RESULT][NEW]") || !draft.content.includes("[PLAN][NEW]")) throw new Error("offline New tag failed");
  if ((draft.content.match(/\[NEW\]/g) || []).length < 5) throw new Error("offline current-week additions were not marked New");
  if (draft.content.indexOf("적용조건 기준안을 수립") > draft.content.indexOf("M08과 M11 제품 반복 시험")) throw new Error("offline carryover ordering failed");
  const editedNote = "[WI-RSND-2026-0032][PLAN][NEW] (W35) 팀원 확인 후 K12 시험 순서를 M08·M11 결과와 동일 조건으로 조정하겠습니다.";
  const editedContent = draft.content.replace("@@ENDPAGE@@", `${editedNote}\n@@ENDPAGE@@`);
  const savedVersion = await api("/api/draft/version", { body: JSON.stringify({ role: "MEMBER", content: editedContent }) });
  if (!savedVersion.ok || savedVersion.version < 4) throw new Error("offline edited version save failed");
  const memberAfter = await api("/api/bootstrap?role=MEMBER");
  if (!memberAfter.worklogs.some((item) => item.narrative === addedPlan)) throw new Error("offline next-screen propagation failed");
  if (!memberAfter.submission_versions[0].content.includes(addedPlan)) throw new Error("offline draft version propagation failed");
  if (!memberAfter.submission_versions[0].content.includes(editedNote)) throw new Error("offline edited version propagation failed");

  const leaderDraft = await api("/api/agent/draft", { body: JSON.stringify({ role: "LEADER" }) });
  if (!leaderDraft.content.includes(editedNote) || !leaderDraft.content.includes("[ANALYSIS]") || !leaderDraft.content.includes("[PLAN]")) throw new Error("offline leader propagation failed");
  if (!leaderDraft.content.includes("[SNP-YIELD-2026-W35-003][KPI][VERIFIED][NEW]") || (leaderDraft.content.match(/\[NEW\]/g) || []).length < 10) throw new Error("offline leader weekly comparison draft failed");
  if (!leaderDraft.content.includes("[MEMBER:강민재]") || !leaderDraft.content.includes("[MEMBER:배지호]")) throw new Error("offline leader multi-member draft failed");
  const leaderEditNote = "[WI-RSND-2026-0032][PLAN] 팀장 검토 의견: K12 검증 완료 후 제품별 수평전개 기준을 담당과 협의하겠습니다.";
  await api("/api/draft/version", { body: JSON.stringify({ role: "LEADER", content: `${leaderDraft.content}\n\n${leaderEditNote}` }) });
  const leaderAfter = await api("/api/bootstrap?role=LEADER");
  if (!leaderAfter.reports.find((item) => item.id === "rpt_team").content.includes(leaderEditNote)) throw new Error("offline leader edited version propagation failed");

  await api("/api/action", { body: JSON.stringify({ role: "DATA_OWNER", action: "VALIDATE_SNAPSHOT" }) });
  await api("/api/action", { body: JSON.stringify({ role: "DATA_OWNER", action: "APPROVE_SNAPSHOT" }) });
  const after = await api("/api/bootstrap?role=DATA_OWNER");
  const pd = after.snapshots.find((item) => item.id === "snp_pd_w35");
  if (pd.status !== "LOCKED" || pd.verification_state !== "VERIFIED") throw new Error("offline snapshot workflow failed");

  await api("/api/reset", { body: "{}" });
  const reset = await api("/api/bootstrap?role=DATA_OWNER");
  const resetPd = reset.snapshots.find((item) => item.id === "snp_pd_w35");
  if (resetPd.status !== "VALIDATION_FAILED") throw new Error("offline reset failed");

  console.log("PASS: rich issue-resolution leader report, W35 full 31-page RSND report, 10 fictional members, KPI dashboards, current-only PDF, 60 screens, workflow, reset");
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
