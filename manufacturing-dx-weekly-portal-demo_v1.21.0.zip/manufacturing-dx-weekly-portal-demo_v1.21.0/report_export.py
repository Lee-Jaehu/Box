#!/usr/bin/env python3
"""Builds a .pptx file from the Report Agent's structured output.

Two visual sources, both derived from a real LG에너지솔루션 internal report
that was analyzed for this project:

1. Cover slide: assets/company_template.pptx is a ~100KB extract containing
   ONLY the real cover slide (logo + teal swoosh graphic), stripped of all
   other slides/charts/embeddings from the original ~11MB source file. We
   reuse this slide as-is and only edit its three text boxes.
2. Content slides: the source reports don't have a reusable "simple content"
   layout (every content slide is a bespoke data-table/chart infographic), so
   these are custom-built here. They follow the same semantic color
   convention found across the real reports: 성과/결과 = green, 리스크/이슈 =
   red, 계획 = navy, 분석 = gray.
"""

from __future__ import annotations

import io
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
COMPANY_TEMPLATE_PATH = ROOT / "assets" / "company_template.pptx"

LATIN_FONT = "Arial Narrow"
EA_FONT = "LG스마트체 Regular"

NAVY = (0, 32, 96)      # 002060 - default header band / 계획 / 분석 fallback
GREEN = (0, 102, 0)     # 006600 - 성과/결과
RED = (192, 0, 0)       # C00000 - 리스크/이슈
GRAY = (127, 127, 127)  # 7F7F7F - 분석


class ExportDependencyError(RuntimeError):
    """Raised when python-pptx is not installed on the server."""


def _load_pptx_module():
    try:
        import pptx  # noqa: F401
        return pptx
    except ImportError as exc:  # pragma: no cover - environment dependent
        raise ExportDependencyError(
            "PPT 내보내기를 사용하려면 서버에 python-pptx를 설치해야 합니다. "
            "'pip install python-pptx' 실행 후 서버를 다시 시작하십시오."
        ) from exc


def _section_color(heading: str) -> tuple[int, int, int]:
    if "성과" in heading or "결과" in heading:
        return GREEN
    if "리스크" in heading or "이슈" in heading:
        return RED
    if "분석" in heading:
        return GRAY
    return NAVY  # 계획, 요약, 기타


def _set_dual_font(run, size_pt: float | None = None, bold: bool | None = None,
                    color: tuple[int, int, int] | None = None) -> None:
    from pptx.oxml.ns import qn
    from pptx.util import Pt
    from pptx.dml.color import RGBColor

    run.font.name = LATIN_FONT
    rPr = run._r.get_or_add_rPr()
    ea_el = rPr.find(qn("a:ea"))
    if ea_el is None:
        ea_el = rPr.makeelement(qn("a:ea"), {})
        rPr.append(ea_el)
    ea_el.set("typeface", EA_FONT)
    if size_pt is not None:
        run.font.size = Pt(size_pt)
    if bold is not None:
        run.font.bold = bold
    if color is not None:
        run.font.color.rgb = RGBColor(*color)


def _clear_extra_paragraphs(text_frame) -> None:
    for paragraph in list(text_frame.paragraphs[1:]):
        paragraph._p.getparent().remove(paragraph._p)


def _style_cover_slide(slide, report: dict[str, Any], persona_label: str, emphasis_label: str) -> None:
    boxes = {shape.name: shape for shape in slide.shapes if shape.has_text_frame}

    title_box = boxes.get("TextBox 5")
    if title_box is not None:
        tf = title_box.text_frame
        _clear_extra_paragraphs(tf)
        tf.paragraphs[0].text = report.get("title", "주간보고")
        for run in tf.paragraphs[0].runs:
            _set_dual_font(run, bold=True)
        p2 = tf.add_paragraph()
        p2.text = f"강조점: {emphasis_label}"
        for run in p2.runs:
            _set_dual_font(run, size_pt=14, bold=False)

    date_box = boxes.get("TextBox 3")
    if date_box is not None:
        tf = date_box.text_frame
        _clear_extra_paragraphs(tf)
        tf.paragraphs[0].text = persona_label
        for run in tf.paragraphs[0].runs:
            _set_dual_font(run)

    agenda_box = boxes.get("TextBox 7")
    if agenda_box is not None:
        tf = agenda_box.text_frame
        _clear_extra_paragraphs(tf)
        headings = ["요약"] + [s.get("heading", "") for s in report.get("sections", [])]
        tf.paragraphs[0].text = f"1. {headings[0]}" if headings else ""
        for run in tf.paragraphs[0].runs:
            _set_dual_font(run)
        for idx, heading in enumerate(headings[1:], start=2):
            p = tf.add_paragraph()
            p.text = f"{idx}. {heading}"
            for run in p.runs:
                _set_dual_font(run)


def _add_content_slide(prs, blank_layout, heading: str, bullets: list[str]) -> None:
    from pptx.util import Emu, Pt
    from pptx.dml.color import RGBColor
    from pptx.enum.text import PP_ALIGN

    slide = prs.slides.add_slide(blank_layout)
    width = prs.slide_width
    height = prs.slide_height
    color = _section_color(heading)

    band_height = Emu(int(height * 0.14))
    band = slide.shapes.add_shape(1, Emu(0), Emu(0), width, band_height)  # 1 = MSO_SHAPE.RECTANGLE
    band.fill.solid()
    band.fill.fore_color.rgb = RGBColor(*color)
    band.line.fill.background()
    band.shadow.inherit = False
    tf = band.text_frame
    tf.margin_left = Emu(int(width * 0.03))
    tf.vertical_anchor = 3  # MSO_ANCHOR.MIDDLE
    p = tf.paragraphs[0]
    p.text = heading
    p.alignment = PP_ALIGN.LEFT
    for run in p.runs:
        _set_dual_font(run, size_pt=22, bold=True, color=(255, 255, 255))

    body_top = Emu(int(height * 0.14) + int(height * 0.06))
    body_box = slide.shapes.add_textbox(
        Emu(int(width * 0.06)), body_top,
        Emu(int(width * 0.88)), Emu(int(height * 0.74)),
    )
    body_tf = body_box.text_frame
    body_tf.word_wrap = True
    for idx, bullet in enumerate(bullets):
        p = body_tf.paragraphs[0] if idx == 0 else body_tf.add_paragraph()
        p.text = f"●  {bullet}"
        p.space_after = Pt(10)
        for run in p.runs:
            _set_dual_font(run, size_pt=16)
            run.font.color.rgb = RGBColor(*color)
        if p.runs:
            marker_len = 2  # "●  "
            text = p.runs[0].text
            if len(text) > marker_len:
                p.runs[0].text = text[:marker_len]
                run2 = p.add_run()
                run2.text = text[marker_len:]
                _set_dual_font(run2, size_pt=16, color=(38, 38, 38))


def _paginate_bullets(bullets: list[str], line_budget: int = 13) -> list[list[str]]:
    """Split long report sections so body copy remains readable on 4:3 slides."""
    pages: list[list[str]] = []
    current: list[str] = []
    used_lines = 0
    for bullet in bullets:
        text = str(bullet).strip()
        estimated_lines = max(1, (len(text) + 54) // 55)
        paragraph_cost = estimated_lines + 1
        if current and used_lines + paragraph_cost > line_budget:
            pages.append(current)
            current = []
            used_lines = 0
        current.append(text)
        used_lines += paragraph_cost
    if current:
        pages.append(current)
    return pages or [["표시할 내용이 없습니다."]]


def build_presentation(report: dict[str, Any], persona_label: str, emphasis_label: str) -> bytes:
    _load_pptx_module()
    from pptx import Presentation

    use_template = COMPANY_TEMPLATE_PATH.exists()
    if use_template:
        prs = Presentation(str(COMPANY_TEMPLATE_PATH))
        cover_slide = prs.slides[0]
        _style_cover_slide(cover_slide, report, persona_label, emphasis_label)
        blank_layout = prs.slide_layouts[6] if len(prs.slide_layouts) > 6 else prs.slide_layouts[-1]
    else:
        from pptx.util import Inches
        prs = Presentation()
        prs.slide_width = Inches(13.333)
        prs.slide_height = Inches(7.5)
        blank_layout = prs.slide_layouts[6]
        title_slide = prs.slides.add_slide(prs.slide_layouts[0])
        title_slide.shapes.title.text = report.get("title", "주간보고")
        if len(title_slide.placeholders) > 1:
            title_slide.placeholders[1].text = f"{persona_label} 보고 · 강조점: {emphasis_label}"
        for shape in title_slide.shapes:
            if shape.has_text_frame and shape == title_slide.shapes.title:
                for paragraph in shape.text_frame.paragraphs:
                    for run in paragraph.runs:
                        _set_dual_font(run, bold=True, color=NAVY)

    summary = report.get("summary", "").strip()
    if summary:
        for page_index, bullets in enumerate(_paginate_bullets([summary])):
            heading = "요약" if page_index == 0 else "요약 (계속)"
            _add_content_slide(prs, blank_layout, heading, bullets)

    for section in report.get("sections", []):
        section_heading = section.get("heading", "")
        for page_index, bullets in enumerate(_paginate_bullets(section.get("bullets", []))):
            heading = section_heading if page_index == 0 else f"{section_heading} (계속)"
            _add_content_slide(prs, blank_layout, heading, bullets)

    flagged = report.get("flagged_terms", [])
    if flagged:
        _add_content_slide(prs, blank_layout, "참고: 순화 처리된 표현", [", ".join(flagged)])

    buffer = io.BytesIO()
    prs.save(buffer)
    return buffer.getvalue()
