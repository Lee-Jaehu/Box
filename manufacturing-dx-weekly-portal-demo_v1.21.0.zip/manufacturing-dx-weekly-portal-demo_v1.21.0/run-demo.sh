#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
python3 -c "import pptx" >/dev/null 2>&1 || python3 -m pip install --quiet -r requirements.txt || \
  echo "[WARN] python-pptx install failed - PPT download will not work until requirements.txt is installed."
python3 server.py --open
