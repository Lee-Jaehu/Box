# Windows 빠른 실행·오류 확인

## 가장 쉬운 실행

1. ZIP 파일을 마우스 오른쪽 버튼으로 눌러 `모두 압축 풀기`를 선택합니다.
2. 압축을 푼 폴더에서 `run-demo.bat`을 더블클릭합니다.
3. 검은 실행 창은 시연이 끝날 때까지 닫지 않습니다.
4. 브라우저가 자동으로 열리지 않으면 검은 창에 표시된 주소를 입력합니다.

서버가 정상 실행되면 다음과 같이 표시됩니다.

```text
Manufacturing DX Weekly Portal demo: http://127.0.0.1:8080
Press Ctrl+C to stop.
```

8080 포트가 사용 중이면 8081~8089 중 다른 주소가 자동으로 표시됩니다.

## Python이 없거나 BAT가 차단될 때

`web` 폴더의 `index.html`을 더블클릭합니다.

- 서버 설치 없이 실행됩니다.
- 8개 역할과 55개 화면을 모두 확인할 수 있습니다.
- AI 초안·Q&A·검증·승인 상태전환은 오프라인 샘플 데이터로 동작합니다.
- 실제 SQLite DB를 갱신하지는 않습니다.

## 실제 업무 Agent와 연결할 때

`run-demo.bat`은 오른쪽에 `DEMO` 상태가 표시되며 실제 모델을 호출하지 않습니다. 승인된 회사 LLM Endpoint가 있다면 CMD에서 다음 환경변수를 설정한 뒤 `run-live-agent.bat`을 실행합니다.

```bat
set WORK_AGENT_API_URL=https://사내승인엔드포인트/v1/chat/completions
set WORK_AGENT_API_KEY=서버용인증정보
set WORK_AGENT_MODEL=승인된모델배포명
set WORK_AGENT_PROVIDER=openai_compatible
run-live-agent.bat
```

정상 연결이면 오른쪽 업무 Agent 제목 옆에 `LIVE · 모델명`이 표시됩니다. `연결 필요`가 보이면 [WORK_AGENT_SETUP.md](WORK_AGENT_SETUP.md)를 확인하십시오.

## 접속 주소가 열리지 않는 이유

`http://127.0.0.1:8080`은 BAT의 검은 창에서 서버가 실행 중일 때만 유효합니다. BAT가 오류로 종료됐거나 검은 창을 닫으면 브라우저에서 연결할 수 없습니다.

## 추가 확인

- ZIP 내부에서 BAT를 직접 실행하지 않았는지 확인합니다.
- 회사 보안 프로그램이 Python 실행을 차단했는지 확인합니다.
- BAT 창에 표시된 주소가 8080이 아닌 다른 포트인지 확인합니다.
- 문제가 계속되면 BAT 창의 오류 문구를 캡처하여 전달합니다.
