"use strict";

/* Offline fixture used when index.html is opened directly or the local server is unavailable. */
(function () {
  const clone = (value) => JSON.parse(JSON.stringify(value));
  const screen = (screen_id, role_code, display_order, title, kind, purpose, primary_action) => ({
    screen_id, role_code, display_order, title, kind, purpose, primary_action,
    ai_function: "업무 맥락·근거를 기준으로 요약·추천·검사 결과를 설명한다.",
    main_data: "Role Scope, Reporting Cycle, WorkItem, Snapshot, Evidence, Report Version",
    control_rule: "사람 확인, 권한 범위, 원문 보존, 수치·출처 검증을 적용한다.",
    done_condition: `${title} 처리 결과와 감사 이력을 저장한다.`,
  });

  const screens = [
    screen("COM-01", "COMMON", 1, "SSO 로그인", "login", "회사 계정으로 인증하고 Portal Principal을 생성한다.", "회사 계정으로 로그인"),
    screen("COM-02", "COMMON", 2, "역할·조직 선택", "context", "복수 역할 사용자가 현재 업무 범위를 선택한다.", "선택 범위로 시작"),
    screen("COM-03", "COMMON", 3, "통합 업무함", "inbox", "제출·검토·승인·오류를 한곳에서 확인한다.", "선택 업무 처리"),
    screen("COM-04", "COMMON", 4, "통합 검색", "search", "권한 범위의 업무·보고·KPI·근거를 찾는다.", "검색 결과 열기"),
    screen("COM-05", "COMMON", 5, "알림·마감", "notifications", "마감·반려·정정·Action 지연을 확인한다.", "관련 화면 이동"),

    screen("MBR-01", "MEMBER", 1, "팀원 홈", "dashboard", "이번 주 기록·제출상태와 우선업무를 본다.", "금주 업무 작성"),
    screen("MBR-02", "MEMBER", 2, "내 WorkItem 목록", "worklist", "담당업무 목표·상태·KPI·협업을 관리한다.", "WorkItem 생성"),
    screen("MBR-03", "MEMBER", 3, "WorkItem 상세", "detail", "업무 목표·이력·KPI·협업·Action을 본다.", "상태·계획 수정"),
    screen("MBR-04", "MEMBER", 4, "Worklog 빠른 기록", "entry", "사실·결과·분석·계획·Risk를 기록한다.", "기록 저장"),
    screen("MBR-05", "MEMBER", 5, "Evidence 업로드", "uploadEvidence", "업무파일을 증빙으로 등록한다.", "파일 업로드"),
    screen("MBR-06", "MEMBER", 6, "업무페이지 선택", "selection", "법인·공정·프로젝트별 주간보고 페이지를 선택한다.", "선택 페이지로 초안 생성"),
    screen("MBR-07", "MEMBER", 7, "업무페이지 AI 초안 편집", "memberEditor", "최근 4주 이력과 금주 변경이 합쳐진 업무페이지를 검토한다.", "페이지 초안 생성·확정"),
    screen("MBR-08", "MEMBER", 8, "제출·반려 이력", "submission", "팀장 제출과 반려·재제출 Version을 관리한다.", "팀장에게 제출"),

    screen("LDR-01", "LEADER", 1, "팀장 홈", "dashboard", "팀 제출률·KPI·미검토·마감을 확인한다.", "팀 보고 시작"),
    screen("LDR-02", "LEADER", 2, "팀원 제출 현황", "submissionMatrix", "팀원별 제출·반려·미제출 상태를 관리한다.", "제출본 열기"),
    screen("LDR-03", "LEADER", 3, "팀원 제출 상세", "memberDetail", "팀원 원문·AI초안·Evidence·Snapshot을 검토한다.", "포함 또는 반려"),
    screen("LDR-04", "LEADER", 4, "업무페이지 포함·제외", "selectionLeader", "팀보고에 사용할 업무페이지를 선별한다.", "페이지 선택 확정"),
    screen("LDR-05", "LEADER", 5, "팀장 서술형 보고", "leaderEditor", "서술형 설명을 유지하고 ID·근거·상태를 보강한다.", "담당에게 승인 제출"),
    screen("LDR-06", "LEADER", 6, "KPI·근거 대조", "compareEvidence", "보고문장과 Snapshot·Evidence를 대조한다.", "검증결과 반영"),
    screen("LDR-07", "LEADER", 7, "반려·승인 확인", "approve", "반려 또는 담당제출 상태변경을 확인한다.", "반려 또는 승인 제출"),
    screen("LDR-08", "LEADER", 8, "팀 보고 Version 이력", "history", "AI·팀장수정·승인본을 비교한다.", "Version 비교"),

    screen("DPT-01", "DEPT", 1, "담당 홈", "dashboard", "팀별 승인상태·성과·KPI·Risk를 본다.", "담당 보고 시작"),
    screen("DPT-02", "DEPT", 2, "팀 보고 Matrix", "teamMatrix", "하위 팀보고를 비교한다.", "팀 보고 상세 열기"),
    screen("DPT-03", "DEPT", 3, "협업 안건 묶음", "collaboration", "같은 Collaboration과 팀별 기여를 묶는다.", "묶음 확정"),
    screen("DPT-04", "DEPT", 4, "KPI·주장 충돌", "conflict", "Snapshot Version과 해석충돌을 조정한다.", "해결방식 기록"),
    screen("DPT-05", "DEPT", 5, "담당 보고 초안", "deptEditor", "담당 관점의 결과·병목·요청으로 재구성한다.", "담당본 확정"),
    screen("DPT-06", "DEPT", 6, "Risk·Decision Register", "decisionRegister", "담당 Risk·Decision·Action을 관리한다.", "Decision 요청 등록"),
    screen("DPT-07", "DEPT", 7, "기획 제출·승인 이력", "approve", "기획제출 전 QA와 이력을 확인한다.", "기획팀에 승인 제출"),

    screen("PLN-01", "PLANNING", 1, "그룹 보고 준비현황", "dashboard", "4개 담당 승인·보완·지연상태를 본다.", "QA 시작"),
    screen("PLN-02", "PLANNING", 2, "QA Issue 목록", "qa", "KPI·출처·협업·잠정·보안·Action을 점검한다.", "Issue 해소 요청"),
    screen("PLN-03", "PLANNING", 3, "그룹 보고 구성", "groupEditor", "그룹장 관점의 KPI·성과·병목·Decision으로 구성한다.", "그룹 초안 확정"),
    screen("PLN-04", "PLANNING", 4, "민감정보·외부공유", "redaction", "보고대상에 맞게 민감정보 제외후보를 검토한다.", "제외안 적용"),
    screen("PLN-05", "PLANNING", 5, "Decision·Action 통합", "decisionRegister", "Decision과 미종결 Action을 정리한다.", "그룹장 요청 확정"),
    screen("PLN-06", "PLANNING", 6, "그룹장 보고 확정", "approve", "QA결과와 예외를 확인해 그룹장보고를 확정한다.", "그룹장 보고 확정 요청"),
    screen("PLN-07", "PLANNING", 7, "보고 이력·Export", "export", "주차별 확정본과 산출물을 관리한다.", "확정본 Export"),

    screen("HED-01", "HEAD", 1, "그룹장 Overview", "dashboard", "그룹 KPI·대표성과·Risk·Decision을 본다.", "담당 상세 확인"),
    screen("HED-02", "HEAD", 2, "담당별 Drill-down", "memberDetail", "4개 담당성과와 팀기여를 내려본다.", "업무 근거 열기"),
    screen("HED-03", "HEAD", 3, "문장·수치 근거", "evidence", "보고문장을 원천까지 추적한다.", "원문 위치 확인"),
    screen("HED-04", "HEAD", 4, "보고 Q&A Agent", "question", "자연어 질문에 승인 근거로 답한다.", "근거 기반 질문"),
    screen("HED-05", "HEAD", 5, "Decision 확정", "decision", "의사결정을 검토하고 Action으로 연결한다.", "결정·Action 확정"),
    screen("HED-06", "HEAD", 6, "Action·주차 Trend", "trend", "Action 이행과 KPI 주차변화를 추적한다.", "지연 Action 점검"),

    screen("DAT-01", "DATA_OWNER", 1, "Snapshot 운영현황", "dashboard", "Metric별 업로드·검증·승인상태를 본다.", "새 Snapshot 업로드"),
    screen("DAT-02", "DATA_OWNER", 2, "KPI 파일 업로드", "snapshotUpload", "기준일 원천파일을 업로드한다.", "파일 업로드 완료"),
    screen("DAT-03", "DATA_OWNER", 3, "컬럼·차원 매핑", "mapping", "컬럼을 Metric·공장·라인·제품과 매핑한다.", "매핑 저장·검증"),
    screen("DAT-04", "DATA_OWNER", 4, "Validation 결과", "validation", "중복·누락·단위·급변오류를 처리한다.", "재검증"),
    screen("DAT-05", "DATA_OWNER", 5, "전주·정정 비교", "snapshotCompare", "현재와 이전 Snapshot을 비교한다.", "변동 사유 기록"),
    screen("DAT-06", "DATA_OWNER", 6, "승인·잠금", "snapshotApprove", "공식 Snapshot을 최종승인한다.", "Snapshot 승인·잠금"),
    screen("DAT-07", "DATA_OWNER", 7, "Metric Catalog", "catalog", "KPI 공식정의와 파일계약을 관리한다.", "Metric 정의 저장"),

    screen("ADM-01", "ADMIN", 1, "운영 Dashboard", "dashboard", "사용현황·오류·마감·연동상태를 본다.", "운영 이슈 열기"),
    screen("ADM-02", "ADMIN", 2, "조직·사용자·역할", "iam", "조직계층과 역할·대리권한을 관리한다.", "권한 변경 요청"),
    screen("ADM-03", "ADMIN", 3, "보고 Calendar", "calendar", "단계별 마감과 휴일예외를 설정한다.", "보고주차 개시"),
    screen("ADM-04", "ADMIN", 4, "Template·Prompt·Model", "release", "양식과 Prompt·Model을 평가 후 배포한다.", "승인 Version 배포"),
    screen("ADM-05", "ADMIN", 5, "권한·보안 Policy", "policy", "권한정책과 Agent Tool Allowlist를 관리한다.", "정책 변경 검토"),
    screen("ADM-06", "ADMIN", 6, "Audit Log", "audit", "조회·AI·제출·승인·권한변경을 추적한다.", "감사 이벤트 조회"),
    screen("ADM-07", "ADMIN", 7, "System Health·Feature Flag", "health", "Portal·DB·LLM·Copilot 상태를 관리한다.", "기능 Flag 변경"),
  ];

  const principals = {
    COMMON: ["u_member1", "김현수", "공통 사용자", "RSND자동보정팀"],
    MEMBER: ["u_member1", "김현수", "팀원", "RSND자동보정팀"],
    LEADER: ["u_leader", "이선우", "팀장", "RSND자동보정팀"],
    DEPT: ["u_dept", "김도윤", "담당", "자동보정담당"],
    PLANNING: ["u_planning", "최은서", "기획팀", "제조DX기획팀"],
    HEAD: ["u_head", "그룹장 사용자", "그룹장", "제조DX그룹"],
    DATA_OWNER: ["u_data", "데이터 운영자", "KPI Data Owner", "품질DX담당"],
    ADMIN: ["u_admin", "시스템 운영자", "운영자", "제조DX기획팀"],
  };

  const initial = {
    cycle: {
      id: "cycle_w34", cycle_code: "2026-W34", year: 2026, week: 34, state: "OPEN",
      snapshot_due_at: "2026-08-24T10:00:00+09:00", member_due_at: "2026-08-25T17:00:00+09:00",
      leader_due_at: "2026-08-26T12:00:00+09:00", department_due_at: "2026-08-26T17:00:00+09:00",
      planning_due_at: "2026-08-27T12:00:00+09:00",
    },
    snapshots: [
      { id: "snp_yield_w34", snapshot_code: "SNP-YIELD-2026-W34-003", metric_code: "YIELD_RATE", metric_name: "수율", unit: "%", display_value: 92.4, previous_value: 91.8, target_value: 94.0, cutoff_at: "2026-08-23T23:59:00+09:00", status: "LOCKED", verification_state: "VERIFIED", source_file: "Yield_2026W34_0823.xlsx", version: 3, validation_errors: 0, validation_warnings: 0 },
      { id: "snp_bm_w34", snapshot_code: "SNP-BM-2026-W34-002", metric_code: "BM_LOSS", metric_name: "BM Loss", unit: "%", display_value: 6.8, previous_value: 7.0, target_value: 6.0, cutoff_at: "2026-08-23T23:59:00+09:00", status: "LOCKED", verification_state: "VERIFIED", source_file: "BM_Loss_2026W34_0823.xlsx", version: 2, validation_errors: 0, validation_warnings: 0 },
      { id: "snp_pd_w34", snapshot_code: "SNP-PD-2026-W34-004", metric_code: "PD_LOSS", metric_name: "PD Loss", unit: "%", display_value: 1.2, previous_value: 1.5, target_value: 1.0, cutoff_at: "2026-08-23T23:59:00+09:00", status: "VALIDATION_FAILED", verification_state: "PROVISIONAL", source_file: "PD_Loss_2026W34_0823.xlsx", version: 4, validation_errors: 1, validation_warnings: 1 },
      { id: "snp_defect_w34", snapshot_code: "SNP-DEFECT-2026-W34-002", metric_code: "DEFECT_RATE", metric_name: "불량률", unit: "%", display_value: 0.7, previous_value: 0.8, target_value: 0.6, cutoff_at: "2026-08-23T23:59:00+09:00", status: "LOCKED", verification_state: "VERIFIED", source_file: "Defect_2026W34_0823.xlsx", version: 2, validation_errors: 0, validation_warnings: 0 },
    ],
    work_items: [
      { id: "wi_rsnd_32", work_item_code: "WI-RSND-2026-0032", organization_id: "team_rsnd", owner_user_id: "u_member1", collaboration_id: "col_yield", collaboration_code: "COL-YIELD-2026-0014", organization_name: "RSND자동보정팀", owner_name: "김현수", title: "Lami Jamming 자동보정 조건 검증", objective: "제품별 적용 조건과 예외조건 확정", state: "IN_PROGRESS", start_date: "2026-08-03", target_date: "2026-08-27", metric_code: "PD_LOSS", security_label: "CONFIDENTIAL" },
      { id: "wi_rsnd_38", work_item_code: "WI-RSND-2026-0038", organization_id: "team_rsnd", owner_user_id: "u_member2", collaboration_id: "col_yield", collaboration_code: "COL-YIELD-2026-0014", organization_name: "RSND자동보정팀", owner_name: "박은지", title: "ESWA L07 PD Loss 개선 로직 적용", objective: "동일 조건 반복 검증 후 효과 확정", state: "IN_PROGRESS", start_date: "2026-08-10", target_date: "2026-08-28", metric_code: "PD_LOSS", security_label: "CONFIDENTIAL" },
      { id: "wi_rsnd_41", work_item_code: "WI-RSND-2026-0041", organization_id: "team_rsnd", owner_user_id: "u_member3", collaboration_id: "col_yield", collaboration_code: "COL-YIELD-2026-0014", organization_name: "RSND자동보정팀", owner_name: "이정훈", title: "FDC 진단 결과 연계", objective: "장력 편차와 Jamming 발생시점 연계 검증", state: "IN_PROGRESS", start_date: "2026-08-17", target_date: "2026-08-31", metric_code: "PD_LOSS", security_label: "CONFIDENTIAL" },
      { id: "wi_rsnd_45", work_item_code: "WI-RSND-2026-0045", organization_id: "team_rsnd", owner_user_id: "u_member1", collaboration_id: null, collaboration_code: null, organization_name: "RSND자동보정팀", owner_name: "김현수", title: "차주 자동보정 조건 사전 검토", objective: "W35 적용 후보 검토", state: "PLANNED", start_date: "2026-08-24", target_date: "2026-09-04", metric_code: "PD_LOSS", security_label: "INTERNAL" },
      { id: "wi_rsnd_48", work_item_code: "WI-RSND-2026-0048", organization_id: "team_rsnd", owner_user_id: "u_member1", collaboration_id: "col_yield", collaboration_code: "COL-YIELD-2026-0014", organization_name: "RSND자동보정팀", owner_name: "김현수", title: "로딩량 연계 Feedforward 자동보정", objective: "코터 로딩량과 롤프레스 Tension을 연계해 단선 Loss 개선", state: "IN_PROGRESS", start_date: "2026-07-27", target_date: "2026-08-28", metric_code: "PD_LOSS", security_label: "CONFIDENTIAL" },
      { id: "wi_rsnd_52", work_item_code: "WI-RSND-2026-0052", organization_id: "team_rsnd", owner_user_id: "u_member1", collaboration_id: null, collaboration_code: null, organization_name: "RSND자동보정팀", owner_name: "김현수", title: "GM1·2 VM 기반 자동보정 시스템 구축", objective: "RP·NND 기준정보와 VM 제어 모델 구축", state: "IN_PROGRESS", start_date: "2026-07-27", target_date: "2026-11-30", metric_code: "PD_LOSS", security_label: "CONFIDENTIAL" },
      { id: "wi_elc_12", work_item_code: "WI-ELC-2026-0012", organization_id: "team_electrode", owner_user_id: "u_member2", collaboration_id: "col_bm", collaboration_code: "COL-BM-2026-0007", organization_name: "전극자동보정팀", owner_name: "박은지", title: "코터 로딩량 편차 보정 확대", objective: "좌우 편차 보정 대상 확대", state: "IN_PROGRESS", start_date: "2026-08-01", target_date: "2026-08-30", metric_code: "BM_LOSS", security_label: "CONFIDENTIAL" },
      { id: "wi_asm_19", work_item_code: "WI-ASM-2026-0019", organization_id: "team_assembly", owner_user_id: "u_member3", collaboration_id: "col_pd", collaboration_code: "COL-PD-2026-0011", organization_name: "조립자동보정팀", owner_name: "이정훈", title: "주액기 보정 파라미터 적용", objective: "PD Loss 저감 로직 적용", state: "IN_PROGRESS", start_date: "2026-08-05", target_date: "2026-08-29", metric_code: "PD_LOSS", security_label: "CONFIDENTIAL" },
    ],
    work_pages: [
      { id: "pg_tension", page_code: "RPG-RSND-2026-0001", cycle_id: "cycle_w34", organization_id: "team_rsnd", organization_name: "RSND자동보정팀", title: "Tension 편차 자동보정 적용 및 확산", site_scope: "MI_LS · HD · WA", process_scope: "Roll Press", project_scope: "[전사DX_1] PD Loss 개선", objective: "법인별 적용조건 검증과 수평전개", primary_owner_user_id: "u_member1", primary_owner_name: "김현수", contributors: "김현수:PRIMARY,이정훈:COAUTHOR", work_item_ids: "wi_rsnd_32,wi_rsnd_41", retention_weeks: 4, display_order: 1, state: "IN_PROGRESS" },
      { id: "pg_loading", page_code: "RPG-RSND-2026-0002", cycle_id: "cycle_w34", organization_id: "team_rsnd", organization_name: "RSND자동보정팀", title: "로딩량 연계 Feedforward 자동보정", site_scope: "WA", process_scope: "Coater → Roll Press", project_scope: "[전사DX_1] PD Loss 개선", objective: "로딩량 기반 Tension 예측 및 단선 사전보정", primary_owner_user_id: "u_member1", primary_owner_name: "김현수", contributors: "김현수:PRIMARY,박은지:COAUTHOR", work_item_ids: "wi_rsnd_48,wi_rsnd_38", retention_weeks: 4, display_order: 2, state: "IN_PROGRESS" },
      { id: "pg_vm", page_code: "RPG-RSND-2026-0003", cycle_id: "cycle_w34", organization_id: "team_rsnd", organization_name: "RSND자동보정팀", title: "GM1·2 VM 기반 자동보정 시스템 구축", site_scope: "GM1 · GM2", process_scope: "Roll Press · NND", project_scope: "Global 자동보정 수평전개", objective: "VM 기반 수집·제어 환경과 기준정보 표준화", primary_owner_user_id: "u_member1", primary_owner_name: "김현수", contributors: "김현수:PRIMARY,이정훈:COAUTHOR", work_item_ids: "wi_rsnd_52", retention_weeks: 4, display_order: 3, state: "IN_PROGRESS" },
    ],
    worklogs: [
      { id: "wl_tension_w31", work_item_id: "wi_rsnd_32", author_user_id: "u_member1", author_name: "김현수", work_item_code: "WI-RSND-2026-0032", occurred_on: "2026-07-30", entry_type: "BACKGROUND", narrative: "OC(NFF), MI_LS, HD 법인의 Tension 편차 자동보정을 적용하여 Roll Press 단선에 따른 PD Loss를 개선하고자 합니다." },
      { id: "wl_tension_w32", work_item_id: "wi_rsnd_32", author_user_id: "u_member3", author_name: "이정훈", work_item_code: "WI-RSND-2026-0032", occurred_on: "2026-08-06", entry_type: "RESULT", narrative: "MI_LS와 HD 대상 APC 기준정보 등록과 대표호기 자동보정 적용을 완료했습니다." },
      { id: "wl_prev1", work_item_id: "wi_rsnd_32", author_user_id: "u_member1", author_name: "김현수", work_item_code: "WI-RSND-2026-0032", occurred_on: "2026-08-13", entry_type: "RESULT", narrative: "ESWA L07 대상 제품별 Jamming 자동보정 적용조건 기준안을 수립하고, M08·M11 초기 시험에서 유사 경향을 확인했습니다." },
      { id: "wl_prev2", work_item_id: "wi_rsnd_32", author_user_id: "u_member1", author_name: "김현수", work_item_code: "WI-RSND-2026-0032", occurred_on: "2026-08-14", entry_type: "ANALYSIS", narrative: "제품별 생산조건 차이가 재현성에 영향을 줄 수 있어 K12는 별도 조건으로 검증하기로 했습니다." },
      { id: "wl_prev3", work_item_id: "wi_rsnd_32", author_user_id: "u_member1", author_name: "김현수", work_item_code: "WI-RSND-2026-0032", occurred_on: "2026-08-14", entry_type: "NEXT", narrative: "K12 생산 일정 확보 후 동일 조건 재현성 검증을 진행하고 제품별 상·하한을 확정할 예정입니다." },
      { id: "wl1", work_item_id: "wi_rsnd_32", author_user_id: "u_member1", author_name: "김현수", work_item_code: "WI-RSND-2026-0032", occurred_on: "2026-08-20", entry_type: "RESULT", narrative: "M08과 M11 제품 반복 시험에서 동일 경향을 확인하였다." },
      { id: "wl2", work_item_id: "wi_rsnd_32", author_user_id: "u_member1", author_name: "김현수", work_item_code: "WI-RSND-2026-0032", occurred_on: "2026-08-21", entry_type: "ANALYSIS", narrative: "K12는 생산 조건이 달라 재현성 검증이 추가로 필요하다." },
      { id: "wl3", work_item_id: "wi_rsnd_32", author_user_id: "u_member1", author_name: "김현수", work_item_code: "WI-RSND-2026-0032", occurred_on: "2026-08-22", entry_type: "NEXT", narrative: "8월 27일까지 K12 재현성 검증 후 적용 여부를 확정한다." },
      { id: "wl4", work_item_id: "wi_rsnd_32", author_user_id: "u_member1", author_name: "김현수", work_item_code: "WI-RSND-2026-0032", occurred_on: "2026-08-23", entry_type: "RISK", narrative: "검증용 생산 일정이 미확정되어 완료 일정이 지연될 수 있다." },
      { id: "wl5", work_item_id: "wi_rsnd_38", author_user_id: "u_member2", author_name: "박은지", work_item_code: "WI-RSND-2026-0038", occurred_on: "2026-08-22", entry_type: "RESULT", narrative: "ESWA L07 적용 구간의 PD Loss 감소 경향을 확인하였다." },
      { id: "wl6", work_item_id: "wi_rsnd_41", author_user_id: "u_member3", author_name: "이정훈", work_item_code: "WI-RSND-2026-0041", occurred_on: "2026-08-23", entry_type: "ANALYSIS", narrative: "FDC 장력 편차 구간과 Jamming 발생 시점의 상관성을 검토 중이다." },
      { id: "wl_loading_w31", work_item_id: "wi_rsnd_48", author_user_id: "u_member1", author_name: "김현수", work_item_code: "WI-RSND-2026-0048", occurred_on: "2026-07-31", entry_type: "BACKGROUND", narrative: "코터 로딩량을 Roll Press 공정에 Feedforward로 연계하여 단선 발생 가능 구간을 사전에 보정하고자 합니다." },
      { id: "wl_loading_w32", work_item_id: "wi_rsnd_48", author_user_id: "u_member2", author_name: "박은지", work_item_code: "WI-RSND-2026-0048", occurred_on: "2026-08-07", entry_type: "RESULT", narrative: "코터 롤맵 PLC와 Roll Press PLC의 데이터 수집 및 하프 슬리팅 방향을 고려한 전처리 프로그램 개발을 완료했습니다." },
      { id: "wl_loading_w33", work_item_id: "wi_rsnd_48", author_user_id: "u_member1", author_name: "김현수", work_item_code: "WI-RSND-2026-0048", occurred_on: "2026-08-14", entry_type: "ANALYSIS", narrative: "로딩량·두께·Moving EPC·Gap을 활용한 Tension 예측모델의 적용 가능성을 확인하고 법인과 분석 기준을 협의했습니다." },
      { id: "wl_loading_w34", work_item_id: "wi_rsnd_48", author_user_id: "u_member1", author_name: "김현수", work_item_code: "WI-RSND-2026-0048", occurred_on: "2026-08-21", entry_type: "NEXT", narrative: "8월 28일까지 Tension 예측값을 활용한 Feedforward 자동보정 로직과 설비별 기준정보를 확정하겠습니다." },
      { id: "wl_vm_w31", work_item_id: "wi_rsnd_52", author_user_id: "u_member1", author_name: "김현수", work_item_code: "WI-RSND-2026-0052", occurred_on: "2026-07-28", entry_type: "BACKGROUND", narrative: "GM1·2의 자동보정 고도화와 수평전개를 위해 VM 서버 기반 자동보정 시스템 구축이 필요합니다." },
      { id: "wl_vm_w32", work_item_id: "wi_rsnd_52", author_user_id: "u_member3", author_name: "이정훈", work_item_code: "WI-RSND-2026-0052", occurred_on: "2026-08-05", entry_type: "RESULT", narrative: "GM1·2 제조역량강화팀, 공정DX와 데이터 수집·제어 파라미터 범위를 협의했습니다." },
      { id: "wl_vm_w33", work_item_id: "wi_rsnd_52", author_user_id: "u_member1", author_name: "김현수", work_item_code: "WI-RSND-2026-0052", occurred_on: "2026-08-12", entry_type: "RESULT", narrative: "RP와 NND 기준정보 표준화 및 작성 완료 후 VM 제작사양서 초안을 작성했습니다." },
      { id: "wl_vm_w34", work_item_id: "wi_rsnd_52", author_user_id: "u_member3", author_name: "이정훈", work_item_code: "WI-RSND-2026-0052", occurred_on: "2026-08-20", entry_type: "NEXT", narrative: "8월 28일까지 VM·응용 환경 설정 범위와 RP·NND 제작사양서를 확정하고 데이터 수집 일정을 연결하겠습니다." },
    ],
    evidence: [
      { id: "ev1", evidence_code: "EVD-RSND-2026-W34-028", work_item_id: "wi_rsnd_32", work_item_code: "WI-RSND-2026-0032", file_name: "Jamming_보정조건_검증표.xlsx", content_type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", sha256: "1111111111111111111111111111111111111111111111111111111111111111", locator: "Result!B4:H18", scan_status: "CLEAN", security_label: "CONFIDENTIAL" },
      { id: "ev2", evidence_code: "EVD-RSND-2026-W34-029", work_item_id: "wi_rsnd_32", work_item_code: "WI-RSND-2026-0032", file_name: "K12_시험조건_비교.pdf", content_type: "application/pdf", sha256: "2222222222222222222222222222222222222222222222222222222222222222", locator: "p.3-5", scan_status: "CLEAN", security_label: "CONFIDENTIAL" },
      { id: "ev3", evidence_code: "EVD-RSND-2026-W34-031", work_item_id: "wi_rsnd_38", work_item_code: "WI-RSND-2026-0038", file_name: "ESWA_L07_적용결과.xlsx", content_type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", sha256: "3333333333333333333333333333333333333333333333333333333333333333", locator: "Result!B4:H18", scan_status: "CLEAN", security_label: "CONFIDENTIAL" },
      { id: "ev4", evidence_code: "EVD-RSND-2026-W34-033", work_item_id: "wi_rsnd_41", work_item_code: "WI-RSND-2026-0041", file_name: "FDC_장력편차_연계.csv", content_type: "text/csv", sha256: "4444444444444444444444444444444444444444444444444444444444444444", locator: "rows 21-44", scan_status: "CLEAN", security_label: "CONFIDENTIAL" },
    ],
    submissions: [
      { id: "sub_member1", submission_code: "SUB-RSND-2026-W34-001", member_user_id: "u_member1", member_name: "김현수", organization_name: "RSND자동보정팀", status: "AI_DRAFTED", version: 2, submitted_at: null },
      { id: "sub_member2", submission_code: "SUB-RSND-2026-W34-002", member_user_id: "u_member2", member_name: "박은지", organization_name: "RSND자동보정팀", status: "SUBMITTED", version: 1, submitted_at: "2026-08-24T09:20:00+09:00" },
      { id: "sub_member3", submission_code: "SUB-RSND-2026-W34-003", member_user_id: "u_member3", member_name: "이정훈", organization_name: "RSND자동보정팀", status: "SUBMITTED", version: 1, submitted_at: "2026-08-24T09:32:00+09:00" },
    ],
    submission_items: [
      { submission_id: "sub_member1", work_item_id: "wi_rsnd_32", included: 1, inclusion_reason: "금주 검증 결과 존재", work_item_code: "WI-RSND-2026-0032", title: "Lami Jamming 자동보정 조건 검증" },
      { submission_id: "sub_member1", work_item_id: "wi_rsnd_45", included: 0, inclusion_reason: "금주 수행 결과 없음", work_item_code: "WI-RSND-2026-0045", title: "차주 자동보정 조건 사전 검토" },
      { submission_id: "sub_member1", work_item_id: "wi_rsnd_48", included: 1, inclusion_reason: "업무페이지 연결", work_item_code: "WI-RSND-2026-0048", title: "로딩량 연계 Feedforward 자동보정" },
      { submission_id: "sub_member1", work_item_id: "wi_rsnd_52", included: 1, inclusion_reason: "업무페이지 연결", work_item_code: "WI-RSND-2026-0052", title: "GM1·2 VM 기반 자동보정 시스템 구축" },
      { submission_id: "sub_member2", work_item_id: "wi_rsnd_38", included: 1, inclusion_reason: "KPI와 Evidence 연결", work_item_code: "WI-RSND-2026-0038", title: "ESWA L07 PD Loss 개선 로직 적용" },
      { submission_id: "sub_member3", work_item_id: "wi_rsnd_41", included: 1, inclusion_reason: "협업 분석 진행", work_item_code: "WI-RSND-2026-0041", title: "FDC 진단 결과 연계" },
    ],
    submission_pages: [
      { submission_id: "sub_member1", work_page_id: "pg_tension", included: 1, inclusion_reason: "4주 이력과 금주 변경 존재", page_code: "RPG-RSND-2026-0001", title: "Tension 편차 자동보정 적용 및 확산", site_scope: "MI_LS · HD · WA", process_scope: "Roll Press", primary_owner_name: "김현수" },
      { submission_id: "sub_member1", work_page_id: "pg_loading", included: 1, inclusion_reason: "공동작성 페이지·금주 계획 존재", page_code: "RPG-RSND-2026-0002", title: "로딩량 연계 Feedforward 자동보정", site_scope: "WA", process_scope: "Coater → Roll Press", primary_owner_name: "김현수" },
      { submission_id: "sub_member1", work_page_id: "pg_vm", included: 1, inclusion_reason: "프로젝트 진행사항·금주 계획 존재", page_code: "RPG-RSND-2026-0003", title: "GM1·2 VM 기반 자동보정 시스템 구축", site_scope: "GM1 · GM2", process_scope: "Roll Press · NND", primary_owner_name: "김현수" },
    ],
    submission_versions: [
      { id: "sv_member1_2", submission_id: "sub_member1", version_number: 2, content: "[WI-RSND-2026-0032][RESULT] 1. Lami Jamming 자동보정 조건 검증\nESWA L07 대상 제품별 Jamming 자동보정 적용조건 기준안을 수립하고, M08·M11 초기 시험에서 유사 경향을 확인했습니다.\n\n[COL-YIELD-2026-0014][ANALYSIS] 제품별 생산조건 차이가 재현성에 영향을 줄 수 있어 K12는 별도 조건으로 검증하기로 했습니다.\n\n[WI-RSND-2026-0032][PLAN] K12 생산 일정 확보 후 동일 조건 재현성 검증을 진행하고 제품별 상·하한을 확정할 예정입니다.\n\n[SNP-PD-2026-W34-004][KPI][PROVISIONAL][NEW] W34 PD Loss는 1.2%로 전주 1.5% 대비 0.3%p 감소했습니다. 다만 현재 Snapshot은 Data Owner 승인 전 잠정값이므로 자동보정 단독 효과로 확정하지 않았습니다.\n\n[WI-RSND-2026-0032][RESULT][NEW] 금주 추가\nM08과 M11 제품 반복 시험에서 동일 경향을 확인했습니다. [EVD-RSND-2026-W34-028] [EVD-RSND-2026-W34-029]\n\n[COL-YIELD-2026-0014][ANALYSIS][NEW] K12는 생산 조건이 달라 재현성 검증이 추가로 필요합니다.\n\n[WI-RSND-2026-0032][RISK][NEW] 검증용 생산 일정이 미확정되어 완료 일정이 지연될 수 있습니다.\n\n[WI-RSND-2026-0032][PLAN][NEW] 8월 27일까지 K12 재현성 검증 후 적용 여부를 확정하고 제품별 상·하한 및 예외조건을 정리하겠습니다.\n\n[DEC-RSND-2026-0008][DECISION][NEW] K12 검증 생산 일정 우선 배정이 필요합니다.", source_manifest: "WI-RSND-2026-0032,SNP-PD-2026-W34-004,EVD-RSND-2026-W34-028,EVD-RSND-2026-W34-029,COL-YIELD-2026-0014,DEC-RSND-2026-0008", generated_by: "MEMBER_AGENT", created_at: "2026-08-24T09:10:00+09:00" },
      { id: "sv_member2_1", submission_id: "sub_member2", version_number: 1, content: "[WI-RSND-2026-0038][RESULT] ESWA L07 자동보정 적용 구간에서 PD Loss 감소 경향을 확인했습니다. 현재 단기 결과이므로 적용 전후 생산량과 제품 Mix를 동일 기준으로 재정렬하여 효과를 검증하고 있습니다. [EVD-RSND-2026-W34-031]\n\n[WI-RSND-2026-0038][PLAN] 8월 28일까지 동일 조건 반복 검증을 완료하고 장기간 효과 산출 범위를 확정하겠습니다.", source_manifest: "WI-RSND-2026-0038,EVD-RSND-2026-W34-031,SNP-PD-2026-W34-004", generated_by: "MEMBER", created_at: "2026-08-24T09:20:00+09:00" },
      { id: "sv_member3_1", submission_id: "sub_member3", version_number: 1, content: "[WI-RSND-2026-0041][ANALYSIS] FDC 장력 편차 구간과 Jamming 발생 시점의 상관성을 공동 검토 중입니다. 현재 일부 구간에서 방향성은 확인했으나 원인으로 확정할 수준은 아니며, Roll·제품·설비조건을 분리한 추가 분석이 필요합니다. [EVD-RSND-2026-W34-033]\n\n[COL-YIELD-2026-0014][PLAN] 8월 31일까지 FDC 이상구간과 자동보정 동작이력을 동일 시간축으로 정렬하여 공동 검증하겠습니다.", source_manifest: "WI-RSND-2026-0041,EVD-RSND-2026-W34-033,COL-YIELD-2026-0014", generated_by: "MEMBER", created_at: "2026-08-24T09:32:00+09:00" },
    ],
    reports: [
      { id: "rpt_team", report_code: "RPT-TEAM-RSND-2026-W34", report_level: "TEAM", organization_name: "RSND자동보정팀", status: "DRAFT", current_version: 1, content: "[SNP-PD-2026-W34-004][KPI][PROVISIONAL] RSND자동보정팀은 W34 PD Loss 1.2%로 전주 1.5% 대비 0.3%p 감소한 수준을 확인했습니다. 다만 현재 값은 Data Owner 승인 전 잠정 Snapshot이며, 자동보정 적용 전후의 생산량과 제품 Mix가 동일하지 않아 팀 단독 개선효과로 확정하지 않았습니다.\n\n[WI-RSND-2026-0032][RESULT] 1. Lami Jamming 자동보정 조건 검증\nESWA L07 제품 3종을 대상으로 보정조건을 검증했습니다. M08과 M11은 반복 시험에서 동일 경향을 확인했고, K12는 생산 조건 차이로 재현성 검증이 추가로 필요합니다. 기존 계획보다 검증 범위를 제품별 예외조건까지 확대하여 상·하한 기준을 함께 정리하고 있습니다. [EVD-RSND-2026-W34-028]\n\n[WI-RSND-2026-0038][RESULT] 2. PD Loss 개선 로직 적용\nESWA L07 자동보정 적용 구간에서 PD Loss 감소 경향을 확인했습니다. 단기 결과만으로 효과를 판단하지 않기 위해 적용 전후 생산량과 제품 Mix를 동일 기준으로 재정렬하고 있으며, 8월 28일까지 반복 검증 후 장기간 효과 산출 범위를 확정할 예정입니다. [EVD-RSND-2026-W34-031]\n\n[COL-YIELD-2026-0014][ANALYSIS] 3. FDC 진단 결과 연계\nFDC에서 제공한 장력 편차 구간과 Jamming 발생 시점을 동일 시간축으로 정렬하여 상관성을 검토하고 있습니다. 일부 구간에서 방향성은 확인했으나 현재 단계에서는 원인으로 확정하지 않았으며, Roll·제품·설비조건을 분리한 추가 분석이 필요합니다. [EVD-RSND-2026-W34-033]\n\n[WI-RSND-2026-0032][RISK] K12 검증용 생산 일정이 미확정되어 제품별 적용조건 확정이 지연될 수 있습니다. 생산 일정이 W35 이후로 밀릴 경우 금주 확인한 M08·M11 결과만으로 수평전개 여부를 판단하지 않고 K12 검증 완료 후 최종 판단하겠습니다.\n\n[WI-RSND-2026-0032][PLAN] W35에는 K12 재현성 검증과 제품별 상·하한 및 예외조건 확정을 우선 진행하겠습니다. 동시에 FDC 이상구간과 자동보정 동작이력을 결합하여 원인 후보를 축소하고, 동일 조건의 적용 전후 PD Loss를 재산출하겠습니다.\n\n[DEC-RSND-2026-0008][DECISION] K12 검증 생산 일정 우선 배정이 필요합니다.", source_manifest: "WI-RSND-2026-0032,WI-RSND-2026-0038,WI-RSND-2026-0041,SNP-PD-2026-W34-004,EVD-RSND-2026-W34-028,EVD-RSND-2026-W34-031,EVD-RSND-2026-W34-033,COL-YIELD-2026-0014,DEC-RSND-2026-0008" },
      { id: "rpt_dept", report_code: "RPT-DEPT-AUTO-2026-W34", report_level: "DEPARTMENT", organization_name: "자동보정담당", status: "DRAFT", current_version: 1, content: "자동보정담당은 Jamming 보정 조건과 코터 로딩량 편차, 주액기 파라미터 적용을 추진하였다. 협업 안건은 COL-YIELD-2026-0014 등 3개로 묶어 관리한다.", source_manifest: "RPT-TEAM-RSND-2026-W34,COL-YIELD-2026-0014" },
      { id: "rpt_group", report_code: "RPT-GROUP-DX-2026-W34", report_level: "GROUP", organization_name: "제조DX그룹", status: "PLANNING_QA", current_version: 1, content: "W34 수율은 92.4%, BM Loss는 6.8%, PD Loss는 1.2% 잠정이다. 자동보정 Jamming 조건은 3개 제품 중 2개 검증을 완료했으며 K12 생산 일정 결정이 필요하다.", source_manifest: "SNP-YIELD-2026-W34-003,SNP-BM-2026-W34-002,SNP-PD-2026-W34-004,DEC-RSND-2026-0008" },
    ],
    collaborations: [
      { id: "col_yield", collaboration_code: "COL-YIELD-2026-0014", title: "Lami Jamming 공동 대응", goal: "FDC 이상감지부터 자동보정·품질검증·추적까지 연결", lead_organization: "FDC DX담당", status: "ACTIVE", target_date: "2026-08-31" },
      { id: "col_bm", collaboration_code: "COL-BM-2026-0007", title: "설비 BM Loss 공동 개선", goal: "상태감지와 보정조건을 연계하여 BM Loss 감소", lead_organization: "FDC DX담당", status: "ACTIVE", target_date: "2026-09-15" },
      { id: "col_pd", collaboration_code: "COL-PD-2026-0011", title: "주액기 PD Loss 개선", goal: "PLC 로직과 자동보정 파라미터 공동 검증", lead_organization: "자동보정담당", status: "ACTIVE", target_date: "2026-09-05" },
    ],
    participants: [
      { collaboration_id: "col_yield", organization_name: "FDC DX담당", contribution: "장력 편차 구간 탐지 및 이상시점 제공" },
      { collaboration_id: "col_yield", organization_name: "자동보정담당", contribution: "제품별 보정 상·하한과 예외조건 검증" },
      { collaboration_id: "col_yield", organization_name: "품질DX담당", contribution: "불량 유형과 품질 판정 결과 검증" },
      { collaboration_id: "col_yield", organization_name: "제조DX솔루션담당", contribution: "Roll·Cell·공정 이력 연결" },
      { collaboration_id: "col_bm", organization_name: "FDC DX담당", contribution: "설비 이상패턴 탐지" },
      { collaboration_id: "col_bm", organization_name: "자동보정담당", contribution: "보정 적용 조건 검증" },
      { collaboration_id: "col_pd", organization_name: "자동보정담당", contribution: "주액기 보정 파라미터 적용" },
      { collaboration_id: "col_pd", organization_name: "품질DX담당", contribution: "PD 효과 판정" },
    ],
    qa_issues: [
      { id: "qa1", resource_type: "METRIC_SNAPSHOT", resource_id: "snp_pd_w34", rule_code: "DUPLICATE_KEY", severity: "BLOCK", message: "ESWA L03 K12 W34 Key가 중복되었습니다.", remediation: "원천 파일의 284행과 285행을 확인한 후 재업로드하십시오.", status: "OPEN" },
      { id: "qa2", resource_type: "METRIC_SNAPSHOT", resource_id: "snp_pd_w34", rule_code: "LARGE_CHANGE", severity: "WARN", message: "ESWA L07 M08 PD Loss가 0.8%에서 2.4%로 급변했습니다.", remediation: "Data Owner가 변동 사유를 확인하십시오.", status: "OPEN" },
      { id: "qa3", resource_type: "REPORT", resource_id: "rpt_group", rule_code: "PROVISIONAL_LABEL", severity: "WARN", message: "잠정 PD Loss가 확정값처럼 표현된 문장 2건이 있습니다.", remediation: "PROVISIONAL 상태를 문장에 표시하십시오.", status: "OPEN" },
      { id: "qa4", resource_type: "REPORT", resource_id: "rpt_group", rule_code: "MISSING_EVIDENCE", severity: "BLOCK", message: "활성화자동보정 CTQ 결과의 Evidence가 없습니다.", remediation: "승인 가능한 Evidence를 연결하거나 보고에서 제외하십시오.", status: "OPEN" },
    ],
    decisions: [
      { id: "dec1", decision_code: "DEC-RSND-2026-0008", title: "K12 검증 생산 일정 배정", request: "K12 제품 자동보정 검증을 위한 생산 일정 우선 배정이 필요하다.", status: "REQUESTED", decision_maker: "그룹장 사용자", due_date: "2026-08-25", resolution: null },
      { id: "dec2", decision_code: "DEC-FDC-2026-0005", title: "품질 판정 연계 우선순위", request: "FDC 결과와 품질 판정 연계 일정 확정이 필요하다.", status: "REQUESTED", decision_maker: "그룹장 사용자", due_date: "2026-08-27", resolution: null },
    ],
    action_items: [
      { id: "act1", action_code: "ACT-FDC-2026-0044", title: "품질 판정 결과 연계", owner_name: "이정훈", due_date: "2026-08-27", status: "IN_PROGRESS", priority: "HIGH" },
      { id: "act2", action_code: "ACT-SOL-2026-0031", title: "Trace 누락 구간 보완", owner_name: "박은지", due_date: "2026-08-26", status: "DELAYED", priority: "MEDIUM" },
    ],
    audit_events: [
      { id: 1, occurred_at: "2026-08-24T08:55:00+09:00", trace_id: "TRACE-SEED-001", actor_name: "데이터 운영자", actor_role: "DATA_OWNER", action: "UPLOAD", resource_type: "METRIC_SNAPSHOT", resource_id: "snp_pd_w34", result: "SUCCEEDED", detail: "PD Loss W34 파일 업로드" },
      { id: 2, occurred_at: "2026-08-24T09:40:00+09:00", trace_id: "TRACE-SEED-002", actor_name: "이선우", actor_role: "LEADER", action: "GENERATE_DRAFT", resource_type: "REPORT", resource_id: "rpt_team", result: "SUCCEEDED", detail: "팀장 서술형 초안 생성" },
      { id: 3, occurred_at: "2026-08-24T10:00:00+09:00", trace_id: "TRACE-SEED-003", actor_name: "최은서", actor_role: "PLANNING", action: "RUN_QA", resource_type: "REPORT", resource_id: "rpt_group", result: "WARN", detail: "그룹 보고 QA 경고 2, 차단 1" },
    ],
  };

  const memberPageSeedContent = `@@PAGE|RPG-RSND-2026-0001|Tension 편차 자동보정 적용 및 확산|MI_LS · HD · WA|Roll Press|[전사DX_1] PD Loss 개선|김현수(주), 이정훈(공동)@@
[WI-RSND-2026-0032][BACKGROUND] (W31) OC(NFF), MI_LS, HD 법인의 Tension 편차 자동보정을 적용하여 Roll Press 단선에 따른 PD Loss를 개선하고자 합니다.

[WI-RSND-2026-0032][RESULT] (W32) MI_LS와 HD 대상 APC 기준정보 등록과 대표호기 자동보정 적용을 완료했습니다.

[WI-RSND-2026-0032][RESULT] (W33) ESWA L07 대상 제품별 Jamming 자동보정 적용조건 기준안을 수립하고, M08·M11 초기 시험에서 유사 경향을 확인했습니다.

[COL-YIELD-2026-0014][ANALYSIS] (W33) 제품별 생산조건 차이가 재현성에 영향을 줄 수 있어 K12는 별도 조건으로 검증하기로 했습니다.

[WI-RSND-2026-0032][PLAN] (W33) K12 생산 일정 확보 후 동일 조건 재현성 검증을 진행하고 제품별 상·하한을 확정할 예정입니다.

[SNP-PD-2026-W34-004][KPI][PROVISIONAL][NEW] (W34) PD Loss는 1.2%로 전주 1.5% 대비 0.3%p 감소했습니다. 다만 현재 Snapshot은 Data Owner 승인 전 잠정값이므로 자동보정 단독 효과로 확정하지 않았습니다.

[WI-RSND-2026-0032][RESULT][NEW] (W34) M08과 M11 제품 반복 시험에서 동일 경향을 확인했습니다. [EVD-RSND-2026-W34-028] [EVD-RSND-2026-W34-029]

[COL-YIELD-2026-0014][ANALYSIS][NEW] (W34) K12는 생산 조건이 달라 재현성 검증이 추가로 필요합니다.

[WI-RSND-2026-0032][RISK][NEW] (W34) 검증용 생산 일정이 미확정되어 완료 일정이 지연될 수 있습니다.

[WI-RSND-2026-0032][PLAN][NEW] (W34) 8월 27일까지 K12 재현성 검증 후 적용 여부를 확정하고 제품별 상·하한 및 예외조건을 정리하겠습니다.

[DEC-RSND-2026-0008][DECISION][NEW] (W34) K12 검증 생산 일정 우선 배정이 필요합니다.
@@ENDPAGE@@

@@PAGE|RPG-RSND-2026-0002|로딩량 연계 Feedforward 자동보정|WA|Coater → Roll Press|[전사DX_1] PD Loss 개선|김현수(주), 박은지(공동)@@
[WI-RSND-2026-0048][BACKGROUND] (W31) 코터 로딩량을 Roll Press 공정에 Feedforward로 연계하여 단선 발생 가능 구간을 사전에 보정하고자 합니다.

[WI-RSND-2026-0048][RESULT] (W32) 코터 롤맵 PLC와 Roll Press PLC의 데이터 수집 및 하프 슬리팅 방향을 고려한 전처리 프로그램 개발을 완료했습니다.

[WI-RSND-2026-0048][ANALYSIS] (W33) 로딩량·두께·Moving EPC·Gap을 활용한 Tension 예측모델의 적용 가능성을 확인하고 법인과 분석 기준을 협의했습니다.

[WI-RSND-2026-0038][RESULT][NEW] (W34) ESWA L07 적용 구간에서 PD Loss 감소 경향을 확인했으며, 동일 생산량과 제품 Mix 기준으로 효과를 재검증하고 있습니다. [EVD-RSND-2026-W34-031]

[WI-RSND-2026-0048][PLAN][NEW] (W34) 8월 28일까지 Tension 예측값을 활용한 Feedforward 자동보정 로직과 설비별 기준정보를 확정하겠습니다.
@@ENDPAGE@@

@@PAGE|RPG-RSND-2026-0003|GM1·2 VM 기반 자동보정 시스템 구축|GM1 · GM2|Roll Press · NND|Global 자동보정 수평전개|김현수(주), 이정훈(공동)@@
[WI-RSND-2026-0052][BACKGROUND] (W31) GM1·2의 자동보정 고도화와 수평전개를 위해 VM 서버 기반 자동보정 시스템 구축이 필요합니다.

[WI-RSND-2026-0052][RESULT] (W32) GM1·2 제조역량강화팀, 공정DX와 데이터 수집·제어 파라미터 범위를 협의했습니다.

[WI-RSND-2026-0052][RESULT] (W33) RP와 NND 기준정보 표준화 및 작성 완료 후 VM 제작사양서 초안을 작성했습니다.

[WI-RSND-2026-0052][PLAN][NEW] (W34) 8월 28일까지 VM·응용 환경 설정 범위와 RP·NND 제작사양서를 확정하고 데이터 수집 일정을 연결하겠습니다.
@@ENDPAGE@@`;
  initial.submission_versions[0].content = memberPageSeedContent;
  initial.submission_versions[0].source_manifest = "RPG-RSND-2026-0001,RPG-RSND-2026-0002,RPG-RSND-2026-0003,WI-RSND-2026-0032,WI-RSND-2026-0038,WI-RSND-2026-0041,WI-RSND-2026-0048,WI-RSND-2026-0052,SNP-PD-2026-W34-004,EVD-RSND-2026-W34-028,EVD-RSND-2026-W34-029,EVD-RSND-2026-W34-031,COL-YIELD-2026-0014,DEC-RSND-2026-0008";

  let runtime = clone(initial);

  function latestSubmissionVersions() {
    return runtime.submissions.map((submission) => {
      const version = runtime.submission_versions
        .filter((item) => item.submission_id === submission.id)
        .sort((a, b) => b.version_number - a.version_number)[0];
      return version ? { ...version, submission_code: submission.submission_code, member_user_id: submission.member_user_id, member_name: submission.member_name } : null;
    }).filter(Boolean);
  }

  function sentenceJoin(logs) {
    return logs.map((log) => {
      const text = String(log.narrative || "").trim();
      return text && !/[.!?。]$/.test(text) ? `${text}.` : text;
    }).filter(Boolean).join(" ");
  }

  function isoWeekNumber(value) {
    const date = new Date(`${value}T00:00:00Z`);
    date.setUTCDate(date.getUTCDate() + 4 - (date.getUTCDay() || 7));
    const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
    return Math.ceil((((date - yearStart) / 86400000) + 1) / 7);
  }

  function buildOfflineMemberDraft() {
    const includedPageIds = new Set(runtime.submission_pages
      .filter((item) => item.submission_id === "sub_member1" && Number(item.included) === 1)
      .map((item) => item.work_page_id));
    const selected = runtime.work_pages
      .filter((page) => page.primary_owner_user_id === "u_member1" && includedPageIds.has(page.id))
      .sort((a, b) => a.display_order - b.display_order);
    const snapshot = runtime.snapshots.find((item) => item.id === "snp_pd_w34");
    const pageDocuments = [];
    const citations = [];
    const currentWeekStart = "2026-08-17";
    const retentionStart = "2026-07-27";

    selected.forEach((page) => {
      const itemIds = String(page.work_item_ids || "").split(",").filter(Boolean);
      const items = runtime.work_items.filter((item) => itemIds.includes(item.id));
      const logs = runtime.worklogs
        .filter((log) => itemIds.includes(log.work_item_id) && String(log.occurred_on) >= retentionStart)
        .sort((a, b) => String(a.occurred_on).localeCompare(String(b.occurred_on)) || String(a.id).localeCompare(String(b.id)));
      const pageEvidence = runtime.evidence.filter((evidence) => itemIds.includes(evidence.work_item_id));
      citations.push(page.page_code, ...items.map((item) => item.work_item_code), ...pageEvidence.map((evidence) => evidence.evidence_code));
      items.forEach((item) => { if (item.collaboration_code) citations.push(item.collaboration_code); });
      const sections = logs.map((log) => {
        const tag = log.entry_type === "NEXT" ? "PLAN" : log.entry_type;
        const item = items.find((entry) => entry.id === log.work_item_id);
        const isNew = String(log.occurred_on) >= currentWeekStart;
        const code = tag === "ANALYSIS" && item?.collaboration_code ? item.collaboration_code : item?.work_item_code || log.work_item_code;
        const week = isNew ? "W34" : `W${isoWeekNumber(log.occurred_on)}`;
        const evidenceSuffix = tag === "RESULT" && isNew
          ? ` ${pageEvidence.filter((evidence) => evidence.work_item_id === log.work_item_id).map((evidence) => `[${evidence.evidence_code}]`).join(" ")}`.trimEnd()
          : "";
        return `[${code}][${tag}]${isNew ? "[NEW]" : ""} (${week}) ${sentenceJoin([log])}${evidenceSuffix}`;
      });

      if (page.id === "pg_tension" && snapshot) {
        const stateTag = snapshot.verification_state === "VERIFIED" ? "VERIFIED" : "PROVISIONAL";
        const delta = Number(snapshot.previous_value) - Number(snapshot.display_value);
        sections.push(`[${snapshot.snapshot_code}][KPI][${stateTag}][NEW] (W34) ${snapshot.metric_name}는 ${Number(snapshot.display_value).toFixed(1)}${snapshot.unit}로 전주 ${Number(snapshot.previous_value).toFixed(1)}${snapshot.unit} 대비 ${delta.toFixed(1)}%p 감소했습니다. 다만 적용 전후 생산량과 제품 Mix가 동일하지 않아 자동보정 단독 효과로 확정하지 않았습니다.`);
        citations.push(snapshot.snapshot_code);
      }
      if (page.id === "pg_tension" && sections.some((section) => section.includes("[RISK][NEW]"))) {
        sections.push("[DEC-RSND-2026-0008][DECISION][NEW] (W34) K12 검증 생산 일정 우선 배정이 필요합니다.");
        citations.push("DEC-RSND-2026-0008");
      }
      const authors = String(page.contributors || "").split(",").filter(Boolean).map((entry) => {
        const [name, role] = entry.split(":");
        return `${name}(${role === "PRIMARY" ? "주" : "공동"})`;
      }).join(", ");
      const header = [page.page_code, page.title, page.site_scope, page.process_scope, page.project_scope, authors].join("|");
      pageDocuments.push(`@@PAGE|${header}@@\n${sections.join("\n\n")}\n@@ENDPAGE@@`);
    });

    return { content: pageDocuments.join("\n\n"), citations: [...new Set(citations)] };
  }

  function flattenOfflinePages(content) {
    const matches = [...String(content || "").matchAll(/@@PAGE\|([^\n]+)@@\n([\s\S]*?)\n@@ENDPAGE@@/g)];
    if (!matches.length) return content;
    return matches.map((match) => {
      const [pageCode, title, site, process, project, authors] = match[1].split("|", 6);
      return `[${pageCode}][RESULT] 업무페이지: ${title}\n범위: ${site} · ${process} / ${project} / 작성: ${authors}\n\n${match[2].trim()}`;
    }).join("\n\n");
  }

  function buildOfflineLeaderDraft() {
    const snapshot = runtime.snapshots.find((item) => item.id === "snp_pd_w34");
    const latest = latestSubmissionVersions();
    const stateTag = snapshot.verification_state === "VERIFIED" ? "VERIFIED" : "PROVISIONAL";
    const delta = Number(snapshot.previous_value) - Number(snapshot.display_value);
    const sections = [
      `[${snapshot.snapshot_code}][KPI][${stateTag}] RSND자동보정팀은 W34 ${snapshot.metric_name} ${Number(snapshot.display_value).toFixed(1)}${snapshot.unit}로 전주 ${Number(snapshot.previous_value).toFixed(1)}${snapshot.unit} 대비 ${delta.toFixed(1)}%p 감소한 수준을 확인했습니다. 현재 값은 공통 Snapshot 상태를 따르며, 자동보정 적용 전후 생산량과 제품 Mix가 동일하지 않아 팀 단독 개선효과로 확정하지 않았습니다.`,
      ...latest.map((version) => flattenOfflinePages(version.content)),
      "[COL-YIELD-2026-0014][ANALYSIS] 팀원별 결과를 종합하면 M08·M11은 보정조건의 반복 경향이 확인됐고 ESWA L07 적용 구간에서도 PD Loss 감소 방향성이 나타났습니다. 다만 K12 생산조건과 FDC 장력 편차의 영향이 분리되지 않았으므로 제품·Roll·설비조건별 분석을 추가해야 합니다.",
      "[WI-RSND-2026-0032][RISK] K12 검증용 생산 일정이 미확정되어 제품별 적용조건 확정과 수평전개 판단이 지연될 수 있습니다. 검증 전에는 M08·M11 결과만으로 전체 제품 효과를 확대 해석하지 않겠습니다.",
      "[WI-RSND-2026-0032][PLAN] W35에는 K12 재현성 검증과 제품별 상·하한 및 예외조건 확정을 우선 진행하겠습니다. 동시에 FDC 이상구간과 자동보정 동작이력을 동일 시간축으로 정렬하고, 동일 조건의 적용 전후 PD Loss를 재산출하겠습니다.",
      "[DEC-RSND-2026-0008][DECISION] K12 검증 생산 일정 우선 배정이 필요합니다.",
    ];
    const citations = [snapshot.snapshot_code, ...latest.flatMap((version) => String(version.source_manifest || "").split(",").filter(Boolean)), "COL-YIELD-2026-0014", "WI-RSND-2026-0032", "DEC-RSND-2026-0008"];
    return { content: sections.join("\n\n"), citations: [...new Set(citations)] };
  }

  function saveOfflineWorklog(payload) {
    const item = runtime.work_items.find((work) => work.id === payload.work_item_id && work.owner_user_id === "u_member1");
    const type = String(payload.entry_type || "RESULT").toUpperCase() === "NEXT" ? "PLAN" : String(payload.entry_type || "RESULT").toUpperCase();
    const narrative = String(payload.narrative || "").trim();
    if (!item) throw new Error("본인 소유 WorkItem에만 기록할 수 있습니다.");
    if (!narrative) throw new Error("추가 작성 내용을 입력하십시오.");
    if (!["FACT", "RESULT", "ANALYSIS", "PLAN", "RISK"].includes(type)) throw new Error("지원하지 않는 기록 유형입니다.");
    const record = { id: `wl_offline_${Date.now()}`, work_item_id: item.id, author_user_id: "u_member1", author_name: "김현수", work_item_code: item.work_item_code, occurred_on: payload.occurred_on || "2026-08-24", entry_type: type, narrative };
    runtime.worklogs.unshift(record);
    addAudit("MEMBER", "CREATE_WORKLOG", "WORK_ITEM", item.id, `${type} 기록 추가`);
    return { ok: true, message: "추가 기록을 저장했습니다. 다음 화면과 AI 초안에 반영됩니다.", record: clone(record), trace_id: runtime.audit_events[0].trace_id };
  }

  function saveOfflineEvidence(payload) {
    const item = runtime.work_items.find((work) => work.id === payload.work_item_id && work.owner_user_id === "u_member1");
    const fileName = String(payload.file_name || "").trim();
    if (!item) throw new Error("본인 소유 WorkItem에만 Evidence를 등록할 수 있습니다.");
    if (!fileName) throw new Error("등록할 파일명을 입력하십시오.");
    const lastNumber = Math.max(0, ...runtime.evidence.map((evidence) => Number(String(evidence.evidence_code).match(/(\d+)$/)?.[1] || 0)));
    const record = { id: `ev_offline_${Date.now()}`, evidence_code: `EVD-RSND-2026-W34-${String(lastNumber + 1).padStart(3, "0")}`, work_item_id: item.id, work_item_code: item.work_item_code, file_name: fileName, content_type: "application/octet-stream", sha256: "offline-demo-hash".padEnd(64, "0"), locator: String(payload.locator || "사용자 지정 없음"), scan_status: "CLEAN", security_label: String(payload.security_label || "CONFIDENTIAL") };
    runtime.evidence.unshift(record);
    addAudit("MEMBER", "UPLOAD_EVIDENCE", "WORK_ITEM", item.id, record.evidence_code);
    return { ok: true, message: "Evidence를 등록했습니다. 업무페이지 선택 화면에 반영됩니다.", record: clone(record), trace_id: runtime.audit_events[0].trace_id };
  }

  function saveOfflineSelection(payload) {
    if (Array.isArray(payload.work_page_ids)) {
      const allowed = runtime.work_pages.filter((page) => page.primary_owner_user_id === "u_member1");
      const selected = new Set(payload.work_page_ids.filter((id) => allowed.some((page) => page.id === id)));
      if (!selected.size) throw new Error("보고서에 포함할 업무페이지를 한 건 이상 선택하십시오.");
      allowed.forEach((page) => {
        const existing = runtime.submission_pages.find((entry) => entry.submission_id === "sub_member1" && entry.work_page_id === page.id);
        const values = { submission_id: "sub_member1", work_page_id: page.id, included: selected.has(page.id) ? 1 : 0, inclusion_reason: selected.has(page.id) ? "사용자 선택" : "이번 주 보고 제외", page_code: page.page_code, title: page.title, site_scope: page.site_scope, process_scope: page.process_scope, primary_owner_name: page.primary_owner_name };
        if (existing) Object.assign(existing, values); else runtime.submission_pages.push(values);
      });
      addAudit("MEMBER", "SAVE_PAGE_SELECTION", "SUBMISSION", "sub_member1", `업무페이지 선택 ${selected.size}건`);
      return { ok: true, message: `금주 보고 업무페이지 ${selected.size}건을 선택했습니다.`, work_page_ids: [...selected], trace_id: runtime.audit_events[0].trace_id };
    }
    const allowed = runtime.work_items.filter((item) => item.owner_user_id === "u_member1");
    const selected = new Set((Array.isArray(payload.work_item_ids) ? payload.work_item_ids : []).filter((id) => allowed.some((item) => item.id === id)));
    if (!selected.size) throw new Error("보고서에 포함할 업무를 한 건 이상 선택하십시오.");
    allowed.forEach((item) => {
      const existing = runtime.submission_items.find((entry) => entry.submission_id === "sub_member1" && entry.work_item_id === item.id);
      const values = { submission_id: "sub_member1", work_item_id: item.id, included: selected.has(item.id) ? 1 : 0, inclusion_reason: selected.has(item.id) ? "사용자 선택" : "이번 주 보고 제외", work_item_code: item.work_item_code, title: item.title };
      if (existing) Object.assign(existing, values); else runtime.submission_items.push(values);
    });
    addAudit("MEMBER", "SAVE_SELECTION", "SUBMISSION", "sub_member1", `선택 ${selected.size}건`);
    return { ok: true, message: `금주 보고 업무 ${selected.size}건을 선택했습니다.`, work_item_ids: [...selected], trace_id: runtime.audit_events[0].trace_id };
  }

  function saveOfflineEditedVersion(payload) {
    const role = payload.role || "MEMBER";
    const content = String(payload.content || "").trim();
    if (!content) throw new Error("저장할 보고서 내용을 입력하십시오.");
    const manifest = [...new Set([...content.matchAll(/\[((?:WI|RPG|SNP|COL|EVD|DEC|ACT|RPT|MET)-[^\]]+)\]/g)].map((match) => match[1]))].join(",");
    let version;
    let message;
    if (role === "MEMBER") {
      const submission = runtime.submissions.find((item) => item.id === "sub_member1");
      version = Math.max(0, ...runtime.submission_versions.filter((item) => item.submission_id === submission.id).map((item) => item.version_number)) + 1;
      submission.version = version; submission.status = "AI_DRAFTED";
      runtime.submission_versions.push({ id: `sv_member1_edit_${version}`, submission_id: submission.id, version_number: version, content, source_manifest: manifest, generated_by: "HUMAN_MEMBER", created_at: new Date().toISOString() });
      addAudit(role, "SAVE_EDITED_VERSION", "SUBMISSION", submission.id, `수정본 v${version} 저장`);
      message = `수정본 v${version}을 저장했습니다. 제출 화면과 팀장 검토 화면에 반영됩니다.`;
    } else {
      const reportId = { LEADER: "rpt_team", DEPT: "rpt_dept", PLANNING: "rpt_group" }[role];
      const report = runtime.reports.find((item) => item.id === reportId);
      if (!report) throw new Error("현재 역할에서는 보고서 Version을 저장할 수 없습니다.");
      report.current_version += 1; report.status = "DRAFT"; report.content = content; report.source_manifest = manifest;
      version = report.current_version;
      addAudit(role, "SAVE_EDITED_VERSION", "REPORT", report.id, `수정본 v${version} 저장`);
      message = `수정본 v${version}을 저장했습니다. 다음 검토 화면에 반영됩니다.`;
    }
    return { ok: true, message, version, source_manifest: manifest, trace_id: runtime.audit_events[0].trace_id };
  }

  function generateOfflineDraft(role) {
    if (role === "LEADER") {
      const draft = buildOfflineLeaderDraft();
      const report = runtime.reports.find((item) => item.id === "rpt_team");
      report.content = draft.content; report.source_manifest = draft.citations.join(","); report.current_version += 1; report.status = "DRAFT";
      addAudit(role, "GENERATE_DRAFT", "REPORT", "rpt_team", "팀원 추가기록을 반영한 팀장 서술형 초안");
      return draft;
    }
    const draft = buildOfflineMemberDraft();
    const submission = runtime.submissions.find((item) => item.id === "sub_member1");
    const nextVersion = Math.max(0, ...runtime.submission_versions.filter((item) => item.submission_id === submission.id).map((item) => item.version_number)) + 1;
    submission.status = "AI_DRAFTED"; submission.version = nextVersion;
    runtime.submission_versions.push({ id: `sv_member1_${nextVersion}`, submission_id: submission.id, version_number: nextVersion, content: draft.content, source_manifest: draft.citations.join(","), generated_by: "MEMBER_AGENT", created_at: new Date().toISOString() });
    addAudit(role, "GENERATE_DRAFT", "SUBMISSION", submission.id, "추가기록·Evidence·선택업무를 반영한 팀원 초안");
    return draft;
  }

  function traceId() {
    return `TRACE-OFFLINE-${Math.random().toString(16).slice(2, 12).toUpperCase()}`;
  }

  function addAudit(role, action, resourceType, resourceId, detail) {
    const p = principals[role] || principals.MEMBER;
    runtime.audit_events.unshift({
      id: Date.now(), occurred_at: new Date().toISOString(), trace_id: traceId(), actor_name: p[1], actor_role: role,
      action, resource_type: resourceType, resource_id: resourceId, result: "SUCCEEDED", detail,
    });
  }

  function scopedWork(role) {
    if (role === "MEMBER") return runtime.work_items.filter((item) => item.owner_user_id === "u_member1");
    if (role === "LEADER") return runtime.work_items.filter((item) => item.organization_id === "team_rsnd");
    if (role === "DEPT") return runtime.work_items.filter((item) => ["team_rsnd", "team_electrode", "team_assembly", "team_activation"].includes(item.organization_id));
    return runtime.work_items;
  }

  function scopedPages(role) {
    if (role === "MEMBER") return runtime.work_pages.filter((page) => String(page.contributors || "").includes("김현수:"));
    if (role === "LEADER") return runtime.work_pages.filter((page) => page.organization_id === "team_rsnd");
    return runtime.work_pages;
  }

  function bootstrap(role) {
    const selectedRole = principals[role] ? role : "MEMBER";
    const p = principals[selectedRole];
    const items = scopedWork(selectedRole);
    const workPages = scopedPages(selectedRole);
    const counts = {
      screens: screens.filter((item) => item.role_code === selectedRole).length,
      snapshots_locked: runtime.snapshots.filter((item) => item.status === "LOCKED").length,
      snapshots_total: runtime.snapshots.length,
      work_items: items.length,
      work_pages: workPages.length,
      open_qa: runtime.qa_issues.filter((item) => item.status === "OPEN").length,
      open_decisions: runtime.decisions.filter((item) => item.status !== "RESOLVED").length,
      submitted_members: runtime.submissions.filter((item) => ["SUBMITTED", "ACCEPTED", "LOCKED"].includes(item.status)).length,
      members_total: runtime.submissions.length,
    };
    return clone({
      principal: { id: p[0], display_name: p[1], email: `${p[0]}@example.internal`, role_code: selectedRole, role_label: p[2], organization_name: p[3] },
      cycle: runtime.cycle,
      screens: screens.filter((item) => item.role_code === selectedRole).sort((a, b) => a.display_order - b.display_order),
      snapshots: runtime.snapshots, work_items: items, work_pages: workPages, worklogs: runtime.worklogs, evidence: runtime.evidence,
      submissions: runtime.submissions, submission_items: runtime.submission_items, submission_pages: runtime.submission_pages,
      submission_versions: latestSubmissionVersions(), reports: runtime.reports, collaborations: runtime.collaborations,
      participants: runtime.participants, qa_issues: runtime.qa_issues, decisions: runtime.decisions,
      action_items: runtime.action_items, audit_events: runtime.audit_events.slice(0, 50), counts,
      role_labels: Object.fromEntries(Object.entries(principals).map(([key, value]) => [key, value[2]])),
    });
  }

  function runAction(action, role) {
    const pd = runtime.snapshots.find((item) => item.id === "snp_pd_w34");
    let message;
    if (action === "VALIDATE_SNAPSHOT") {
      pd.validation_errors = 0; pd.validation_warnings = 0; pd.status = "READY_FOR_APPROVAL";
      runtime.qa_issues.filter((item) => item.resource_id === "snp_pd_w34").forEach((item) => { item.status = "RESOLVED"; });
      message = "PD Snapshot 재검증이 통과했습니다. 승인·잠금할 수 있습니다.";
    } else if (action === "APPROVE_SNAPSHOT") {
      if (pd.validation_errors) throw new Error("BLOCK 오류를 먼저 해소해야 합니다.");
      pd.status = "LOCKED"; pd.verification_state = "VERIFIED";
      message = "PD Snapshot을 승인하고 잠갔습니다.";
    } else if (action === "SUBMIT_MEMBER") {
      runtime.submissions[0].status = "SUBMITTED"; runtime.submissions[0].submitted_at = new Date().toISOString();
      message = "팀원 보고를 팀장에게 제출했습니다.";
    } else if (action === "APPROVE_TEAM") {
      runtime.reports.find((item) => item.id === "rpt_team").status = "TEAM_APPROVED";
      message = "팀 보고를 승인하고 담당에게 제출했습니다.";
    } else if (action === "APPROVE_DEPT") {
      runtime.reports.find((item) => item.id === "rpt_dept").status = "DEPT_APPROVED";
      message = "담당 보고를 승인하고 기획팀에 제출했습니다.";
    } else if (action === "RESOLVE_QA") {
      runtime.qa_issues.filter((item) => item.resource_id === "rpt_group").forEach((item) => { item.status = "RESOLVED"; });
      message = "그룹 보고 QA Issue를 해소했습니다.";
    } else if (action === "APPROVE_PLANNING") {
      if (runtime.qa_issues.some((item) => item.resource_id === "rpt_group" && item.severity === "BLOCK" && item.status === "OPEN")) throw new Error("BLOCK QA Issue를 먼저 해소해야 합니다.");
      runtime.reports.find((item) => item.id === "rpt_group").status = "READY_FOR_REPORT";
      message = "그룹장 보고 확정 요청을 완료했습니다.";
    } else if (action === "RESOLVE_DECISION") {
      const decision = runtime.decisions.find((item) => item.id === "dec1");
      decision.status = "RESOLVED"; decision.resolution = "W35 K12 검증 생산 일정 우선 배정 승인";
      if (!runtime.action_items.some((item) => item.action_code === "ACT-RSND-2026-0052")) runtime.action_items.push({ id: "act3", action_code: "ACT-RSND-2026-0052", title: "K12 재현성 검증 완료", owner_name: "이선우", due_date: "2026-08-27", status: "OPEN", priority: "HIGH" });
      message = "Decision을 확정하고 후속 Action을 만들었습니다.";
    } else {
      throw new Error("지원하지 않는 오프라인 시연 동작입니다.");
    }
    addAudit(role, action, "DEMO_RESOURCE", action, message);
    return { ok: true, message, trace_id: runtime.audit_events[0].trace_id };
  }

  window.demoOfflineApi = async function (path, options = {}) {
    const url = new URL(path, "http://offline.local");
    const payload = options.body ? JSON.parse(options.body) : {};
    if (url.pathname === "/api/health") return { ok: true, database: false, mode: "OFFLINE_FIXTURE", time: new Date().toISOString() };
    if (url.pathname === "/api/agent/status") return { ok: true, mode: "OFFLINE", configured: false, provider: "local_demo", model: "미설정", message: "오프라인 로컬 시연 응답입니다. 실제 모델은 호출하지 않습니다." };
    if (url.pathname === "/api/bootstrap") return bootstrap(url.searchParams.get("role") || "MEMBER");
    if (url.pathname === "/api/screen-catalog") return clone(screens);
    if (url.pathname === "/api/reset") { runtime = clone(initial); return { ok: true, message: "오프라인 시연 데이터를 최초 상태로 초기화했습니다." }; }
    if (url.pathname === "/api/worklogs") return saveOfflineWorklog(payload);
    if (url.pathname === "/api/evidence") return saveOfflineEvidence(payload);
    if (url.pathname === "/api/submission/items") return saveOfflineSelection(payload);
    if (url.pathname === "/api/draft/version") return saveOfflineEditedVersion(payload);
    if (url.pathname === "/api/action") return runAction(payload.action, payload.role || "MEMBER");
    if (url.pathname === "/api/agent/draft") {
      const draft = generateOfflineDraft(payload.role || "MEMBER");
      return { ok: true, content: draft.content, citations: draft.citations, validation: { schema: true, numbers: true, citations: true, policy: true }, trace_id: runtime.audit_events[0].trace_id, model: "OFFLINE_CONTEXT_AWARE_AGENT" };
    }
    if (url.pathname === "/api/agent/ask") {
      return { ok: true, question: payload.question || "", answer: "현재 근거만으로 자동보정의 단독 효과를 확정할 수 없습니다. W34 PD Loss 1.2%는 전체 범위의 잠정 Snapshot이며, 동일 제품·동일 조건에서 적용 전후를 분리한 승인 데이터가 추가로 필요합니다.", citations: [{ code: "SNP-PD-2026-W34-004", detail: "PD Loss 1.2% · 기준 2026-08-23 23:59 · PROVISIONAL" }, { code: "WI-RSND-2026-0032", detail: "Jamming 자동보정 조건 검증" }, { code: "EVD-RSND-2026-W34-028", detail: "검증표 Result!B4:H18" }], freshness: "2026-08-23T23:59:00+09:00", trace_id: traceId() };
    }
    throw new Error(`오프라인 API를 찾을 수 없습니다: ${url.pathname}`);
  };
})();
