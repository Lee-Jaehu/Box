"use strict";

const $ = (selector, root = document) => root.querySelector(selector);

const state = {
  role: "MEMBER",
  data: null,
  screenIndex: 0,
  generatedDraft: null,
  pendingAction: null,
  lastAnswer: null,
  agent: {
    draft: null,
    conversationCount: 0,
    activePageId: null,
    attachment: null,
    messages: [],
    busy: false,
    engine: {
      mode: "CHECKING",
      configured: false,
      provider: "",
      model: "",
      message: "업무 Agent 연결 상태를 확인하는 중입니다.",
    },
  },
};

const roleColors = {
  COMMON: "#53657d", MEMBER: "#2356a8", LEADER: "#7655a6", DEPT: "#8a5323",
  PLANNING: "#13706c", HEAD: "#9b3e55", DATA_OWNER: "#3c6f3d", ADMIN: "#4b5568",
};

const actionMap = {
  "DAT-04": "VALIDATE_SNAPSHOT", "DAT-06": "APPROVE_SNAPSHOT",
  "MBR-08": "SUBMIT_MEMBER", "LDR-05": "APPROVE_TEAM", "LDR-07": "APPROVE_TEAM",
  "DPT-07": "APPROVE_DEPT", "PLN-02": "RESOLVE_QA", "PLN-06": "APPROVE_PLANNING",
  "HED-05": "RESOLVE_DECISION",
};

const confirmCopy = {
  VALIDATE_SNAPSHOT: ["PD Snapshot 재검증", "중복 Key를 보정한 것으로 가정하고 Rule Engine을 다시 실행합니다."],
  APPROVE_SNAPSHOT: ["Snapshot 승인·잠금", "검증을 통과한 PD Snapshot을 공식값으로 승인하고 변경 불가 상태로 잠급니다."],
  SUBMIT_MEMBER: ["팀원 보고 제출", "현재 Version과 Source Manifest를 고정하여 팀장에게 제출합니다."],
  APPROVE_TEAM: ["팀 보고 승인·제출", "서술형 보고 원문과 ID·근거 연결을 유지한 새 Version을 담당에게 제출합니다."],
  APPROVE_DEPT: ["담당 보고 승인·제출", "승인된 팀 보고를 기준으로 담당 보고를 기획팀에 제출합니다."],
  RESOLVE_QA: ["QA Issue 시연 해소", "그룹 보고의 데모 QA Issue를 해소 상태로 전환합니다."],
  APPROVE_PLANNING: ["그룹장 보고 확정 요청", "BLOCK Issue가 없는지 확인한 뒤 그룹장 검토 상태로 전환합니다."],
  RESOLVE_DECISION: ["Decision 확정", "K12 검증 생산 일정을 우선 배정하고 후속 Action을 생성합니다."],
};

const navTargets = {
  "MBR-01": "MBR-04", "LDR-01": "LDR-02", "DPT-01": "DPT-02", "PLN-01": "PLN-02",
  "HED-01": "HED-02", "DAT-01": "DAT-02", "ADM-01": "ADM-06", "COM-03": "COM-04",
};

const agentSourceLabels = {
  CHAT: "대화 입력",
  WORK_HISTORY: "업무 이력",
  MAIL: "메일 발췌",
  FILE: "파일 내용",
};

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;").replaceAll("'", "&#039;");
}

function formatDate(value, withTime = false) {
  if (!value) return "—";
  const normalized = /T/.test(value) ? value : `${value}T00:00:00+09:00`;
  const date = new Date(normalized);
  if (Number.isNaN(date.getTime())) return escapeHtml(value);
  return new Intl.DateTimeFormat("ko-KR", {
    month: "2-digit", day: "2-digit", ...(withTime ? { hour: "2-digit", minute: "2-digit" } : {}),
  }).format(date);
}

function stateClass(value) {
  const text = String(value ?? "").toUpperCase();
  if (/LOCKED|VERIFIED|APPROVED|ACCEPTED|RESOLVED|REPORTED|CLEAN|SUCCEEDED|PASS|ACTIVE|ON|UP/.test(text)) return "success";
  if (/BLOCK|ERROR|DELAYED|RETURNED|FAILED|NEEDS/.test(text)) return "danger";
  if (/WARN|PROVISIONAL|REQUESTED|DRAFT|OPEN|IN_PROGRESS|READY|OFF|NOT_CONNECTED|DEMO/.test(text)) return "warn";
  return "";
}

function badge(value, label = value) {
  return `<span class="badge ${stateClass(value)}">${escapeHtml(label)}</span>`;
}

function table(headers, rows, empty = "표시할 데이터가 없습니다.") {
  if (!rows.length) return `<div class="empty-state">${escapeHtml(empty)}</div>`;
  return `<div class="table-wrap"><table><thead><tr>${headers.map((h) => `<th>${escapeHtml(h)}</th>`).join("")}</tr></thead><tbody>${rows.join("")}</tbody></table></div>`;
}

function card(title, content, extraClass = "") {
  return `<section class="card ${extraClass}"><h3>${escapeHtml(title)}</h3>${content}</section>`;
}

function metricCard(label, value, context, tone = "") {
  return `<article class="card metric ${tone}"><span class="metric-label">${escapeHtml(label)}</span><strong class="metric-value">${escapeHtml(value)}</strong><span class="metric-context">${escapeHtml(context)}</span></article>`;
}

async function api(path, options = {}) {
  if (window.location.protocol === "file:" && window.demoOfflineApi) {
    return window.demoOfflineApi(path, options);
  }
  try {
    const response = await fetch(path, { headers: { "Content-Type": "application/json", ...(options.headers || {}) }, ...options });
    let payload;
    try { payload = await response.json(); } catch { payload = { message: `HTTP ${response.status}` }; }
    if (!response.ok) throw new Error(payload.message || `HTTP ${response.status}`);
    return payload;
  } catch (error) {
    if (window.demoOfflineApi) {
      $("#runtime-label").textContent = "오프라인 샘플 데이터";
      return window.demoOfflineApi(path, options);
    }
    throw error;
  }
}

async function liveAgentApi(path, options = {}) {
  if (window.location.protocol === "file:") throw new Error("오프라인 HTML에서는 실제 모델을 호출할 수 없습니다.");
  const response = await fetch(path, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options,
  });
  let payload;
  try { payload = await response.json(); } catch { payload = { message: `HTTP ${response.status}` }; }
  if (!response.ok) throw new Error(payload.detail || payload.message || `HTTP ${response.status}`);
  return payload;
}

function renderAgentEngineStatus() {
  const engine = state.agent.engine || {};
  const mode = String(engine.mode || "CHECKING").toUpperCase();
  const badgeElement = $("#agent-engine-status");
  const dot = $("#agent-engine-dot");
  const detail = $("#agent-engine-detail");
  const welcome = $("#agent-engine-welcome");
  const labels = {
    LIVE: `LIVE${engine.model && engine.model !== "미설정" ? ` · ${engine.model}` : ""}`,
    SETUP: "연결 필요",
    DEMO: "DEMO",
    OFFLINE: "OFFLINE DEMO",
    CHECKING: "확인 중",
  };
  if (badgeElement) {
    badgeElement.textContent = labels[mode] || mode;
    badgeElement.className = `agent-engine-badge ${mode.toLowerCase()}`;
  }
  if (dot) dot.className = `agent-online-dot ${mode.toLowerCase()}`;
  if (detail) detail.textContent = engine.message || "업무 Agent 상태를 확인할 수 없습니다.";
  if (welcome) {
    welcome.textContent = mode === "LIVE"
      ? `현재 ${engine.model} 모델과 연결되어 있습니다. 생성 결과를 확인한 뒤 업무페이지에 반영하세요.`
      : mode === "SETUP"
        ? "서버의 LLM 연결 설정이 필요합니다. 설정 전에는 실제 모델 응답을 생성하지 않습니다."
        : "현재는 로컬 시연 응답입니다. LIVE 설정 시 같은 화면에서 실제 업무 Agent가 동작합니다.";
  }
}

async function loadAgentStatus() {
  try {
    state.agent.engine = await api("/api/agent/status");
  } catch (error) {
    state.agent.engine = { mode: "SETUP", configured: false, message: error.message, model: "미설정" };
  }
  renderAgentEngineStatus();
}

function currentScreen() { return state.data?.screens?.[state.screenIndex] || null; }

async function loadRole(role, preferredScreenId = null) {
  state.role = role;
  state.generatedDraft = null;
  state.lastAnswer = null;
  $("#loading").hidden = false;
  $("#screen-body").innerHTML = "";
  try {
    const data = await api(`/api/bootstrap?role=${encodeURIComponent(role)}`);
    state.data = data;
    const target = data.screens.findIndex((screen) => screen.screen_id === preferredScreenId);
    state.screenIndex = target >= 0 ? target : 0;
    renderPrincipal(); renderNavigation(); renderScreen();
    await loadAgentStatus();
  } catch (error) {
    $("#loading").textContent = `데이터를 불러오지 못했습니다: ${error.message}`;
    showToast(error.message, true);
  }
}

function renderPrincipal() {
  const p = state.data.principal;
  $("#principal-name").textContent = p.display_name;
  $("#principal-scope").textContent = `${p.role_label} · ${p.organization_name}`;
  $("#principal-avatar").textContent = p.display_name.slice(0, 1);
  $("#principal-avatar").style.background = roleColors[state.role] || roleColors.COMMON;
  $("#principal-avatar").style.color = "white";
  $("#screen-count").textContent = state.data.screens.length;
  $("#runtime-label").textContent = window.location.protocol === "file:" ? "오프라인 샘플 데이터" : "SQLite 연결됨";
}

function renderNavigation() {
  $("#screen-nav").innerHTML = state.data.screens.map((screen, index) => `
    <button type="button" class="nav-button ${index === state.screenIndex ? "active" : ""}" data-screen-index="${index}">
      <code>${escapeHtml(screen.screen_id)}</code><span>${escapeHtml(screen.title)}</span>
    </button>`).join("");
}

function renderScreen() {
  const screen = currentScreen();
  if (!screen) return;
  $("#loading").hidden = true;
  $("#screen-id").textContent = screen.screen_id;
  $("#screen-kind").textContent = screen.kind;
  $("#screen-title").textContent = screen.title;
  $("#screen-purpose").textContent = screen.purpose;
  const primary = $("#primary-action");
  primary.textContent = screen.primary_action;
  primary.hidden = screen.primary_action === "없음";
  primary.disabled = false;
  $("#screen-body").innerHTML = renderByKind(screen);
  renderNavigation();
  bindScreenForms();
  renderAgentContext();
}

function renderAgentContext() {
  if (!state.data) return;
  const screen = currentScreen();
  const screenLabel = screen ? `${screen.screen_id} · ${screen.title}` : "화면 선택 전";
  if ($("#agent-context-screen")) $("#agent-context-screen").textContent = screenLabel;
  const pages = state.data.work_pages || [];
  if (!pages.some((page) => page.id === state.agent.activePageId)) state.agent.activePageId = pages[0]?.id || null;
  const activePage = pages.find((page) => page.id === state.agent.activePageId);
  const pageChip = $("#agent-page-chip");
  if (pageChip) pageChip.textContent = activePage ? `▣ ${activePage.title}` : "업무페이지 선택";
  const pageMenu = $("#agent-page-menu");
  if (pageMenu) {
    pageMenu.innerHTML = pages.map((page) => `<button type="button" class="${page.id === state.agent.activePageId ? "active" : ""}" data-agent-page="${escapeHtml(page.id)}"><strong>${escapeHtml(page.title)}</strong><span>${escapeHtml(page.site_scope)} · ${escapeHtml(page.process_scope)}</span></button>`).join("");
  }
  const count = $("#agent-collected-count");
  if (count) count.textContent = `대화 ${state.agent.conversationCount}건`;
}

function selectAgentPage(pageId, announce = true) {
  const page = (state.data?.work_pages || []).find((item) => item.id === pageId);
  if (!page) return;
  state.agent.activePageId = page.id;
  if (state.agent.draft) state.agent.draft.targetPageId = page.id;
  $("#agent-page-menu").hidden = true;
  $("#agent-page-chip").setAttribute("aria-expanded", "false");
  renderAgentContext();
  if (announce) appendAgentMessage("assistant", `대화의 기준 업무페이지를 ‘${page.title}’로 변경했습니다. 이후 “보고에 반영해줘”라고 하면 이 페이지에 New 문장으로 추가합니다.`);
}

function appendAgentMessage(role, text, options = {}) {
  const messages = $("#agent-messages");
  if (!messages) return;
  const welcome = $("#agent-welcome");
  if (welcome) welcome.hidden = true;
  const article = document.createElement("article");
  article.className = `agent-message-row ${role}`;
  const avatar = document.createElement("div");
  avatar.className = "agent-message-avatar";
  avatar.textContent = role === "user" ? (state.data?.principal?.display_name || "나").slice(0, 1) : "AI";
  const content = document.createElement("div");
  content.className = "agent-message-content";
  const label = document.createElement("strong");
  label.textContent = role === "user" ? (state.data?.principal?.display_name || "나") : "업무 Agent";
  const copy = document.createElement("div");
  copy.className = "agent-message-copy";
  copy.textContent = text;
  content.append(label, copy);
  if (options.attachment) {
    const file = document.createElement("div");
    file.className = "agent-inline-file";
    file.textContent = `▤ ${options.attachment.name}`;
    content.appendChild(file);
  }
  if (options.draft) content.insertAdjacentHTML("beforeend", renderAgentCandidate(options.draft));
  if (options.suggestions?.length) {
    const suggestions = document.createElement("div");
    suggestions.className = "agent-followups";
    suggestions.innerHTML = options.suggestions.map((suggestion) => `<button type="button" data-agent-prompt="${escapeHtml(suggestion)}">${escapeHtml(suggestion)}</button>`).join("");
    content.appendChild(suggestions);
  }
  article.append(avatar, content);
  messages.appendChild(article);
  messages.scrollTop = messages.scrollHeight;
  if (options.record !== false && ["user", "assistant"].includes(role) && text) {
    state.agent.messages.push({ role, content: String(text) });
    state.agent.messages = state.agent.messages.slice(-16);
  }
}

function renderAgentCandidate(draft) {
  const page = (state.data?.work_pages || []).find((item) => item.id === draft.targetPageId);
  return `<section class="agent-candidate"><div class="agent-candidate-top"><div>${reportTag(draft.tag)}${reportTag("NEW")}</div><span>${escapeHtml(page?.title || "선택 업무페이지")}</span></div><p>${escapeHtml(draft.body)}</p><div class="agent-candidate-source"><span>근거</span><strong>${escapeHtml(agentSourceLabels[draft.sourceMode] || draft.sourceMode)} · ${escapeHtml(draft.sourceTitle)}</strong></div><div class="agent-candidate-actions"><button type="button" data-agent-prompt="더 간결하게 다듬어줘">더 간결하게</button><button type="button" data-agent-prompt="Plan 문장으로 바꿔줘">Plan으로 변경</button><button type="button" class="primary" data-agent-apply-chat>보고에 반영</button></div></section>`;
}

function cleanAgentSource(text, mode) {
  let value = String(text || "").replace(/\r/g, "").trim();
  if (mode === "MAIL") {
    value = value
      .split("\n")
      .filter((line) => !/^\s*(아래|이|다음).*메일.*(?:추출|정리|요약|추가|작성).*$/i.test(line))
      .filter((line) => !/^\s*(보낸 사람|받는 사람|참조|보낸 날짜|제목|from|to|cc|sent|subject)\s*:/i.test(line))
      .filter((line) => !/^\s*(감사합니다|고맙습니다|best regards)[.!\s]*$/i.test(line))
      .join("\n");
  }
  return value
    .replace(/^[-•·]\s*/gm, "")
    .replace(/\n{2,}/g, "\n")
    .replace(/[ \t]+/g, " ")
    .trim();
}

function inferAgentTag(text) {
  const value = String(text || "");
  if (/지연|미확정|불가|우려|위험|리스크|차질/.test(value)) return "RISK";
  if (/분석|원인|영향|상관|가설|추정|가능성/.test(value)) return "ANALYSIS";
  if (/예정|계획|까지|추진|진행할|확정 후|차주|W3[5-9]/i.test(value)) return "PLAN";
  if (/완료|확인|검증|적용|개선|협의/.test(value)) return "RESULT";
  return "FACT";
}

function formalizeAgentNarrative(text, tag) {
  let value = String(text || "")
    .replace(/확인함(?=[.\s]|$)/g, "확인했습니다")
    .replace(/완료함(?=[.\s]|$)/g, "완료했습니다")
    .replace(/진행 예정임(?=[.\s]|$)/g, "진행할 예정입니다")
    .replace(/필요함(?=[.\s]|$)/g, "필요합니다")
    .replace(/검토 부탁드립니다[.!]?/g, "검토가 필요합니다.")
    .trim();
  const lines = value.split("\n").map((line) => line.trim()).filter(Boolean);
  value = lines.join(" ");
  if (value.length > 560) value = `${value.slice(0, 557).trim()}…`;
  if (value && !/[.!?。]$/.test(value)) value += ".";
  if (tag === "PLAN" && !/예정|계획|진행|확정|추진|완료하겠습니다/.test(value)) {
    value = `${value.replace(/[.]$/, "")}를 차주 계획에 반영하겠습니다.`;
  }
  return value;
}

function agentPageFromPrompt(prompt) {
  const pages = state.data?.work_pages || [];
  if (/GM1|GM2|VM|NND/i.test(prompt)) return pages.find((page) => page.id === "pg_vm");
  if (/로딩|Feedforward|코터|Coater/i.test(prompt)) return pages.find((page) => page.id === "pg_loading");
  if (/Tension|K12|Jamming|M08|M11|MI_LS|장력/i.test(prompt)) return pages.find((page) => page.id === "pg_tension");
  return pages.find((page) => prompt.includes(page.title)) || pages.find((page) => page.id === state.agent.activePageId) || pages[0];
}

function currentMemberDraftContent() {
  if (state.generatedDraft) return state.generatedDraft;
  const submission = state.data?.submissions?.find((item) => item.member_user_id === state.data?.principal?.id) || state.data?.submissions?.[0];
  return state.data?.submission_versions?.find((item) => item.submission_id === submission?.id)?.content || "";
}

function workHistoryForPage(page) {
  const itemIds = String(page?.work_item_ids || "").split(",").filter(Boolean);
  return (state.data?.worklogs || [])
    .filter((item) => itemIds.includes(item.work_item_id))
    .slice()
    .sort((left, right) => String(right.occurred_on).localeCompare(String(left.occurred_on)))
    .slice(0, 5);
}

function setAgentDraft(draft) {
  state.agent.draft = draft;
  state.agent.activePageId = draft.targetPageId;
  renderAgentContext();
  return draft;
}

function modifyAgentDraft(prompt) {
  const draft = { ...state.agent.draft };
  if (/Plan|계획/i.test(prompt)) draft.tag = "PLAN";
  else if (/Analysis|분석/i.test(prompt)) draft.tag = "ANALYSIS";
  else if (/Risk|리스크|위험/i.test(prompt)) draft.tag = "RISK";
  else if (/Result|결과/i.test(prompt)) draft.tag = "RESULT";
  else if (/Fact|사실/i.test(prompt)) draft.tag = "FACT";
  if (/간결|짧게|줄여/.test(prompt)) {
    const sentences = draft.body.match(/[^.!?]+[.!?]?/g) || [draft.body];
    draft.body = sentences.slice(0, 2).join(" ").trim();
  }
  if (/자세|구체|근거.*추가/.test(prompt)) {
    draft.body = `${draft.body.replace(/[.]$/, "")} 적용 대상·검증 조건·완료 기준은 Evidence와 동일한 기준으로 확인하고, 미확정 항목은 차주 계획으로 분리하겠습니다.`;
  }
  const page = agentPageFromPrompt(prompt);
  if (page && /페이지|업무|반영|이쪽|여기/.test(prompt)) draft.targetPageId = page.id;
  return setAgentDraft(draft);
}

function createAgentResponse(prompt, attachment = null) {
  const page = agentPageFromPrompt(prompt);
  if (page) state.agent.activePageId = page.id;
  const compact = prompt.replace(/\s+/g, " ").trim();

  if (/할 수 있|사용법|어떻게 써|도와줄 수/.test(compact)) {
    return { message: "저는 업무 Agent입니다. 대화로 ① 최근 4주 업무이력 조회, ② 메일·파일의 보고사항 추출, ③ Result·Analysis·Plan·Risk 문장 생성, ④ 문장 수정, ⑤ 선택 업무페이지 New 반영을 처리할 수 있습니다.", suggestions: ["내 최근 업무이력을 정리해줘", "메일 예시로 보고문장을 만들어줘", "현재 초안의 보완점을 찾아줘"] };
  }
  if (/안녕|반가워/.test(compact)) {
    return { message: "안녕하세요. 업무이력이나 메일 내용을 그대로 입력해 주세요. 필요한 보고문장을 만들고 대화로 수정한 뒤 왼쪽 업무페이지에 반영하겠습니다.", suggestions: ["내 최근 업무이력을 정리해줘", "메일 내용에서 보고사항을 추출해줘"] };
  }
  if (state.agent.draft && /반영해|추가해|보고에 넣|업무페이지에 넣|이대로 저장/.test(compact)) return { apply: true };
  if (state.agent.draft && /간결|짧게|줄여|자세|구체|Plan|계획|Analysis|분석|Risk|리스크|Result|결과|Fact|사실|페이지로/i.test(compact)) {
    const draft = modifyAgentDraft(compact);
    return { message: "요청한 방식으로 보고문장을 다시 구성했습니다. 추가 수정도 대화로 요청할 수 있습니다.", draft, suggestions: ["조금 더 자세히 써줘", "이 내용을 보고에 반영해줘"] };
  }
  if (/최근.*업무|업무이력|Worklog|지난.*작성|이번 주.*한 일/i.test(compact)) {
    const history = workHistoryForPage(page);
    if (!history.length) return { message: `‘${page?.title || "선택 업무페이지"}’에 조회할 업무이력이 없습니다. 다른 업무페이지를 선택하거나 내용을 직접 입력해 주세요.` };
    const listing = history.map((item) => `• ${item.occurred_on} · ${item.entry_type}: ${item.narrative}`).join("\n");
    const candidate = history[0];
    const tag = candidate.entry_type === "NEXT" ? "PLAN" : candidate.entry_type;
    const draft = setAgentDraft({ sourceMode: "WORK_HISTORY", sourceTitle: `${page.title} 최근 업무이력`, targetPageId: page.id, tag, body: formalizeAgentNarrative(candidate.narrative, tag) });
    return { message: `선택한 업무페이지의 최근 이력입니다.\n\n${listing}\n\n가장 최근 기록을 기준으로 금주 보고 후보를 만들었습니다.`, draft, suggestions: ["최근 2건을 합쳐서 더 자세히 써줘", "Plan 문장으로 바꿔줘", "이 내용을 보고에 반영해줘"] };
  }
  if (/현재.*초안|초안.*빠|보완점|누락/.test(compact)) {
    const content = currentMemberDraftContent();
    const missing = [];
    if (!content.includes("[RISK]")) missing.push("Risk");
    if (!content.includes("[PLAN]")) missing.push("Plan");
    if (!content.includes("[ANALYSIS]")) missing.push("Analysis");
    const answer = missing.length ? `${missing.join("·")} 항목이 부족합니다.` : "Result·Analysis·Plan·Risk가 모두 포함되어 있습니다.";
    return { message: `${answer} 현재 초안은 4주 이력과 금주 New를 유지하고 있으므로, 확정되지 않은 효과와 차주 검증 일정을 우선 보완하는 것이 좋습니다.`, suggestions: ["K12 검증 계획을 Plan으로 작성해줘", "현재 문장을 더 구체적으로 만들어줘"] };
  }

  let sourceMode = "CHAT";
  let sourceTitle = "업무 Agent 대화 입력";
  let sourceText = compact;
  if (attachment) {
    sourceMode = "FILE";
    sourceTitle = attachment.name;
    if (!attachment.text && /파일.*요약|첨부.*분석|내용.*정리/.test(compact)) {
      return { message: `‘${attachment.name}’ 파일을 첨부했습니다. 이 시연에서는 파일명과 텍스트 발췌를 처리합니다. 실제 사내 GPT 연결 시 파일 본문을 직접 읽게 되며, 현재는 보고에 넣을 핵심 내용을 메시지에 함께 적어 주세요.`, suggestions: ["K12 검증 일정과 반복시험 결과를 보고문장으로 작성해줘"] };
    }
    sourceText = attachment.text ? `${attachment.text}\n${compact}` : compact;
  } else if (/메일|보낸 사람|받는 사람|제목\s*:|from\s*:|subject\s*:/i.test(compact)) {
    sourceMode = "MAIL";
    sourceTitle = compact.match(/(?:제목|subject)\s*:\s*([^\n]+)/i)?.[1]?.trim() || "사용자 선택 메일 발췌";
  }
  const cleaned = cleanAgentSource(sourceText, sourceMode);
  if (!cleaned) return { message: "분석할 내용을 입력하거나 파일을 첨부해 주세요." };
  const tag = inferAgentTag(cleaned);
  const draft = setAgentDraft({ sourceMode, sourceTitle, targetPageId: page?.id, tag, body: formalizeAgentNarrative(cleaned, tag) });
  const sourceLabel = agentSourceLabels[sourceMode];
  return { message: `${sourceLabel}에서 주간보고에 필요한 내용을 추출했습니다. 확정 사실과 계획을 임의로 합치지 않고 가장 적합한 문장 성격으로 분류했습니다.`, draft, suggestions: ["더 간결하게 다듬어줘", "Analysis 문장으로 바꿔줘", "이 내용을 보고에 반영해줘"] };
}

function showAgentTyping() {
  const messages = $("#agent-messages");
  const article = document.createElement("article");
  article.id = "agent-typing";
  article.className = "agent-message-row assistant typing";
  article.innerHTML = `<div class="agent-message-avatar">AI</div><div class="agent-message-content"><strong>업무 Agent</strong><div class="typing-dots"><i></i><i></i><i></i></div></div>`;
  messages.appendChild(article);
  messages.scrollTop = messages.scrollHeight;
}

function hideAgentTyping() { $("#agent-typing")?.remove(); }

function setAgentBusy(busy) {
  state.agent.busy = busy;
  const send = $("#agent-send");
  const input = $("#agent-chat-input");
  if (send) send.disabled = busy;
  if (input) input.disabled = busy;
}

function autoResizeAgentInput() {
  const input = $("#agent-chat-input");
  if (!input) return;
  input.style.height = "auto";
  input.style.height = `${Math.min(input.scrollHeight, 150)}px`;
}

async function handleAgentChatSubmit(event) {
  event?.preventDefault();
  if (state.agent.busy) return;
  const input = $("#agent-chat-input");
  const attachment = state.agent.attachment;
  const prompt = input.value.trim() || (attachment ? "첨부 파일에서 주간보고에 반영할 내용을 정리해줘" : "");
  if (!prompt) return;
  appendAgentMessage("user", prompt, { attachment });
  state.agent.conversationCount += 1;
  input.value = "";
  autoResizeAgentInput();
  state.agent.attachment = null;
  renderAgentAttachment();
  renderAgentContext();
  showAgentTyping();
  setAgentBusy(true);
  try {
    let response;
    if (state.agent.engine.mode === "LIVE" && state.agent.engine.configured) {
      response = await liveAgentApi("/api/agent/chat", {
        method: "POST",
        body: JSON.stringify({
          role: state.role,
          screen_id: currentScreen()?.screen_id || "",
          page_id: state.agent.activePageId,
          prompt,
          messages: state.agent.messages.slice(0, -1),
          current_draft: state.agent.draft,
          attachment,
        }),
      });
      if (response.draft) setAgentDraft(response.draft);
      if (response.action === "APPLY") {
        hideAgentTyping();
        await applyAgentDraft();
        return;
      }
      appendAgentMessage("assistant", response.reply, { draft: response.draft, suggestions: response.suggestions });
      return;
    }
    if (state.agent.engine.mode === "SETUP") {
      appendAgentMessage("assistant", "실제 업무 Agent 연결 설정이 아직 완료되지 않았습니다. 서버에 승인된 LLM Endpoint·Model·인증정보를 설정한 뒤 다시 실행해 주세요.", { suggestions: ["연결 설정 방법을 알려줘"] });
      return;
    }
    await new Promise((resolve) => setTimeout(resolve, 380));
    response = createAgentResponse(prompt, attachment);
    if (response.apply) {
      hideAgentTyping();
      await applyAgentDraft();
      return;
    }
    appendAgentMessage("assistant", response.message, { draft: response.draft, suggestions: response.suggestions });
  } catch (error) {
    appendAgentMessage("assistant", `실제 업무 Agent 호출을 완료하지 못했습니다. ${error.message}`);
    showToast(error.message, true);
  } finally {
    hideAgentTyping();
    setAgentBusy(false);
    $("#agent-chat-input")?.focus();
  }
}

async function applyAgentDraft() {
  const draft = state.agent.draft;
  if (!draft?.body) { appendAgentMessage("assistant", "먼저 업무이력·메일·파일에서 보고문장을 만들어 주세요."); return; }
  try {
    if (state.role !== "MEMBER") {
      $("#role-select").value = "MEMBER";
      await loadRole("MEMBER", "MBR-07");
    }
    const page = (state.data.work_pages || []).find((item) => item.id === draft.targetPageId);
    if (!page) throw new Error("선택한 업무페이지를 찾을 수 없습니다.");
    const pageItemIds = String(page.work_item_ids || "").split(",").filter(Boolean);
    const workItem = state.data.work_items.find((item) => pageItemIds.includes(item.id));
    if (!workItem) throw new Error("업무페이지에 연결된 본인 WorkItem이 없습니다.");

    const includedPages = new Set((state.data.submission_pages || [])
      .filter((item) => item.submission_id === "sub_member1" && Number(item.included) === 1)
      .map((item) => item.work_page_id));
    includedPages.add(page.id);
    await api("/api/submission/items", {
      method: "POST",
      body: JSON.stringify({ role: "MEMBER", work_page_ids: [...includedPages] }),
    });
    await api("/api/worklogs", {
      method: "POST",
      body: JSON.stringify({
        role: "MEMBER",
        work_item_id: workItem.id,
        entry_type: draft.tag,
        occurred_on: "2026-08-24",
        narrative: draft.body,
      }),
    });
    if (["MAIL", "FILE"].includes(draft.sourceMode)) {
      const extension = draft.sourceMode === "MAIL" ? ".eml" : ".txt";
      const safeTitle = draft.sourceTitle.replace(/[\\/:*?"<>|]/g, "_").slice(0, 60) || agentSourceLabels[draft.sourceMode];
      await api("/api/evidence", {
        method: "POST",
        body: JSON.stringify({
          role: "MEMBER",
          work_item_id: workItem.id,
          file_name: `${safeTitle}${/\.[a-z0-9]+$/i.test(safeTitle) ? "" : extension}`,
          locator: `업무 Agent 수집 · ${agentSourceLabels[draft.sourceMode]} · 사용자 선택 발췌`,
          security_label: "CONFIDENTIAL",
        }),
      });
    }
    const generated = await api("/api/agent/draft", { method: "POST", body: JSON.stringify({ role: "MEMBER", screen_id: "MBR-07" }) });
    state.generatedDraft = generated.content;
    await refreshCurrent();
    navigateTo("MBR-07");
    appendAgentMessage("assistant", `완료했습니다. ‘${page.title}’ 업무페이지의 W34 마지막에 ${draft.tag} 문장을 파란색 New로 반영했습니다. 왼쪽 초안에서 바로 확인할 수 있습니다.`, { suggestions: ["반영된 초안을 다시 검토해줘", "다른 업무페이지의 이력도 정리해줘"] });
    state.agent.draft = null;
    showToast(`업무 Agent 문장을 ${page.page_code}에 New로 추가했습니다.`);
  } catch (error) {
    showToast(error.message, true);
  }
}

function setAgentPrompt(prompt) {
  const input = $("#agent-chat-input");
  let value = prompt;
  if (/아래 메일|메일 예시/.test(prompt)) {
    value = "아래 메일에서 주간보고에 추가할 내용만 추출해줘.\n\n보낸 사람: ESWA 생산팀\n받는 사람: RSND자동보정팀\n제목: K12 검증 생산 일정 협의\n\nK12 검증 생산은 W35 수요일 우선 배정이 가능합니다. M08·M11과 동일 조건으로 시험하려면 제품 전환 전까지 조건표를 전달해주시기 바랍니다. 시험 완료 후 결과를 공동 확인할 예정입니다.";
  }
  input.value = value;
  autoResizeAgentInput();
  input.focus();
}

function renderAgentAttachment() {
  const tray = $("#agent-attachment-tray");
  const attachment = state.agent.attachment;
  tray.hidden = !attachment;
  tray.innerHTML = attachment ? `<div class="agent-attachment-card"><div>▤</div><span><strong>${escapeHtml(attachment.name)}</strong><small>${escapeHtml(attachment.type || "업무파일")}</small></span><button type="button" data-agent-remove-file aria-label="첨부 삭제">×</button></div>` : "";
}

async function handleAgentFile(event) {
  const file = event.target.files?.[0];
  if (!file) return;
  const textLike = /\.(txt|md|csv|eml|log)$/i.test(file.name) || /^text\//.test(file.type);
  state.agent.attachment = { name: file.name, type: file.type || "업무파일", text: textLike && file.size <= 2_000_000 ? await file.text() : "" };
  renderAgentAttachment();
  $("#agent-chat-input").focus();
  event.target.value = "";
}

function newAgentChat() {
  $("#agent-messages").querySelectorAll(".agent-message-row").forEach((item) => item.remove());
  $("#agent-welcome").hidden = false;
  state.agent.draft = null;
  state.agent.attachment = null;
  state.agent.conversationCount = 0;
  state.agent.messages = [];
  renderAgentAttachment();
  renderAgentContext();
  $("#agent-chat-input").value = "";
  autoResizeAgentInput();
}

function bindScreenForms() {
  const questionForm = $("#question-form");
  if (questionForm) questionForm.addEventListener("submit", handleQuestion);
  const searchForm = $("#search-form");
  if (searchForm) searchForm.addEventListener("submit", (event) => {
    event.preventDefault();
    $("#search-results")?.removeAttribute("hidden");
    showToast("권한 범위 안에서 WorkItem·KPI·보고서를 검색했습니다.");
  });
  const reportEditor = $("#structured-report-editor");
  if (reportEditor) {
    reportEditor.addEventListener("input", syncStructuredReportEditor);
    reportEditor.addEventListener("change", (event) => {
      const select = event.target.closest(".block-tag-select");
      if (select) {
        const block = select.closest(".structured-edit-block");
        const tagPreview = $(".block-tag-preview", block);
        const statuses = ($(".block-status-tags", block)?.value || "").split(",").filter(Boolean);
        if (tagPreview) tagPreview.innerHTML = reportTag(select.value) + statuses.map(reportTag).join("");
        block.dataset.tag = select.value.toLowerCase();
      }
      syncStructuredReportEditor();
    });
  }
  const workPageEditor = $("#work-page-editor");
  if (workPageEditor) {
    workPageEditor.addEventListener("input", syncWorkPageEditor);
    workPageEditor.addEventListener("change", (event) => {
      const select = event.target.closest(".block-tag-select");
      if (select) {
        const block = select.closest(".structured-edit-block");
        const statuses = ($(".block-status-tags", block)?.value || "").split(",").filter(Boolean);
        const tagPreview = $(".block-tag-preview", block);
        if (tagPreview) tagPreview.innerHTML = reportTag(select.value) + statuses.map(reportTag).join("");
        block.dataset.tag = select.value.toLowerCase();
      }
      syncWorkPageEditor();
    });
  }
}

function renderByKind(screen) {
  const renderers = {
    dashboard: () => renderDashboard(screen), login: renderLogin, context: renderContext,
    inbox: renderInbox, search: renderSearch, notifications: renderNotifications,
    worklist: renderWorklist, detail: renderWorkDetail, entry: renderEntry,
    uploadEvidence: renderEvidenceUpload, selection: () => renderSelection(false),
    memberEditor: () => renderEditor("TEAM_MEMBER"), submission: renderSubmission,
    submissionMatrix: renderSubmissionMatrix, memberDetail: renderMemberDetail,
    selectionLeader: () => renderSelection(true), leaderEditor: () => renderEditor("TEAM"),
    compareEvidence: renderEvidenceCompare, approve: renderApproval, history: renderHistory,
    teamMatrix: renderTeamMatrix, collaboration: renderCollaboration, conflict: renderConflict,
    deptEditor: () => renderEditor("DEPARTMENT"), decisionRegister: renderDecisionRegister,
    qa: renderQa, groupEditor: () => renderEditor("GROUP"), redaction: renderRedaction,
    export: renderExport, evidence: renderEvidenceTrace, question: renderQuestion,
    decision: renderDecision, trend: renderTrend, snapshotUpload: renderSnapshotUpload,
    mapping: renderMapping, validation: renderValidation, snapshotCompare: renderSnapshotCompare,
    snapshotApprove: renderSnapshotApprove, catalog: renderMetricCatalog, iam: renderIam,
    calendar: renderCalendar, release: renderRelease, policy: renderPolicy,
    audit: renderAudit, health: renderHealth,
  };
  return (renderers[screen.kind] || (() => renderGeneric(screen)))();
}

function renderWorkflow(activeIndex) {
  const stages = ["팀원 작성", "팀장 검토", "담당 승인", "기획 QA", "그룹장 보고"];
  return `<div class="steps">${stages.map((label, index) => `<div class="step ${index < activeIndex ? "done" : index === activeIndex ? "active" : ""}"><strong>${index + 1}</strong><span>${label}</span></div>`).join("")}</div>`;
}

function renderKpis() {
  return `<div class="metrics kpi-metrics">${state.data.snapshots.slice(0, 4).map((item) => {
    const value = `${Number(item.display_value).toFixed(1)}${item.unit}`;
    const delta = item.previous_value == null ? "전주 없음" : `전주 ${Number(item.previous_value).toFixed(1)}${item.unit}`;
    return metricCard(item.metric_name, value, `${delta} · ${item.verification_state}`, stateClass(item.verification_state));
  }).join("")}</div>`;
}

function reportByLevel(level) {
  return state.data.reports.find((report) => report.report_level === level && report.report_code.includes("W34"));
}

function renderDashboard() {
  const d = state.data;
  const role = state.role;
  let summary;
  let activeStage = 0;
  if (role === "MEMBER") {
    const submission = d.submissions.find((item) => item.member_name === d.principal.display_name);
    summary = [["내 업무페이지", d.counts.work_pages || 0, "법인·공정·프로젝트별"], ["금주 Worklog", d.worklogs.filter((item) => d.work_items.some((work) => work.id === item.work_item_id) && String(item.occurred_on) >= "2026-08-17").length, "공동작성 기록 포함"], ["제출 상태", submission?.status || "미작성", `Version ${submission?.version || 0}`]];
  } else if (role === "LEADER") {
    summary = [["팀원 제출", `${d.counts.submitted_members}/${d.counts.members_total}`, "금주 제출 현황"], ["검토 업무페이지", d.counts.work_pages || 0, "페이지 단위 선택"], ["팀 보고", reportByLevel("TEAM")?.status || "DRAFT", "서술형 원문 유지"]]; activeStage = 1;
  } else if (role === "DEPT") {
    summary = [["하위 팀", 4, "자동보정담당"], ["협업 안건", d.collaborations.length, "중복은 1회 집계"], ["미결 Decision", d.counts.open_decisions, "Owner·Due 확인"]]; activeStage = 2;
  } else if (role === "PLANNING") {
    summary = [["담당 보고", 4, "승인본 기준"], ["Open QA", d.counts.open_qa, "BLOCK 우선"], ["그룹 보고", reportByLevel("GROUP")?.status || "DRAFT", "그룹장 관점 재구성"]]; activeStage = 3;
  } else if (role === "HEAD") {
    summary = [["대표 KPI", d.snapshots.length, "기준시각·상태 표시"], ["결정 요청", d.counts.open_decisions, "이번 주 검토"], ["지연 Action", d.action_items.filter((item) => item.status === "DELAYED").length, "담당 확인 필요"]]; activeStage = 4;
  } else if (role === "DATA_OWNER") {
    summary = [["공식 Snapshot", `${d.counts.snapshots_locked}/${d.counts.snapshots_total}`, "승인·잠금"], ["검증 오류", d.qa_issues.filter((item) => item.resource_type === "METRIC_SNAPSHOT" && item.status === "OPEN").length, "PD 파일 확인"], ["Cut-off", "08/23", "23:59 기준"]];
  } else if (role === "ADMIN") {
    summary = [["Portal", "정상", "127.0.0.1"], ["SQLite", "정상", "Foreign key ON"], ["감사 이벤트", d.audit_events.length, "최근 50건"]];
  } else {
    summary = [["처리할 업무", 5, "역할 범위 기준"], ["알림", 3, "마감·반려·오류"], ["보고 주차", "W34", "진행 중"]];
  }
  const itemRows = d.work_items.slice(0, 5).map((item) => `<tr><td><code>${escapeHtml(item.work_item_code)}</code><br><span class="small muted">${escapeHtml(item.organization_name)}</span></td><td>${escapeHtml(item.title)}</td><td>${badge(item.state)}</td><td>${formatDate(item.target_date)}</td></tr>`);
  return `<div class="hero-strip"><div><span class="eyebrow-text">2026 W34</span><h2>${escapeHtml(d.principal.role_label)} 업무 공간</h2><p>${escapeHtml(d.principal.organization_name)} 범위의 기준 데이터와 승인 상태입니다.</p></div><div class="hero-code"><span>Portal 기준</span><strong>${escapeHtml(d.cycle.cycle_code)}</strong><small>${escapeHtml(d.cycle.state)}</small></div></div><div class="metrics">${summary.map(([a, b, c]) => metricCard(a, b, c)).join("")}</div>${role !== "ADMIN" ? renderKpis() : ""}${card("주간보고 진행 단계", renderWorkflow(activeStage))}${card("우선 검토 업무", table(["Code / 조직", "업무", "상태", "목표일"], itemRows))}`;
}

function renderLogin() {
  return `<div class="login-layout"><section class="login-panel"><div class="brand-mark large">DX</div><h2>Manufacturing DX Weekly</h2><p>회사 계정으로 로그인하면 역할·조직·보고주차에 맞는 업무 공간을 생성합니다.</p><button class="button primary wide" data-demo="login">회사 SSO로 로그인</button><div class="small muted">시연에서는 인증을 생략하고 역할 선택기로 전환합니다.</div></section>${card("인증 통제", `<ul class="list"><li><strong>OIDC Claim 검증</strong><span>Issuer · Audience · MFA · 계정 활성 여부</span></li><li><strong>Principal 생성</strong><span>User · RoleAssignment · Organization Scope</span></li><li><strong>Deny by default</strong><span>권한이 없는 보고·파일·AI 도구는 노출하지 않음</span></li></ul>`)}</div>`;
}

function renderContext() {
  const options = [["팀원", "RSND자동보정팀", "본인 WorkItem 작성·제출"], ["팀장", "RSND자동보정팀", "팀원 검토·팀 보고 승인"], ["담당", "자동보정담당", "4개 팀 종합·기획 제출"]];
  return `${card("현재 업무 범위 선택", `<div class="context-grid">${options.map(([r, o, x], i) => `<label class="context-card"><input type="radio" name="context" ${i === 0 ? "checked" : ""}><span>${badge(r)}<strong>${escapeHtml(o)}</strong><small>${escapeHtml(x)}</small></span></label>`).join("")}</div><div class="button-row"><button class="button primary" data-demo="context">선택 범위로 시작</button></div>`)}${card("적용 원칙", `<div class="notice"><strong>역할과 조직 범위는 모든 조회·Agent 검색·승인의 기준입니다.</strong>복수 역할 사용자는 업무 시작 전에 하나의 Context를 명시적으로 선택합니다.</div>`)}`;
}

function renderInbox() {
  const tasks = [["KPI 검증 오류", "SNP-PD-2026-W34-004", "오늘 10:00", "BLOCK"], ["팀원 제출 검토", "SUB-RSND-2026-W34-002", "오늘 12:00", "OPEN"], ["Decision 요청", "DEC-RSND-2026-0008", "08/25", "REQUESTED"], ["지연 Action", "ACT-SOL-2026-0031", "08/26", "DELAYED"]];
  return `${card("내가 처리할 업무", table(["업무", "Resource", "마감", "상태"], tasks.map((row) => `<tr><td><strong>${escapeHtml(row[0])}</strong></td><td><code>${escapeHtml(row[1])}</code></td><td>${escapeHtml(row[2])}</td><td>${badge(row[3])}</td></tr>`)))}${card("Agent 우선순위 설명", `<div class="notice"><strong>1순위: 보고를 차단하는 KPI 중복 Key</strong>마감 영향, BLOCK 여부, 후속 단계 수를 기준으로 정렬했습니다. Agent는 상태를 자동 변경하지 않습니다.</div>`)}`;
}

function renderSearch() {
  const rows = state.data.work_items.slice(0, 4).map((item) => `<tr><td>${badge("WorkItem", "WORK")}</td><td><code>${escapeHtml(item.work_item_code)}</code></td><td>${escapeHtml(item.title)}</td><td>${escapeHtml(item.organization_name)}</td></tr>`);
  return `${card("권한 기반 통합 검색", `<form id="search-form" class="inline search-bar"><input class="grow" value="Jamming 자동보정 PD Loss" aria-label="검색어"><button class="button primary">검색</button></form><p class="small muted">자연어를 WorkItem·KPI·Evidence·Report ID와 연결합니다. 권한 밖 문서는 존재 여부도 노출하지 않습니다.</p>`)}<section id="search-results" class="card"><h3>검색 결과</h3>${table(["구분", "Code", "제목", "조직"], rows)}<div class="source-chips">${state.data.snapshots.slice(0, 2).map((s) => `<span class="source-chip">${escapeHtml(s.snapshot_code)}</span>`).join("")}</div></section>`;
}

function renderNotifications() {
  const list = [["BLOCK", "PD Snapshot 중복 Key 1건", "Data Owner · 8분 전"], ["DUE", "팀원 제출 마감까지 1일", "2026-08-25 17:00"], ["RETURN", "수치 근거 보완 요청", "기획팀 · 어제"], ["ACTION", "ACT-SOL-2026-0031 지연", "목표 08/26"]];
  return card("알림·마감", `<ul class="notification-list">${list.map(([type, title, meta], i) => `<li class="${i === 0 ? "unread" : ""}">${badge(type)}<div><strong>${escapeHtml(title)}</strong><span>${escapeHtml(meta)}</span></div><button class="button secondary" data-demo="notification">열기</button></li>`).join("")}</ul>`);
}

function renderWorklist() {
  const rows = state.data.work_items.map((item) => `<tr><td><input class="row-check" type="checkbox" aria-label="${escapeHtml(item.work_item_code)} 선택"></td><td><code>${escapeHtml(item.work_item_code)}</code></td><td><strong>${escapeHtml(item.title)}</strong><br><span class="small muted">${escapeHtml(item.objective)}</span></td><td>${badge(item.state)}</td><td>${escapeHtml(item.metric_code || "—")}</td><td>${escapeHtml(item.collaboration_code || "—")}</td><td>${formatDate(item.target_date)}</td></tr>`);
  return `${card("내 업무 Portfolio", `<div class="toolbar"><div class="inline"><select><option>전체 상태</option><option>진행 중</option><option>계획</option></select><input placeholder="Code 또는 업무명"></div><span class="muted small">${rows.length}건</span></div>${table(["", "WorkItem ID", "업무·목표", "상태", "KPI", "Collaboration", "목표일"], rows)}`)}${card("Code 작성 가이드", `<div class="code-guide"><code>WI-RSND-2026-0032</code><span><b>WI</b> 업무 레코드</span><span><b>RSND</b> 소유 팀</span><span><b>2026</b> 생성 연도</span><span><b>0032</b> 순번</span></div>`)}`;
}

function renderWorkDetail() {
  const item = state.data.work_items[0];
  const logs = state.data.worklogs.filter((log) => log.work_item_id === item.id);
  const ev = state.data.evidence.filter((evidence) => evidence.work_item_id === item.id);
  return `<div class="grid-2"><section class="card"><div class="card-top"><div><code>${escapeHtml(item.work_item_code)}</code><h2>${escapeHtml(item.title)}</h2></div>${badge(item.state)}</div><dl class="detail-grid"><div><dt>업무 목표</dt><dd>${escapeHtml(item.objective)}</dd></div><div><dt>Owner</dt><dd>${escapeHtml(item.owner_name)} · ${escapeHtml(item.organization_name)}</dd></div><div><dt>KPI</dt><dd>${escapeHtml(item.metric_code)}</dd></div><div><dt>Collaboration</dt><dd>${escapeHtml(item.collaboration_code)}</dd></div><div><dt>기간</dt><dd>${formatDate(item.start_date)} – ${formatDate(item.target_date)}</dd></div><div><dt>보안등급</dt><dd>${badge(item.security_label)}</dd></div></dl></section>${card("연결 Resource", `<ul class="list"><li><strong>공통 KPI Snapshot</strong><span>SNP-PD-2026-W34-004 · PROVISIONAL</span></li>${ev.map((x) => `<li><strong>${escapeHtml(x.evidence_code)}</strong><span>${escapeHtml(x.file_name)} · ${escapeHtml(x.locator)}</span></li>`).join("")}<li><strong>협업 안건</strong><span>${escapeHtml(item.collaboration_code)}</span></li></ul>`)}</div>${card("업무 이력", `<div class="timeline">${logs.map((log) => `<article><span>${formatDate(log.occurred_on)}</span><div>${badge(log.entry_type)}<p>${escapeHtml(log.narrative)}</p></div></article>`).join("")}</div>`)}`;
}

const reportTagLabels = {
  BACKGROUND: "Background", FACT: "Fact", KPI: "KPI", RESULT: "Result",
  ANALYSIS: "Analysis", PLAN: "Plan", NEXT: "Plan", RISK: "Risk",
  DECISION: "Decision", PROVISIONAL: "Provisional", VERIFIED: "Verified",
  NEW: "New",
};

const reportPrimaryTags = ["BACKGROUND", "FACT", "RESULT", "KPI", "ANALYSIS", "RISK", "PLAN", "DECISION"];
const reportStateTags = ["PROVISIONAL", "VERIFIED", "NEW"];
const reportTagDescriptions = {
  BACKGROUND: "배경·목표", FACT: "확인된 사실", RESULT: "수행·확인 결과", KPI: "공통 Snapshot 수치",
  ANALYSIS: "해석·원인 가설", RISK: "일정·품질 위험", PLAN: "차주 실행계획", DECISION: "결정·지원 요청",
  NEW: "금주 추가·변경 내용",
};

function isResourceCode(token) {
  return /^(WI|RPG|SNP|COL|EVD|DEC|ACT|RPT|MET)-/i.test(String(token || ""));
}

function reportTag(token) {
  const normalized = String(token || "").toUpperCase();
  if (reportTagLabels[normalized]) {
    return `<span class="report-tag tag-${normalized.toLowerCase()}">${escapeHtml(reportTagLabels[normalized])}</span>`;
  }
  return `<code class="report-code">${escapeHtml(token)}</code>`;
}

function parseReportBlocks(content) {
  if (!String(content || "").trim()) return [];
  return String(content).trim().split(/\n\s*\n/).map((paragraph) => {
    const tokens = [...paragraph.matchAll(/\[([^\]]+)\]/g)].map((item) => item[1]);
    const normalized = tokens.map((token) => String(token).toUpperCase() === "NEXT" ? "PLAN" : String(token).toUpperCase());
    const tag = normalized.find((token) => reportPrimaryTags.includes(token)) || "RESULT";
    const statusTags = [...new Set(normalized.filter((token) => reportStateTags.includes(token)))];
    const resources = [...new Set(tokens.filter(isResourceCode))];
    const removable = [...new Set([
      ...tokens.filter(isResourceCode),
      ...tokens.filter((token) => reportPrimaryTags.includes(String(token).toUpperCase()) || String(token).toUpperCase() === "NEXT"),
      ...tokens.filter((token) => reportStateTags.includes(String(token).toUpperCase())),
    ])];
    let body = paragraph;
    removable.forEach((token) => { body = body.split(`[${token}]`).join(""); });
    body = body.replace(/^[ \t]+/gm, "").replace(/[ \t]+$/gm, "").trim();
    return { tag, statusTags, resources, body };
  });
}

function renderTaggedReport(content) {
  const blocks = parseReportBlocks(content);
  if (!blocks.length) return `<div class="empty-state">초안을 생성하면 Tag가 적용된 보고서가 표시됩니다.</div>`;
  return blocks.map((block) => `<article class="tagged-report-block"><div class="report-tag-row">${reportTag(block.tag)}${block.statusTags.map(reportTag).join("")}</div><div class="tagged-report-copy">${escapeHtml(block.body).replaceAll("\n", "<br>")}</div>${block.resources.length ? `<div class="report-resource-row"><span>자동 연결 근거</span>${block.resources.map(reportTag).join("")}</div>` : ""}</article>`).join("");
}

function parseReportPages(content) {
  const pages = [];
  const pattern = /@@PAGE\|([^\n]+)@@\n([\s\S]*?)\n@@ENDPAGE@@/g;
  for (const match of String(content || "").matchAll(pattern)) {
    const fields = match[1].split("|", 6);
    if (fields.length !== 6) continue;
    const [pageCode, title, siteScope, processScope, projectScope, authors] = fields;
    pages.push({ pageCode, title, siteScope, processScope, projectScope, authors, blocks: parseReportBlocks(match[2]) });
  }
  return pages;
}

function renderReportPage(page, compact = false) {
  const lines = page.blocks.map((block) => {
    const isNew = block.statusTags.includes("NEW");
    return `<section class="weekly-page-line ${isNew ? "is-new" : ""}"><div class="weekly-page-line-meta">${reportTag(block.tag)}${block.statusTags.map(reportTag).join("")}</div><p class="weekly-page-copy">${escapeHtml(block.body).replaceAll("\n", "<br>")}</p></section>`;
  }).join("");
  return `<article class="weekly-report-page ${compact ? "compact-page" : ""}"><header class="weekly-page-header"><div><span class="weekly-page-code">${escapeHtml(page.pageCode)}</span><h3>${escapeHtml(page.title)}</h3><p>${escapeHtml(page.projectScope)}</p></div><div class="weekly-page-meta"><span><b>법인</b>${escapeHtml(page.siteScope)}</span><span><b>공정</b>${escapeHtml(page.processScope)}</span><span><b>작성</b>${escapeHtml(page.authors)}</span></div></header><div class="weekly-page-retention"><span>최근 4주 이력 유지</span><span class="blue-rule">파란색 = 금주 신규·업데이트</span></div><div class="weekly-page-body">${lines || `<div class="empty-state">표시할 업무 내용이 없습니다.</div>`}</div></article>`;
}

function renderReportPages(content, compact = false) {
  const pages = parseReportPages(content);
  if (!pages.length) return renderTaggedReport(content);
  return `<div class="weekly-page-stack">${pages.map((page) => renderReportPage(page, compact)).join("")}</div>`;
}

function reportTagOptions(selected) {
  return reportPrimaryTags.map((tag) => `<option value="${tag}" ${tag === selected ? "selected" : ""}>${reportTagLabels[tag]} · ${reportTagDescriptions[tag]}</option>`).join("");
}

function renderStructuredReportBlock(block) {
  const tag = reportPrimaryTags.includes(block.tag) ? block.tag : "RESULT";
  const resources = [...new Set(block.resources || [])];
  const statusTags = [...new Set(block.statusTags || [])].filter((item) => reportStateTags.includes(item));
  return `<article class="structured-edit-block ${statusTags.includes("NEW") ? "is-new" : ""}" data-tag="${tag.toLowerCase()}"><div class="structured-block-top"><div class="block-tag-preview">${reportTag(tag)}${statusTags.map(reportTag).join("")}</div><label class="block-tag-control"><span>문단 유형</span><select class="block-tag-select">${reportTagOptions(tag)}</select></label><button type="button" class="button ghost compact-button" data-remove-report-block>문단 삭제</button></div><textarea class="block-body" spellcheck="false" aria-label="${escapeHtml(reportTagLabels[tag])} 문단 내용">${escapeHtml(block.body || "")}</textarea><input type="hidden" class="block-resources" value="${escapeHtml(resources.join(","))}"><input type="hidden" class="block-status-tags" value="${escapeHtml(statusTags.join(","))}"><div class="linked-resource-row"><span>AI 자동 연결</span>${resources.length ? resources.map(reportTag).join("") : `<em>현재 보고서의 업무 맥락에서 저장 시 연결</em>`}</div></article>`;
}

function defaultReportResourceCode() {
  return state.data?.work_items?.[0]?.work_item_code || "";
}

function renderStructuredReportEditor(content) {
  const blocks = parseReportBlocks(content);
  const editorBlocks = blocks.length ? blocks : [{ tag: "RESULT", statusTags: [], resources: [defaultReportResourceCode()].filter(Boolean), body: "" }];
  return `<div id="structured-report-editor" class="structured-report-editor">${editorBlocks.map(renderStructuredReportBlock).join("")}</div><div class="structured-editor-footer"><button type="button" class="button secondary" data-add-report-block>+ 문단 추가</button><span>전주 문장은 유지되고, 금주 추가 문단에는 New가 자동 표시됩니다.</span></div>`;
}

function renderWorkPageEditor(page) {
  const blocks = page.blocks.length ? page.blocks : [{ tag: "RESULT", statusTags: ["NEW"], resources: [page.pageCode], body: "" }];
  return `<article class="work-page-editor" data-page-code="${escapeHtml(page.pageCode)}" data-page-title="${escapeHtml(page.title)}" data-page-site="${escapeHtml(page.siteScope)}" data-page-process="${escapeHtml(page.processScope)}" data-page-project="${escapeHtml(page.projectScope)}" data-page-authors="${escapeHtml(page.authors)}"><header class="work-page-editor-header"><div><span>${escapeHtml(page.pageCode)}</span><strong>${escapeHtml(page.title)}</strong></div><small>${escapeHtml(page.siteScope)} · ${escapeHtml(page.processScope)} · ${escapeHtml(page.authors)}</small></header><div class="work-page-edit-sections">${blocks.map(renderStructuredReportBlock).join("")}</div><div class="work-page-editor-actions"><button type="button" class="button secondary" data-add-page-section>+ 금주 문장 추가</button><span>새 문장은 이 페이지의 마지막에 추가되고 파란색 New로 표시됩니다.</span></div></article>`;
}

function renderWorkPagesEditor(content) {
  const pages = parseReportPages(content);
  if (!pages.length) return renderStructuredReportEditor(content);
  return `<div id="work-page-editor" class="work-pages-editor">${pages.map(renderWorkPageEditor).join("")}</div>`;
}

function composeStructuredReportContent() {
  const blocks = [...document.querySelectorAll(".structured-edit-block")].map((block) => {
    const tag = $(".block-tag-select", block)?.value || "RESULT";
    const body = $(".block-body", block)?.value.trim() || "";
    const resources = ($(".block-resources", block)?.value || "").split(",").map((item) => item.trim()).filter(Boolean);
    const statusTags = ($(".block-status-tags", block)?.value || "").split(",").map((item) => item.trim()).filter((item) => reportStateTags.includes(item));
    if (!body) return "";
    const tokens = [...new Set(resources)].map((item) => `[${item}]`).join("") + `[${tag}]` + [...new Set(statusTags)].map((item) => `[${item}]`).join("");
    return `${tokens} ${body}`;
  }).filter(Boolean);
  return blocks.join("\n\n");
}

function composeWorkPageContent() {
  const pages = [...document.querySelectorAll(".work-page-editor")].map((page) => {
    const blocks = [...page.querySelectorAll(".structured-edit-block")].map((block) => {
      const tag = $(".block-tag-select", block)?.value || "RESULT";
      const body = $(".block-body", block)?.value.trim() || "";
      const resources = ($(".block-resources", block)?.value || "").split(",").map((item) => item.trim()).filter(Boolean);
      const statusTags = ($(".block-status-tags", block)?.value || "").split(",").map((item) => item.trim()).filter((item) => reportStateTags.includes(item));
      if (!body) return "";
      const tokens = [...new Set(resources)].map((item) => `[${item}]`).join("") + `[${tag}]` + [...new Set(statusTags)].map((item) => `[${item}]`).join("");
      return `${tokens} ${body}`;
    }).filter(Boolean);
    if (!blocks.length) return "";
    const header = [page.dataset.pageCode, page.dataset.pageTitle, page.dataset.pageSite, page.dataset.pageProcess, page.dataset.pageProject, page.dataset.pageAuthors].join("|");
    return `@@PAGE|${header}@@\n${blocks.join("\n\n")}\n@@ENDPAGE@@`;
  }).filter(Boolean);
  return pages.join("\n\n");
}

function syncWorkPageEditor() {
  const content = composeWorkPageContent();
  const preview = $("#formatted-report-preview");
  const machinePreview = $("#machine-record-preview");
  if (preview) preview.innerHTML = renderReportPages(content);
  if (machinePreview) machinePreview.textContent = content;
}

function syncStructuredReportEditor() {
  const content = composeStructuredReportContent();
  const preview = $("#formatted-report-preview");
  const machinePreview = $("#machine-record-preview");
  if (preview) preview.innerHTML = renderTaggedReport(content);
  if (machinePreview) machinePreview.textContent = content;
}

function renderEntry() {
  const recent = state.data.worklogs
    .filter((log) => state.data.work_items.some((item) => item.id === log.work_item_id))
    .slice()
    .sort((left, right) => String(right.occurred_on).localeCompare(String(left.occurred_on)))
    .slice(0, 5);
  const options = state.data.work_items.map((item) => `<option value="${escapeHtml(item.id)}">${escapeHtml(item.work_item_code)} · ${escapeHtml(item.title)}</option>`).join("");
  return `<div class="grid-2">${card("Worklog 추가 작성", `<div class="notice"><strong>여기에 저장한 내용은 다음 화면부터 계속 사용됩니다.</strong>Evidence 연결, 업무페이지 선택, AI 초안과 팀장 검토 화면에 동일 Record가 표시됩니다.</div><div class="form-grid"><label class="full">WorkItem<select id="worklog-workitem">${options}</select></label><label>기록 유형<select id="worklog-type"><option value="RESULT">RESULT · 수행 결과</option><option value="FACT">FACT · 확인된 사실</option><option value="ANALYSIS">ANALYSIS · 분석/가설</option><option value="PLAN" selected>PLAN · 차주 계획</option><option value="RISK">RISK · 위험</option></select></label><label>발생일<input id="worklog-date" type="date" value="2026-08-24"></label><label class="full">추가 작성<textarea id="worklog-narrative">K12 검증용 생산 일정을 W35 우선 배정한 후, 제품별 상·하한 및 예외조건을 확정하고 동일 조건 기준으로 PD Loss 효과를 재산출하겠습니다.</textarea></label></div><div class="button-row"><button class="button secondary" data-demo="apply-suggestion">AI 문장 다듬기</button><button class="button primary" data-save-worklog>저장하고 다음 화면으로</button></div>`)}${card("최근 작성 이력", `<div class="timeline compact-timeline">${recent.map((log) => `<article><span>${formatDate(log.occurred_on)}</span><div>${reportTag(log.entry_type)} <code>${escapeHtml(log.work_item_code)}</code><p>${escapeHtml(log.narrative)}</p></div></article>`).join("")}</div>`)}</div>`;
}

function renderEvidenceUpload() {
  const rows = state.data.evidence.map((item) => `<tr><td><code>${escapeHtml(item.evidence_code)}</code></td><td>${escapeHtml(item.file_name)}</td><td>${escapeHtml(item.locator || "—")}</td><td>${badge(item.scan_status)}</td><td>${badge(item.security_label)}</td></tr>`);
  const options = state.data.work_items.map((item) => `<option value="${escapeHtml(item.id)}">${escapeHtml(item.work_item_code)} · ${escapeHtml(item.title)}</option>`).join("");
  const latestLog = state.data.worklogs.find((log) => state.data.work_items.some((item) => item.id === log.work_item_id));
  return `${card("업무파일 등록", `<div class="continuity-banner"><span>직전 작성</span><strong>${latestLog ? escapeHtml(latestLog.narrative) : "추가 기록 없음"}</strong></div><div class="dropzone compact-dropzone"><div class="upload-icon">⇧</div><strong>파일명과 원문 위치를 등록하십시오</strong><span>시연에서는 파일 Metadata와 연결관계를 저장합니다.</span></div><div class="form-grid compact"><label>연결 WorkItem<select id="evidence-workitem">${options}</select></label><label>보안등급<select id="evidence-security"><option>CONFIDENTIAL</option><option>INTERNAL</option></select></label><label class="full">파일명<input id="evidence-file-name" value="K12_추가검증_결과.xlsx"></label><label class="full">원문 위치·범위<input id="evidence-locator" value="Result!B4:H18"></label></div><div class="button-row"><button class="button primary" data-save-evidence>등록하고 업무페이지 선택으로</button></div>`)}${card("등록된 Evidence", table(["Evidence ID", "파일", "Locator", "검사", "등급"], rows))}`;
}

function pageContributorsLabel(page) {
  return String(page.contributors || "").split(",").filter(Boolean).map((entry) => {
    const [name, role] = entry.split(":");
    return `${name}${role === "PRIMARY" ? "(주)" : "(공동)"}`;
  }).join(" · ") || page.primary_owner_name || "—";
}

function pageWorkItemIds(page) {
  return String(page.work_item_ids || "").split(",").filter(Boolean);
}

function renderSelection(leaderMode) {
  const selection = new Map((state.data.submission_pages || []).filter((item) => item.submission_id === "sub_member1").map((item) => [item.work_page_id, Boolean(item.included)]));
  const rows = (state.data.work_pages || []).map((page, index) => {
    const itemIds = pageWorkItemIds(page);
    const logs = state.data.worklogs.filter((log) => itemIds.includes(log.work_item_id) && String(log.occurred_on) >= "2026-07-27");
    const newLogs = logs.filter((log) => String(log.occurred_on) >= "2026-08-17");
    const evidenceCount = state.data.evidence.filter((evidence) => itemIds.includes(evidence.work_item_id)).length;
    const checked = leaderMode ? index < 3 : (selection.has(page.id) ? selection.get(page.id) : logs.length > 0);
    return `<tr><td><input class="row-check" type="checkbox" data-page-select="${escapeHtml(page.id)}" ${checked ? "checked" : ""}></td><td><code>${escapeHtml(page.page_code)}</code><br><strong>${escapeHtml(page.title)}</strong><br><span class="small muted">${escapeHtml(page.project_scope)}</span></td><td>${escapeHtml(page.site_scope)}<br><span class="small muted">${escapeHtml(page.process_scope)}</span></td><td>${escapeHtml(pageContributorsLabel(page))}</td><td>${badge("RETAINED", `${page.retention_weeks || 4}주 · ${logs.length}건`)}</td><td>${newLogs.length ? `${reportTag("NEW")} ${newLogs.length}건` : badge("NO_CHANGE", "변경 없음")}</td><td>${evidenceCount ? badge("EVIDENCE", `근거 ${evidenceCount}건`) : badge("NO_EVIDENCE", "근거 없음")}</td></tr>`;
  });
  const title = leaderMode ? "팀 보고 업무페이지 포함·제외" : "주간보고 업무페이지 선택";
  return `${card(title, `<div class="notice"><strong>제출 단위는 개별 문장이 아니라 업무페이지입니다.</strong>법인·공정·프로젝트별 페이지에 최근 4주 기록과 공동작성자의 내용이 함께 누적됩니다.</div>${table(["포함", "업무페이지", "법인·공정", "작성자", "유지 이력", "금주 변경", "Evidence"], rows)}<div class="button-row">${leaderMode ? "" : `<button class="button secondary" data-save-selection>페이지 선택 저장</button>`}<button class="button primary" data-generate-draft>${leaderMode ? "선택 페이지로 팀 초안 생성" : "선택 페이지로 개인 초안 생성"}</button></div>`)}${card("다음 화면 반영 원칙", `<ul class="list"><li><strong>페이지 단위</strong><span>선택한 업무페이지가 순서대로 한 장씩 구성됨</span></li><li><strong>최근 4주</strong><span>기존 서술을 삭제하지 않고 최소 4주간 유지</span></li><li><strong>금주 변경</strong><span>신규·수정 문장만 파란색 New로 표시</span></li><li><strong>공동작성</strong><span>대표 작성자와 공동 작성자의 Worklog를 한 페이지로 통합</span></li></ul>`)}`;
}

function editorLevel(level) {
  if (level === "TEAM_MEMBER") {
    const submission = state.data.submissions.find((item) => item.member_user_id === state.data.principal.id) || state.data.submissions[0];
    const version = (state.data.submission_versions || []).find((item) => item.submission_id === submission?.id);
    return { title: "팀원 주간실적", report: null, reportCode: submission?.submission_code, status: submission?.status, content: version?.content, sourceManifest: version?.source_manifest };
  }
  if (level === "TEAM") return { title: "RSND자동보정팀 팀장 서술형 보고", report: reportByLevel("TEAM") };
  if (level === "DEPARTMENT") return { title: "자동보정담당 주간보고", report: reportByLevel("DEPARTMENT") };
  return { title: "제조DX그룹 주간보고", report: reportByLevel("GROUP") };
}

function renderEditor(level) {
  const config = editorLevel(level);
  const content = state.generatedDraft || config.content || config.report?.content || "선택한 업무를 기준으로 Agent 초안을 생성하십시오.";
  const manifest = config.sourceManifest || config.report?.source_manifest || "";
  const sources = String(manifest).split(",").filter(Boolean);
  const reportCode = config.reportCode || config.report?.report_code || "SUB-RSND-2026-W34-001";
  const status = config.status || config.report?.status || "AI_DRAFTED";
  const memberPageMode = level === "TEAM_MEMBER" && parseReportPages(content).length > 0;
  const preview = memberPageMode ? renderReportPages(content) : renderTaggedReport(content);
  const editor = memberPageMode ? renderWorkPagesEditor(content) : renderStructuredReportEditor(content);
  const notice = memberPageMode
    ? `<div class="notice"><strong>업무페이지가 팀장 제출의 최소 단위입니다.</strong>법인·공정·프로젝트별로 최근 4주 서술을 유지하고 금주 신규·수정 문장만 파란색 New로 표시합니다. 공동작성자의 기록도 같은 페이지에 합쳐집니다.</div>`
    : `<div class="notice"><strong>Code를 직접 입력하지 않아도 됩니다.</strong>문단 Tag와 서술을 수정하면 ID와 근거는 내부에서 연결됩니다.</div>`;
  const checks = memberPageMode
    ? `<ul class="check-list"><li class="pass">✓ 업무페이지 3개 구성</li><li class="pass">✓ 최근 4주 이력 유지</li><li class="pass">✓ 금주 변경 파란색 표시</li><li class="pass">✓ 대표·공동 작성자 연결</li><li class="pass">✓ 페이지 단위 팀장 제출</li><li class="warn">! 잠정 KPI 상태 확인</li></ul>`
    : `<ul class="check-list"><li class="pass">✓ 서술형 원문 유지</li><li class="pass">✓ 문단 유형 Tag</li><li class="pass">✓ ID·Code 자동 연결</li><li class="pass">✓ 숫자·단위 대조</li><li class="warn">! 잠정 KPI 상태 확인</li></ul>`;
  return `<div class="editor-layout"><section class="card editor-main"><div class="card-top"><div><span class="small muted">${escapeHtml(reportCode)}</span><h2>${escapeHtml(config.title)}</h2></div>${badge(status)}</div>${notice}<div class="report-preview-heading"><strong>${memberPageMode ? "업무페이지 미리보기" : "보고서 미리보기"}</strong><span>${memberPageMode ? "팀장에게 이 페이지 단위로 전달됩니다." : "아래 문단을 수정하면 즉시 반영됩니다."}</span></div><div id="formatted-report-preview" class="formatted-report-preview">${preview}</div><div class="structured-editor-heading"><strong>${memberPageMode ? "업무페이지별 내용 편집" : "보고서 문단 편집"}</strong><span>${memberPageMode ? "기존 4주 이력 유지 + 금주 문장 추가" : "Tag 선택 + 일반 문장 입력"}</span></div>${editor}<details class="machine-record"><summary>AI 저장 구조 확인</summary><pre id="machine-record-preview">${escapeHtml(content)}</pre></details><div class="button-row"><button class="button secondary" data-generate-draft>추가 기록으로 다시 생성</button><button class="button primary" data-save-version>수정본 저장하고 다음 화면으로</button></div></section><aside class="stack">${card("표시 가이드", `<div class="tag-guide">${["BACKGROUND", "RESULT", "ANALYSIS", "PLAN", "RISK", "KPI", "DECISION", "NEW"].map((tag) => `${reportTag(tag)}<span>${reportTagDescriptions[tag]}</span>`).join("")}</div>`)}${card("AI Readable 검사", checks)}${card("Source Manifest", `<div>${sources.map((source) => `<span class="source-chip">${escapeHtml(source)}</span>`).join("") || "생성 후 표시"}</div><p class="small muted">페이지 Version과 함께 불변 저장됩니다.</p>`)}</aside></div>`;
}

function renderSubmission() {
  const mine = state.data.submissions.find((item) => item.member_name === state.data.principal.display_name) || state.data.submissions[0];
  const version = (state.data.submission_versions || []).find((item) => item.submission_id === mine.id);
  const content = version?.content || state.generatedDraft || "";
  const pageCount = parseReportPages(content).length;
  return `${card("제출 상태", `<div class="submission-hero"><div><span class="small muted">${escapeHtml(mine.submission_code)}</span><h2>${escapeHtml(mine.member_name)} · W34</h2><p>현재 Version ${mine.version} · 업무페이지 ${pageCount || 1}장 · ${mine.submitted_at ? formatDate(mine.submitted_at, true) : "아직 제출하지 않음"}</p></div>${badge(mine.status)}</div>${renderWorkflow(mine.status === "SUBMITTED" ? 1 : 0)}<div class="notice"><strong>팀장에게는 아래 업무페이지 전체가 전달됩니다.</strong>Result·Analysis·Plan 문장을 별도 제출하지 않고 페이지의 연속된 글과 작성자 정보를 함께 고정합니다.</div><div class="button-row"><button class="button primary" data-action="SUBMIT_MEMBER">업무페이지 ${pageCount || 1}장을 팀장에게 제출</button></div>`)}${card("팀장에게 전달될 업무페이지", `<div class="formatted-report-preview compact-preview">${renderReportPages(content, true)}</div>`)}${card("Version 이력", table(["Version", "생성 주체", "단위", "상태", "시각"], [`<tr><td>v${mine.version}</td><td>MEMBER + AGENT</td><td>업무페이지 ${pageCount || 1}장</td><td>${badge(mine.status)}</td><td>${mine.submitted_at ? formatDate(mine.submitted_at, true) : "임시 저장"}</td></tr>`, `<tr><td>v1</td><td>MEMBER</td><td>업무페이지</td><td>${badge("DRAFT")}</td><td>08.23 16:42</td></tr>`]))}`;
}

function renderSubmissionMatrix() {
  const rows = state.data.submissions.map((item) => `<tr><td><strong>${escapeHtml(item.member_name)}</strong><br><span class="small muted">${escapeHtml(item.organization_name)}</span></td><td><code>${escapeHtml(item.submission_code)}</code></td><td>${badge(item.status)}</td><td>v${item.version}</td><td>${item.submitted_at ? formatDate(item.submitted_at, true) : "—"}</td><td><button class="button secondary" data-demo="open-submission">검토</button></td></tr>`);
  return `${card("RSND자동보정팀 제출 현황", `<div class="metrics compact-metrics">${metricCard("제출 완료", state.data.counts.submitted_members, `전체 ${state.data.counts.members_total}명`)}${metricCard("미검토", 2, "오늘 12:00까지")}${metricCard("반려", 0, "보완 요청 없음")}</div>${table(["팀원", "Submission", "상태", "Version", "제출시각", ""], rows)}`)}${card("검토 순서 제안", `<div class="notice"><strong>1. 김현수 — 잠정 KPI와 Decision 요청 포함</strong>2. 박은지 — 정량 효과 근거 확인<br>3. 이정훈 — 협업 가설이 확정 사실과 분리됐는지 확인</div>`)}`;
}

function renderMemberDetail() {
  const sub = state.data.submissions[0];
  const version = (state.data.submission_versions || []).find((item) => item.submission_id === sub.id);
  const sources = String(version?.source_manifest || "").split(",").filter(Boolean);
  const content = version?.content || "";
  const pageCount = parseReportPages(content).length;
  return `<div class="grid-2 member-review-grid">${card("팀원 제출 업무페이지", `<div class="card-top"><div><code>${escapeHtml(sub.submission_code)}</code><h2>${escapeHtml(sub.member_name)} · ${pageCount || 1}개 페이지</h2></div>${badge(sub.status)}</div><div class="formatted-report-preview compact-preview">${renderReportPages(content, true)}</div><div class="button-row"><button class="button danger" data-demo="return">페이지 보완 요청</button><button class="button primary" data-demo="include">선택 페이지를 팀 보고에 포함</button></div>`)}${card("페이지 검토 기준", `<div>${sources.map((source) => `<span class="source-chip">${escapeHtml(source)}</span>`).join("")}</div><ul class="list"><li><strong>보고 단위</strong><span>문장이 아니라 법인·공정·프로젝트 업무페이지 단위로 검토</span></li><li><strong>4주 유지</strong><span>W31~W34 기존 서술의 누락 여부 확인</span></li><li><strong>금주 변경</strong><span>파란색 New 문장만 신규·업데이트로 식별</span></li><li><strong>공동작성</strong><span>대표 작성자와 공동 작성자의 기여가 한 페이지에 통합됨</span></li><li><strong>Evidence</strong><span>파일명·원문 위치·Hash를 Source Manifest로 연결</span></li></ul>`)}</div>`;
}

function renderEvidenceCompare() {
  const report = reportByLevel("TEAM");
  return `${card("문장–근거 대조", `<div class="compare-grid"><div><span class="pane-title">보고 문장</span><p><mark>W34 PD Loss는 1.2%</mark>로 전주 1.5% 대비 감소했으나 Data Owner 승인 전 잠정값이다.</p></div><div><span class="pane-title">공식 Resource</span><dl class="detail-grid"><div><dt>Snapshot</dt><dd>SNP-PD-2026-W34-004</dd></div><div><dt>값</dt><dd>1.2%</dd></div><div><dt>전주</dt><dd>1.5%</dd></div><div><dt>상태</dt><dd>${badge("PROVISIONAL")}</dd></div><div><dt>Cut-off</dt><dd>2026-08-23 23:59</dd></div><div><dt>일치</dt><dd>${badge("MATCH", "일치")}</dd></div></dl></div></div>`)}${card("검사 결과", `<div class="metrics compact-metrics">${metricCard("숫자", "4/4", "Exact match")}${metricCard("Citation", "4/4", "Resource 존재")}${metricCard("주의", "1", "잠정 상태 유지")}</div><div class="source-chips">${String(report?.source_manifest || "").split(",").map((x) => `<span class="source-chip">${escapeHtml(x)}</span>`).join("")}</div>`)}`;
}

function renderApproval() {
  const role = state.role;
  const level = role === "LEADER" ? "TEAM" : role === "DEPT" ? "DEPARTMENT" : "GROUP";
  const report = reportByLevel(level);
  const next = role === "LEADER" ? "자동보정담당" : role === "DEPT" ? "제조DX기획팀" : "그룹장";
  return `${card("승인 Action Preview", `<div class="approval-preview"><div><span>대상 Report</span><strong>${escapeHtml(report?.report_code || "RPT-GROUP-DX-2026-W34")}</strong></div><div><span>현재 상태</span><strong>${badge(report?.status || "DRAFT")}</strong></div><div><span>다음 수신</span><strong>${escapeHtml(next)}</strong></div><div><span>고정 Version</span><strong>v${report?.current_version || 1}</strong></div></div><div class="notice warn"><strong>승인 후 원문을 덮어쓰지 않습니다.</strong>정정이 필요하면 새 Version을 만들고 승인 이력을 다시 남깁니다.</div><div class="button-row"><button class="button danger" data-demo="return-report">반려·보완 요청</button><button class="button primary" data-action="${escapeHtml(actionMap[currentScreen().screen_id] || "APPROVE_TEAM")}">${escapeHtml(currentScreen().primary_action)}</button></div>`)}${card("승인 체크", `<ul class="check-list"><li class="pass">✓ 하위 제출·승인 상태 확인</li><li class="pass">✓ 숫자와 Snapshot 일치</li><li class="pass">✓ Evidence 연결</li><li class="warn">! 잠정 KPI 라벨 유지</li><li class="pass">✓ Owner·Due 누락 없음</li></ul>`)}`;
}

function renderHistory() {
  const report = reportByLevel("TEAM");
  return `${card("Report Version 비교", `<div class="version-tabs"><button class="active">v${report?.current_version || 1} · 현재</button><button>v1 · Agent</button><button>원문</button></div><div class="diff-view"><div><span class="pane-title">이전 Version</span><p>Jamming 보정조건 검증 완료. K12 추가 확인 필요.</p></div><div><span class="pane-title">현재 승인 후보</span><p><ins>[WI-RSND-2026-0032][RESULT]</ins> Jamming 자동보정 조건을 검증하였다. 대상 3개 제품 중 2개는 반복 경향을 확인했고 <ins>K12는 추가 검증이 필요하다.</ins></p></div></div>`)}${card("변경 이력", table(["Version", "생성 주체", "변경 요약", "시각"], [`<tr><td>v2</td><td>팀장</td><td>ID·잠정상태·Decision 보강</td><td>08.24 10:12</td></tr>`, `<tr><td>v1</td><td>LEADER_AGENT</td><td>팀원 제출 3건 종합</td><td>08.24 09:40</td></tr>`]))}`;
}

function renderTeamMatrix() {
  const teams = [["RSND자동보정팀", "RPT-TEAM-RSND-2026-W34", "DRAFT", "3/3", "PD Loss · Jamming"], ["전극자동보정팀", "RPT-TEAM-ELC-2026-W34", "TEAM_APPROVED", "4/4", "BM Loss · 로딩량"], ["조립자동보정팀", "RPT-TEAM-ASM-2026-W34", "TEAM_APPROVED", "5/5", "PD Loss · 주액기"], ["활성화자동보정팀", "RPT-TEAM-ACT-2026-W34", "NEEDS_EVIDENCE", "3/4", "CTQ · Evidence 누락"]];
  return `${card("팀 보고 Matrix", table(["팀", "Report", "상태", "제출", "핵심 안건"], teams.map((r) => `<tr><td><strong>${r[0]}</strong></td><td><code>${r[1]}</code></td><td>${badge(r[2])}</td><td>${r[3]}</td><td>${r[4]}</td></tr>`)))}${card("담당 관점 Agent 요약", `<div class="notice"><strong>우선 검토: 활성화자동보정팀 Evidence 누락</strong>미승인 팀 원문은 담당 보고의 확정 사실로 집계하지 않습니다. RSND·FDC의 Jamming 안건은 Collaboration ID로 한 번만 묶습니다.</div>`)}`;
}

function renderCollaboration() {
  const participants = state.data.participants;
  return `<div class="collab-grid">${state.data.collaborations.map((c) => {
    const people = participants.filter((p) => p.collaboration_id === c.id);
    return `<section class="card"><div class="card-top"><code>${escapeHtml(c.collaboration_code)}</code>${badge(c.status)}</div><h2>${escapeHtml(c.title)}</h2><p>${escapeHtml(c.goal)}</p><div class="collab-flow"><span>${escapeHtml(c.lead_organization)} · 주관</span>${people.map((p) => `<span>${escapeHtml(p.organization_name)}</span>`).join("")}</div><ul class="list">${people.map((p) => `<li><strong>${escapeHtml(p.organization_name)}</strong><span>${escapeHtml(p.contribution)}</span></li>`).join("")}</ul><p class="small muted">목표일 ${formatDate(c.target_date)}</p></section>`;
  }).join("")}</div>`;
}

function renderConflict() {
  return `${card("KPI·주장 충돌", `<div class="conflict-row"><div>${badge("PROVISIONAL")}<h3>PD Loss 값 상태</h3><p>팀 보고는 1.2%를 확정값처럼 기술했으나 Snapshot은 Data Owner 승인 전입니다.</p></div><div class="conflict-arrow">→</div><div><strong>권고 처리</strong><p>값은 유지하고 문장에 <code>[PROVISIONAL]</code>과 Cut-off를 표시합니다.</p><button class="button secondary" data-demo="conflict">권고 적용</button></div></div><div class="conflict-row"><div>${badge("ANALYSIS")}<h3>Jamming 원인 해석</h3><p>FDC 장력 편차와 발생 시점의 상관성을 원인으로 표현한 팀이 있습니다.</p></div><div class="conflict-arrow">→</div><div><strong>권고 처리</strong><p>팀별 가설을 병렬 유지하고 공동 검증 중으로 표시합니다.</p><button class="button secondary" data-demo="conflict">병렬 표기</button></div></div>`)}${card("충돌 처리 원칙", `<ol class="principles"><li>최신값을 임의 선택하지 않습니다.</li><li>Snapshot Version·집계범위·기준시각을 먼저 대조합니다.</li><li>확정 사실과 팀별 분석·가설을 분리합니다.</li><li>해결 방식과 승인자를 감사 이력에 남깁니다.</li></ol>`)}`;
}

function renderDecisionRegister() {
  const decisions = state.data.decisions.map((d) => `<tr><td><code>${escapeHtml(d.decision_code)}</code></td><td><strong>${escapeHtml(d.title)}</strong><br><span class="small muted">${escapeHtml(d.request)}</span></td><td>${escapeHtml(d.decision_maker || "미지정")}</td><td>${formatDate(d.due_date)}</td><td>${badge(d.status)}</td></tr>`);
  const actions = state.data.action_items.map((a) => `<tr><td><code>${escapeHtml(a.action_code)}</code></td><td>${escapeHtml(a.title)}</td><td>${escapeHtml(a.owner_name || "미지정")}</td><td>${formatDate(a.due_date)}</td><td>${badge(a.status)}</td></tr>`);
  return `${card("Decision 요청", table(["Decision ID", "요청", "결정자", "기한", "상태"], decisions))}${card("후속 Action", table(["Action ID", "조치", "Owner", "Due", "상태"], actions))}`;
}

function issueRows(resourceType = null) {
  return state.data.qa_issues.filter((item) => !resourceType || item.resource_type === resourceType).map((item) => `<article class="qa-item"><span>${badge(item.severity)}</span><div><strong>${escapeHtml(item.rule_code)} · ${escapeHtml(item.message)}</strong><p>${escapeHtml(item.remediation)}</p><code>${escapeHtml(item.resource_id)}</code></div>${badge(item.status)}</article>`).join("") || `<div class="empty-state">열린 Issue가 없습니다.</div>`;
}

function renderQa() {
  const open = state.data.qa_issues.filter((item) => item.status === "OPEN");
  const blocks = open.filter((item) => item.severity === "BLOCK").length;
  return `${renderKpis()}${card("그룹 보고 QA Issue", `<div class="metrics compact-metrics">${metricCard("OPEN", open.length, "전체 미해소")}${metricCard("BLOCK", blocks, "확정 차단")}${metricCard("WARN", open.length - blocks, "사유 확인")}</div><div class="stack">${issueRows()}</div><div class="button-row"><button class="button primary" data-action="RESOLVE_QA">Issue 해소 요청</button></div>`)}${card("결정적 검사 → LLM 설명", `<div class="notice"><strong>Pass/Fail은 Rule Engine이 판단합니다.</strong>LLM은 오류의 의미, 영향 문장, 수정 위치를 사람이 이해하기 쉽게 설명합니다.</div>`)}`;
}

function renderRedaction() {
  const rows = [["설비 상세번호 ESWA-L07-03", "CONFIDENTIAL", "내부 그룹 보고", "유지"], ["제품 K12 시험조건", "CONFIDENTIAL", "외부 공유", "제외 후보"], ["PD Loss 1.2%", "INTERNAL", "외부 공유", "승인 필요"], ["WorkItem·Snapshot Code", "INTERNAL", "내부 그룹 보고", "유지"]];
  return `${card("민감정보 제외 후보", table(["항목", "등급", "대상", "처리"], rows.map((r) => `<tr><td>${escapeHtml(r[0])}</td><td>${badge(r[1])}</td><td>${escapeHtml(r[2])}</td><td>${badge(r[3], r[3])}</td></tr>`)))}${card("공유 Version 원칙", `<div class="notice warn"><strong>Agent가 원본을 자동 삭제하지 않습니다.</strong>원본 Version을 보존하고, 승인된 Redaction 규칙으로 별도 공유 Version을 생성합니다.</div><div class="button-row"><button class="button secondary" data-demo="redaction">제외안 미리보기</button><button class="button primary" data-demo="redaction">공유 Version 생성</button></div>`)}`;
}

function renderExport() {
  const rows = state.data.reports.map((r) => `<tr><td><code>${escapeHtml(r.report_code)}</code></td><td>${escapeHtml(r.report_level)}</td><td>${badge(r.status)}</td><td>v${r.current_version}</td><td><button class="button secondary" data-demo="export">PPTX</button> <button class="button secondary" data-demo="export">JSON</button></td></tr>`);
  return `${card("확정본·산출물", table(["Report", "Level", "상태", "Version", "Export"], rows))}${card("재현 가능한 Export", `<ul class="list"><li><strong>Human-readable</strong><span>PPTX · PDF · 포털 화면</span></li><li><strong>Machine companion</strong><span>JSON · Source Manifest · Citation</span></li><li><strong>감사 정보</strong><span>Template · Prompt · Model · 생성시각 · 승인 Version</span></li></ul>`)}`;
}

function renderEvidenceTrace() {
  const evidence = state.data.evidence[0];
  return `<section class="trace-map card"><h3>문장부터 원천까지 추적</h3><div class="trace-node"><span>보고 문장</span><strong>대상 3개 제품 중 2개 제품에서 동일 경향 확인</strong></div><div class="trace-arrow">↓ Citation</div><div class="trace-node"><span>WorkItem</span><strong>WI-RSND-2026-0032</strong></div><div class="trace-arrow">↓ Evidence</div><div class="trace-node"><span>파일·위치</span><strong>${escapeHtml(evidence.file_name)} · ${escapeHtml(evidence.locator)}</strong></div><div class="trace-arrow">↓ Integrity</div><div class="trace-node"><span>Hash·검사</span><strong>${escapeHtml(evidence.sha256.slice(0, 16))}… · ${escapeHtml(evidence.scan_status)}</strong></div></section>${card("신뢰 상태", `<div class="metrics compact-metrics">${metricCard("원문 Hash", "일치", "SHA-256")}${metricCard("보안 범위", evidence.security_label, "현재 사용자 조회 가능")}${metricCard("Freshness", "W34", "08/23 23:59")}</div>`)}`;
}

function renderQuestion() {
  const answer = state.lastAnswer;
  return `<div class="question-layout"><section class="card"><h3>근거 기반 질문</h3><form id="question-form"><textarea id="question-input" aria-label="질문">자동보정 적용으로 PD Loss가 개선됐다고 확정할 수 있어?</textarea><div class="question-suggestions"><button type="button" data-question="K12 검증이 지연되면 어떤 영향이 있어?">K12 검증 지연 영향</button><button type="button" data-question="이번 주 가장 중요한 Decision은 무엇이야?">중요 Decision</button></div><div class="button-row"><button class="button primary">보고 Q&A Agent에 질문</button></div></form></section><section class="card"><h3>Agent 답변</h3>${answer ? renderAnswer(answer) : `<div class="empty-state">질문하면 승인된 보고와 Citation 범위 안에서 답변합니다.</div>`}</section></div>`;
}

function renderAnswer(answer) {
  return `<div class="answer"><p>${escapeHtml(answer.answer)}</p><div class="notice warn"><strong>불확실성</strong>동일 제품·동일 조건의 적용 전후 승인 데이터가 추가로 필요합니다.</div><h4>근거</h4>${answer.citations.map((c) => `<div class="citation"><code>${escapeHtml(c.code)}</code><span>${escapeHtml(c.detail)}</span></div>`).join("")}<p class="small muted">Freshness ${escapeHtml(answer.freshness)} · Trace ${escapeHtml(answer.trace_id)}</p></div>`;
}

function renderDecision() {
  const rows = state.data.decisions.map((d) => `<section class="card decision-card"><div class="card-top"><code>${escapeHtml(d.decision_code)}</code>${badge(d.status)}</div><h2>${escapeHtml(d.title)}</h2><p>${escapeHtml(d.request)}</p><dl class="detail-grid"><div><dt>결정자</dt><dd>${escapeHtml(d.decision_maker || "그룹장")}</dd></div><div><dt>기한</dt><dd>${formatDate(d.due_date)}</dd></div><div><dt>선택지 A</dt><dd>W35 생산 일정 우선 배정</dd></div><div><dt>선택지 B</dt><dd>W36 정규 일정 수행</dd></div></dl>${d.status === "RESOLVED" ? `<div class="notice"><strong>확정 결과</strong>${escapeHtml(d.resolution)}</div>` : `<div class="button-row"><button class="button secondary" data-demo="decision-detail">추가 근거 요청</button><button class="button primary" data-action="RESOLVE_DECISION">결정·Action 확정</button></div>`}</section>`).join("");
  return `<div class="stack">${rows}</div>`;
}

function renderTrend() {
  const series = [["W30", 1.8], ["W31", 1.7], ["W32", 1.6], ["W33", 1.5], ["W34", 1.2]];
  const chart = `<div class="bar-chart" role="img" aria-label="PD Loss W30부터 W34 추이">${series.map(([week, value]) => `<div class="bar-col"><span>${value}%</span><div class="bar" style="height:${value * 75}px"></div><strong>${week}</strong></div>`).join("")}</div>`;
  const actions = state.data.action_items.map((a) => `<tr><td><code>${escapeHtml(a.action_code)}</code></td><td>${escapeHtml(a.title)}</td><td>${escapeHtml(a.owner_name || "—")}</td><td>${formatDate(a.due_date)}</td><td>${badge(a.status)}</td></tr>`);
  return `<div class="grid-2">${card("PD Loss 주차 Trend", `${chart}<p class="small muted">동일 Metric 정의 v4 기준. W34는 승인 전 Snapshot일 수 있습니다.</p>`)}${card("추이 해석", `<div class="notice"><strong>W30 1.8% → W34 1.2%</strong>감소 경향은 관찰되지만 자동보정 단독 효과를 확정하려면 적용 전후 통제 데이터가 필요합니다.</div><ul class="list"><li><strong>질문 제안</strong><span>제품·라인별 개선 폭은 동일한가?</span></li><li><strong>확인 항목</strong><span>K12 추가 검증 후 경향 유지 여부</span></li></ul>`)}</div>${card("Action 추적", table(["Action", "조치", "Owner", "Due", "상태"], actions))}`;
}

function renderSnapshotUpload() {
  return `<div class="grid-2">${card("KPI 원천파일 업로드", `<div class="dropzone"><div class="upload-icon">⇧</div><strong>정기 다운로드 파일을 업로드</strong><span>메일·분석시스템 API 연계 전 운영 방식</span><button class="button primary" data-demo="snapshot-upload">PD_Loss_2026W34_0823.xlsx 선택</button></div><div class="form-grid compact"><label>Metric<select><option>PD_LOSS · PD Loss</option></select></label><label>기준시각<input value="2026-08-23 23:59"></label><label>보고주차<select><option>2026-W34</option></select></label><label>Source System<input value="분석시스템"></label></div>`)}${card("자동 추출 Preview", `<dl class="detail-grid"><div><dt>파일명 계약</dt><dd>${badge("PASS")}</dd></div><div><dt>SHA-256</dt><dd><code>8ae1…bd42</code></dd></div><div><dt>Sheet</dt><dd>Weekly_Result</dd></div><div><dt>Rows</dt><dd>1,284</dd></div><div><dt>예상 Metric</dt><dd>PD_LOSS · 96%</dd></div><div><dt>상태</dt><dd>UPLOADED 예정</dd></div></dl><div class="notice warn"><strong>96% 제안은 자동확정하지 않습니다.</strong>Data Owner가 Metric과 Cut-off를 확인합니다.</div>`)}</div>`;
}

function renderMapping() {
  const mappings = [["SITE_CD", "site", "ESWA", "100%"], ["PROC_NM", "process", "조립", "98%"], ["LINE_ID", "line", "L07", "100%"], ["MODEL", "product", "M08", "94%"], ["PD_LOSS_RT", "value", "2.4", "99%"], ["BASE_DT", "cutoff_at", "2026-08-23", "92%"]];
  return `${card("Source → 표준 Dimension 매핑", table(["원천 Header", "표준 Field", "Sample", "Confidence"], mappings.map((r) => `<tr><td><code>${r[0]}</code></td><td><select><option>${r[1]}</option></select></td><td>${r[2]}</td><td>${Number(r[3].replace("%", "")) < 95 ? badge("WARN", r[3]) : badge("PASS", r[3])}</td></tr>`)))}${card("Mapping Version", `<div class="approval-preview"><div><span>Metric</span><strong>PD_LOSS v4</strong></div><div><span>File Contract</span><strong>FC-PD-2026-02</strong></div><div><span>현재 Mapping</span><strong>MAP-PD-v7</strong></div><div><span>변경 예정</span><strong>MAP-PD-v8</strong></div></div><div class="button-row"><button class="button primary" data-demo="mapping">매핑 저장·검증</button></div>`)}`;
}

function renderValidation() {
  const snapshot = state.data.snapshots.find((item) => item.id === "snp_pd_w34");
  return `<div class="metrics">${metricCard("검사 상태", snapshot.status, snapshot.snapshot_code)}${metricCard("BLOCK", snapshot.validation_errors, "중복 Key")}${metricCard("WARN", snapshot.validation_warnings, "급변값")}</div>${card("Validation Issue", `<div class="stack">${issueRows("METRIC_SNAPSHOT")}</div><div class="button-row"><button class="button secondary" data-demo="source-row">원본 행 보기</button><button class="button primary" data-action="VALIDATE_SNAPSHOT">재검증</button></div>`)}${card("Rule 실행 순서", `<div class="pipeline"><span>Schema</span><b>→</b><span>Key 중복</span><b>→</b><span>누락</span><b>→</b><span>단위</span><b>→</b><span>급변</span><b>→</b><span>집계 대조</span></div>`)}`;
}

function renderSnapshotCompare() {
  const rows = [["전체", "ALL", "ALL", 1.5, 1.2, -0.3, "정상"], ["조립", "L07", "M08", 0.8, 2.4, 1.6, "급변"], ["조립", "L03", "K12", 1.2, 1.1, -0.1, "중복 Key"]];
  return `${card("W33 ↔ W34 Snapshot 비교", table(["공정", "Line", "제품", "W33", "W34", "차이(%p)", "Flag"], rows.map((r) => `<tr><td>${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td><td class="numeric">${r[3]}%</td><td class="numeric">${r[4]}%</td><td class="numeric">${r[5] > 0 ? "+" : ""}${r[5]}</td><td>${badge(r[6], r[6])}</td></tr>`)))}${card("변동 사유", `<div class="form-grid"><label class="full">ESWA L07 M08 급변 사유<textarea>제품 전환 직후 초기 구간 값이 포함되었는지 원천 파일과 집계 범위를 확인 중.</textarea></label></div><div class="button-row"><button class="button primary" data-demo="save-reason">변동 사유 기록</button></div>`)}`;
}

function renderSnapshotApprove() {
  const s = state.data.snapshots.find((item) => item.id === "snp_pd_w34");
  const canApprove = Number(s.validation_errors) === 0;
  return `${card("PD Loss Snapshot 승인", `<div class="snapshot-header"><div><code>${escapeHtml(s.snapshot_code)}</code><h2>${escapeHtml(s.metric_name)} · ${Number(s.display_value).toFixed(1)}${escapeHtml(s.unit)}</h2><p>Cut-off ${escapeHtml(s.cutoff_at)} · Source ${escapeHtml(s.source_file)}</p></div>${badge(s.status)}</div><div class="approval-preview"><div><span>Verification</span><strong>${badge(s.verification_state)}</strong></div><div><span>Version</span><strong>v${s.version}</strong></div><div><span>BLOCK</span><strong>${s.validation_errors}</strong></div><div><span>WARN</span><strong>${s.validation_warnings}</strong></div></div>${!canApprove ? `<div class="notice danger"><strong>승인 차단</strong>Validation의 BLOCK 오류를 먼저 해소하십시오.</div>` : `<div class="notice"><strong>승인 가능</strong>승인하면 공식 Snapshot으로 잠기며 정정은 새 Version으로만 가능합니다.</div>`}<div class="button-row"><button class="button primary" ${canApprove ? "" : "disabled"} data-action="APPROVE_SNAPSHOT">Snapshot 승인·잠금</button></div>`)}${card("영향 범위", `<ul class="list"><li><strong>팀원 초안</strong><span>잠정 → 검증됨 상태로 표시 변경</span></li><li><strong>팀·담당·그룹 보고</strong><span>동일 Snapshot ID를 참조하는 문장 재검사</span></li><li><strong>Audit</strong><span>Data Owner · 승인시각 · Trace ID 기록</span></li></ul>`)}`;
}

function renderMetricCatalog() {
  const definitions = [["YIELD_RATE", "수율", "정상품 수량 / 전체 투입 수량", "%", "분석시스템", "v3"], ["BM_LOSS", "BM Loss", "설비 기인 Loss 비율", "%", "분석시스템", "v2"], ["PD_LOSS", "PD Loss", "공정 기인 Loss 비율", "%", "분석시스템", "v4"], ["DEFECT_RATE", "불량률", "검사 불량 수량 / 전체 검사 수량", "%", "분석시스템", "v2"]];
  return `${card("Metric Catalog", table(["Metric Code", "표시명", "공식 정의", "단위", "원천", "Version"], definitions.map((r) => `<tr><td><code>${r[0]}</code></td><td><strong>${r[1]}</strong></td><td>${r[2]}</td><td>${r[3]}</td><td>${r[4]}</td><td>${badge(r[5])}</td></tr>`)))}${card("약어 관리 원칙", `<div class="notice"><strong>BM·PD라는 표시명만으로 데이터를 연결하지 않습니다.</strong>Metric Code, 공식 산식, 집계 차원, Owner, Version을 함께 저장합니다.</div>`)}`;
}

function renderIam() {
  const rows = [["김현수", "D1001", "MEMBER", "RSND자동보정팀", "활성"], ["이선우", "D1100", "LEADER", "RSND자동보정팀", "활성"], ["김도윤", "D1200", "DEPT", "자동보정담당", "활성"], ["최은서", "D1300", "PLANNING", "제조DX그룹", "활성"], ["그룹장 사용자", "D1400", "HEAD", "제조DX그룹", "활성"]];
  return `${card("조직·사용자·역할", table(["사용자", "사번", "Role", "Scope", "상태"], rows.map((r) => `<tr><td><strong>${r[0]}</strong></td><td>${r[1]}</td><td>${badge(r[2])}</td><td>${r[3]}</td><td>${badge("ACTIVE", r[4])}</td></tr>`)))}${card("권한 변경 통제", `<div class="notice warn"><strong>역할과 조직 범위 변경은 승인·기간·사유가 필요합니다.</strong>작성과 최종 승인 등 상충 역할은 SoD 규칙으로 경고합니다.</div>`)}`;
}

function renderCalendar() {
  const c = state.data.cycle;
  const dates = [["Snapshot", c.snapshot_due_at, "Data Owner"], ["팀원 제출", c.member_due_at, "팀원"], ["팀장 승인", c.leader_due_at, "팀장"], ["담당 승인", c.department_due_at, "담당"], ["기획 QA", c.planning_due_at, "기획팀"]];
  return `${card("2026 W34 보고 Calendar", `<div class="calendar-strip">${dates.map(([name, date, owner], index) => `<article class="${index === 0 ? "done" : index === 1 ? "active" : ""}"><span>${formatDate(date, true)}</span><strong>${name}</strong><small>${owner}</small></article>`).join("")}</div>`)}${card("주차 개시 설정", `<div class="form-grid"><label>Cycle Code<input value="2026-W35"></label><label>개시일<input type="date" value="2026-08-24"></label><label>휴일 예외<select><option>없음</option></select></label><label>이전주 복사<select><option>마감 규칙만 복사</option></select></label></div><div class="button-row"><button class="button primary" data-demo="calendar">보고주차 개시</button></div>`)}`;
}

function renderRelease() {
  const rows = [["PROMPT-LEADER", "팀장 서술형 초안", "v1.4", "Sonnet 4.5", "PASS", "활성"], ["PROMPT-PLANNING", "그룹 보고 구성", "v2.1", "Opus", "PASS", "활성"], ["TPL-WEEKLY-PPT", "내부 보고 PPT", "v3.2", "—", "PASS", "활성"], ["POLICY-CITATION", "Citation 검사", "v1.7", "Rule", "PASS", "활성"]];
  return `${card("Template · Prompt · Model Release", table(["Artifact", "용도", "Version", "Model", "Eval", "상태"], rows.map((r) => `<tr><td><code>${r[0]}</code></td><td>${r[1]}</td><td>${r[2]}</td><td>${r[3]}</td><td>${badge(r[4])}</td><td>${badge("ACTIVE", r[5])}</td></tr>`)))}${card("배포 Gate", `<div class="pipeline"><span>변경 제안</span><b>→</b><span>Golden Set</span><b>→</b><span>Regression</span><b>→</b><span>2인 검토</span><b>→</b><span>배포</span><b>→</b><span>Rollback</span></div>`)}`;
}

function renderPolicy() {
  const policies = [["POL-ACL-001", "권한 밖 Resource 검색 금지", "ENFORCED"], ["POL-LLM-003", "승인·결정 Tool 자동실행 금지", "ENFORCED"], ["POL-DATA-007", "Snapshot 잠금 후 덮어쓰기 금지", "ENFORCED"], ["POL-EXPORT-004", "외부공유 민감정보 검토", "ENFORCED"]];
  return `${card("권한·보안 Policy", table(["Policy", "규칙", "상태"], policies.map((r) => `<tr><td><code>${r[0]}</code></td><td>${r[1]}</td><td>${badge(r[2])}</td></tr>`)))}${card("Agent Tool Allowlist", `<div class="permission-grid"><div><strong>읽기 허용</strong><span>WorkItem · 승인 Report · Snapshot · Evidence metadata</span></div><div><strong>초안 허용</strong><span>요약 · Citation · QA 설명 · 질문 제안</span></div><div><strong>사람 확인 필수</strong><span>제출 · 승인 · Decision · 권한 변경 · 외부 공유</span></div><div><strong>차단</strong><span>권한 밖 검색 · 원본 삭제 · Snapshot 덮어쓰기</span></div></div>`)}`;
}

function renderAudit() {
  const rows = state.data.audit_events.map((a) => `<tr><td>${formatDate(a.occurred_at, true)}</td><td><code>${escapeHtml(a.trace_id)}</code></td><td>${escapeHtml(a.actor_name || "SYSTEM")}<br><span class="small muted">${escapeHtml(a.actor_role)}</span></td><td>${escapeHtml(a.action)}</td><td>${escapeHtml(a.resource_type)}<br><code>${escapeHtml(a.resource_id || "—")}</code></td><td>${badge(a.result)}</td><td>${escapeHtml(a.detail || "—")}</td></tr>`);
  return card("Audit Log", `<div class="toolbar"><div class="inline"><input placeholder="Trace · Actor · Resource"><select><option>전체 결과</option><option>SUCCEEDED</option><option>WARN</option></select></div><button class="button secondary" data-demo="audit-export">CSV Export</button></div>${table(["시각", "Trace", "Actor", "Action", "Resource", "결과", "상세"], rows)}`);
}

function renderHealth() {
  const services = [["Portal Web", "UP", "18 ms", "Local demo server"], ["SQLite DB", "UP", "4 ms", "Foreign key enabled"], ["LLM Agent", "DEMO", "결정적 응답", "외부 호출 없음"], ["Company Copilot", "NOT_CONNECTED", "—", "향후 사내 연동"], ["Data Analysis API", "NOT_CONNECTED", "—", "정기 파일 업로드 대체"]];
  return `${card("System Health", `<div class="health-grid">${services.map((r) => `<article><span class="status-dot ${r[1] !== "UP" ? "muted-dot" : ""}"></span><div><strong>${r[0]}</strong><span>${r[3]}</span></div><div>${badge(r[1])}<small>${r[2]}</small></div></article>`).join("")}</div>`)}${card("Feature Flag · Fallback", `<div class="permission-grid"><div><strong>agent.draft.enabled</strong><span>${badge("ON")}</span></div><div><strong>copilot.connector.enabled</strong><span>${badge("OFF")}</span></div><div><strong>manual.workflow.enabled</strong><span>${badge("ON")}</span></div><div><strong>snapshot.api.enabled</strong><span>${badge("OFF")}</span></div></div><div class="notice"><strong>Agent 장애 시에도 수동 작성·제출·승인 Workflow는 유지합니다.</strong></div>`)}`;
}

function renderGeneric(screen) {
  return `${card(screen.title, `<div class="empty-state"><strong>${escapeHtml(screen.screen_id)} 시연 화면</strong><p>${escapeHtml(screen.purpose)}</p><button class="button primary" data-demo="generic">${escapeHtml(screen.primary_action)}</button></div>`)}${card("화면 정의", `<dl class="detail-grid"><div><dt>주요 데이터</dt><dd>${escapeHtml(screen.main_data)}</dd></div><div><dt>AI 기능</dt><dd>${escapeHtml(screen.ai_function)}</dd></div><div><dt>검증·통제</dt><dd>${escapeHtml(screen.control_rule)}</dd></div><div><dt>완료조건</dt><dd>${escapeHtml(screen.done_condition)}</dd></div></dl>`)}`;
}

async function saveWorklog() {
  const workItemId = $("#worklog-workitem")?.value;
  const entryType = $("#worklog-type")?.value;
  const occurredOn = $("#worklog-date")?.value;
  const narrative = $("#worklog-narrative")?.value.trim();
  if (!narrative) { showToast("추가 작성 내용을 입력하십시오.", true); return; }
  showToast("Worklog를 저장하고 다음 화면에 연결하고 있습니다.");
  try {
    const result = await api("/api/worklogs", { method: "POST", body: JSON.stringify({ role: state.role, work_item_id: workItemId, entry_type: entryType, occurred_on: occurredOn, narrative }) });
    state.generatedDraft = null;
    await refreshCurrent();
    navigateTo("MBR-05");
    showToast(`${result.message} · ${result.trace_id}`);
  } catch (error) { showToast(error.message, true); }
}

async function saveEvidence() {
  const workItemId = $("#evidence-workitem")?.value;
  const fileName = $("#evidence-file-name")?.value.trim();
  const locator = $("#evidence-locator")?.value.trim();
  const securityLabel = $("#evidence-security")?.value;
  if (!fileName) { showToast("등록할 파일명을 입력하십시오.", true); return; }
  showToast("Evidence Metadata를 저장하고 금주 실적에 연결하고 있습니다.");
  try {
    const result = await api("/api/evidence", { method: "POST", body: JSON.stringify({ role: state.role, work_item_id: workItemId, file_name: fileName, locator, security_label: securityLabel }) });
    state.generatedDraft = null;
    await refreshCurrent();
    navigateTo("MBR-06");
    showToast(`${result.message} · ${result.record.evidence_code}`);
  } catch (error) { showToast(error.message, true); }
}

async function saveSelection(generateAfter = false) {
  const workPageIds = [...document.querySelectorAll("[data-page-select]:checked")].map((input) => input.dataset.pageSelect);
  if (!workPageIds.length) { showToast("보고서에 포함할 업무페이지를 한 건 이상 선택하십시오.", true); return; }
  try {
    const result = await api("/api/submission/items", { method: "POST", body: JSON.stringify({ role: state.role, work_page_ids: workPageIds }) });
    state.generatedDraft = null;
    await refreshCurrent();
    showToast(result.message);
    if (generateAfter) await generateDraft();
  } catch (error) { showToast(error.message, true); }
}

async function saveReportVersion() {
  const content = $("#work-page-editor") ? composeWorkPageContent() : composeStructuredReportContent();
  if (!content) { showToast("저장할 보고서 내용을 입력하십시오.", true); return; }
  showToast("수정본 Version을 저장하고 다음 화면에 연결하고 있습니다.");
  try {
    const result = await api("/api/draft/version", { method: "POST", body: JSON.stringify({ role: state.role, content }) });
    state.generatedDraft = content;
    await refreshCurrent();
    const nextScreen = { MEMBER: "MBR-08", LEADER: "LDR-06", DEPT: "DPT-06", PLANNING: "PLN-04" }[state.role];
    if (nextScreen) navigateTo(nextScreen);
    showToast(`${result.message} · ${result.trace_id}`);
  } catch (error) { showToast(error.message, true); }
}

async function generateDraft() {
  const button = $("#primary-action");
  if (button) button.disabled = true;
  showToast(state.role === "MEMBER" ? "선택한 업무페이지의 최근 4주 기록과 금주 변경을 조합하고 있습니다." : "승인된 업무와 근거로 초안을 생성 중입니다.");
  try {
    const result = await api("/api/agent/draft", { method: "POST", body: JSON.stringify({ role: state.role, screen_id: currentScreen().screen_id }) });
    state.generatedDraft = result.content;
    await refreshCurrent();
    if (state.role === "MEMBER" && currentScreen().screen_id === "MBR-06") navigateTo("MBR-07");
    if (state.role === "LEADER" && currentScreen().screen_id === "LDR-04") navigateTo("LDR-05");
    showToast(`AI 초안을 생성했습니다. Citation ${result.citations.length}건 · ${result.trace_id}`);
  } catch (error) { showToast(error.message, true); }
  finally { if (button) button.disabled = false; }
}

async function handleQuestion(event) {
  event.preventDefault();
  const question = $("#question-input").value.trim();
  if (!question) return;
  showToast("승인 보고와 근거를 검색하고 있습니다.");
  try {
    state.lastAnswer = await api("/api/agent/ask", { method: "POST", body: JSON.stringify({ role: state.role, question }) });
    renderScreen();
  } catch (error) { showToast(error.message, true); }
}

function openConfirmation(action) {
  const [title, message] = confirmCopy[action] || ["상태 변경 확인", "선택한 동작을 실행합니다."];
  state.pendingAction = action;
  $("#confirm-title").textContent = title;
  $("#confirm-message").textContent = message;
  $("#confirm-role").textContent = `${state.data.principal.role_label} · ${state.data.principal.display_name}`;
  $("#confirm-screen").textContent = `${currentScreen().screen_id} · ${currentScreen().title}`;
  $("#confirm-dialog").showModal();
}

async function executePendingAction() {
  const action = state.pendingAction;
  if (!action) return;
  state.pendingAction = null;
  $("#confirm-dialog").close();
  showToast("상태 변경과 감사 기록을 처리 중입니다.");
  try {
    const result = await api("/api/action", { method: "POST", body: JSON.stringify({ action, role: state.role }) });
    await refreshCurrent();
    showToast(`${result.message} · ${result.trace_id}`);
  } catch (error) { showToast(error.message, true); }
}

async function refreshCurrent() {
  const screenId = currentScreen()?.screen_id;
  const draft = state.generatedDraft;
  const answer = state.lastAnswer;
  const data = await api(`/api/bootstrap?role=${encodeURIComponent(state.role)}`);
  state.data = data;
  state.screenIndex = Math.max(0, data.screens.findIndex((screen) => screen.screen_id === screenId));
  state.generatedDraft = draft;
  state.lastAnswer = answer;
  renderPrincipal(); renderScreen();
}

function showToast(message, error = false) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.toggle("error", error);
  toast.hidden = false;
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => { toast.hidden = true; }, 4300);
}

function openSpec() {
  const screen = currentScreen();
  $("#spec-id").textContent = screen.screen_id;
  $("#spec-title").textContent = screen.title;
  $("#spec-purpose").textContent = screen.purpose;
  $("#spec-data").textContent = screen.main_data;
  $("#spec-ai").textContent = screen.ai_function;
  $("#spec-rule").textContent = screen.control_rule;
  $("#spec-done").textContent = screen.done_condition;
  $("#spec-dialog").showModal();
}

function navigateTo(screenId) {
  const index = state.data.screens.findIndex((screen) => screen.screen_id === screenId);
  if (index < 0) return false;
  state.screenIndex = index;
  renderScreen();
  window.scrollTo({ top: 0, behavior: "smooth" });
  return true;
}

function handlePrimaryAction() {
  const screen = currentScreen();
  if (screen.screen_id === "MBR-04") { saveWorklog(); return; }
  if (screen.screen_id === "MBR-05") { saveEvidence(); return; }
  if (screen.screen_id === "MBR-06") { saveSelection(true); return; }
  if (screen.screen_id === "MBR-07") { saveReportVersion(); return; }
  if (actionMap[screen.screen_id]) { openConfirmation(actionMap[screen.screen_id]); return; }
  if (navTargets[screen.screen_id] && navigateTo(navTargets[screen.screen_id])) return;
  showToast(`${screen.primary_action}: 시연용 화면에서 입력·미리보기를 확인했습니다.`);
}

$("#screen-nav").addEventListener("click", (event) => {
  const button = event.target.closest("[data-screen-index]");
  if (!button) return;
  state.screenIndex = Number(button.dataset.screenIndex);
  state.lastAnswer = null;
  renderScreen();
  window.scrollTo({ top: 0, behavior: "smooth" });
});

$("#screen-body").addEventListener("click", (event) => {
  const addPageSectionButton = event.target.closest("[data-add-page-section]");
  if (addPageSectionButton) {
    const page = addPageSectionButton.closest(".work-page-editor");
    const sections = $(".work-page-edit-sections", page);
    if (sections) {
      sections.insertAdjacentHTML("beforeend", renderStructuredReportBlock({ tag: "PLAN", statusTags: ["NEW"], resources: [page.dataset.pageCode].filter(Boolean), body: "" }));
      sections.lastElementChild?.querySelector(".block-body")?.focus();
      syncWorkPageEditor();
    }
    return;
  }
  const addReportBlockButton = event.target.closest("[data-add-report-block]");
  if (addReportBlockButton) {
    const editor = $("#structured-report-editor");
    if (editor) {
      editor.insertAdjacentHTML("beforeend", renderStructuredReportBlock({ tag: "PLAN", statusTags: state.role === "MEMBER" ? ["NEW"] : [], resources: [defaultReportResourceCode()].filter(Boolean), body: "" }));
      const addedBody = editor.lastElementChild?.querySelector(".block-body");
      addedBody?.focus();
      syncStructuredReportEditor();
    }
    return;
  }
  const removeReportBlockButton = event.target.closest("[data-remove-report-block]");
  if (removeReportBlockButton) {
    const page = removeReportBlockButton.closest(".work-page-editor");
    const blocks = page ? page.querySelectorAll(".structured-edit-block") : document.querySelectorAll(".structured-edit-block");
    if (blocks.length <= 1) { showToast(page ? "업무페이지에는 한 개 이상의 문장이 필요합니다." : "보고서에는 한 개 이상의 문단이 필요합니다.", true); return; }
    removeReportBlockButton.closest(".structured-edit-block")?.remove();
    if (page) syncWorkPageEditor(); else syncStructuredReportEditor();
    return;
  }
  const worklogButton = event.target.closest("[data-save-worklog]");
  if (worklogButton) { saveWorklog(); return; }
  const evidenceButton = event.target.closest("[data-save-evidence]");
  if (evidenceButton) { saveEvidence(); return; }
  const selectionButton = event.target.closest("[data-save-selection]");
  if (selectionButton) { saveSelection(false); return; }
  const versionButton = event.target.closest("[data-save-version]");
  if (versionButton) { saveReportVersion(); return; }
  const draftButton = event.target.closest("[data-generate-draft]");
  if (draftButton) {
    if (state.role === "MEMBER" && currentScreen()?.screen_id === "MBR-06") saveSelection(true);
    else generateDraft();
    return;
  }
  const actionButton = event.target.closest("[data-action]");
  if (actionButton && !actionButton.disabled) { openConfirmation(actionButton.dataset.action); return; }
  const questionButton = event.target.closest("[data-question]");
  if (questionButton) { const input = $("#question-input"); if (input) input.value = questionButton.dataset.question; return; }
  const demoButton = event.target.closest("[data-demo]");
  if (demoButton) showToast("시연 입력을 반영했습니다. 실제 운영에서는 저장 전 Schema·권한·보안 검사를 수행합니다.");
});

$("#role-select").addEventListener("change", (event) => loadRole(event.target.value));
$("#open-spec").addEventListener("click", openSpec);
$("#primary-action").addEventListener("click", handlePrimaryAction);
$("#confirm-submit").addEventListener("click", (event) => { event.preventDefault(); executePendingAction(); });
$("#toggle-agent").addEventListener("click", () => {
  const split = $("#content-split");
  const hidden = split.classList.toggle("agent-hidden");
  $("#toggle-agent").setAttribute("aria-expanded", String(!hidden));
  if (!hidden) $("#agent-chat-input")?.focus();
});
$("#close-agent").addEventListener("click", () => {
  $("#content-split").classList.add("agent-hidden");
  $("#toggle-agent").setAttribute("aria-expanded", "false");
});
$("#new-agent-chat").addEventListener("click", newAgentChat);
$("#agent-composer").addEventListener("submit", handleAgentChatSubmit);
$("#agent-chat-input").addEventListener("input", autoResizeAgentInput);
$("#agent-chat-input").addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey && !event.isComposing) {
    event.preventDefault();
    handleAgentChatSubmit();
  }
});
$("#agent-attach").addEventListener("click", () => $("#agent-source-file").click());
$("#agent-tools").addEventListener("click", () => {
  setAgentPrompt("업무 Agent가 할 수 있는 일을 알려줘");
  handleAgentChatSubmit();
});
$("#agent-source-file").addEventListener("change", handleAgentFile);
$("#agent-page-chip").addEventListener("click", () => {
  const menu = $("#agent-page-menu");
  menu.hidden = !menu.hidden;
  $("#agent-page-chip").setAttribute("aria-expanded", String(!menu.hidden));
});
$("#agent-page-menu").addEventListener("click", (event) => {
  const button = event.target.closest("[data-agent-page]");
  if (button) selectAgentPage(button.dataset.agentPage);
});
$("#weekly-agent").addEventListener("click", (event) => {
  const promptButton = event.target.closest("[data-agent-prompt]");
  if (promptButton) {
    setAgentPrompt(promptButton.dataset.agentPrompt);
    handleAgentChatSubmit();
    return;
  }
  if (event.target.closest("[data-agent-attach]")) {
    $("#agent-source-file").click();
    return;
  }
  if (event.target.closest("[data-agent-remove-file]")) {
    state.agent.attachment = null;
    renderAgentAttachment();
    return;
  }
  if (event.target.closest("[data-agent-apply-chat]")) applyAgentDraft();
});
$("#reset-demo").addEventListener("click", async () => {
  if (!window.confirm("모든 시연 데이터를 최초 상태로 되돌릴까요?")) return;
  try {
    const result = await api("/api/reset", { method: "POST", body: "{}" });
    state.generatedDraft = null; state.lastAnswer = null;
    state.agent.draft = null; state.agent.attachment = null; state.agent.conversationCount = 0;
    newAgentChat();
    await loadRole(state.role, currentScreen()?.screen_id);
    showToast(result.message);
  } catch (error) { showToast(error.message, true); }
});

loadRole(state.role);
