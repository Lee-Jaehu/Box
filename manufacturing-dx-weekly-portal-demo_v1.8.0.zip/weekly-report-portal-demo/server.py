#!/usr/bin/env python3
"""Dependency-free local demo server for the weekly report portal."""

from __future__ import annotations

import argparse
import errno
import json
import mimetypes
import os
import re
import sqlite3
import threading
import time
import uuid
import webbrowser
from datetime import datetime, timedelta, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

from build_db import DB_PATH, build_database
from work_agent import (
    AgentConfigurationError,
    AgentProviderError,
    agent_status,
    run_work_agent,
)

ROOT = Path(__file__).resolve().parent
WEB_ROOT = ROOT / "web"
RESET_LOCK = threading.Lock()

ROLE_USERS = {
    "COMMON": "u_member1",
    "MEMBER": "u_member1",
    "LEADER": "u_leader",
    "DEPT": "u_dept",
    "PLANNING": "u_planning",
    "HEAD": "u_head",
    "DATA_OWNER": "u_data",
    "ADMIN": "u_admin",
}

ROLE_LABELS = {
    "COMMON": "공통 사용자",
    "MEMBER": "팀원",
    "LEADER": "팀장",
    "DEPT": "담당",
    "PLANNING": "기획팀",
    "HEAD": "그룹장",
    "DATA_OWNER": "KPI Data Owner",
    "ADMIN": "운영자",
}


def now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def trace_id() -> str:
    return "TRACE-DEMO-" + uuid.uuid4().hex[:10].upper()


def connect() -> sqlite3.Connection:
    connection = sqlite3.connect(DB_PATH, timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def rows(connection: sqlite3.Connection, sql: str, params: tuple = ()) -> list[dict]:
    return [dict(row) for row in connection.execute(sql, params).fetchall()]


def one(connection: sqlite3.Connection, sql: str, params: tuple = ()) -> dict | None:
    row = connection.execute(sql, params).fetchone()
    return dict(row) if row else None


def scoped_work_items(connection: sqlite3.Connection, role: str, user_id: str) -> list[dict]:
    base = """
        SELECT w.*, u.display_name AS owner_name, o.name AS organization_name,
               c.collaboration_code
          FROM work_items w
          JOIN users u ON u.id = w.owner_user_id
          JOIN organizations o ON o.id = w.organization_id
          LEFT JOIN collaborations c ON c.id = w.collaboration_id
    """
    if role == "MEMBER":
        return rows(connection, base + " WHERE w.owner_user_id = ? ORDER BY w.work_item_code", (user_id,))
    if role == "LEADER":
        return rows(connection, base + " WHERE w.organization_id = 'team_rsnd' ORDER BY w.work_item_code")
    if role == "DEPT":
        return rows(connection, base + " WHERE w.organization_id IN ('team_rsnd','team_electrode','team_assembly','team_activation') ORDER BY w.work_item_code")
    return rows(connection, base + " ORDER BY w.work_item_code")


def scoped_work_pages(connection: sqlite3.Connection, role: str, user_id: str) -> list[dict]:
    base = """
        SELECT p.*, owner.display_name AS primary_owner_name, o.name AS organization_name,
               (SELECT GROUP_CONCAT(u.display_name || ':' || c.contributor_role, ',')
                  FROM work_page_contributors c JOIN users u ON u.id=c.user_id
                 WHERE c.work_page_id=p.id ORDER BY c.display_order) AS contributors,
               (SELECT GROUP_CONCAT(i.work_item_id, ',') FROM work_page_items i
                 WHERE i.work_page_id=p.id) AS work_item_ids
          FROM work_pages p
          JOIN users owner ON owner.id=p.primary_owner_user_id
          JOIN organizations o ON o.id=p.organization_id
         WHERE p.cycle_id='cycle_w34'
    """
    if role == "MEMBER":
        return rows(connection, base + " AND EXISTS (SELECT 1 FROM work_page_contributors c WHERE c.work_page_id=p.id AND c.user_id=?) ORDER BY p.display_order", (user_id,))
    if role == "LEADER":
        return rows(connection, base + " AND p.organization_id='team_rsnd' ORDER BY p.display_order")
    return rows(connection, base + " ORDER BY p.organization_id, p.display_order")


def bootstrap(role: str) -> dict:
    role = role if role in ROLE_USERS else "MEMBER"
    user_id = ROLE_USERS[role]
    with connect() as connection:
        principal = one(connection, """
            SELECT u.id, u.display_name, u.email, o.name AS organization_name,
                   ? AS role_code, ? AS role_label
              FROM users u JOIN organizations o ON o.id = u.organization_id
             WHERE u.id = ?
        """, (role, ROLE_LABELS[role], user_id))
        cycle = one(connection, "SELECT * FROM reporting_cycles WHERE cycle_code = '2026-W34'")
        screens = rows(connection, "SELECT * FROM screen_definitions WHERE role_code = ? ORDER BY display_order", (role,))
        snapshots = rows(connection, """
            SELECT s.*, m.metric_code, m.name AS metric_name, m.unit,
                   ROUND(AVG(v.value), 3) AS display_value,
                   ROUND(AVG(v.previous_value), 3) AS previous_value,
                   ROUND(AVG(v.target_value), 3) AS target_value
              FROM metric_snapshots s
              JOIN metric_definitions m ON m.id = s.metric_id
              LEFT JOIN metric_values v ON v.snapshot_id = s.id
             WHERE s.cycle_id = 'cycle_w34'
             GROUP BY s.id ORDER BY m.metric_code
        """)
        items = scoped_work_items(connection, role, user_id)
        work_pages = scoped_work_pages(connection, role, user_id)
        worklogs = rows(connection, """
            SELECT l.*, w.work_item_code, u.display_name AS author_name
              FROM worklogs l JOIN work_items w ON w.id = l.work_item_id
              JOIN users u ON u.id = l.author_user_id
             ORDER BY l.occurred_on DESC
        """)
        evidence = rows(connection, """
            SELECT e.*, w.work_item_code FROM evidence e
            JOIN work_items w ON w.id = e.work_item_id ORDER BY e.evidence_code
        """)
        submissions = rows(connection, """
            SELECT s.*, u.display_name AS member_name, o.name AS organization_name
              FROM submissions s JOIN users u ON u.id = s.member_user_id
              JOIN organizations o ON o.id = s.organization_id
             ORDER BY u.display_name
        """)
        submission_items = rows(connection, """
            SELECT si.*, w.work_item_code, w.title
              FROM submission_items si JOIN work_items w ON w.id = si.work_item_id
             ORDER BY si.submission_id, w.work_item_code
        """)
        submission_pages = rows(connection, """
            SELECT sp.*, p.page_code, p.title, p.site_scope, p.process_scope,
                   owner.display_name AS primary_owner_name
              FROM submission_pages sp JOIN work_pages p ON p.id=sp.work_page_id
              JOIN users owner ON owner.id=p.primary_owner_user_id
             ORDER BY sp.submission_id, p.display_order
        """)
        submission_versions = rows(connection, """
            SELECT sv.*, s.submission_code, s.member_user_id, u.display_name AS member_name
              FROM submission_versions sv
              JOIN submissions s ON s.id = sv.submission_id
              JOIN users u ON u.id = s.member_user_id
             WHERE sv.version_number = (
                   SELECT MAX(latest.version_number) FROM submission_versions latest
                    WHERE latest.submission_id = sv.submission_id
             )
             ORDER BY u.display_name
        """)
        reports = rows(connection, """
            SELECT r.*, o.name AS organization_name, v.content, v.source_manifest,
                   v.generated_by, v.created_at AS version_created_at
              FROM reports r JOIN organizations o ON o.id = r.organization_id
              LEFT JOIN report_versions v ON v.report_id = r.id AND v.version_number = r.current_version
             WHERE r.cycle_id = 'cycle_w34' ORDER BY r.report_level
        """)
        collaborations = rows(connection, """
            SELECT c.*, o.name AS lead_organization FROM collaborations c
            JOIN organizations o ON o.id = c.lead_org_id ORDER BY c.collaboration_code
        """)
        participants = rows(connection, """
            SELECT cp.*, c.collaboration_code, o.name AS organization_name
              FROM collaboration_participants cp
              JOIN collaborations c ON c.id = cp.collaboration_id
              JOIN organizations o ON o.id = cp.organization_id
             ORDER BY c.collaboration_code, o.name
        """)
        qa = rows(connection, "SELECT * FROM qa_issues ORDER BY CASE severity WHEN 'BLOCK' THEN 1 WHEN 'WARN' THEN 2 ELSE 3 END, id")
        decisions = rows(connection, """
            SELECT d.*, u.display_name AS decision_maker FROM decisions d
            LEFT JOIN users u ON u.id = d.decision_maker_user_id ORDER BY d.due_date
        """)
        actions = rows(connection, """
            SELECT a.*, u.display_name AS owner_name FROM action_items a
            LEFT JOIN users u ON u.id = a.owner_user_id ORDER BY a.due_date
        """)
        audit = rows(connection, """
            SELECT a.*, u.display_name AS actor_name FROM audit_events a
            LEFT JOIN users u ON u.id = a.actor_user_id ORDER BY a.id DESC LIMIT 50
        """)
        counts = {
            "screens": len(screens),
            "snapshots_locked": sum(1 for item in snapshots if item["status"] == "LOCKED"),
            "snapshots_total": len(snapshots),
            "work_items": len(items),
            "work_pages": len(work_pages),
            "open_qa": sum(1 for item in qa if item["status"] == "OPEN"),
            "open_decisions": sum(1 for item in decisions if item["status"] != "RESOLVED"),
            "submitted_members": sum(1 for item in submissions if item["status"] in {"SUBMITTED", "ACCEPTED", "LOCKED"}),
            "members_total": len(submissions),
        }
    return {
        "principal": principal,
        "cycle": cycle,
        "screens": screens,
        "snapshots": snapshots,
        "work_items": items,
        "work_pages": work_pages,
        "worklogs": worklogs,
        "evidence": evidence,
        "submissions": submissions,
        "submission_items": submission_items,
        "submission_pages": submission_pages,
        "submission_versions": submission_versions,
        "reports": reports,
        "collaborations": collaborations,
        "participants": participants,
        "qa_issues": qa,
        "decisions": decisions,
        "action_items": actions,
        "audit_events": audit,
        "counts": counts,
        "role_labels": ROLE_LABELS,
    }


def audit_event(connection: sqlite3.Connection, role: str, action: str, resource_type: str, resource_id: str, result: str, detail: str, trace: str) -> None:
    connection.execute(
        """INSERT INTO audit_events(occurred_at,trace_id,actor_user_id,actor_role,action,resource_type,resource_id,result,detail)
           VALUES(?,?,?,?,?,?,?,?,?)""",
        (now_iso(), trace, ROLE_USERS.get(role), role, action, resource_type, resource_id, result, detail),
    )


def save_worklog(payload: dict) -> tuple[int, dict]:
    role = str(payload.get("role", "MEMBER"))
    work_item_id = str(payload.get("work_item_id", "")).strip()
    entry_type = str(payload.get("entry_type", "RESULT")).strip().upper()
    narrative = str(payload.get("narrative", "")).strip()
    occurred_on = str(payload.get("occurred_on", now_iso()[:10])).strip()
    if entry_type == "NEXT":
        entry_type = "PLAN"
    if entry_type not in {"FACT", "RESULT", "ANALYSIS", "PLAN", "RISK"}:
        return HTTPStatus.BAD_REQUEST, {"ok": False, "message": "지원하지 않는 기록 유형입니다."}
    if not narrative:
        return HTTPStatus.BAD_REQUEST, {"ok": False, "message": "추가 작성 내용을 입력하십시오."}
    if len(narrative) > 4000:
        return HTTPStatus.BAD_REQUEST, {"ok": False, "message": "기록 내용은 4,000자 이하로 입력하십시오."}
    trace = trace_id()
    with connect() as connection:
        item = one(connection, "SELECT * FROM work_items WHERE id=?", (work_item_id,))
        if not item or item["owner_user_id"] != ROLE_USERS.get(role):
            return HTTPStatus.FORBIDDEN, {"ok": False, "message": "본인 소유 WorkItem에만 기록할 수 있습니다.", "trace_id": trace}
        record_id = "wl_" + uuid.uuid4().hex[:12]
        connection.execute(
            "INSERT INTO worklogs VALUES(?,?,?,?,?,?)",
            (record_id, work_item_id, ROLE_USERS[role], occurred_on, entry_type, narrative),
        )
        audit_event(connection, role, "CREATE_WORKLOG", "WORK_ITEM", work_item_id, "SUCCEEDED", f"{entry_type} 기록 추가", trace)
        connection.commit()
        saved = one(connection, """
            SELECT l.*, w.work_item_code, u.display_name AS author_name
              FROM worklogs l JOIN work_items w ON w.id=l.work_item_id
              JOIN users u ON u.id=l.author_user_id WHERE l.id=?
        """, (record_id,))
    return HTTPStatus.OK, {"ok": True, "message": "추가 기록을 저장했습니다. 다음 화면과 AI 초안에 반영됩니다.", "record": saved, "trace_id": trace}


def save_evidence(payload: dict) -> tuple[int, dict]:
    role = str(payload.get("role", "MEMBER"))
    work_item_id = str(payload.get("work_item_id", "")).strip()
    file_name = str(payload.get("file_name", "")).strip()
    locator = str(payload.get("locator", "사용자 지정 없음")).strip() or "사용자 지정 없음"
    security_label = str(payload.get("security_label", "CONFIDENTIAL")).strip().upper()
    if not file_name:
        return HTTPStatus.BAD_REQUEST, {"ok": False, "message": "등록할 파일을 선택하십시오."}
    if security_label not in {"INTERNAL", "CONFIDENTIAL"}:
        return HTTPStatus.BAD_REQUEST, {"ok": False, "message": "지원하지 않는 보안등급입니다."}
    trace = trace_id()
    with connect() as connection:
        item = one(connection, "SELECT * FROM work_items WHERE id=?", (work_item_id,))
        if not item or item["owner_user_id"] != ROLE_USERS.get(role):
            return HTTPStatus.FORBIDDEN, {"ok": False, "message": "본인 소유 WorkItem에만 Evidence를 등록할 수 있습니다.", "trace_id": trace}
        last_code = one(connection, "SELECT evidence_code FROM evidence ORDER BY evidence_code DESC LIMIT 1")
        last_number = int(last_code["evidence_code"][-3:]) if last_code else 0
        evidence_code = f"EVD-RSND-2026-W34-{last_number + 1:03d}"
        record_id = "ev_" + uuid.uuid4().hex[:12]
        content_type = mimetypes.guess_type(file_name)[0] or "application/octet-stream"
        file_hash = (uuid.uuid4().hex + uuid.uuid4().hex)[:64]
        connection.execute(
            "INSERT INTO evidence VALUES(?,?,?,?,?,?,?,?,?)",
            (record_id, evidence_code, work_item_id, file_name, content_type, file_hash, locator, "CLEAN", security_label),
        )
        audit_event(connection, role, "UPLOAD_EVIDENCE", "WORK_ITEM", work_item_id, "SUCCEEDED", evidence_code, trace)
        connection.commit()
        saved = one(connection, "SELECT e.*, w.work_item_code FROM evidence e JOIN work_items w ON w.id=e.work_item_id WHERE e.id=?", (record_id,))
    return HTTPStatus.OK, {"ok": True, "message": "Evidence를 등록했습니다. 업무페이지 선택 화면에 반영됩니다.", "record": saved, "trace_id": trace}


def save_submission_items(payload: dict) -> tuple[int, dict]:
    role = str(payload.get("role", "MEMBER"))
    selected_pages = payload.get("work_page_ids")
    if selected_pages is not None:
        if not isinstance(selected_pages, list):
            return HTTPStatus.BAD_REQUEST, {"ok": False, "message": "업무페이지 선택 형식이 올바르지 않습니다."}
        selected_ids = {str(item) for item in selected_pages}
        trace = trace_id()
        with connect() as connection:
            allowed = rows(connection, """
                SELECT p.id FROM work_pages p
                 WHERE p.cycle_id='cycle_w34'
                   AND EXISTS (
                       SELECT 1 FROM work_page_contributors c
                        WHERE c.work_page_id=p.id AND c.user_id=?
                   )
            """, (ROLE_USERS.get(role),))
            allowed_ids = {item["id"] for item in allowed}
            selected_ids &= allowed_ids
            if not selected_ids:
                return HTTPStatus.BAD_REQUEST, {"ok": False, "message": "보고서에 포함할 업무페이지를 한 건 이상 선택하십시오.", "trace_id": trace}
            for page_id in allowed_ids:
                included = 1 if page_id in selected_ids else 0
                reason = "사용자 선택" if included else "이번 주 보고 제외"
                connection.execute("""
                    INSERT INTO submission_pages(submission_id,work_page_id,included,inclusion_reason)
                    VALUES('sub_member1',?,?,?)
                    ON CONFLICT(submission_id,work_page_id)
                    DO UPDATE SET included=excluded.included, inclusion_reason=excluded.inclusion_reason
                """, (page_id, included, reason))
            audit_event(connection, role, "SAVE_PAGE_SELECTION", "SUBMISSION", "sub_member1", "SUCCEEDED", f"업무페이지 선택 {len(selected_ids)}건", trace)
            connection.commit()
        return HTTPStatus.OK, {"ok": True, "message": f"금주 보고 업무페이지 {len(selected_ids)}건을 선택했습니다.", "work_page_ids": sorted(selected_ids), "trace_id": trace}

    selected = payload.get("work_item_ids", [])
    if not isinstance(selected, list):
        return HTTPStatus.BAD_REQUEST, {"ok": False, "message": "선택 항목 형식이 올바르지 않습니다."}
    selected_ids = {str(item) for item in selected}
    trace = trace_id()
    with connect() as connection:
        allowed = rows(connection, "SELECT id FROM work_items WHERE owner_user_id=?", (ROLE_USERS.get(role),))
        allowed_ids = {item["id"] for item in allowed}
        selected_ids &= allowed_ids
        if not selected_ids:
            return HTTPStatus.BAD_REQUEST, {"ok": False, "message": "보고서에 포함할 업무를 한 건 이상 선택하십시오.", "trace_id": trace}
        for work_item_id in allowed_ids:
            included = 1 if work_item_id in selected_ids else 0
            reason = "사용자 선택" if included else "이번 주 보고 제외"
            connection.execute("""
                INSERT INTO submission_items(submission_id,work_item_id,included,inclusion_reason)
                VALUES('sub_member1',?,?,?)
                ON CONFLICT(submission_id,work_item_id)
                DO UPDATE SET included=excluded.included, inclusion_reason=excluded.inclusion_reason
            """, (work_item_id, included, reason))
        audit_event(connection, role, "SAVE_SELECTION", "SUBMISSION", "sub_member1", "SUCCEEDED", f"선택 {len(selected_ids)}건", trace)
        connection.commit()
    return HTTPStatus.OK, {"ok": True, "message": f"금주 보고 업무 {len(selected_ids)}건을 선택했습니다.", "work_item_ids": sorted(selected_ids), "trace_id": trace}


def save_edited_version(payload: dict) -> tuple[int, dict]:
    role = str(payload.get("role", "MEMBER"))
    content = str(payload.get("content", "")).strip()
    if not content:
        return HTTPStatus.BAD_REQUEST, {"ok": False, "message": "저장할 보고서 내용을 입력하십시오."}
    if len(content) > 50_000:
        return HTTPStatus.BAD_REQUEST, {"ok": False, "message": "보고서 내용은 50,000자 이하로 입력하십시오."}
    source_codes = list(dict.fromkeys(re.findall(r"\[((?:WI|RPG|SNP|COL|EVD|DEC|ACT|RPT|MET)-[^\]]+)\]", content)))
    trace = trace_id()
    with connect() as connection:
        if role == "MEMBER":
            latest = one(connection, "SELECT * FROM submission_versions WHERE submission_id='sub_member1' ORDER BY version_number DESC LIMIT 1")
            current = (latest["version_number"] if latest else 0) + 1
            manifest = ",".join(source_codes) or (latest["source_manifest"] if latest else "")
            connection.execute("UPDATE submissions SET status='AI_DRAFTED', version=? WHERE id='sub_member1'", (current,))
            connection.execute(
                "INSERT INTO submission_versions VALUES(?,?,?,?,?,?,?)",
                ("sv_member1_" + uuid.uuid4().hex[:10], "sub_member1", current, content, manifest, "HUMAN_MEMBER", now_iso()),
            )
            resource_type, resource_id = "SUBMISSION", "sub_member1"
            message = f"수정본 v{current}을 저장했습니다. 제출 화면과 팀장 검토 화면에 반영됩니다."
        else:
            report_map = {"LEADER": "rpt_team", "DEPT": "rpt_dept", "PLANNING": "rpt_group"}
            report_id = report_map.get(role)
            if not report_id:
                return HTTPStatus.FORBIDDEN, {"ok": False, "message": "현재 역할에서는 보고서 Version을 저장할 수 없습니다.", "trace_id": trace}
            report = one(connection, "SELECT * FROM reports WHERE id=?", (report_id,))
            latest = one(connection, "SELECT * FROM report_versions WHERE report_id=? ORDER BY version_number DESC LIMIT 1", (report_id,))
            current = report["current_version"] + 1
            manifest = ",".join(source_codes) or (latest["source_manifest"] if latest else "")
            generator = {"LEADER": "HUMAN_LEADER", "DEPT": "HUMAN_DEPARTMENT", "PLANNING": "HUMAN_PLANNING"}[role]
            connection.execute("UPDATE reports SET status='DRAFT', current_version=? WHERE id=?", (current, report_id))
            connection.execute(
                "INSERT INTO report_versions VALUES(?,?,?,?,?,?,?)",
                ("rv_edit_" + uuid.uuid4().hex[:10], report_id, current, content, manifest, generator, now_iso()),
            )
            resource_type, resource_id = "REPORT", report_id
            message = f"수정본 v{current}을 저장했습니다. 다음 검토 화면에 반영됩니다."
        audit_event(connection, role, "SAVE_EDITED_VERSION", resource_type, resource_id, "SUCCEEDED", message, trace)
        connection.commit()
    return HTTPStatus.OK, {"ok": True, "message": message, "version": current, "source_manifest": manifest, "trace_id": trace}


def run_action(payload: dict) -> tuple[int, dict]:
    action = str(payload.get("action", ""))
    role = str(payload.get("role", "MEMBER"))
    trace = trace_id()
    with connect() as connection:
        if action == "VALIDATE_SNAPSHOT":
            connection.execute("UPDATE metric_snapshots SET validation_errors=0, validation_warnings=0, status='READY_FOR_APPROVAL' WHERE id='snp_pd_w34'")
            connection.execute("UPDATE qa_issues SET status='RESOLVED' WHERE resource_id='snp_pd_w34'")
            audit_event(connection, role, action, "METRIC_SNAPSHOT", "snp_pd_w34", "SUCCEEDED", "오류 해소 후 재검증 통과", trace)
            message = "PD Snapshot 재검증이 통과했습니다. 승인·잠금할 수 있습니다."
        elif action == "APPROVE_SNAPSHOT":
            snapshot = one(connection, "SELECT * FROM metric_snapshots WHERE id='snp_pd_w34'")
            if not snapshot or snapshot["validation_errors"]:
                return HTTPStatus.CONFLICT, {"ok": False, "message": "BLOCK 오류를 먼저 해소해야 합니다.", "trace_id": trace}
            connection.execute("UPDATE metric_snapshots SET status='LOCKED', verification_state='VERIFIED' WHERE id='snp_pd_w34'")
            audit_event(connection, role, action, "METRIC_SNAPSHOT", "snp_pd_w34", "SUCCEEDED", "Data Owner 승인 및 불변 잠금", trace)
            message = "PD Snapshot을 승인하고 잠갔습니다."
        elif action == "SUBMIT_MEMBER":
            connection.execute("UPDATE submissions SET status='SUBMITTED', submitted_at=? WHERE id='sub_member1'", (now_iso(),))
            audit_event(connection, role, action, "SUBMISSION", "sub_member1", "SUCCEEDED", "팀원 제출", trace)
            message = "팀원 보고를 팀장에게 제출했습니다."
        elif action == "APPROVE_TEAM":
            connection.execute("UPDATE reports SET status='TEAM_APPROVED', current_version=current_version+1 WHERE id='rpt_team'")
            current = one(connection, "SELECT current_version FROM reports WHERE id='rpt_team'")["current_version"]
            source = one(connection, "SELECT content, source_manifest FROM report_versions WHERE report_id='rpt_team' ORDER BY version_number DESC LIMIT 1")
            connection.execute("INSERT INTO report_versions VALUES(?,?,?,?,?,?,?)", ("rv_team_" + uuid.uuid4().hex[:8], "rpt_team", current, source["content"], source["source_manifest"], "HUMAN_LEADER", now_iso()))
            audit_event(connection, role, action, "REPORT", "rpt_team", "SUCCEEDED", "팀장 승인 후 담당 제출", trace)
            message = "팀 보고를 승인하고 담당에게 제출했습니다."
        elif action == "APPROVE_DEPT":
            connection.execute("UPDATE reports SET status='DEPT_APPROVED' WHERE id='rpt_dept'")
            audit_event(connection, role, action, "REPORT", "rpt_dept", "SUCCEEDED", "담당 승인 후 기획 제출", trace)
            message = "담당 보고를 승인하고 기획팀에 제출했습니다."
        elif action == "RESOLVE_QA":
            connection.execute("UPDATE qa_issues SET status='RESOLVED' WHERE resource_id='rpt_group'")
            audit_event(connection, role, action, "REPORT", "rpt_group", "SUCCEEDED", "데모 QA Issue 해소", trace)
            message = "그룹 보고 QA Issue를 해소했습니다."
        elif action == "APPROVE_PLANNING":
            open_blocks = one(connection, "SELECT COUNT(*) AS count FROM qa_issues WHERE resource_id='rpt_group' AND severity='BLOCK' AND status='OPEN'")["count"]
            if open_blocks:
                return HTTPStatus.CONFLICT, {"ok": False, "message": "BLOCK QA Issue를 먼저 해소해야 합니다.", "trace_id": trace}
            connection.execute("UPDATE reports SET status='READY_FOR_REPORT' WHERE id='rpt_group'")
            audit_event(connection, role, action, "REPORT", "rpt_group", "SUCCEEDED", "기획 QA 완료 및 그룹장 확정 요청", trace)
            message = "그룹장 보고 확정 요청을 완료했습니다."
        elif action == "RESOLVE_DECISION":
            connection.execute("UPDATE decisions SET status='RESOLVED', resolution='W35 K12 검증 생산 일정 우선 배정 승인' WHERE id='dec1'")
            exists = one(connection, "SELECT id FROM action_items WHERE action_code='ACT-RSND-2026-0052'")
            if not exists:
                connection.execute("INSERT INTO action_items VALUES(?,?,?,?,?,?,?,?)", ("act3", "ACT-RSND-2026-0052", "dec1", "K12 재현성 검증 완료", "u_leader", "2026-08-27", "OPEN", "HIGH"))
            audit_event(connection, role, action, "DECISION", "dec1", "SUCCEEDED", "그룹장 결정 및 Action 생성", trace)
            message = "Decision을 확정하고 후속 Action을 만들었습니다."
        else:
            return HTTPStatus.BAD_REQUEST, {"ok": False, "message": "지원하지 않는 시연 동작입니다.", "trace_id": trace}
        connection.commit()
    return HTTPStatus.OK, {"ok": True, "message": message, "trace_id": trace}


def _join_narratives(log_items: list[dict]) -> str:
    sentences = []
    for item in log_items:
        sentence = str(item["narrative"]).strip()
        if sentence and sentence[-1] not in ".!?습니다요함됨":
            sentence += "."
        sentences.append(sentence)
    return " ".join(sentences)


def build_member_draft(connection: sqlite3.Connection) -> tuple[str, list[str]]:
    selected_pages = rows(connection, """
        SELECT p.*
          FROM submission_pages sp JOIN work_pages p ON p.id=sp.work_page_id
         WHERE sp.submission_id='sub_member1' AND sp.included=1
         ORDER BY p.display_order
    """)
    snapshot = one(connection, """
        SELECT s.snapshot_code, s.verification_state, m.name AS metric_name, m.unit,
               ROUND(AVG(v.value),3) AS value, ROUND(AVG(v.previous_value),3) AS previous_value
          FROM metric_snapshots s JOIN metric_definitions m ON m.id=s.metric_id
          LEFT JOIN metric_values v ON v.snapshot_id=s.id
         WHERE s.id='snp_pd_w34' GROUP BY s.id
    """)
    page_documents: list[str] = []
    citations: list[str] = []
    current_week_start = "2026-08-17"
    retention_start = (datetime.fromisoformat(current_week_start) - timedelta(weeks=3)).date().isoformat()

    for page in selected_pages:
        contributors = rows(connection, """
            SELECT u.display_name, c.contributor_role
              FROM work_page_contributors c JOIN users u ON u.id=c.user_id
             WHERE c.work_page_id=? ORDER BY c.display_order
        """, (page["id"],))
        author_label = ", ".join(
            f"{item['display_name']}({'주' if item['contributor_role'] == 'PRIMARY' else '공동'})"
            for item in contributors
        )
        logs = rows(connection, """
            SELECT l.*, w.work_item_code, c.collaboration_code
              FROM work_page_items pi JOIN work_items w ON w.id=pi.work_item_id
              JOIN worklogs l ON l.work_item_id=w.id
              LEFT JOIN collaborations c ON c.id=w.collaboration_id
             WHERE pi.work_page_id=? AND l.occurred_on>=?
             ORDER BY l.occurred_on, l.id
        """, (page["id"], retention_start))
        evidence_items = rows(connection, """
            SELECT e.evidence_code, e.work_item_id
              FROM work_page_items pi JOIN evidence e ON e.work_item_id=pi.work_item_id
             WHERE pi.work_page_id=? ORDER BY e.evidence_code
        """, (page["id"],))
        page_items = rows(connection, """
            SELECT w.work_item_code, c.collaboration_code
              FROM work_page_items pi JOIN work_items w ON w.id=pi.work_item_id
              LEFT JOIN collaborations c ON c.id=w.collaboration_id
             WHERE pi.work_page_id=? ORDER BY w.work_item_code
        """, (page["id"],))
        citations.append(page["page_code"])
        for item in page_items:
            citations.append(item["work_item_code"])
            if item.get("collaboration_code"):
                citations.append(item["collaboration_code"])
        citations.extend(item["evidence_code"] for item in evidence_items)

        sections: list[str] = []
        for log in logs:
            tag = "PLAN" if log["entry_type"] == "NEXT" else log["entry_type"]
            is_new = log["occurred_on"] >= current_week_start
            state_token = "[NEW]" if is_new else ""
            code = log["collaboration_code"] if tag == "ANALYSIS" and log.get("collaboration_code") else log["work_item_code"]
            week = "W34" if is_new else f"W{datetime.fromisoformat(log['occurred_on']).isocalendar().week}"
            body = _join_narratives([log])
            evidence_suffix = ""
            if tag == "RESULT" and is_new:
                linked = [item["evidence_code"] for item in evidence_items if item["work_item_id"] == log["work_item_id"]]
                if linked:
                    evidence_suffix = " " + " ".join(f"[{code}]" for code in linked)
            sections.append(f"[{code}][{tag}]{state_token} ({week}) {body}{evidence_suffix}")

        if page["id"] == "pg_tension" and snapshot:
            state_tag = "VERIFIED" if snapshot["verification_state"] == "VERIFIED" else "PROVISIONAL"
            sections.append(
                f"[{snapshot['snapshot_code']}][KPI][{state_tag}][NEW] (W34) {snapshot['metric_name']}는 {snapshot['value']}{snapshot['unit']}로 "
                f"전주 {snapshot['previous_value']}{snapshot['unit']} 대비 {snapshot['previous_value'] - snapshot['value']:.1f}%p 감소했습니다. "
                "다만 적용 전후 생산량과 제품 Mix가 동일하지 않아 자동보정 단독 효과로 확정하지 않았습니다."
            )
            citations.append(snapshot["snapshot_code"])
        if page["id"] == "pg_tension" and any("[RISK][NEW]" in section for section in sections):
            sections.append("[DEC-RSND-2026-0008][DECISION][NEW] (W34) K12 검증 생산 일정 우선 배정이 필요합니다.")
            citations.append("DEC-RSND-2026-0008")

        header = "|".join([
            page["page_code"], page["title"], page["site_scope"], page["process_scope"],
            page["project_scope"], author_label,
        ])
        page_documents.append(f"@@PAGE|{header}@@\n" + "\n\n".join(sections) + "\n@@ENDPAGE@@")

    return "\n\n".join(page_documents), list(dict.fromkeys(citations))


def _flatten_work_pages(content: str) -> str:
    matches = re.findall(r"@@PAGE\|([^\n]+)@@\n([\s\S]*?)\n@@ENDPAGE@@", content)
    if not matches:
        return content
    flattened = []
    for header, body in matches:
        fields = header.split("|", 5)
        if len(fields) != 6:
            continue
        page_code, title, site, process, project, authors = fields
        flattened.append(
            f"[{page_code}][RESULT] 업무페이지: {title}\n"
            f"범위: {site} · {process} / {project} / 작성: {authors}\n\n{body.strip()}"
        )
    return "\n\n".join(flattened) if flattened else content


def build_leader_draft(connection: sqlite3.Connection) -> tuple[str, list[str]]:
    latest = rows(connection, """
        SELECT sv.content, sv.source_manifest, u.display_name AS member_name
          FROM submission_versions sv
          JOIN submissions s ON s.id=sv.submission_id
          JOIN users u ON u.id=s.member_user_id
         WHERE sv.version_number=(SELECT MAX(v2.version_number) FROM submission_versions v2 WHERE v2.submission_id=sv.submission_id)
         ORDER BY u.display_name
    """)
    snapshot = one(connection, """
        SELECT s.snapshot_code, s.verification_state, m.name AS metric_name, m.unit,
               ROUND(AVG(v.value),3) AS value, ROUND(AVG(v.previous_value),3) AS previous_value
          FROM metric_snapshots s JOIN metric_definitions m ON m.id=s.metric_id
          LEFT JOIN metric_values v ON v.snapshot_id=s.id
         WHERE s.id='snp_pd_w34' GROUP BY s.id
    """)
    state_tag = "VERIFIED" if snapshot["verification_state"] == "VERIFIED" else "PROVISIONAL"
    sections = [(
        f"[{snapshot['snapshot_code']}][KPI][{state_tag}] RSND자동보정팀은 W34 {snapshot['metric_name']} {snapshot['value']}{snapshot['unit']}로 "
        f"전주 {snapshot['previous_value']}{snapshot['unit']} 대비 {snapshot['previous_value'] - snapshot['value']:.1f}%p 감소한 수준을 확인했습니다. "
        "현재 값은 공통 Snapshot 상태를 따르며, 자동보정 적용 전후 생산량과 제품 Mix가 동일하지 않아 팀 단독 개선효과로 확정하지 않았습니다."
    )]
    citations = [snapshot["snapshot_code"]]
    for row in latest:
        sections.append(_flatten_work_pages(row["content"]))
        citations.extend(item for item in row["source_manifest"].split(",") if item)
    sections.extend([
        "[COL-YIELD-2026-0014][ANALYSIS] 팀원별 결과를 종합하면 M08·M11은 보정조건의 반복 경향이 확인됐고 ESWA L07 적용 구간에서도 PD Loss 감소 방향성이 나타났습니다. 다만 K12 생산조건과 FDC 장력 편차의 영향이 분리되지 않았으므로 제품·Roll·설비조건별 분석을 추가해야 합니다.",
        "[WI-RSND-2026-0032][RISK] K12 검증용 생산 일정이 미확정되어 제품별 적용조건 확정과 수평전개 판단이 지연될 수 있습니다. 검증 전에는 M08·M11 결과만으로 전체 제품 효과를 확대 해석하지 않겠습니다.",
        "[WI-RSND-2026-0032][PLAN] W35에는 K12 재현성 검증과 제품별 상·하한 및 예외조건 확정을 우선 진행하겠습니다. 동시에 FDC 이상구간과 자동보정 동작이력을 동일 시간축으로 정렬하고, 동일 조건의 적용 전후 PD Loss를 재산출하겠습니다.",
        "[DEC-RSND-2026-0008][DECISION] K12 검증 생산 일정 우선 배정이 필요합니다.",
    ])
    citations.extend(["COL-YIELD-2026-0014", "WI-RSND-2026-0032", "DEC-RSND-2026-0008"])
    return "\n\n".join(sections), list(dict.fromkeys(citations))


def generate_draft(payload: dict) -> dict:
    role = str(payload.get("role", "MEMBER"))
    trace = trace_id()
    with connect() as connection:
        if role == "LEADER":
            content, citations = build_leader_draft(connection)
            current = one(connection, "SELECT current_version FROM reports WHERE id='rpt_team'")["current_version"] + 1
            connection.execute("UPDATE reports SET status='DRAFT', current_version=? WHERE id='rpt_team'", (current,))
            connection.execute(
                "INSERT INTO report_versions VALUES(?,?,?,?,?,?,?)",
                ("rv_team_" + uuid.uuid4().hex[:10], "rpt_team", current, content, ",".join(citations), "LEADER_AGENT", now_iso()),
            )
            resource_type, resource_id, detail = "REPORT", "rpt_team", "팀원 추가기록을 반영한 팀장 서술형 초안"
        elif role == "MEMBER":
            content, citations = build_member_draft(connection)
            current = one(connection, "SELECT COALESCE(MAX(version_number),0) AS version FROM submission_versions WHERE submission_id='sub_member1'")["version"] + 1
            connection.execute("UPDATE submissions SET status='AI_DRAFTED', version=? WHERE id='sub_member1'", (current,))
            connection.execute(
                "INSERT INTO submission_versions VALUES(?,?,?,?,?,?,?)",
                ("sv_member1_" + uuid.uuid4().hex[:10], "sub_member1", current, content, ",".join(citations), "MEMBER_AGENT", now_iso()),
            )
            resource_type, resource_id, detail = "SUBMISSION", "sub_member1", "추가기록·Evidence·선택업무를 반영한 팀원 초안"
        else:
            level = "DEPARTMENT" if role == "DEPT" else "GROUP"
            report = one(connection, """
                SELECT r.id, v.content, v.source_manifest FROM reports r
                JOIN report_versions v ON v.report_id=r.id AND v.version_number=r.current_version
                WHERE r.report_level=? AND r.cycle_id='cycle_w34'
            """, (level,))
            content = report["content"]
            citations = [item for item in report["source_manifest"].split(",") if item]
            resource_type, resource_id, detail = "REPORT", report["id"], "현재 보고 초안 재구성"
        audit_event(connection, role, "GENERATE_DRAFT", resource_type, resource_id, "SUCCEEDED", detail, trace)
        connection.commit()
    return {
        "ok": True,
        "content": content,
        "citations": citations,
        "validation": {"schema": True, "numbers": True, "citations": True, "policy": True},
        "trace_id": trace,
        "model": "DEMO_CONTEXT_AWARE_AGENT",
    }


def answer_question(payload: dict) -> dict:
    question = str(payload.get("question", "")).strip()
    return {
        "ok": True,
        "question": question,
        "answer": "현재 근거만으로 자동보정의 단독 효과를 확정할 수 없습니다. W34 PD Loss 1.2%는 전체 범위의 잠정 Snapshot이며, 동일 제품·동일 조건에서 자동보정 적용 전후를 분리한 승인 데이터가 추가로 필요합니다.",
        "citations": [
            {"code": "SNP-PD-2026-W34-004", "detail": "PD Loss 1.2% · 기준 2026-08-23 23:59 · PROVISIONAL"},
            {"code": "WI-RSND-2026-0032", "detail": "Jamming 자동보정 조건 검증"},
            {"code": "EVD-RSND-2026-W34-028", "detail": "검증표 Result!B4:H18"},
        ],
        "freshness": "2026-08-23T23:59:00+09:00",
        "trace_id": trace_id(),
    }


def build_work_agent_context(payload: dict) -> dict:
    """Return the role-scoped context that the single Work Agent may inspect."""
    role = str(payload.get("role", "MEMBER")).upper()
    if role not in ROLE_USERS:
        role = "MEMBER"
    user_id = ROLE_USERS[role]
    requested_page_id = str(payload.get("page_id", "")).strip()
    with connect() as connection:
        principal = one(connection, """
            SELECT u.id, u.display_name, o.name AS organization_name,
                   ? AS role_code, ? AS role_label
              FROM users u JOIN organizations o ON o.id=u.organization_id
             WHERE u.id=?
        """, (role, ROLE_LABELS[role], user_id))
        pages = scoped_work_pages(connection, role, user_id)
        selected_page = next((page for page in pages if page["id"] == requested_page_id), None)
        if selected_page is None and pages:
            selected_page = pages[0]

        work_items: list[dict] = []
        worklogs: list[dict] = []
        evidence_items: list[dict] = []
        if selected_page:
            work_items = rows(connection, """
                SELECT w.id, w.work_item_code, w.title, w.state, w.target_date,
                       u.display_name AS owner_name, c.collaboration_code
                  FROM work_page_items pi JOIN work_items w ON w.id=pi.work_item_id
                  JOIN users u ON u.id=w.owner_user_id
                  LEFT JOIN collaborations c ON c.id=w.collaboration_id
                 WHERE pi.work_page_id=? ORDER BY w.work_item_code
            """, (selected_page["id"],))
            worklogs = rows(connection, """
                SELECT l.occurred_on, l.entry_type, l.narrative, w.work_item_code,
                       u.display_name AS author_name
                  FROM work_page_items pi JOIN work_items w ON w.id=pi.work_item_id
                  JOIN worklogs l ON l.work_item_id=w.id
                  JOIN users u ON u.id=l.author_user_id
                 WHERE pi.work_page_id=? AND l.occurred_on>='2026-07-27'
                 ORDER BY l.occurred_on, l.id
            """, (selected_page["id"],))
            evidence_items = rows(connection, """
                SELECT e.evidence_code, e.file_name, e.locator, e.security_label,
                       w.work_item_code
                  FROM work_page_items pi JOIN work_items w ON w.id=pi.work_item_id
                  JOIN evidence e ON e.work_item_id=w.id
                 WHERE pi.work_page_id=? ORDER BY e.evidence_code
            """, (selected_page["id"],))

        snapshots = rows(connection, """
            SELECT s.snapshot_code, s.cutoff_at, s.verification_state, s.status,
                   m.metric_code, m.name AS metric_name, m.unit,
                   ROUND(AVG(v.value),3) AS value,
                   ROUND(AVG(v.previous_value),3) AS previous_value,
                   ROUND(AVG(v.target_value),3) AS target_value
              FROM metric_snapshots s JOIN metric_definitions m ON m.id=s.metric_id
              LEFT JOIN metric_values v ON v.snapshot_id=s.id
             WHERE s.cycle_id='cycle_w34'
             GROUP BY s.id ORDER BY m.metric_code
        """)

        current_report = ""
        if role == "MEMBER":
            latest = one(connection, """
                SELECT sv.content FROM submission_versions sv
                 WHERE sv.submission_id='sub_member1'
                 ORDER BY sv.version_number DESC LIMIT 1
            """)
            current_report = latest["content"] if latest else ""
        else:
            report_ids = {"LEADER": "rpt_team", "DEPT": "rpt_dept", "PLANNING": "rpt_group", "HEAD": "rpt_group"}
            report_id = report_ids.get(role)
            if report_id:
                latest = one(connection, """
                    SELECT content FROM report_versions WHERE report_id=?
                     ORDER BY version_number DESC LIMIT 1
                """, (report_id,))
                current_report = latest["content"] if latest else ""

    page_fields = ("id", "page_code", "title", "site_scope", "process_scope", "project_scope", "contributors", "work_item_ids")
    return {
        "current_date": now_iso()[:10],
        "cycle": {"code": "2026-W34", "current_week": "W34", "retention_weeks": 4},
        "screen_id": str(payload.get("screen_id", ""))[:30],
        "principal": principal,
        "available_pages": [{key: page.get(key) for key in page_fields} for page in pages],
        "selected_page": ({key: selected_page.get(key) for key in page_fields} if selected_page else None),
        "work_items": work_items,
        "four_week_worklogs": worklogs[-80:],
        "evidence": evidence_items[-40:],
        "metric_snapshots": snapshots,
        "current_report_excerpt": str(current_report or "")[-24_000:],
        "current_candidate": payload.get("current_draft"),
        "rules": {
            "ids_in_prose": False,
            "new_content_only": True,
            "render_tags_as_boxes": True,
            "human_confirmation_before_apply": True,
        },
    }


class DemoHandler(BaseHTTPRequestHandler):
    server_version = "WeeklyReportDemo/1.0"

    def log_message(self, fmt: str, *args: object) -> None:
        print("[%s] %s" % (self.log_date_time_string(), fmt % args))

    def send_json(self, payload: dict | list, status: int = HTTPStatus.OK) -> None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def read_json(self) -> dict:
        length = int(self.headers.get("Content-Length", "0"))
        if length > 1_000_000:
            raise ValueError("request too large")
        raw = self.rfile.read(length) if length else b"{}"
        return json.loads(raw.decode("utf-8"))

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/api/health":
            self.send_json({"ok": True, "database": DB_PATH.exists(), "time": now_iso()})
            return
        if parsed.path == "/api/bootstrap":
            role = parse_qs(parsed.query).get("role", ["MEMBER"])[0]
            self.send_json(bootstrap(role))
            return
        if parsed.path == "/api/screen-catalog":
            with connect() as connection:
                catalog = rows(connection, "SELECT * FROM screen_definitions ORDER BY role_code, display_order")
            self.send_json(catalog)
            return
        if parsed.path == "/api/agent/status":
            self.send_json(agent_status())
            return
        if parsed.path.startswith("/api/"):
            self.send_json({"ok": False, "message": "API not found"}, HTTPStatus.NOT_FOUND)
            return
        self.serve_static(parsed.path)

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        try:
            payload = self.read_json()
            if parsed.path == "/api/action":
                status, result = run_action(payload)
                self.send_json(result, status)
                return
            if parsed.path == "/api/worklogs":
                status, result = save_worklog(payload)
                self.send_json(result, status)
                return
            if parsed.path == "/api/evidence":
                status, result = save_evidence(payload)
                self.send_json(result, status)
                return
            if parsed.path == "/api/submission/items":
                status, result = save_submission_items(payload)
                self.send_json(result, status)
                return
            if parsed.path == "/api/draft/version":
                status, result = save_edited_version(payload)
                self.send_json(result, status)
                return
            if parsed.path == "/api/agent/draft":
                self.send_json(generate_draft(payload))
                return
            if parsed.path == "/api/agent/ask":
                self.send_json(answer_question(payload))
                return
            if parsed.path == "/api/agent/chat":
                agent_trace = trace_id()
                try:
                    context = build_work_agent_context(payload)
                    result = run_work_agent(payload, context)
                    result["trace_id"] = agent_trace
                    with connect() as connection:
                        selected = context.get("selected_page") or {}
                        audit_event(
                            connection,
                            str(payload.get("role", "MEMBER")),
                            "WORK_AGENT_CHAT",
                            "WORK_PAGE",
                            str(selected.get("id", "NOT_SELECTED")),
                            "SUCCEEDED",
                            f"{result.get('provider')} · {result.get('model')} · {result.get('action')}",
                            agent_trace,
                        )
                        connection.commit()
                    self.send_json(result)
                except AgentConfigurationError as exc:
                    self.send_json(
                        {"ok": False, "message": str(exc), "trace_id": agent_trace},
                        HTTPStatus.SERVICE_UNAVAILABLE,
                    )
                except AgentProviderError as exc:
                    print(f"[{agent_trace}] Work Agent provider error: {exc}")
                    error_payload = {
                        "ok": False,
                        "message": f"업무 Agent 모델 호출에 실패했습니다. 관리자에게 Trace ID {agent_trace}를 전달하십시오.",
                        "trace_id": agent_trace,
                    }
                    if os.getenv("WORK_AGENT_DEBUG", "").lower() in {"1", "true", "yes"}:
                        error_payload["detail"] = str(exc)
                    self.send_json(error_payload, HTTPStatus.BAD_GATEWAY)
                return
            if parsed.path == "/api/reset":
                with RESET_LOCK:
                    build_database()
                self.send_json({"ok": True, "message": "데모 데이터를 최초 상태로 초기화했습니다."})
                return
            self.send_json({"ok": False, "message": "API not found"}, HTTPStatus.NOT_FOUND)
        except (ValueError, json.JSONDecodeError) as exc:
            self.send_json({"ok": False, "message": str(exc)}, HTTPStatus.BAD_REQUEST)
        except sqlite3.Error as exc:
            self.send_json({"ok": False, "message": "database error", "detail": str(exc)}, HTTPStatus.INTERNAL_SERVER_ERROR)

    def serve_static(self, request_path: str) -> None:
        relative = "index.html" if request_path in {"", "/"} else unquote(request_path.lstrip("/"))
        candidate = (WEB_ROOT / relative).resolve()
        try:
            candidate.relative_to(WEB_ROOT.resolve())
        except ValueError:
            self.send_error(HTTPStatus.FORBIDDEN)
            return
        if not candidate.is_file():
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        content = candidate.read_bytes()
        content_type = mimetypes.guess_type(candidate.name)[0] or "application/octet-stream"
        if candidate.suffix in {".js", ".css", ".html"}:
            content_type += "; charset=utf-8"
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(content)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the Manufacturing DX weekly report demo")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--open", action="store_true", help="Open the demo in the default browser")
    parser.add_argument("--no-open", action="store_true", help="Do not open a browser")
    args = parser.parse_args()

    if not DB_PATH.exists():
        build_database()

    server = None
    selected_port = args.port
    for candidate_port in range(args.port, args.port + 10):
        try:
            server = ThreadingHTTPServer((args.host, candidate_port), DemoHandler)
            selected_port = candidate_port
            break
        except OSError as exc:
            if exc.errno not in {errno.EADDRINUSE, 10048}:
                raise
    if server is None:
        raise SystemExit(f"사용 가능한 포트를 찾지 못했습니다: {args.port}~{args.port + 9}")

    url = f"http://{args.host}:{selected_port}"
    if args.open and not args.no_open:
        threading.Thread(target=lambda: (time.sleep(0.7), webbrowser.open(url)), daemon=True).start()

    print(f"Manufacturing DX Weekly Portal demo: {url}")
    if selected_port != args.port:
        print(f"Port {args.port} was busy; switched to {selected_port}.")
    print("Press Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
