@echo off
setlocal EnableExtensions
chcp 65001 >nul
title Manufacturing DX Weekly Portal - LIVE Work Agent
cd /d "%~dp0"

if not defined WORK_AGENT_API_URL goto :missing
if not defined WORK_AGENT_MODEL goto :missing
if not defined WORK_AGENT_PROVIDER set "WORK_AGENT_PROVIDER=openai_compatible"
if not defined WORK_AGENT_API_KEY_HEADER set "WORK_AGENT_API_KEY_HEADER=Authorization"
if /I not "%WORK_AGENT_API_KEY_HEADER%"=="none" if not defined WORK_AGENT_API_KEY if not defined OPENAI_API_KEY goto :missing

set "WORK_AGENT_MODE=live"
echo [LIVE] 업무 Agent Provider: %WORK_AGENT_PROVIDER%
echo [LIVE] 업무 Agent Model: %WORK_AGENT_MODEL%
echo [보안] 인증정보는 서버 프로세스에서만 사용하며 브라우저에 전달하지 않습니다.
call run-demo.bat
exit /b %errorlevel%

:missing
echo.
echo [연결 필요] LIVE 업무 Agent 환경변수가 부족합니다.
echo.
echo  set WORK_AGENT_API_URL=https://사내승인엔드포인트/v1/chat/completions
echo  set WORK_AGENT_API_KEY=서버용인증정보
echo  set WORK_AGENT_MODEL=승인된모델배포명
echo  set WORK_AGENT_PROVIDER=openai_compatible
echo  run-live-agent.bat
echo.
echo 자세한 내용: WORK_AGENT_SETUP.md
pause
exit /b 1
