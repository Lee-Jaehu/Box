#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"

: "${WORK_AGENT_API_URL:?WORK_AGENT_API_URL is required}"
: "${WORK_AGENT_MODEL:?WORK_AGENT_MODEL is required}"
if [ "${WORK_AGENT_API_KEY_HEADER:-Authorization}" != "none" ]; then
  : "${WORK_AGENT_API_KEY:=${OPENAI_API_KEY:-}}"
  : "${WORK_AGENT_API_KEY:?WORK_AGENT_API_KEY or OPENAI_API_KEY is required}"
  export WORK_AGENT_API_KEY
fi

export WORK_AGENT_MODE=live
export WORK_AGENT_PROVIDER="${WORK_AGENT_PROVIDER:-openai_compatible}"
python3 server.py --open
