# 데모 데이터 사전

| 테이블 | 목적 | 대표 샘플 |
|---|---|---|
| `organizations` | 그룹·담당·팀 조직계층 | 제조DX그룹, 자동보정담당, RSND자동보정팀 |
| `users` | 데모 사용자 | 김현수, 이선우, 김도윤 등 가상 사용자 |
| `role_assignments` | 사용자 역할과 조직범위 | MEMBER, LEADER, DEPT, PLANNING, HEAD |
| `reporting_cycles` | 보고 주차와 마감 | 2026-W34 |
| `metric_definitions` | KPI 공식 정의 | YIELD_RATE, BM_LOSS, PD_LOSS, DEFECT_RATE |
| `metric_snapshots` | 기준일 KPI Snapshot | SNP-PD-2026-W34-004 |
| `metric_values` | Snapshot 상세값 | ESWA L07 PD Loss 1.2% |
| `work_items` | 개인·팀 업무 단위 | WI-RSND-2026-0032 |
| `worklogs` | 사실·결과·분석·계획·Risk 이력 | K12 추가검증 필요 |
| `work_pages` | 법인·공정·프로젝트별 주간보고 페이지 | RPG-RSND-2026-0001 |
| `work_page_contributors` | 페이지 주작성자·공동작성자 | 김현수(주), 이정훈(공동) |
| `work_page_items` | 한 업무페이지와 복수 WorkItem 연결 | Tension 페이지 ↔ WI-0032·WI-0041 |
| `evidence` | 업무파일·원문위치·hash | EVD-RSND-2026-W34-028 |
| `collaborations` | 타담당 공동 안건 | COL-YIELD-2026-0014 |
| `submissions` | 팀원 주간 제출 | SUB-RSND-2026-W34-001 |
| `submission_pages` | 팀원·팀장 검토용 페이지 포함·제외 | 3개 업무페이지 선택 |
| `reports` | 팀·담당·그룹 보고 상태 | RPT-TEAM-RSND-2026-W34 |
| `report_versions` | AI/사람 수정 보고본문 | Version 1~n |
| `approval_events` | 제출·승인·반려 이력 | TEAM_APPROVE, DEPT_APPROVE |
| `decisions` | 의사결정 요청과 결과 | DEC-RSND-2026-0008 |
| `action_items` | 결정 후 후속조치 | ACT-FDC-2026-0044 |
| `qa_issues` | 기획/데이터 검증 Issue | 잠정값 표시, 출처 누락 |
| `audit_events` | 사용자·Agent·상태변경 감사 | trace ID, actor, action |
| `screen_definitions` | 역할별 55개 화면 정의 | MBR-07 AI 초안 편집 |

모든 이름·수치·조직은 시연용 가상 데이터입니다.

## 업무페이지 운영 규칙

- `WorkPage`는 팀장에게 제출하는 최소 단위이며 개별 Worklog 블록으로 분해해 제출하지 않습니다.
- 하나의 사용자는 복수의 WorkPage를 가질 수 있고, 한 WorkPage에는 복수의 공동작성자를 연결할 수 있습니다.
- 페이지는 `법인·공정·프로젝트·목적·작성자·표시순서`를 유지합니다.
- 페이지 본문은 최근 4주 Worklog를 시간순으로 합치며, 현재 주차 항목은 내부적으로 `NEW` 상태를 갖습니다.
- 화면에서는 내부 ID를 원문에 노출하지 않고 의미 Tag와 파란색 변경 표시로 보여주며, ID는 Source Manifest에 보존합니다.

## 오른쪽 업무 Agent의 저장 규칙

- 기존 업무이력을 불러오거나 직접 입력해 확정한 문장은 해당 페이지의 대표 WorkItem에 금주 `Worklog`로 저장합니다.
- 메일·파일에서 발췌한 내용은 Worklog와 함께 `Evidence` 메타데이터를 생성합니다.
- 업무 Agent의 대화 중간내용은 시연 세션에서만 유지하고, 사용자가 대화로 `보고에 반영해줘`라고 확정하거나 후보의 `보고에 반영`을 누른 문장만 기준 DB에 반영합니다.
- 실제 구축에서는 ChatGPT/Copilot Agent 호출 이력과 사용자 확인 결과를 별도 AgentRun·SourceRecord로 저장해야 합니다.
- 메일 API가 연결되기 전에는 사용자가 필요한 문장만 선택해 붙여넣으며, Agent가 메일함 전체를 자동 조회하지 않습니다.
