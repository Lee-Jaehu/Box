# 제조DX 주간업무 AI Portal 시연 패키지

설계된 역할별 화면과 주요 업무 흐름을 로컬 PC에서 시연하기 위한 데모입니다.

현재 버전: `v1.8.0` — 2:1 분할 `업무 Agent 1개`, 실제 LLM endpoint 연결·대화·업무페이지 New 확인 반영

## 빠른 실행

### Windows

1. ZIP 압축을 풉니다.
2. Python 3가 설치되어 있는지 확인합니다.
3. `run-demo.bat`을 더블클릭합니다.
4. 브라우저가 열리지 않으면 `http://127.0.0.1:8080`에 접속합니다.

BAT는 `py -3`, `python`, `python3` 순서로 Python을 자동 탐색합니다. Python이 없거나 실행이 차단된 경우 `web/index.html` 오프라인 시연 화면을 자동으로 엽니다.

### macOS / Linux

```bash
chmod +x run-demo.sh
./run-demo.sh
```

외부 패키지를 설치하지 않습니다. Python 표준 라이브러리와 SQLite만 사용합니다.

`run-demo.bat`은 모델을 호출하지 않는 DEMO 모드입니다. 실제 승인 모델과 연결하려면 [WORK_AGENT_SETUP.md](WORK_AGENT_SETUP.md)의 환경변수를 설정하고 `run-live-agent.bat`을 실행합니다.

## 포함 내용

```text
web/index.html       역할별 화면과 시연 UI
web/styles.css       화면 스타일
web/app.js           화면 전환·API 호출·시연 동작
web/demo-data.js     서버 없이 실행할 오프라인 샘플 데이터
server.py            정적 화면 + SQLite API 서버
work_agent.py        실제 LLM·사내 Agent Gateway 서버 어댑터
config/work_agent_prompt.md 업무 Agent System Prompt
WORK_AGENT_SETUP.md   실제 모델 연결·보안·Endpoint 계약
run-live-agent.bat    Windows LIVE 실행 점검기
db/demo.db           즉시 실행 가능한 샘플 DB
db/schema.sql        DB 스키마
db/seed.sql          샘플 데이터
build_db.py          DB 재생성 도구
DEMO_GUIDE.md        15분 시연 순서
DATA_DICTIONARY.md   테이블·샘플데이터 설명
WINDOWS_QUICK_START.md Windows 실행·오류 확인
```

## 사용자 역할

상단 역할 선택에서 다음 화면을 전환할 수 있습니다.

- 공통 사용자: 로그인, 역할 선택, 통합 업무함, 검색, 알림
- 팀원: WorkItem·Worklog·Evidence·업무페이지 선택·주간 초안·제출
- 팀장: 팀원 업무페이지 검토, 포함/제외, 서술형 보고, 승인/반려
- 담당: 팀 보고 Matrix, 협업 묶음, KPI 충돌, 담당 보고 승인
- 기획팀: 그룹 준비현황, QA, 그룹 보고 구성, 민감정보, 최종 확정
- 그룹장: KPI Overview, 담당 Drill-down, 근거, Q&A, Decision, Action
- KPI Data Owner: 파일 업로드, 매핑, Validation, 비교, 승인·잠금
- 운영자: 사용자/권한, 보고 Calendar, Prompt/Model, Policy, Audit, Health

총 55개 화면이 `screen_definitions` 테이블과 화면 메뉴로 연결됩니다.

## 주요 시연 동작

- 포털 화면과 `업무 Agent`를 가로 `2:1`로 동시에 표시
- 제목 옆 `LIVE·DEMO·OFFLINE DEMO·연결 필요` 상태로 실제 모델 호출 여부를 구분
- LIVE에서는 서버가 선택 WorkPage·최근 4주 이력·Snapshot·초안을 조회해 승인된 LLM Endpoint에 전달
- 오른쪽을 현재 GPT와 같은 대화형 UI로 구성해 모든 요청·응답·후속 수정을 한 대화에서 처리
- 자유문장으로 최근 업무이력 조회, 메일 붙여넣기, 파일 첨부, 보고문장 생성·수정·반영 요청
- 업무 Agent가 Result·Analysis·Plan·Risk·Fact를 자동 분류하고 대화로 재작성
- 생성 문장을 선택 업무페이지의 W34 파란색 `New`로 직접 반영
- 메일·파일 출처는 Evidence 메타데이터와 Source Manifest로 연결
- KPI Snapshot Validation 및 승인·잠금
- 팀원 Worklog 추가 작성 → Evidence 등록 → 업무페이지 선택 → AI 초안으로 이어지는 연속 입력
- 추가 작성 내용이 다음 화면, 제출본, 팀장 검토 화면에 그대로 반영
- 법인·공정·프로젝트별 `업무페이지`를 팀장 제출의 최소 단위로 사용
- 한 사람이 2~3개 업무페이지를 작성하거나 여러 사람이 한 페이지를 공동작성하는 사례 지원
- 업무페이지별 최근 4주 원문을 시간순으로 유지하고 금주 Worklog·KPI·계획을 뒤에 덧붙임
- 금주에 신규 작성·업데이트된 문장만 `New` 배지와 파란색 글자로 자동 구분
- Result·Analysis·Plan·Risk·KPI·Decision을 색상 Tag로 선택하고 일반 문장만 편집
- WorkPage·WorkItem·Collaboration·Evidence ID는 자동 연결 근거로 관리하며 사용자가 Code를 직접 입력하지 않음
- W33 자동보정 주간보고의 서술 깊이를 반영한 팀원·팀장 초안 생성
- 팀장→담당→기획 승인 흐름
- KPI·Evidence Citation 확인
- 그룹장 근거 기반 질문과 Decision 확정
- 역할별 상태 변경 감사로그
- 데모 데이터 초기화

## 데모 데이터 초기화

화면 우측 상단의 `데모 초기화`를 누르거나 다음 명령을 실행합니다.

```bash
python build_db.py
```

기존 `db/demo.db`를 샘플 초기 상태로 다시 생성합니다.

## 실행이 되지 않을 때

1. ZIP 안에서 바로 실행하지 말고 먼저 압축을 완전히 풉니다.
2. `run-demo.bat` 실행 후 검은 창을 닫지 않습니다. 창이 닫히면 접속 주소도 종료됩니다.
3. 포트 8080이 사용 중이면 서버가 8081~8089 중 사용 가능한 주소로 자동 전환하고 화면에 표시합니다.
4. Python 실행이 불가능하면 `web/index.html`을 더블클릭합니다. 이 모드는 화면·Agent·상태전환을 브라우저 메모리로 시연하며 SQLite 서버는 사용하지 않습니다.
5. 서버 오류는 BAT 창에 그대로 표시됩니다. 오류 화면을 캡처하면 원인을 추가로 확인할 수 있습니다.

## 주의

- 배포 ZIP에는 회사 시스템·LLM·Copilot·메일·분석시스템의 Endpoint나 인증정보가 포함되지 않습니다.
- 화면의 회사·사이트·수치·사람 이름은 가상 샘플입니다.
- `run-demo.bat`과 오프라인 HTML의 답변은 시연용 결정적 응답이며 실제 모델을 호출하지 않습니다.
- `run-live-agent.bat`은 승인 Endpoint·Model·서버 인증정보가 설정된 경우 실제 모델을 호출합니다. 미설정 상태를 LIVE로 표시하거나 Demo 응답으로 위장하지 않습니다.
- 오른쪽 `업무 Agent`는 포털 데이터와 연결된 전용 Agent UI입니다. 실제 ChatGPT 화면을 iframe으로 삽입하지 않으며, 서버 어댑터가 사내 LLM/Copilot Agent API를 호출합니다.
- 현재 메일시스템과 직접 연동하지 않으므로 사용자가 필요한 메일 문장만 선택해 붙여넣는 방식입니다.
- 서버 모드는 추가 기록과 Version을 SQLite에 저장합니다. 오프라인 모드는 현재 브라우저 세션에서만 유지되며 새로고침하면 초기 샘플로 돌아갑니다.
- 실제 구축 시 SSO, RBAC/ABAC, Object Storage, LLM Gateway, DLP, 감사정책을 별도로 연결해야 합니다.
