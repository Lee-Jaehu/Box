# 업무 Agent 실제 모델 연결 가이드

## 1. 이번 버전의 동작 방식

오른쪽 패널은 별도 ChatGPT 화면을 삽입한 것이 아니라, 이 포털의 업무 데이터와 연결된 `업무 Agent 1개`입니다.

```text
브라우저 오른쪽 업무 Agent
  → 포털 서버 /api/agent/chat
    → 권한 범위의 WorkPage·최근 4주 Worklog·KPI Snapshot·기존 초안 조회
      → 승인된 사내 LLM Gateway 또는 OpenAI-compatible endpoint
        → 구조화 응답(Result/Analysis/Plan/Risk 등)
          → 사용자가 확인 후 왼쪽 업무페이지에 New 반영
```

모델은 DB에 직접 접속하지 않습니다. 포털 서버가 로그인 역할과 선택 업무페이지를 기준으로 필요한 컨텍스트만 만들어 모델에 전달합니다. 모델 응답도 곧바로 저장하지 않고, 화면에서 `보고에 반영`을 누르거나 사용자가 명시적으로 반영을 요청했을 때만 기존 저장 API를 실행합니다.

## 2. 상태 표시

- `LIVE`: 실제 승인 LLM endpoint 호출
- `DEMO`: 기존 로컬 규칙 기반 시연 응답. 실제 모델 미호출
- `OFFLINE DEMO`: `web/index.html` 단독 실행. DB와 모델 모두 미연결
- `연결 필요`: LIVE를 요청했지만 URL·Model·인증 설정이 부족함

상태는 오른쪽 업무 Agent 제목 옆과 하단에 항상 표시됩니다. 실제 호출 실패 시 Demo 답변으로 몰래 대체하지 않습니다.

## 3. 가장 빠른 LIVE 실행

### Windows CMD

압축을 푼 폴더에서 CMD를 열어 아래 값을 회사 승인 정보로 바꿔 실행합니다.

```bat
set WORK_AGENT_API_URL=https://approved-company-gateway.example/v1/chat/completions
set WORK_AGENT_API_KEY=server-side-secret
set WORK_AGENT_MODEL=approved-model-deployment-name
set WORK_AGENT_PROVIDER=openai_compatible
run-live-agent.bat
```

### macOS / Linux

```bash
export WORK_AGENT_API_URL=https://approved-company-gateway.example/v1/chat/completions
export WORK_AGENT_API_KEY=server-side-secret
export WORK_AGENT_MODEL=approved-model-deployment-name
export WORK_AGENT_PROVIDER=openai_compatible
chmod +x run-live-agent.sh
./run-live-agent.sh
```

비밀키를 `app.js`, HTML, `work-agent.env.example`, BAT 파일에 직접 적지 마십시오. 운영에서는 Secret Manager 또는 서버 런타임 환경변수를 사용합니다.

## 4. 지원 Endpoint 계약

### A. `openai_compatible` — 권장 시작점

Chat Completions 호환 요청을 사용합니다.

- 요청: `model`, `messages`, `response_format`, `max_completion_tokens`
- 인증 기본값: `Authorization: Bearer <WORK_AGENT_API_KEY>`
- 응답: `choices[0].message.content` 안의 JSON
- 모델명에는 제품명이 아니라 회사 Gateway에 등록된 실제 배포명을 입력

회사 Gateway가 JSON Schema를 지원하지 않으면 다음을 설정합니다.

```bat
set WORK_AGENT_JSON_SCHEMA=false
```

인증 헤더가 다른 경우:

```bat
set WORK_AGENT_API_KEY_HEADER=X-API-Key
set WORK_AGENT_API_KEY_PREFIX=
```

내부망 mTLS·Integrated Authentication 등으로 API Key가 필요 없는 경우에만:

```bat
set WORK_AGENT_API_KEY_HEADER=none
```

### B. `company_gateway` — 사내 전용 Agent API

사내 Gateway가 자체 계약을 제공한다면 다음을 설정합니다.

```bat
set WORK_AGENT_PROVIDER=company_gateway
```

요청에는 `agent_id`, `model`, `system_prompt`, `prompt`, `messages`, `context`, `attachment`, `output_schema`가 포함됩니다. 응답은 아래 객체 또는 `{ "data": 아래 객체 }`를 반환해야 합니다.

```json
{
  "reply": "사용자에게 보여줄 답변",
  "action": "NONE | PROPOSE | APPLY",
  "draft": {
    "tag": "FACT | RESULT | ANALYSIS | PLAN | RISK",
    "body": "ID 태그가 없는 보고문장",
    "target_page_id": "pg_tension",
    "source_mode": "CHAT | WORK_HISTORY | MAIL | FILE",
    "source_title": "근거 제목"
  },
  "suggestions": ["후속 요청"]
}
```

회사 Copilot이 화면 사용권만 제공하고 외부 호출용 API를 제공하지 않는다면 그 화면 자체를 포털에 삽입해서는 실제 연동이 되지 않습니다. 이 경우 Copilot 운영팀으로부터 승인된 inference/Agent endpoint 또는 LLM Gateway 계약을 받아 `work_agent.py`의 Provider Adapter에 연결해야 합니다.

## 5. Agent가 보는 정보

- 현재 로그인 역할과 조직
- 선택한 업무페이지와 공동작성자
- 해당 페이지에 연결된 WorkItem
- 최근 4주 Worklog
- 등록된 Evidence의 코드·파일명·원문 위치
- 수율·BM·PD 등 업로드된 KPI Snapshot
- 현재 주간보고 최신 Version 일부
- 대화 중 사용자가 붙여넣은 메일·텍스트 파일 발췌

Agent는 전체 DB, 다른 사용자의 비허용 페이지, 원본 파일 바이너리를 직접 읽지 않습니다. 현재 데모의 PDF·PPTX·XLSX 첨부는 파일명만 전달되며, 실제 본문 처리는 사내 파일 추출·악성코드 검사·DLP 계층을 추가해야 합니다.

## 6. 운영 전 필수 보완

1. 회사 SSO와 사용자별 RBAC/ABAC 적용
2. LLM Gateway의 모델 Allowlist, Rate Limit, Timeout, Retry
3. Prompt/Response DLP와 민감정보 마스킹
4. 파일 Object Storage, 악성코드 검사, 텍스트 추출기
5. Agent 호출·사용자 승인·최종 반영 Audit 연결
6. 품질 Eval: 사실성, 숫자 일치, 출처 연결, 잘못된 확정 표현, 4주 연속성
7. 개발·검증·운영 환경별 Secret 분리

## 7. 연결 확인

서버 시작 후 다음 주소를 확인합니다.

```text
http://127.0.0.1:8080/api/agent/status
```

정상 LIVE 예시:

```json
{
  "ok": true,
  "mode": "LIVE",
  "configured": true,
  "provider": "openai_compatible",
  "model": "approved-model-deployment-name"
}
```

오른쪽 패널에서 업무내용을 입력한 후 모델 호출이 실패하면 서버 창의 `TRACE-DEMO-...` 또는 화면 오류의 Trace ID로 Gateway 로그를 대조합니다. `WORK_AGENT_DEBUG=true`는 로컬 연결시험에서만 사용하십시오.
