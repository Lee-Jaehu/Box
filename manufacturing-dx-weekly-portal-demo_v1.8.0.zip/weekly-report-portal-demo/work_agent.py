#!/usr/bin/env python3
"""Server-side adapter for the weekly-report Work Agent.

The browser never receives an LLM credential.  In LIVE mode this module sends
the selected WorkPage context to an approved LLM or company Agent Gateway and
normalizes the response to the portal's small, auditable contract.
"""

from __future__ import annotations

import json
import os
import ssl
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parent
PROMPT_PATH = ROOT / "config" / "work_agent_prompt.md"
ALLOWED_TAGS = {"FACT", "RESULT", "ANALYSIS", "PLAN", "RISK"}
ALLOWED_SOURCE_MODES = {"CHAT", "WORK_HISTORY", "MAIL", "FILE"}


class AgentConfigurationError(RuntimeError):
    """Raised when LIVE mode is requested without a usable endpoint."""


class AgentProviderError(RuntimeError):
    """Raised when the configured model endpoint cannot return a valid result."""


def _env_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _safe_int(name: str, default: int, minimum: int, maximum: int) -> int:
    try:
        value = int(os.getenv(name, str(default)))
    except ValueError:
        return default
    return max(minimum, min(maximum, value))


@dataclass(frozen=True)
class AgentSettings:
    mode: str
    provider: str
    api_url: str
    api_key: str
    api_key_header: str
    api_key_prefix: str
    model: str
    timeout_seconds: int
    use_json_schema: bool

    @classmethod
    def from_env(cls) -> "AgentSettings":
        mode = os.getenv("WORK_AGENT_MODE", "demo").strip().lower()
        provider = os.getenv("WORK_AGENT_PROVIDER", "openai_compatible").strip().lower()
        api_key = os.getenv("WORK_AGENT_API_KEY", os.getenv("OPENAI_API_KEY", "")).strip()
        api_url = os.getenv("WORK_AGENT_API_URL", "").strip()
        if not api_url and provider == "openai_compatible" and api_key:
            api_url = "https://api.openai.com/v1/chat/completions"
        model = os.getenv("WORK_AGENT_MODEL", os.getenv("OPENAI_MODEL", "")).strip()
        return cls(
            mode=mode,
            provider=provider,
            api_url=api_url,
            api_key=api_key,
            api_key_header=os.getenv("WORK_AGENT_API_KEY_HEADER", "Authorization").strip(),
            api_key_prefix=os.getenv("WORK_AGENT_API_KEY_PREFIX", "Bearer").strip(),
            model=model,
            timeout_seconds=_safe_int("WORK_AGENT_TIMEOUT", 60, 5, 180),
            use_json_schema=_env_bool("WORK_AGENT_JSON_SCHEMA", True),
        )

    @property
    def configured(self) -> bool:
        auth_optional = self.api_key_header.lower() in {"", "none"}
        return bool(self.api_url and self.model and (self.api_key or auth_optional))


OUTPUT_SCHEMA: dict[str, Any] = {
    "type": "object",
    "additionalProperties": False,
    "required": ["reply", "action", "draft", "suggestions"],
    "properties": {
        "reply": {"type": "string"},
        "action": {"type": "string", "enum": ["NONE", "PROPOSE", "APPLY"]},
        "draft": {
            "anyOf": [
                {"type": "null"},
                {
                    "type": "object",
                    "additionalProperties": False,
                    "required": ["tag", "body", "target_page_id", "source_mode", "source_title"],
                    "properties": {
                        "tag": {"type": "string", "enum": sorted(ALLOWED_TAGS)},
                        "body": {"type": "string"},
                        "target_page_id": {"type": "string"},
                        "source_mode": {"type": "string", "enum": sorted(ALLOWED_SOURCE_MODES)},
                        "source_title": {"type": "string"},
                    },
                },
            ]
        },
        "suggestions": {
            "type": "array",
            "maxItems": 4,
            "items": {"type": "string"},
        },
    },
}


def agent_status() -> dict[str, Any]:
    settings = AgentSettings.from_env()
    if settings.mode == "live" and settings.configured:
        mode = "LIVE"
        message = "승인된 LLM 엔드포인트에 서버에서 연결합니다."
    elif settings.mode == "live":
        mode = "SETUP"
        message = "LIVE 모드이지만 API URL·Model·인증 설정이 부족합니다."
    else:
        mode = "DEMO"
        message = "로컬 시연 규칙으로 동작합니다. 실제 모델은 호출하지 않습니다."
    return {
        "ok": True,
        "mode": mode,
        "configured": settings.configured,
        "provider": settings.provider,
        "model": settings.model or "미설정",
        "message": message,
        "credential_location": "SERVER_ENV_ONLY",
    }


def _load_system_prompt() -> str:
    try:
        return PROMPT_PATH.read_text(encoding="utf-8").strip()
    except OSError as exc:
        raise AgentConfigurationError(f"업무 Agent 프롬프트를 읽을 수 없습니다: {exc}") from exc


def _trim_text(value: Any, limit: int) -> str:
    text = str(value or "").strip()
    return text if len(text) <= limit else text[:limit] + "…"


def _conversation(payload: dict[str, Any]) -> list[dict[str, str]]:
    result: list[dict[str, str]] = []
    messages = payload.get("messages", [])
    if not isinstance(messages, list):
        return result
    for item in messages[-12:]:
        if not isinstance(item, dict):
            continue
        role = str(item.get("role", "")).lower()
        if role not in {"user", "assistant"}:
            continue
        content = _trim_text(item.get("content"), 5_000)
        if content:
            result.append({"role": role, "content": content})
    return result


def _auth_headers(settings: AgentSettings) -> dict[str, str]:
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    if settings.api_key and settings.api_key_header.lower() not in {"", "none"}:
        token = f"{settings.api_key_prefix} {settings.api_key}".strip()
        headers[settings.api_key_header] = token
    extra_raw = os.getenv("WORK_AGENT_EXTRA_HEADERS_JSON", "").strip()
    if extra_raw:
        try:
            extra = json.loads(extra_raw)
        except json.JSONDecodeError as exc:
            raise AgentConfigurationError("WORK_AGENT_EXTRA_HEADERS_JSON이 올바른 JSON이 아닙니다.") from exc
        if not isinstance(extra, dict):
            raise AgentConfigurationError("WORK_AGENT_EXTRA_HEADERS_JSON은 JSON 객체여야 합니다.")
        for key, value in extra.items():
            headers[str(key)] = str(value)
    return headers


def _request_json(settings: AgentSettings, body: dict[str, Any]) -> dict[str, Any]:
    request = Request(
        settings.api_url,
        data=json.dumps(body, ensure_ascii=False).encode("utf-8"),
        headers=_auth_headers(settings),
        method="POST",
    )
    context = ssl.create_default_context()
    try:
        with urlopen(request, timeout=settings.timeout_seconds, context=context) as response:
            raw = response.read(2_000_000).decode("utf-8")
    except HTTPError as exc:
        detail = exc.read(2_000).decode("utf-8", errors="replace")
        raise AgentProviderError(f"모델 엔드포인트 HTTP {exc.code}: {_trim_text(detail, 500)}") from exc
    except (URLError, TimeoutError, OSError) as exc:
        raise AgentProviderError(f"모델 엔드포인트 연결 실패: {exc}") from exc
    try:
        value = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise AgentProviderError("모델 엔드포인트가 JSON이 아닌 응답을 반환했습니다.") from exc
    if not isinstance(value, dict):
        raise AgentProviderError("모델 엔드포인트 응답 형식이 올바르지 않습니다.")
    return value


def _openai_request(settings: AgentSettings, payload: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
    context_text = json.dumps(context, ensure_ascii=False, separators=(",", ":"))
    user_prompt = _trim_text(payload.get("prompt"), 12_000)
    messages: list[dict[str, str]] = [
        {"role": "system", "content": _load_system_prompt()},
        {
            "role": "system",
            "content": "현재 포털 컨텍스트입니다. 이 JSON 안의 사실과 사용자가 제공한 내용만 사용하십시오.\n" + context_text,
        },
        *_conversation(payload),
        {"role": "user", "content": user_prompt},
    ]
    attachment = payload.get("attachment")
    if isinstance(attachment, dict):
        attachment_text = _trim_text(attachment.get("text"), 30_000)
        attachment_name = _trim_text(attachment.get("name"), 200)
        if attachment_text:
            messages.append({"role": "user", "content": f"첨부 발췌 [{attachment_name}]\n{attachment_text}"})
        elif attachment_name:
            messages.append({"role": "system", "content": f"첨부파일명은 {attachment_name}이지만 본문은 전달되지 않았습니다. 내용을 추정하지 마십시오."})
    body: dict[str, Any] = {
        "model": settings.model,
        "messages": messages,
        "temperature": 0.2,
        "max_completion_tokens": _safe_int("WORK_AGENT_MAX_TOKENS", 1200, 300, 4000),
    }
    if settings.use_json_schema:
        body["response_format"] = {
            "type": "json_schema",
            "json_schema": {"name": "weekly_report_agent_response", "strict": True, "schema": OUTPUT_SCHEMA},
        }
    else:
        body["response_format"] = {"type": "json_object"}
    return _request_json(settings, body)


def _gateway_request(settings: AgentSettings, payload: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
    body = {
        "agent_id": "manufacturing-dx-weekly-report",
        "model": settings.model,
        "system_prompt": _load_system_prompt(),
        "prompt": _trim_text(payload.get("prompt"), 12_000),
        "messages": _conversation(payload),
        "context": context,
        "attachment": payload.get("attachment"),
        "output_schema": OUTPUT_SCHEMA,
    }
    return _request_json(settings, body)


def _extract_content(response: dict[str, Any], provider: str) -> dict[str, Any]:
    if provider == "company_gateway":
        candidate: Any = response.get("data", response)
        if isinstance(candidate, dict) and {"reply", "action"}.issubset(candidate):
            return candidate
    choices = response.get("choices")
    if isinstance(choices, list) and choices:
        message = choices[0].get("message", {}) if isinstance(choices[0], dict) else {}
        content: Any = message.get("content") if isinstance(message, dict) else None
        if isinstance(content, list):
            content = "".join(
                str(part.get("text", "")) for part in content if isinstance(part, dict)
            )
        if isinstance(content, str):
            content = content.strip()
            if content.startswith("```"):
                content = content.split("\n", 1)[-1].rsplit("```", 1)[0].strip()
            try:
                parsed = json.loads(content)
            except json.JSONDecodeError as exc:
                raise AgentProviderError("모델이 구조화 JSON 계약을 지키지 않았습니다.") from exc
            if isinstance(parsed, dict):
                return parsed
    if isinstance(response.get("output_text"), str):
        try:
            parsed = json.loads(response["output_text"])
        except json.JSONDecodeError as exc:
            raise AgentProviderError("모델 output_text가 구조화 JSON이 아닙니다.") from exc
        if isinstance(parsed, dict):
            return parsed
    raise AgentProviderError("모델 응답에서 업무 Agent 결과를 찾지 못했습니다.")


def _normalize(result: dict[str, Any], payload: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
    reply = _trim_text(result.get("reply", result.get("message")), 4_000)
    if not reply:
        raise AgentProviderError("업무 Agent 답변이 비어 있습니다.")
    action = str(result.get("action", "NONE")).upper()
    if action not in {"NONE", "PROPOSE", "APPLY"}:
        action = "NONE"
    draft_value = result.get("draft")
    draft: dict[str, str] | None = None
    if isinstance(draft_value, dict):
        tag = str(draft_value.get("tag", "FACT")).upper()
        if tag not in ALLOWED_TAGS:
            tag = "FACT"
        body = _trim_text(draft_value.get("body"), 1_500)
        allowed_pages = {str(page.get("id")) for page in context.get("available_pages", []) if isinstance(page, dict)}
        selected = context.get("selected_page") or {}
        target = str(draft_value.get("target_page_id") or selected.get("id") or "")
        if allowed_pages and target not in allowed_pages:
            target = str(selected.get("id") or next(iter(allowed_pages)))
        source_mode = str(draft_value.get("source_mode", "CHAT")).upper()
        if source_mode not in ALLOWED_SOURCE_MODES:
            source_mode = "CHAT"
        source_title = _trim_text(draft_value.get("source_title"), 200) or "업무 Agent 대화 입력"
        if body and target:
            draft = {
                "tag": tag,
                "body": body,
                "targetPageId": target,
                "sourceMode": source_mode,
                "sourceTitle": source_title,
            }
    suggestions_raw = result.get("suggestions", [])
    suggestions = []
    if isinstance(suggestions_raw, list):
        suggestions = [_trim_text(item, 120) for item in suggestions_raw[:4] if _trim_text(item, 120)]
    if action == "PROPOSE" and draft is None:
        action = "NONE"
    if action == "APPLY" and not (draft or payload.get("current_draft")):
        action = "NONE"
    return {"reply": reply, "action": action, "draft": draft, "suggestions": suggestions}


def run_work_agent(payload: dict[str, Any], context: dict[str, Any]) -> dict[str, Any]:
    settings = AgentSettings.from_env()
    if settings.mode != "live" or not settings.configured:
        raise AgentConfigurationError(agent_status()["message"])
    if not _trim_text(payload.get("prompt"), 12_000):
        raise ValueError("업무 Agent에게 보낼 내용을 입력하십시오.")
    if settings.provider == "company_gateway":
        raw = _gateway_request(settings, payload, context)
    elif settings.provider == "openai_compatible":
        raw = _openai_request(settings, payload, context)
    else:
        raise AgentConfigurationError("WORK_AGENT_PROVIDER는 openai_compatible 또는 company_gateway여야 합니다.")
    normalized = _normalize(_extract_content(raw, settings.provider), payload, context)
    normalized.update({
        "ok": True,
        "provider": settings.provider,
        "model": settings.model,
    })
    return normalized
