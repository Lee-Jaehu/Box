#!/usr/bin/env python3
"""End-to-end smoke test for the dependency-free local demo server."""

from __future__ import annotations

import json
import sys
from urllib.error import HTTPError
from urllib.request import Request, urlopen


BASE_URL = sys.argv[1].rstrip("/") if len(sys.argv) > 1 else "http://127.0.0.1:8765"


def request_json(path: str, payload: dict | None = None) -> dict | list:
    body = None if payload is None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
    request = Request(
        BASE_URL + path,
        data=body,
        headers={"Content-Type": "application/json"},
        method="GET" if payload is None else "POST",
    )
    try:
        with urlopen(request, timeout=5) as response:
            return json.loads(response.read().decode("utf-8"))
    except HTTPError as error:
        detail = error.read().decode("utf-8")
        raise AssertionError(f"{path}: HTTP {error.code} {detail}") from error


def request_text(path: str) -> str:
    with urlopen(BASE_URL + path, timeout=5) as response:
        return response.read().decode("utf-8")


def assert_equal(actual: object, expected: object, label: str) -> None:
    if actual != expected:
        raise AssertionError(f"{label}: expected {expected!r}, got {actual!r}")


def main() -> None:
    expected_screens = {
        "COMMON": 5,
        "MEMBER": 8,
        "LEADER": 8,
        "DEPT": 7,
        "PLANNING": 7,
        "HEAD": 6,
        "DATA_OWNER": 7,
        "ADMIN": 7,
    }

    health = request_json("/api/health")
    assert health["ok"] and health["database"], "health check failed"

    index_html = request_text("/")
    styles = request_text("/styles.css")
    app_script = request_text("/app.js")
    assert 'id="weekly-agent"' in index_html and 'id="agent-chat-input"' in index_html
    assert 'id="agent-page-chip"' in index_html and 'id="agent-attach"' in index_html
    assert 'id="agent-engine-status"' in index_html and 'id="agent-engine-detail"' in index_html
    assert "업무 Agent" in index_html
    assert "minmax(0, 2fr) minmax(340px, 1fr)" in styles
    assert "handleAgentChatSubmit" in app_script and "createAgentResponse" in app_script
    assert "liveAgentApi" in app_script and "/api/agent/chat" in app_script and "loadAgentStatus" in app_script
    assert "applyAgentDraft" in app_script and "data-agent-apply-chat" in app_script

    agent_status = request_json("/api/agent/status")
    assert_equal(agent_status["mode"], "DEMO", "default agent mode")
    assert not agent_status["configured"], "demo mode must not claim a live model"

    catalog = request_json("/api/screen-catalog")
    assert_equal(len(catalog), 55, "screen catalog count")
    assert_equal(len({screen["screen_id"] for screen in catalog}), 55, "unique screen IDs")

    for role, count in expected_screens.items():
        bootstrap = request_json(f"/api/bootstrap?role={role}")
        assert_equal(len(bootstrap["screens"]), count, f"{role} screen count")
        assert_equal(bootstrap["principal"]["role_code"], role, f"{role} principal")
        assert bootstrap["cycle"]["cycle_code"] == "2026-W34"

    member_initial = request_json("/api/bootstrap?role=MEMBER")
    assert_equal(len(member_initial["work_pages"]), 3, "member work page count")
    assert all(page["contributors"] for page in member_initial["work_pages"]), "work page contributors missing"

    added_plan = "K12 검증 결과를 반영해 제품별 예외조건을 W35에 확정하겠습니다."
    worklog = request_json("/api/worklogs", {
        "role": "MEMBER",
        "work_item_id": "wi_rsnd_32",
        "entry_type": "PLAN",
        "occurred_on": "2026-08-24",
        "narrative": added_plan,
    })
    assert worklog["ok"] and worklog["record"]["entry_type"] == "PLAN"

    evidence = request_json("/api/evidence", {
        "role": "MEMBER",
        "work_item_id": "wi_rsnd_32",
        "file_name": "K12_W35_검증계획.xlsx",
        "locator": "Plan!A1:F12",
        "security_label": "CONFIDENTIAL",
    })
    assert evidence["ok"] and evidence["record"]["evidence_code"].startswith("EVD-RSND-2026-W34-")

    selection = request_json("/api/submission/items", {
        "role": "MEMBER",
        "work_page_ids": ["pg_tension", "pg_loading", "pg_vm"],
    })
    assert selection["ok"] and set(selection["work_page_ids"]) == {"pg_tension", "pg_loading", "pg_vm"}

    draft = request_json("/api/agent/draft", {"role": "MEMBER"})
    assert draft["ok"] and len(draft["citations"]) >= 4
    assert_equal(draft["content"].count("@@PAGE|"), 3, "draft work page count")
    assert "RPG-RSND-2026-0001" in draft["content"]
    assert "RPG-RSND-2026-0002" in draft["content"]
    assert "RPG-RSND-2026-0003" in draft["content"]
    assert "김현수(주)" in draft["content"] and "이정훈(공동)" in draft["content"]
    assert "(W31)" in draft["content"] and "(W32)" in draft["content"]
    assert "(W33)" in draft["content"] and "(W34)" in draft["content"]
    assert "WI-RSND-2026-0032" in draft["content"]
    assert "[PLAN]" in draft["content"] and added_plan in draft["content"]
    assert "적용조건 기준안을 수립" in draft["content"], "previous-week narrative was not carried forward"
    assert "[RESULT][NEW]" in draft["content"] and "[PLAN][NEW]" in draft["content"]
    assert draft["content"].count("[NEW]") >= 5, "current-week additions were not marked New"
    assert draft["content"].index("적용조건 기준안을 수립") < draft["content"].index("M08과 M11 제품 반복 시험")
    edited_note = "[WI-RSND-2026-0032][PLAN][NEW] (W34) 팀원 확인 후 K12 시험 순서를 M08·M11 결과와 동일 조건으로 조정하겠습니다."
    edited_content = draft["content"].replace("@@ENDPAGE@@", edited_note + "\n@@ENDPAGE@@", 1)
    saved_version = request_json("/api/draft/version", {"role": "MEMBER", "content": edited_content})
    assert saved_version["ok"] and saved_version["version"] >= 4
    member_data = request_json("/api/bootstrap?role=MEMBER")
    assert any(item["narrative"] == added_plan for item in member_data["worklogs"])
    assert any(item["file_name"] == "K12_W35_검증계획.xlsx" for item in member_data["evidence"])
    assert added_plan in member_data["submission_versions"][0]["content"]
    assert edited_note in member_data["submission_versions"][0]["content"]

    leader_draft = request_json("/api/agent/draft", {"role": "LEADER"})
    assert leader_draft["ok"] and edited_note in leader_draft["content"]
    assert "[ANALYSIS]" in leader_draft["content"] and "[PLAN]" in leader_draft["content"]
    leader_edit_note = "[WI-RSND-2026-0032][PLAN] 팀장 검토 의견: K12 검증 완료 후 제품별 수평전개 기준을 담당과 협의하겠습니다."
    leader_version = request_json("/api/draft/version", {"role": "LEADER", "content": leader_draft["content"] + "\n\n" + leader_edit_note})
    assert leader_version["ok"]
    leader_data = request_json("/api/bootstrap?role=LEADER")
    team_report = next(item for item in leader_data["reports"] if item["id"] == "rpt_team")
    assert leader_edit_note in team_report["content"]

    answer = request_json("/api/agent/ask", {"role": "HEAD", "question": "자동보정 효과를 확정할 수 있어?"})
    assert answer["ok"] and len(answer["citations"]) == 3
    assert "확정할 수 없습니다" in answer["answer"]

    workflow = [
        ("DATA_OWNER", "VALIDATE_SNAPSHOT"),
        ("DATA_OWNER", "APPROVE_SNAPSHOT"),
        ("MEMBER", "SUBMIT_MEMBER"),
        ("LEADER", "APPROVE_TEAM"),
        ("DEPT", "APPROVE_DEPT"),
        ("PLANNING", "RESOLVE_QA"),
        ("PLANNING", "APPROVE_PLANNING"),
        ("HEAD", "RESOLVE_DECISION"),
    ]
    for role, action in workflow:
        result = request_json("/api/action", {"role": role, "action": action})
        assert result["ok"] and result["trace_id"].startswith("TRACE-DEMO-")

    final_data = request_json("/api/bootstrap?role=HEAD")
    pd_snapshot = next(item for item in final_data["snapshots"] if item["id"] == "snp_pd_w34")
    assert_equal(pd_snapshot["status"], "LOCKED", "PD snapshot lock")
    decision = next(item for item in final_data["decisions"] if item["id"] == "dec1")
    assert_equal(decision["status"], "RESOLVED", "decision state")
    assert any(item["action_code"] == "ACT-RSND-2026-0052" for item in final_data["action_items"])

    reset = request_json("/api/reset", {})
    assert reset["ok"]
    reset_data = request_json("/api/bootstrap?role=DATA_OWNER")
    reset_pd = next(item for item in reset_data["snapshots"] if item["id"] == "snp_pd_w34")
    assert_equal(reset_pd["verification_state"], "PROVISIONAL", "reset snapshot state")
    assert_equal(len(reset_data["audit_events"]), 3, "reset audit count")

    print("PASS: 2:1 LIVE-ready 업무 Agent, explicit DEMO status, 55 screens, 3 work pages, 4-week carryover, coauthors, New propagation, workflow, reset")


if __name__ == "__main__":
    main()
