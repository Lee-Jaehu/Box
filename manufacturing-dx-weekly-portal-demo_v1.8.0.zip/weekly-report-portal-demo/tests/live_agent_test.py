#!/usr/bin/env python3
"""Integration test for the actual server-side Work Agent call path."""

from __future__ import annotations

import json
import os
import sys
import threading
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from build_db import build_database  # noqa: E402
from server import DemoHandler  # noqa: E402


class MockModelHandler(BaseHTTPRequestHandler):
    last_request: dict = {}

    def log_message(self, fmt: str, *args: object) -> None:
        return

    def do_POST(self) -> None:
        length = int(self.headers.get("Content-Length", "0"))
        MockModelHandler.last_request = json.loads(self.rfile.read(length).decode("utf-8"))
        result = {
            "reply": "최근 4주 이력과 금주 입력을 구분해 보고 후보를 작성했습니다.",
            "action": "PROPOSE",
            "draft": {
                "tag": "PLAN",
                "body": "K12 검증 생산을 W35에 우선 배정한 뒤 M08·M11과 동일 조건으로 재현성을 확인하고, 제품별 상·하한 및 예외조건을 확정하겠습니다.",
                "target_page_id": "pg_tension",
                "source_mode": "CHAT",
                "source_title": "사용자 업무 입력",
            },
            "suggestions": ["이 내용을 보고에 반영해줘"],
        }
        payload = {"choices": [{"message": {"content": json.dumps(result, ensure_ascii=False)}}]}
        raw = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)


@contextmanager
def environment(values: dict[str, str]):
    previous = {key: os.environ.get(key) for key in values}
    os.environ.update(values)
    try:
        yield
    finally:
        for key, value in previous.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value


def request_json(url: str, payload: dict | None = None) -> dict:
    body = None if payload is None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
    request = Request(
        url,
        data=body,
        headers={"Content-Type": "application/json"},
        method="GET" if body is None else "POST",
    )
    with urlopen(request, timeout=5) as response:
        return json.loads(response.read().decode("utf-8"))


def main() -> None:
    build_database()
    model_server = ThreadingHTTPServer(("127.0.0.1", 0), MockModelHandler)
    model_thread = threading.Thread(target=model_server.serve_forever, daemon=True)
    model_thread.start()
    model_url = f"http://127.0.0.1:{model_server.server_address[1]}/v1/chat/completions"

    with environment({
        "WORK_AGENT_MODE": "live",
        "WORK_AGENT_PROVIDER": "openai_compatible",
        "WORK_AGENT_API_URL": model_url,
        "WORK_AGENT_API_KEY": "test-server-secret",
        "WORK_AGENT_MODEL": "approved-claude-deployment",
    }):
        portal_server = ThreadingHTTPServer(("127.0.0.1", 0), DemoHandler)
        portal_thread = threading.Thread(target=portal_server.serve_forever, daemon=True)
        portal_thread.start()
        portal_url = f"http://127.0.0.1:{portal_server.server_address[1]}"
        try:
            status = request_json(portal_url + "/api/agent/status")
            assert status["mode"] == "LIVE" and status["configured"]
            assert status["model"] == "approved-claude-deployment"
            result = request_json(portal_url + "/api/agent/chat", {
                "role": "MEMBER",
                "screen_id": "MBR-07",
                "page_id": "pg_tension",
                "prompt": "K12 검증 계획을 주간보고 문장으로 작성해줘",
                "messages": [{"role": "user", "content": "M08·M11 반복 경향은 확인했어"}],
                "current_draft": None,
                "attachment": None,
            })
            assert result["ok"] and result["action"] == "PROPOSE"
            assert result["draft"]["tag"] == "PLAN"
            assert result["draft"]["targetPageId"] == "pg_tension"
            assert result["model"] == "approved-claude-deployment"
            sent = MockModelHandler.last_request
            assert sent["model"] == "approved-claude-deployment"
            joined = "\n".join(message["content"] for message in sent["messages"])
            assert "RPG-RSND-2026-0001" in joined
            assert "four_week_worklogs" in joined
            assert "test-server-secret" not in json.dumps(sent, ensure_ascii=False)
        finally:
            portal_server.shutdown()
            portal_server.server_close()

    model_server.shutdown()
    model_server.server_close()
    build_database()
    print("PASS: LIVE Work Agent server path, role-scoped context, structured model response, no browser credential")


if __name__ == "__main__":
    main()
