"use strict";

const fs = require("fs");
const path = require("path");

global.window = {};
require("../web/demo-data.js");

async function main() {
  const api = global.window.demoOfflineApi;
  if (typeof api !== "function") throw new Error("offline API was not registered");

  const webRoot = path.join(__dirname, "..", "web");
  const indexHtml = fs.readFileSync(path.join(webRoot, "index.html"), "utf8");
  const styles = fs.readFileSync(path.join(webRoot, "styles.css"), "utf8");
  const appScript = fs.readFileSync(path.join(webRoot, "app.js"), "utf8");
  if (!indexHtml.includes('id="weekly-agent"') || !indexHtml.includes('id="agent-chat-input"')) throw new Error("offline Agent chat markup missing");
  if (!indexHtml.includes('id="agent-page-chip"') || !indexHtml.includes('id="agent-attach"') || !indexHtml.includes("업무 Agent")) throw new Error("offline Agent controls missing");
  if (!indexHtml.includes('id="agent-engine-status"') || !indexHtml.includes('id="agent-engine-detail"')) throw new Error("offline Agent status UI missing");
  if (!styles.includes("minmax(0, 2fr) minmax(340px, 1fr)")) throw new Error("offline 2:1 split missing");
  if (!appScript.includes("handleAgentChatSubmit") || !appScript.includes("createAgentResponse") || !appScript.includes("applyAgentDraft") || !appScript.includes("liveAgentApi")) throw new Error("offline conversational Agent workflow missing");

  const agentStatus = await api("/api/agent/status");
  if (agentStatus.mode !== "OFFLINE" || agentStatus.configured) throw new Error("offline Agent status must be explicit");

  const expected = { COMMON: 5, MEMBER: 8, LEADER: 8, DEPT: 7, PLANNING: 7, HEAD: 6, DATA_OWNER: 7, ADMIN: 7 };
  const catalog = await api("/api/screen-catalog");
  if (catalog.length !== 55) throw new Error(`expected 55 screens, got ${catalog.length}`);

  for (const [role, count] of Object.entries(expected)) {
    const data = await api(`/api/bootstrap?role=${role}`);
    if (data.screens.length !== count) throw new Error(`${role}: expected ${count} screens, got ${data.screens.length}`);
    if (data.principal.role_code !== role) throw new Error(`${role}: principal mismatch`);
  }

  const memberInitial = await api("/api/bootstrap?role=MEMBER");
  if (memberInitial.work_pages.length !== 3) throw new Error("offline member work page count failed");
  if (!memberInitial.work_pages.every((page) => page.contributors)) throw new Error("offline work page contributors missing");

  const addedPlan = "K12 검증 결과를 반영해 제품별 예외조건을 W35에 확정하겠습니다.";
  const worklog = await api("/api/worklogs", { body: JSON.stringify({ role: "MEMBER", work_item_id: "wi_rsnd_32", entry_type: "PLAN", occurred_on: "2026-08-24", narrative: addedPlan }) });
  if (!worklog.ok || worklog.record.entry_type !== "PLAN") throw new Error("offline worklog save failed");

  const evidence = await api("/api/evidence", { body: JSON.stringify({ role: "MEMBER", work_item_id: "wi_rsnd_32", file_name: "K12_W35_검증계획.xlsx", locator: "Plan!A1:F12", security_label: "CONFIDENTIAL" }) });
  if (!evidence.ok || !evidence.record.evidence_code.startsWith("EVD-RSND-2026-W34-")) throw new Error("offline evidence save failed");

  const selection = await api("/api/submission/items", { body: JSON.stringify({ role: "MEMBER", work_page_ids: ["pg_tension", "pg_loading", "pg_vm"] }) });
  if (!selection.ok || selection.work_page_ids.length !== 3) throw new Error("offline page selection save failed");

  const draft = await api("/api/agent/draft", { body: JSON.stringify({ role: "MEMBER" }) });
  if ((draft.content.match(/@@PAGE\|/g) || []).length !== 3) throw new Error("offline draft work page count failed");
  for (const code of ["RPG-RSND-2026-0001", "RPG-RSND-2026-0002", "RPG-RSND-2026-0003"]) {
    if (!draft.content.includes(code)) throw new Error(`offline missing work page ${code}`);
  }
  if (!draft.content.includes("김현수(주)") || !draft.content.includes("이정훈(공동)")) throw new Error("offline coauthor header failed");
  for (const week of ["(W31)", "(W32)", "(W33)", "(W34)"]) {
    if (!draft.content.includes(week)) throw new Error(`offline missing retained week ${week}`);
  }
  if (!draft.content.includes("WI-RSND-2026-0032") || !draft.content.includes("[PLAN]") || !draft.content.includes(addedPlan)) throw new Error("offline dynamic draft failed");
  if (!draft.content.includes("적용조건 기준안을 수립")) throw new Error("offline previous-week carryover failed");
  if (!draft.content.includes("[RESULT][NEW]") || !draft.content.includes("[PLAN][NEW]")) throw new Error("offline New tag failed");
  if ((draft.content.match(/\[NEW\]/g) || []).length < 5) throw new Error("offline current-week additions were not marked New");
  if (draft.content.indexOf("적용조건 기준안을 수립") > draft.content.indexOf("M08과 M11 제품 반복 시험")) throw new Error("offline carryover ordering failed");
  const editedNote = "[WI-RSND-2026-0032][PLAN][NEW] (W34) 팀원 확인 후 K12 시험 순서를 M08·M11 결과와 동일 조건으로 조정하겠습니다.";
  const editedContent = draft.content.replace("@@ENDPAGE@@", `${editedNote}\n@@ENDPAGE@@`);
  const savedVersion = await api("/api/draft/version", { body: JSON.stringify({ role: "MEMBER", content: editedContent }) });
  if (!savedVersion.ok || savedVersion.version < 4) throw new Error("offline edited version save failed");
  const memberAfter = await api("/api/bootstrap?role=MEMBER");
  if (!memberAfter.worklogs.some((item) => item.narrative === addedPlan)) throw new Error("offline next-screen propagation failed");
  if (!memberAfter.submission_versions[0].content.includes(addedPlan)) throw new Error("offline draft version propagation failed");
  if (!memberAfter.submission_versions[0].content.includes(editedNote)) throw new Error("offline edited version propagation failed");

  const leaderDraft = await api("/api/agent/draft", { body: JSON.stringify({ role: "LEADER" }) });
  if (!leaderDraft.content.includes(editedNote) || !leaderDraft.content.includes("[ANALYSIS]") || !leaderDraft.content.includes("[PLAN]")) throw new Error("offline leader propagation failed");
  const leaderEditNote = "[WI-RSND-2026-0032][PLAN] 팀장 검토 의견: K12 검증 완료 후 제품별 수평전개 기준을 담당과 협의하겠습니다.";
  await api("/api/draft/version", { body: JSON.stringify({ role: "LEADER", content: `${leaderDraft.content}\n\n${leaderEditNote}` }) });
  const leaderAfter = await api("/api/bootstrap?role=LEADER");
  if (!leaderAfter.reports.find((item) => item.id === "rpt_team").content.includes(leaderEditNote)) throw new Error("offline leader edited version propagation failed");

  await api("/api/action", { body: JSON.stringify({ role: "DATA_OWNER", action: "VALIDATE_SNAPSHOT" }) });
  await api("/api/action", { body: JSON.stringify({ role: "DATA_OWNER", action: "APPROVE_SNAPSHOT" }) });
  const after = await api("/api/bootstrap?role=DATA_OWNER");
  const pd = after.snapshots.find((item) => item.id === "snp_pd_w34");
  if (pd.status !== "LOCKED" || pd.verification_state !== "VERIFIED") throw new Error("offline snapshot workflow failed");

  await api("/api/reset", { body: "{}" });
  const reset = await api("/api/bootstrap?role=DATA_OWNER");
  const resetPd = reset.snapshots.find((item) => item.id === "snp_pd_w34");
  if (resetPd.status !== "VALIDATION_FAILED") throw new Error("offline reset failed");

  console.log("PASS: explicit OFFLINE DEMO 업무 Agent, 55 screens, 3 work pages, 4-week carryover, coauthors, New propagation, transition, reset");
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
