#!/usr/bin/env python3
"""Dependency-free local demo server for the weekly report portal."""

from __future__ import annotations

import argparse
import errno
import json
import mimetypes
import os
import sqlite3
import threading
import time
import uuid
import webbrowser
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

from build_db import DB_PATH, build_database

ROOT = Path(__file__).resolve().parent
WEB_ROOT = ROOT / "web"
RESET_LOCK = threading.Lock()

ROLE_USERS = {
    "COMMON": "u_member1",
    "MEMBER": "u_member1",
    "LEADER": "u_leader",
    "DEPT": "u_dept",
    "PLANNING": "u_planning",
    "HEAD": "u_head",
    "DATA_OWNER": "u_data",
    "ADMIN": "u_admin",
}

ROLE_LABELS = {
    "COMMON": "공통 사용자",
    "MEMBER": "팀원",
    "LEADER": "팀장",
    "DEPT": "담당",
    "PLANNING": "기획팀",
    "HEAD": "그룹장",
    "DATA_OWNER": "KPI Data Owner",
    "ADMIN": "운영자",
}


def now_iso() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def trace_id() -> str:
    return "TRACE-DEMO-" + uuid.uuid4().hex[:10].upper()


def connect() -> sqlite3.Connection:
    connection = sqlite3.connect(DB_PATH, timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection


def rows(connection: sqlite3.Connection, sql: str, params: tuple = ()) -> list[dict]:
    return [dict(row) for row in connection.execute(sql, params).fetchall()]


def one(connection: sqlite3.Connection, sql: str, params: tuple = ()) -> dict | None:
    row = connection.execute(sql, params).fetchone()
    return dict(row) if row else None


def scoped_work_items(connection: sqlite3.Connection, role: str, user_id: str) -> list[dict]:
    base = """
        SELECT w.*, u.display_name AS owner_name, o.name AS organization_name,
               c.collaboration_code
          FROM work_items w
          JOIN users u ON u.id = w.owner_user_id
          JOIN organizations o ON o.id = w.organization_id
          LEFT JOIN collaborations c ON c.id = w.collaboration_id
    """
    if role == "MEMBER":
        return rows(connection, base + " WHERE w.owner_user_id = ? ORDER BY w.work_item_code", (user_id,))
    if role == "LEADER":
        return rows(connection, base + " WHERE w.organization_id = 'team_rsnd' ORDER BY w.work_item_code")
    if role == "DEPT":
        return rows(connection, base + " WHERE w.organization_id IN ('team_rsnd','team_electrode','team_assembly','team_activation') ORDER BY w.work_item_code")
    return rows(connection, base + " ORDER BY w.work_item_code")


def bootstrap(role: str) -> dict:
    role = role if role in ROLE_USERS else "MEMBER"
    user_id = ROLE_USERS[role]
    with connect() as connection:
        principal = one(connection, """
            SELECT u.id, u.display_name, u.email, o.name AS organization_name,
                   ? AS role_code, ? AS role_label
              FROM users u JOIN organizations o ON o.id = u.organization_id
             WHERE u.id = ?
        """, (role, ROLE_LABELS[role], user_id))
        cycle = one(connection, "SELECT * FROM reporting_cycles WHERE cycle_code = '2026-W34'")
        screens = rows(connection, "SELECT * FROM screen_definitions WHERE role_code = ? ORDER BY display_order", (role,))
        snapshots = rows(connection, """
            SELECT s.*, m.metric_code, m.name AS metric_name, m.unit,
                   ROUND(AVG(v.value), 3) AS display_value,
                   ROUND(AVG(v.previous_value), 3) AS previous_value,
                   ROUND(AVG(v.target_value), 3) AS target_value
              FROM metric_snapshots s
              JOIN metric_definitions m ON m.id = s.metric_id
              LEFT JOIN metric_values v ON v.snapshot_id = s.id
             WHERE s.cycle_id = 'cycle_w34'
             GROUP BY s.id ORDER BY m.metric_code
        """)
        items = scoped_work_items(connection, role, user_id)
        worklogs = rows(connection, """
            SELECT l.*, w.work_item_code, u.display_name AS author_name
              FROM worklogs l JOIN work_items w ON w.id = l.work_item_id
              JOIN users u ON u.id = l.author_user_id
             ORDER BY l.occurred_on DESC
        """)
        evidence = rows(connection, """
            SELECT e.*, w.work_item_code FROM evidence e
            JOIN work_items w ON w.id = e.work_item_id ORDER BY e.evidence_code
        """)
        submissions = rows(connection, """
            SELECT s.*, u.display_name AS member_name, o.name AS organization_name
              FROM submissions s JOIN users u ON u.id = s.member_user_id
              JOIN organizations o ON o.id = s.organization_id
             ORDER BY u.display_name
        """)
        reports = rows(connection, """
            SELECT r.*, o.name AS organization_name, v.content, v.source_manifest,
                   v.generated_by, v.created_at AS version_created_at
              FROM reports r JOIN organizations o ON o.id = r.organization_id
              LEFT JOIN report_versions v ON v.report_id = r.id AND v.version_number = r.current_version
             WHERE r.cycle_id = 'cycle_w34' ORDER BY r.report_level
        """)
        collaborations = rows(connection, """
            SELECT c.*, o.name AS lead_organization FROM collaborations c
            JOIN organizations o ON o.id = c.lead_org_id ORDER BY c.collaboration_code
        """)
        participants = rows(connection, """
            SELECT cp.*, c.collaboration_code, o.name AS organization_name
              FROM collaboration_participants cp
              JOIN collaborations c ON c.id = cp.collaboration_id
              JOIN organizations o ON o.id = cp.organization_id
             ORDER BY c.collaboration_code, o.name
        """)
        qa = rows(connection, "SELECT * FROM qa_issues ORDER BY CASE severity WHEN 'BLOCK' THEN 1 WHEN 'WARN' THEN 2 ELSE 3 END, id")
        decisions = rows(connection, """
            SELECT d.*, u.display_name AS decision_maker FROM decisions d
            LEFT JOIN users u ON u.id = d.decision_maker_user_id ORDER BY d.due_date
        """)
        actions = rows(connection, """
            SELECT a.*, u.display_name AS owner_name FROM action_items a
            LEFT JOIN users u ON u.id = a.owner_user_id ORDER BY a.due_date
        """)
        audit = rows(connection, """
            SELECT a.*, u.display_name AS actor_name FROM audit_events a
            LEFT JOIN users u ON u.id = a.actor_user_id ORDER BY a.id DESC LIMIT 50
        """)
        counts = {
            "screens": len(screens),
            "snapshots_locked": sum(1 for item in snapshots if item["status"] == "LOCKED"),
            "snapshots_total": len(snapshots),
            "work_items": len(items),
            "open_qa": sum(1 for item in qa if item["status"] == "OPEN"),
            "open_decisions": sum(1 for item in decisions if item["status"] != "RESOLVED"),
            "submitted_members": sum(1 for item in submissions if item["status"] in {"SUBMITTED", "ACCEPTED", "LOCKED"}),
            "members_total": len(submissions),
        }
    return {
        "principal": principal,
        "cycle": cycle,
        "screens": screens,
        "snapshots": snapshots,
        "work_items": items,
        "worklogs": worklogs,
        "evidence": evidence,
        "submissions": submissions,
        "reports": reports,
        "collaborations": collaborations,
        "participants": participants,
        "qa_issues": qa,
        "decisions": decisions,
        "action_items": actions,
        "audit_events": audit,
        "counts": counts,
        "role_labels": ROLE_LABELS,
    }


def audit_event(connection: sqlite3.Connection, role: str, action: str, resource_type: str, resource_id: str, result: str, detail: str, trace: str) -> None:
    connection.execute(
        """INSERT INTO audit_events(occurred_at,trace_id,actor_user_id,actor_role,action,resource_type,resource_id,result,detail)
           VALUES(?,?,?,?,?,?,?,?,?)""",
        (now_iso(), trace, ROLE_USERS.get(role), role, action, resource_type, resource_id, result, detail),
    )


def run_action(payload: dict) -> tuple[int, dict]:
    action = str(payload.get("action", ""))
    role = str(payload.get("role", "MEMBER"))
    trace = trace_id()
    with connect() as connection:
        if action == "VALIDATE_SNAPSHOT":
            connection.execute("UPDATE metric_snapshots SET validation_errors=0, validation_warnings=0, status='READY_FOR_APPROVAL' WHERE id='snp_pd_w34'")
            connection.execute("UPDATE qa_issues SET status='RESOLVED' WHERE resource_id='snp_pd_w34'")
            audit_event(connection, role, action, "METRIC_SNAPSHOT", "snp_pd_w34", "SUCCEEDED", "오류 해소 후 재검증 통과", trace)
            message = "PD Snapshot 재검증이 통과했습니다. 승인·잠금할 수 있습니다."
        elif action == "APPROVE_SNAPSHOT":
            snapshot = one(connection, "SELECT * FROM metric_snapshots WHERE id='snp_pd_w34'")
            if not snapshot or snapshot["validation_errors"]:
                return HTTPStatus.CONFLICT, {"ok": False, "message": "BLOCK 오류를 먼저 해소해야 합니다.", "trace_id": trace}
            connection.execute("UPDATE metric_snapshots SET status='LOCKED', verification_state='VERIFIED' WHERE id='snp_pd_w34'")
            audit_event(connection, role, action, "METRIC_SNAPSHOT", "snp_pd_w34", "SUCCEEDED", "Data Owner 승인 및 불변 잠금", trace)
            message = "PD Snapshot을 승인하고 잠갔습니다."
        elif action == "SUBMIT_MEMBER":
            connection.execute("UPDATE submissions SET status='SUBMITTED', version=version+1, submitted_at=? WHERE id='sub_member1'", (now_iso(),))
            audit_event(connection, role, action, "SUBMISSION", "sub_member1", "SUCCEEDED", "팀원 제출", trace)
            message = "팀원 보고를 팀장에게 제출했습니다."
        elif action == "APPROVE_TEAM":
            connection.execute("UPDATE reports SET status='TEAM_APPROVED', current_version=current_version+1 WHERE id='rpt_team'")
            current = one(connection, "SELECT current_version FROM reports WHERE id='rpt_team'")["current_version"]
            source = one(connection, "SELECT content, source_manifest FROM report_versions WHERE report_id='rpt_team' ORDER BY version_number DESC LIMIT 1")
            connection.execute("INSERT INTO report_versions VALUES(?,?,?,?,?,?,?)", ("rv_team_" + uuid.uuid4().hex[:8], "rpt_team", current, source["content"], source["source_manifest"], "HUMAN_LEADER", now_iso()))
            audit_event(connection, role, action, "REPORT", "rpt_team", "SUCCEEDED", "팀장 승인 후 담당 제출", trace)
            message = "팀 보고를 승인하고 담당에게 제출했습니다."
        elif action == "APPROVE_DEPT":
            connection.execute("UPDATE reports SET status='DEPT_APPROVED' WHERE id='rpt_dept'")
            audit_event(connection, role, action, "REPORT", "rpt_dept", "SUCCEEDED", "담당 승인 후 기획 제출", trace)
            message = "담당 보고를 승인하고 기획팀에 제출했습니다."
        elif action == "RESOLVE_QA":
            connection.execute("UPDATE qa_issues SET status='RESOLVED' WHERE resource_id='rpt_group'")
            audit_event(connection, role, action, "REPORT", "rpt_group", "SUCCEEDED", "데모 QA Issue 해소", trace)
            message = "그룹 보고 QA Issue를 해소했습니다."
        elif action == "APPROVE_PLANNING":
            open_blocks = one(connection, "SELECT COUNT(*) AS count FROM qa_issues WHERE resource_id='rpt_group' AND severity='BLOCK' AND status='OPEN'")["count"]
            if open_blocks:
                return HTTPStatus.CONFLICT, {"ok": False, "message": "BLOCK QA Issue를 먼저 해소해야 합니다.", "trace_id": trace}
            connection.execute("UPDATE reports SET status='READY_FOR_REPORT' WHERE id='rpt_group'")
            audit_event(connection, role, action, "REPORT", "rpt_group", "SUCCEEDED", "기획 QA 완료 및 그룹장 확정 요청", trace)
            message = "그룹장 보고 확정 요청을 완료했습니다."
        elif action == "RESOLVE_DECISION":
            connection.execute("UPDATE decisions SET status='RESOLVED', resolution='W35 K12 검증 생산 일정 우선 배정 승인' WHERE id='dec1'")
            exists = one(connection, "SELECT id FROM action_items WHERE action_code='ACT-RSND-2026-0052'")
            if not exists:
                connection.execute("INSERT INTO action_items VALUES(?,?,?,?,?,?,?,?)", ("act3", "ACT-RSND-2026-0052", "dec1", "K12 재현성 검증 완료", "u_leader", "2026-08-27", "OPEN", "HIGH"))
            audit_event(connection, role, action, "DECISION", "dec1", "SUCCEEDED", "그룹장 결정 및 Action 생성", trace)
            message = "Decision을 확정하고 후속 Action을 만들었습니다."
        else:
            return HTTPStatus.BAD_REQUEST, {"ok": False, "message": "지원하지 않는 시연 동작입니다.", "trace_id": trace}
        connection.commit()
    return HTTPStatus.OK, {"ok": True, "message": message, "trace_id": trace}


def generate_draft(payload: dict) -> dict:
    role = str(payload.get("role", "MEMBER"))
    trace = trace_id()
    content = (
        "[WI-RSND-2026-0032][RESULT] ESWA L07 Lami Jamming 자동보정 조건을 검증하였다. "
        "대상 3개 제품 중 M08과 M11은 반복 시험에서 동일 경향을 확인했으며 K12는 추가 검증이 필요하다. "
        "[EVD-RSND-2026-W34-028]\n\n"
        "[SNP-PD-2026-W34-004][KPI][PROVISIONAL] W34 PD Loss는 1.2%로 전주 1.5% 대비 감소했으나 "
        "Data Owner 최종 승인 전 잠정값이다.\n\n"
        "[COL-YIELD-2026-0014][ANALYSIS] FDC 장력 편차 구간과 Jamming 발생 시점의 상관성을 공동 검증 중이며 "
        "원인으로 확정하지 않았다.\n\n"
        "[DEC-RSND-2026-0008][DECISION] K12 검증 생산 일정 우선 배정이 필요하다."
    )
    with connect() as connection:
        connection.execute("UPDATE submissions SET status='AI_DRAFTED' WHERE id='sub_member1'")
        audit_event(connection, role, "GENERATE_DRAFT", "SUBMISSION", "sub_member1", "SUCCEEDED", "결정적 데모 Agent 초안", trace)
        connection.commit()
    return {
        "ok": True,
        "content": content,
        "citations": ["WI-RSND-2026-0032", "SNP-PD-2026-W34-004", "EVD-RSND-2026-W34-028", "COL-YIELD-2026-0014"],
        "validation": {"schema": True, "numbers": True, "citations": True, "policy": True},
        "trace_id": trace,
        "model": "DEMO_DETERMINISTIC_AGENT",
    }


def answer_question(payload: dict) -> dict:
    question = str(payload.get("question", "")).strip()
    return {
        "ok": True,
        "question": question,
        "answer": "현재 근거만으로 자동보정의 단독 효과를 확정할 수 없습니다. W34 PD Loss 1.2%는 전체 범위의 잠정 Snapshot이며, 동일 제품·동일 조건에서 자동보정 적용 전후를 분리한 승인 데이터가 추가로 필요합니다.",
        "citations": [
            {"code": "SNP-PD-2026-W34-004", "detail": "PD Loss 1.2% · 기준 2026-08-23 23:59 · PROVISIONAL"},
            {"code": "WI-RSND-2026-0032", "detail": "Jamming 자동보정 조건 검증"},
            {"code": "EVD-RSND-2026-W34-028", "detail": "검증표 Result!B4:H18"},
        ],
        "freshness": "2026-08-23T23:59:00+09:00",
        "trace_id": trace_id(),
    }


class DemoHandler(BaseHTTPRequestHandler):
    server_version = "WeeklyReportDemo/1.0"

    def log_message(self, fmt: str, *args: object) -> None:
        print("[%s] %s" % (self.log_date_time_string(), fmt % args))

    def send_json(self, payload: dict | list, status: int = HTTPStatus.OK) -> None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def read_json(self) -> dict:
        length = int(self.headers.get("Content-Length", "0"))
        if length > 1_000_000:
            raise ValueError("request too large")
        raw = self.rfile.read(length) if length else b"{}"
        return json.loads(raw.decode("utf-8"))

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/api/health":
            self.send_json({"ok": True, "database": DB_PATH.exists(), "time": now_iso()})
            return
        if parsed.path == "/api/bootstrap":
            role = parse_qs(parsed.query).get("role", ["MEMBER"])[0]
            self.send_json(bootstrap(role))
            return
        if parsed.path == "/api/screen-catalog":
            with connect() as connection:
                catalog = rows(connection, "SELECT * FROM screen_definitions ORDER BY role_code, display_order")
            self.send_json(catalog)
            return
        if parsed.path.startswith("/api/"):
            self.send_json({"ok": False, "message": "API not found"}, HTTPStatus.NOT_FOUND)
            return
        self.serve_static(parsed.path)

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        try:
            payload = self.read_json()
            if parsed.path == "/api/action":
                status, result = run_action(payload)
                self.send_json(result, status)
                return
            if parsed.path == "/api/agent/draft":
                self.send_json(generate_draft(payload))
                return
            if parsed.path == "/api/agent/ask":
                self.send_json(answer_question(payload))
                return
            if parsed.path == "/api/reset":
                with RESET_LOCK:
                    build_database()
                self.send_json({"ok": True, "message": "데모 데이터를 최초 상태로 초기화했습니다."})
                return
            self.send_json({"ok": False, "message": "API not found"}, HTTPStatus.NOT_FOUND)
        except (ValueError, json.JSONDecodeError) as exc:
            self.send_json({"ok": False, "message": str(exc)}, HTTPStatus.BAD_REQUEST)
        except sqlite3.Error as exc:
            self.send_json({"ok": False, "message": "database error", "detail": str(exc)}, HTTPStatus.INTERNAL_SERVER_ERROR)

    def serve_static(self, request_path: str) -> None:
        relative = "index.html" if request_path in {"", "/"} else unquote(request_path.lstrip("/"))
        candidate = (WEB_ROOT / relative).resolve()
        try:
            candidate.relative_to(WEB_ROOT.resolve())
        except ValueError:
            self.send_error(HTTPStatus.FORBIDDEN)
            return
        if not candidate.is_file():
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        content = candidate.read_bytes()
        content_type = mimetypes.guess_type(candidate.name)[0] or "application/octet-stream"
        if candidate.suffix in {".js", ".css", ".html"}:
            content_type += "; charset=utf-8"
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(content)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the Manufacturing DX weekly report demo")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--open", action="store_true", help="Open the demo in the default browser")
    parser.add_argument("--no-open", action="store_true", help="Do not open a browser")
    args = parser.parse_args()

    if not DB_PATH.exists():
        build_database()

    server = None
    selected_port = args.port
    for candidate_port in range(args.port, args.port + 10):
        try:
            server = ThreadingHTTPServer((args.host, candidate_port), DemoHandler)
            selected_port = candidate_port
            break
        except OSError as exc:
            if exc.errno not in {errno.EADDRINUSE, 10048}:
                raise
    if server is None:
        raise SystemExit(f"사용 가능한 포트를 찾지 못했습니다: {args.port}~{args.port + 9}")

    url = f"http://{args.host}:{selected_port}"
    if args.open and not args.no_open:
        threading.Thread(target=lambda: (time.sleep(0.7), webbrowser.open(url)), daemon=True).start()

    print(f"Manufacturing DX Weekly Portal demo: {url}")
    if selected_port != args.port:
        print(f"Port {args.port} was busy; switched to {selected_port}.")
    print("Press Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
