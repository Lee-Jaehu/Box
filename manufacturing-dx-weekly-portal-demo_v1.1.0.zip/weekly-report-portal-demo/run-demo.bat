@echo off
setlocal EnableExtensions
chcp 65001 >nul
title Manufacturing DX Weekly Portal Demo
cd /d "%~dp0"

echo.
echo ============================================================
echo  Manufacturing DX Weekly Portal Demo
echo ============================================================
echo  실행 폴더: %CD%
echo.

set "DEMO_PYTHON="
py -3 -c "import sys; assert sys.version_info.major == 3" >nul 2>&1
if not errorlevel 1 set "DEMO_PYTHON=py -3"

if not defined DEMO_PYTHON (
  python -c "import sys; assert sys.version_info.major == 3" >nul 2>&1
  if not errorlevel 1 set "DEMO_PYTHON=python"
)

if not defined DEMO_PYTHON (
  python3 -c "import sys; assert sys.version_info.major == 3" >nul 2>&1
  if not errorlevel 1 set "DEMO_PYTHON=python3"
)

if not defined DEMO_PYTHON (
  echo [안내] Python 3를 찾지 못했습니다.
  echo [대체 실행] 서버 없이 동작하는 오프라인 화면을 엽니다.
  start "" "%CD%\web\index.html"
  echo.
  echo 브라우저가 열리지 않으면 web\index.html을 더블클릭하십시오.
  pause
  exit /b 0
)

echo [확인] Python 실행 명령: %DEMO_PYTHON%
if not exist "%CD%\db\demo.db" (
  echo [준비] 샘플 DB를 생성합니다.
  %DEMO_PYTHON% build_db.py
  if errorlevel 1 goto :server_error
)

echo [시작] 로컬 서버를 시작합니다. 이 창을 닫으면 서버도 종료됩니다.
echo [안내] 브라우저가 자동으로 열리지 않으면 아래 표시되는 주소를 입력하십시오.
echo.
%DEMO_PYTHON% server.py --host 127.0.0.1 --port 8080 --open
if errorlevel 1 goto :server_error
goto :normal_end

:server_error
echo.
echo [오류] 서버 실행에 실패했습니다.
echo [대체 실행] web\index.html을 직접 열어 오프라인 시연을 할 수 있습니다.
start "" "%CD%\web\index.html"
echo.
pause
exit /b 1

:normal_end
echo.
echo 서버가 종료되었습니다.
pause
exit /b 0
