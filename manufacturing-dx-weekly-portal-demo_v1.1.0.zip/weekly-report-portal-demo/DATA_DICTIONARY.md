# 데모 데이터 사전

| 테이블 | 목적 | 대표 샘플 |
|---|---|---|
| `organizations` | 그룹·담당·팀 조직계층 | 제조DX그룹, 자동보정담당, RSND자동보정팀 |
| `users` | 데모 사용자 | 김현수, 이선우, 김도윤 등 가상 사용자 |
| `role_assignments` | 사용자 역할과 조직범위 | MEMBER, LEADER, DEPT, PLANNING, HEAD |
| `reporting_cycles` | 보고 주차와 마감 | 2026-W34 |
| `metric_definitions` | KPI 공식 정의 | YIELD_RATE, BM_LOSS, PD_LOSS, DEFECT_RATE |
| `metric_snapshots` | 기준일 KPI Snapshot | SNP-PD-2026-W34-004 |
| `metric_values` | Snapshot 상세값 | ESWA L07 PD Loss 1.2% |
| `work_items` | 개인·팀 업무 단위 | WI-RSND-2026-0032 |
| `worklogs` | 사실·결과·분석·계획·Risk 이력 | K12 추가검증 필요 |
| `evidence` | 업무파일·원문위치·hash | EVD-RSND-2026-W34-028 |
| `collaborations` | 타담당 공동 안건 | COL-YIELD-2026-0014 |
| `submissions` | 팀원 주간 제출 | SUB-RSND-2026-W34-001 |
| `reports` | 팀·담당·그룹 보고 상태 | RPT-TEAM-RSND-2026-W34 |
| `report_versions` | AI/사람 수정 보고본문 | Version 1~n |
| `approval_events` | 제출·승인·반려 이력 | TEAM_APPROVE, DEPT_APPROVE |
| `decisions` | 의사결정 요청과 결과 | DEC-RSND-2026-0008 |
| `action_items` | 결정 후 후속조치 | ACT-FDC-2026-0044 |
| `qa_issues` | 기획/데이터 검증 Issue | 잠정값 표시, 출처 누락 |
| `audit_events` | 사용자·Agent·상태변경 감사 | trace ID, actor, action |
| `screen_definitions` | 역할별 55개 화면 정의 | MBR-07 AI 초안 편집 |

모든 이름·수치·조직은 시연용 가상 데이터입니다.

