PRAGMA foreign_keys = ON;

INSERT INTO organizations VALUES
('org_group','DX-GRP','제조DX그룹','GROUP',NULL),
('org_solution','DX-SOL','제조DX솔루션담당','DEPARTMENT','org_group'),
('org_fdc','DX-FDC','FDC DX담당','DEPARTMENT','org_group'),
('org_auto','DX-AUTO','자동보정담당','DEPARTMENT','org_group'),
('org_quality','DX-QLT','품질DX담당','DEPARTMENT','org_group'),
('org_planning','DX-PLN','제조DX기획팀','TEAM','org_group'),
('team_rsnd','AUTO-RSND','RSND자동보정팀','TEAM','org_auto'),
('team_electrode','AUTO-ELC','전극자동보정팀','TEAM','org_auto'),
('team_assembly','AUTO-ASM','조립자동보정팀','TEAM','org_auto'),
('team_activation','AUTO-ACT','활성화자동보정팀','TEAM','org_auto');

INSERT INTO users VALUES
('u_member1','D1001','김현수','hyunsu.kim@example.internal','team_rsnd',1),
('u_member2','D1002','박은지','eunji.park@example.internal','team_rsnd',1),
('u_member3','D1003','이정훈','junghoon.lee@example.internal','team_rsnd',1),
('u_leader','D1100','이선우','sunwoo.lee@example.internal','team_rsnd',1),
('u_dept','D1200','김도윤','doyoon.kim@example.internal','org_auto',1),
('u_planning','D1300','최은서','eunseo.choi@example.internal','org_planning',1),
('u_head','D1400','그룹장 사용자','group.head@example.internal','org_group',1),
('u_data','D1500','데이터 운영자','data.owner@example.internal','org_quality',1),
('u_admin','D1600','시스템 운영자','system.admin@example.internal','org_planning',1);

INSERT INTO role_assignments VALUES
('ra1','u_member1','MEMBER','team_rsnd','2026-01-01T00:00:00+09:00',NULL),
('ra2','u_member2','MEMBER','team_rsnd','2026-01-01T00:00:00+09:00',NULL),
('ra3','u_member3','MEMBER','team_rsnd','2026-01-01T00:00:00+09:00',NULL),
('ra4','u_leader','LEADER','team_rsnd','2026-01-01T00:00:00+09:00',NULL),
('ra5','u_dept','DEPT','org_auto','2026-01-01T00:00:00+09:00',NULL),
('ra6','u_planning','PLANNING','org_group','2026-01-01T00:00:00+09:00',NULL),
('ra7','u_head','HEAD','org_group','2026-01-01T00:00:00+09:00',NULL),
('ra8','u_data','DATA_OWNER','org_group','2026-01-01T00:00:00+09:00',NULL),
('ra9','u_admin','ADMIN','org_group','2026-01-01T00:00:00+09:00',NULL);

INSERT INTO reporting_cycles VALUES
('cycle_w34','2026-W34',2026,34,'OPEN','2026-08-24T10:00:00+09:00','2026-08-25T17:00:00+09:00','2026-08-26T12:00:00+09:00','2026-08-26T17:00:00+09:00','2026-08-27T12:00:00+09:00'),
('cycle_w33','2026-W33',2026,33,'REPORTED','2026-08-17T10:00:00+09:00','2026-08-18T17:00:00+09:00','2026-08-19T12:00:00+09:00','2026-08-19T17:00:00+09:00','2026-08-20T12:00:00+09:00');

INSERT INTO metric_definitions VALUES
('met_yield','YIELD_RATE','수율','정상품 수량을 전체 투입 수량으로 나눈 비율','%','분석시스템','org_quality',3),
('met_bm','BM_LOSS','BM Loss','설비 기인 Loss 비율','%','분석시스템','org_fdc',2),
('met_pd','PD_LOSS','PD Loss','공정 기인 Loss 비율','%','분석시스템','org_quality',4),
('met_defect','DEFECT_RATE','불량률','검사 불량 수량을 검사 전체 수량으로 나눈 비율','%','분석시스템','org_quality',2);

INSERT INTO metric_snapshots VALUES
('snp_yield_w34','SNP-YIELD-2026-W34-003','met_yield','cycle_w34','2026-08-23T23:59:00+09:00','LOCKED','VERIFIED','Yield_2026W34_0823.xlsx',3,0,0),
('snp_bm_w34','SNP-BM-2026-W34-002','met_bm','cycle_w34','2026-08-23T23:59:00+09:00','LOCKED','VERIFIED','BM_Loss_2026W34_0823.xlsx',2,0,0),
('snp_pd_w34','SNP-PD-2026-W34-004','met_pd','cycle_w34','2026-08-23T23:59:00+09:00','VALIDATION_FAILED','PROVISIONAL','PD_Loss_2026W34_0823.xlsx',4,1,1),
('snp_defect_w34','SNP-DEFECT-2026-W34-002','met_defect','cycle_w34','2026-08-23T23:59:00+09:00','LOCKED','VERIFIED','Defect_2026W34_0823.xlsx',2,0,0),
('snp_pd_w33','SNP-PD-2026-W33-003','met_pd','cycle_w33','2026-08-16T23:59:00+09:00','LOCKED','VERIFIED','PD_Loss_2026W33_0816.xlsx',3,0,0);

INSERT INTO metric_values VALUES
('mv1','snp_yield_w34','ESWA','전체','ALL','ALL',92.4,91.8,94.0,'%','OK'),
('mv2','snp_bm_w34','ESWA','전체','ALL','ALL',6.8,7.0,6.0,'%','OK'),
('mv3','snp_pd_w34','ESWA','전체','ALL','ALL',1.2,1.5,1.0,'%','PROVISIONAL'),
('mv4','snp_pd_w34','ESWA','조립','L07','M08',2.4,0.8,1.0,'%','LARGE_CHANGE'),
('mv5','snp_pd_w34','ESWA','조립','L03','K12',1.1,1.2,1.0,'%','DUPLICATE'),
('mv6','snp_defect_w34','ESWA','전체','ALL','ALL',0.7,0.8,0.6,'%','OK'),
('mv7','snp_pd_w33','ESWA','전체','ALL','ALL',1.5,1.6,1.0,'%','OK');

INSERT INTO collaborations VALUES
('col_yield','COL-YIELD-2026-0014','Lami Jamming 공동 대응','FDC 이상감지부터 자동보정·품질검증·추적까지 연결','org_fdc','ACTIVE','2026-08-31'),
('col_bm','COL-BM-2026-0007','설비 BM Loss 공동 개선','상태감지와 보정조건을 연계하여 BM Loss 감소','org_fdc','ACTIVE','2026-09-15'),
('col_pd','COL-PD-2026-0011','주액기 PD Loss 개선','PLC 로직과 자동보정 파라미터 공동 검증','org_auto','ACTIVE','2026-09-05');

INSERT INTO collaboration_participants VALUES
('col_yield','org_fdc','장력 편차 구간 탐지 및 이상시점 제공'),
('col_yield','org_auto','제품별 보정 상·하한과 예외조건 검증'),
('col_yield','org_quality','불량 유형과 품질 판정 결과 검증'),
('col_yield','org_solution','Roll·Cell·공정 이력 연결'),
('col_bm','org_fdc','설비 이상패턴 탐지'),
('col_bm','org_auto','보정 적용 조건 검증'),
('col_pd','org_auto','주액기 보정 파라미터 적용'),
('col_pd','org_quality','PD 효과 판정');

INSERT INTO work_items VALUES
('wi_rsnd_32','WI-RSND-2026-0032','team_rsnd','u_member1','col_yield','Lami Jamming 자동보정 조건 검증','제품별 적용 조건과 예외조건 확정','IN_PROGRESS','2026-08-03','2026-08-27','PD_LOSS','CONFIDENTIAL'),
('wi_rsnd_38','WI-RSND-2026-0038','team_rsnd','u_member2','col_yield','ESWA L07 PD Loss 개선 로직 적용','동일 조건 반복 검증 후 효과 확정','IN_PROGRESS','2026-08-10','2026-08-28','PD_LOSS','CONFIDENTIAL'),
('wi_rsnd_41','WI-RSND-2026-0041','team_rsnd','u_member3','col_yield','FDC 진단 결과 연계','장력 편차와 Jamming 발생시점 연계 검증','IN_PROGRESS','2026-08-17','2026-08-31','PD_LOSS','CONFIDENTIAL'),
('wi_rsnd_45','WI-RSND-2026-0045','team_rsnd','u_member1',NULL,'차주 자동보정 조건 사전 검토','W35 적용 후보 검토','PLANNED','2026-08-24','2026-09-04','PD_LOSS','INTERNAL'),
('wi_elc_12','WI-ELC-2026-0012','team_electrode','u_member2','col_bm','코터 로딩량 편차 보정 확대','좌우 편차 보정 대상 확대','IN_PROGRESS','2026-08-01','2026-08-30','BM_LOSS','CONFIDENTIAL'),
('wi_asm_19','WI-ASM-2026-0019','team_assembly','u_member3','col_pd','주액기 보정 파라미터 적용','PD Loss 저감 로직 적용','IN_PROGRESS','2026-08-05','2026-08-29','PD_LOSS','CONFIDENTIAL');

INSERT INTO worklogs VALUES
('wl1','wi_rsnd_32','u_member1','2026-08-20','RESULT','M08과 M11 제품 반복 시험에서 동일 경향을 확인하였다.'),
('wl2','wi_rsnd_32','u_member1','2026-08-21','ANALYSIS','K12는 생산 조건이 달라 재현성 검증이 추가로 필요하다.'),
('wl3','wi_rsnd_32','u_member1','2026-08-22','NEXT','8월 27일까지 K12 재현성 검증 후 적용 여부를 확정한다.'),
('wl4','wi_rsnd_32','u_member1','2026-08-23','RISK','검증용 생산 일정이 미확정되어 완료 일정이 지연될 수 있다.'),
('wl5','wi_rsnd_38','u_member2','2026-08-22','RESULT','ESWA L07 적용 구간의 PD Loss 감소 경향을 확인하였다.'),
('wl6','wi_rsnd_41','u_member3','2026-08-23','ANALYSIS','FDC 장력 편차 구간과 Jamming 발생 시점의 상관성을 검토 중이다.');

INSERT INTO evidence VALUES
('ev1','EVD-RSND-2026-W34-028','wi_rsnd_32','Jamming_보정조건_검증표.xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','1111111111111111111111111111111111111111111111111111111111111111','Result!B4:H18','CLEAN','CONFIDENTIAL'),
('ev2','EVD-RSND-2026-W34-029','wi_rsnd_32','K12_시험조건_비교.pdf','application/pdf','2222222222222222222222222222222222222222222222222222222222222222','p.3-5','CLEAN','CONFIDENTIAL'),
('ev3','EVD-RSND-2026-W34-031','wi_rsnd_38','ESWA_L07_적용결과.xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','3333333333333333333333333333333333333333333333333333333333333333','Result!B4:H18','CLEAN','CONFIDENTIAL'),
('ev4','EVD-RSND-2026-W34-033','wi_rsnd_41','FDC_장력편차_연계.csv','text/csv','4444444444444444444444444444444444444444444444444444444444444444','rows 21-44','CLEAN','CONFIDENTIAL');

INSERT INTO submissions VALUES
('sub_member1','SUB-RSND-2026-W34-001','cycle_w34','u_member1','team_rsnd','AI_DRAFTED',2,NULL),
('sub_member2','SUB-RSND-2026-W34-002','cycle_w34','u_member2','team_rsnd','SUBMITTED',1,'2026-08-24T09:20:00+09:00'),
('sub_member3','SUB-RSND-2026-W34-003','cycle_w34','u_member3','team_rsnd','SUBMITTED',1,'2026-08-24T09:32:00+09:00');

INSERT INTO submission_items VALUES
('sub_member1','wi_rsnd_32',1,'금주 검증 결과 존재'),
('sub_member1','wi_rsnd_45',0,'금주 수행 결과 없음'),
('sub_member2','wi_rsnd_38',1,'KPI와 Evidence 연결'),
('sub_member3','wi_rsnd_41',1,'협업 분석 진행');

INSERT INTO reports VALUES
('rpt_team','RPT-TEAM-RSND-2026-W34','cycle_w34','team_rsnd','TEAM','DRAFT',1,'CONFIDENTIAL'),
('rpt_dept','RPT-DEPT-AUTO-2026-W34','cycle_w34','org_auto','DEPARTMENT','DRAFT',1,'CONFIDENTIAL'),
('rpt_group','RPT-GROUP-DX-2026-W34','cycle_w34','org_group','GROUP','PLANNING_QA',1,'CONFIDENTIAL'),
('rpt_group_w33','RPT-GROUP-DX-2026-W33','cycle_w33','org_group','GROUP','REPORTED',1,'CONFIDENTIAL');

INSERT INTO report_versions VALUES
('rv_team_1','rpt_team',1,'[WI-RSND-2026-0032][RESULT] ESWA L07 Lami Jamming 자동보정 조건을 검증하였다. 대상 3개 제품 중 M08과 M11은 반복 시험에서 동일 경향을 확인했으며 K12는 추가 검증이 필요하다.\n\n[SNP-PD-2026-W34-004][KPI][PROVISIONAL] W34 PD Loss는 1.2%로 전주 1.5% 대비 감소했으나 Data Owner 승인 전 잠정값이다.\n\n[COL-YIELD-2026-0014][ANALYSIS] FDC 장력 편차 구간과 Jamming 발생 시점의 상관성을 공동 검증 중이며 원인으로 확정하지 않았다.\n\n[DEC-RSND-2026-0008][DECISION] K12 검증 생산 일정 우선 배정이 필요하다.','WI-RSND-2026-0032,SNP-PD-2026-W34-004,EVD-RSND-2026-W34-028,COL-YIELD-2026-0014','LEADER_AGENT','2026-08-24T09:40:00+09:00'),
('rv_dept_1','rpt_dept',1,'자동보정담당은 Jamming 보정 조건과 코터 로딩량 편차, 주액기 파라미터 적용을 추진하였다. 협업 안건은 COL-YIELD-2026-0014 등 3개로 묶어 관리한다.','RPT-TEAM-RSND-2026-W34,COL-YIELD-2026-0014','DEPARTMENT_AGENT','2026-08-24T09:50:00+09:00'),
('rv_group_1','rpt_group',1,'W34 수율은 92.4%, BM Loss는 6.8%, PD Loss는 1.2% 잠정이다. 자동보정 Jamming 조건은 3개 제품 중 2개 검증을 완료했으며 K12 생산 일정 결정이 필요하다.','SNP-YIELD-2026-W34-003,SNP-BM-2026-W34-002,SNP-PD-2026-W34-004,DEC-RSND-2026-0008','PLANNING_AGENT','2026-08-24T10:00:00+09:00'),
('rv_group_w33_1','rpt_group_w33',1,'W33 그룹 보고 확정본.','SNP-PD-2026-W33-003','PLANNING_AGENT','2026-08-20T12:00:00+09:00');

INSERT INTO decisions VALUES
('dec1','DEC-RSND-2026-0008','K12 검증 생산 일정 배정','K12 제품 자동보정 검증을 위한 생산 일정 우선 배정이 필요하다.','REQUESTED','u_head','2026-08-25',NULL),
('dec2','DEC-FDC-2026-0005','품질 판정 연계 우선순위','FDC 결과와 품질 판정 연계 일정 확정이 필요하다.','REQUESTED','u_head','2026-08-27',NULL);

INSERT INTO action_items VALUES
('act1','ACT-FDC-2026-0044','dec2','품질 판정 결과 연계','u_member3','2026-08-27','IN_PROGRESS','HIGH'),
('act2','ACT-SOL-2026-0031',NULL,'Trace 누락 구간 보완','u_member2','2026-08-26','DELAYED','MEDIUM');

INSERT INTO qa_issues VALUES
('qa1','METRIC_SNAPSHOT','snp_pd_w34','DUPLICATE_KEY','BLOCK','ESWA L03 K12 W34 Key가 중복되었습니다.','원천 파일의 284행과 285행을 확인한 후 재업로드하십시오.','OPEN'),
('qa2','METRIC_SNAPSHOT','snp_pd_w34','LARGE_CHANGE','WARN','ESWA L07 M08 PD Loss가 0.8%에서 2.4%로 급변했습니다.','Data Owner가 변동 사유를 확인하십시오.','OPEN'),
('qa3','REPORT','rpt_group','PROVISIONAL_LABEL','WARN','잠정 PD Loss가 확정값처럼 표현된 문장 2건이 있습니다.','PROVISIONAL 상태를 문장에 표시하십시오.','OPEN'),
('qa4','REPORT','rpt_group','MISSING_EVIDENCE','BLOCK','활성화자동보정 CTQ 결과의 Evidence가 없습니다.','승인 가능한 Evidence를 연결하거나 보고에서 제외하십시오.','OPEN');

INSERT INTO audit_events(occurred_at,trace_id,actor_user_id,actor_role,action,resource_type,resource_id,result,detail) VALUES
('2026-08-24T08:55:00+09:00','TRACE-SEED-001','u_data','DATA_OWNER','UPLOAD','METRIC_SNAPSHOT','snp_pd_w34','SUCCEEDED','PD Loss W34 파일 업로드'),
('2026-08-24T09:40:00+09:00','TRACE-SEED-002','u_leader','LEADER','GENERATE_DRAFT','REPORT','rpt_team','SUCCEEDED','팀장 서술형 초안 생성'),
('2026-08-24T10:00:00+09:00','TRACE-SEED-003','u_planning','PLANNING','RUN_QA','REPORT','rpt_group','WARN','그룹 보고 QA 경고 2, 차단 1');

-- Common screens
INSERT INTO screen_definitions VALUES
('COM-01','COMMON',1,'SSO 로그인','login','회사 계정으로 인증하고 Portal Principal을 생성한다.','회사 계정으로 로그인','없음','OIDC subject, 사용자 상태','Issuer·Audience·MFA·계정 활성 여부 검증','인증 후 역할·조직 범위 확인'),
('COM-02','COMMON',2,'역할·조직 선택','context','복수 역할 사용자가 현재 업무 범위를 선택한다.','선택 범위로 시작','최근 사용 범위 추천','RoleAssignment, Organization','기간 만료 역할과 권한 밖 조직 제외','현재 역할·조직·주차 고정'),
('COM-03','COMMON',3,'통합 업무함','inbox','사용자가 처리할 제출·검토·승인·오류를 모은다.','선택 업무 처리','마감·영향도 기반 우선순위','Task, Deadline, ResourceState','원 업무화면에서 최종 확인','업무 상태 다음 단계 전환'),
('COM-04','COMMON',4,'통합 검색','search','권한 범위의 업무·보고·KPI·근거를 찾는다.','검색 결과 열기','자연어 검색과 관련항목 묶음','SearchIndex, ACL, Freshness','조회시점 ACL과 미인가 존재 비노출','기준 레코드로 이동'),
('COM-05','COMMON',5,'알림·마감','notifications','마감·반려·정정·Action 지연을 확인한다.','관련 화면 이동','중복 알림 요약','Notification, Cycle, Action','알림에서 승인상태 변경 금지','알림 확인 또는 원 업무 처리');

-- Member screens
INSERT INTO screen_definitions VALUES
('MBR-01','MEMBER',1,'팀원 홈','dashboard','이번 주 기록·제출상태와 우선업무를 본다.','금주 업무 작성','미기록 업무와 출처 누락 안내','Cycle, WorkItem, Submission','본인 소유 업무만 표시','제출 준비상태 확인'),
('MBR-02','MEMBER',2,'내 WorkItem 목록','worklist','담당업무 목표·상태·KPI·협업을 관리한다.','WorkItem 생성','유사·중복업무 후보','WorkItem, Metric, Collaboration','Code·Owner·보안등급 필수','추적 Code 생성'),
('MBR-03','MEMBER',3,'WorkItem 상세','detail','업무 목표·이력·KPI·협업·Action을 본다.','상태·계획 수정','지난이력 기반 다음기록 제안','WorkItem, Worklog, Action','잠금 후 원문 version 제한','변경이력 저장'),
('MBR-04','MEMBER',4,'Worklog 빠른 기록','entry','사실·결과·분석·계획·Risk를 기록한다.','기록 저장','메모 구조태그 분류','Worklog, WorkItem','날짜·작성자 자동·추측 금지','Timeline에 이력 추가'),
('MBR-05','MEMBER',5,'Evidence 업로드','uploadEvidence','업무파일을 증빙으로 등록한다.','파일 업로드','안전 추출문·관련업무 추천','Evidence, Hash, Label','MIME·크기·hash·악성코드','Evidence Code 생성'),
('MBR-06','MEMBER',6,'금주 실적 선택','selection','주간보고에 포함할 업무를 선택한다.','선택항목으로 초안 생성','금주변화·결과 존재 추천','WorkItem, Worklog, Evidence','AI 자동제외 금지','Source Manifest 확정'),
('MBR-07','MEMBER',7,'AI 초안 편집','memberEditor','구조화된 주간실적 초안을 검토한다.','AI 초안 생성·확정','업무 요약·ID·Citation 삽입','Source, Snapshot, PromptVersion','숫자·출처·민감정보 검사','사용자 확인 version 생성'),
('MBR-08','MEMBER',8,'제출·반려 이력','submission','팀장 제출과 반려·재제출 version을 관리한다.','팀장에게 제출','반려사유별 보완 안내','Submission, Version, Approval','재확인·Idempotency·마감','SUBMITTED 또는 재제출');

-- Leader screens
INSERT INTO screen_definitions VALUES
('LDR-01','LEADER',1,'팀장 홈','dashboard','팀 제출률·KPI·미검토·마감을 확인한다.','팀 보고 시작','영향도·Risk 기반 검토순서','Submission, KPI, Deadline','소속팀 범위만 표시','검토범위 확인'),
('LDR-02','LEADER',2,'팀원 제출 현황','submissionMatrix','팀원별 제출·반려·미제출 상태를 관리한다.','제출본 열기','미제출·정보부족 요약','Submission, User, State','대리작성·대리제출 구분','필수 팀원 상태 처리'),
('LDR-03','LEADER',3,'팀원 제출 상세','memberDetail','팀원 원문·AI초안·Evidence·Snapshot을 검토한다.','포함 또는 반려','주장·수치·출처 연결','SubmissionVersion, Citation','원문보존·권한내 Evidence','항목별 검토 기록'),
('LDR-04','LEADER',4,'실적 포함·제외','selectionLeader','팀보고에 사용할 업무를 선별한다.','선택 확정','중복·금주결과 없음 추천','SubmissionItem, Reason','AI 자동제외 금지·사유필수','Source Manifest 생성'),
('LDR-05','LEADER',5,'팀장 서술형 보고','leaderEditor','서술형 설명을 유지하고 ID·근거·상태를 보강한다.','담당에게 승인 제출','원문보존 재구성·Code 삽입','SelectedItems, KPI, Collaboration','의미보존·잠정·가설 검사','팀장 ReportVersion 생성'),
('LDR-06','LEADER',6,'KPI·근거 대조','compareEvidence','보고문장과 Snapshot·Evidence를 대조한다.','검증결과 반영','불일치 문장 위치 표시','ReportBlock, Snapshot, Evidence','숫자·단위·기준시각 exact match','BLOCK 해소 또는 반려'),
('LDR-07','LEADER',7,'반려·승인 확인','approve','반려 또는 담당제출 상태변경을 확인한다.','반려 또는 승인 제출','Action Preview·영향 요약','ReportState, Approval, Diff','재확인·If-Match·감사','RETURNED 또는 SUBMITTED'),
('LDR-08','LEADER',8,'팀 보고 Version 이력','history','AI·팀장수정·승인본을 비교한다.','Version 비교','의미변경 후보 표시','ReportVersion, AgentRun','승인 version 불변','변경근거 확인');

-- Department screens
INSERT INTO screen_definitions VALUES
('DPT-01','DEPT',1,'담당 홈','dashboard','팀별 승인상태·성과·KPI·Risk를 본다.','담당 보고 시작','중복·협업·지연 우선순위','TeamReport, KPI, Collaboration','승인 팀 version만 집계','검토범위 확정'),
('DPT-02','DEPT',2,'팀 보고 Matrix','teamMatrix','하위 팀보고를 비교한다.','팀 보고 상세 열기','누락·상충·중복 강조','TeamReport, WorkItem, State','팀 원문·승인상태 보존','모든 팀 상태 확인'),
('DPT-03','DEPT',3,'협업 안건 묶음','collaboration','같은 Collaboration과 팀별 기여를 묶는다.','묶음 확정','동일업무·공통사실 후보','Collaboration, Participant','가설 팀별분리·KPI 한번만','협업구조 확정'),
('DPT-04','DEPT',4,'KPI·주장 충돌','conflict','Snapshot version과 해석충돌을 조정한다.','해결방식 기록','원인·영향문장 표시','SnapshotVersion, Hypothesis','최신값 임의선택 금지','충돌해소 또는 병렬표기'),
('DPT-05','DEPT',5,'담당 보고 초안','deptEditor','담당 관점의 결과·병목·요청으로 재구성한다.','담당본 확정','협업중복 제거·대표성과 구성','TeamReports, KPI, Collaboration','팀분석을 사실로 병합 금지','담당 ReportVersion 생성'),
('DPT-06','DEPT',6,'Risk·Decision Register','decisionRegister','담당 Risk·Decision·Action을 관리한다.','Decision 요청 등록','미지정 Owner·Due 경고','Decision, Action, Risk','Owner·Due 추측 금지','요청·Action 저장'),
('DPT-07','DEPT',7,'기획 제출·승인 이력','approve','기획제출 전 QA와 이력을 확인한다.','기획팀에 승인 제출','변경·예외·미결 요약','ReportVersion, Approval, QA','하위승인 우회 금지','DEPT_APPROVED');

-- Planning screens
INSERT INTO screen_definitions VALUES
('PLN-01','PLANNING',1,'그룹 보고 준비현황','dashboard','4개 담당 승인·보완·지연상태를 본다.','QA 시작','마감영향·미완료 우선순위','DepartmentReport, Cycle, KPI','미승인 담당본 확정 차단','QA 대상 확정'),
('PLN-02','PLANNING',2,'QA Issue 목록','qa','KPI·출처·협업·잠정·보안·Action을 점검한다.','Issue 해소 요청','오류설명·수정위치·권고','QARule, ReportBlock, Citation','Deterministic rule 우선','BLOCK 0 또는 예외승인'),
('PLN-03','PLANNING',3,'그룹 보고 구성','groupEditor','그룹장 관점의 KPI·성과·병목·Decision으로 구성한다.','그룹 초안 확정','중요도·Decision 중심 재구성','DepartmentReports, KPI, Decision','원문근거·잠정·협업 유지','그룹 ReportVersion 생성'),
('PLN-04','PLANNING',4,'민감정보·외부공유','redaction','보고대상에 맞게 민감정보 제외후보를 검토한다.','제외안 적용','Label 기반 redaction 후보','SecurityLabel, Audience','자동삭제 금지·원본보존','공유 version 생성'),
('PLN-05','PLANNING',5,'Decision·Action 통합','decisionRegister','Decision과 미종결 Action을 정리한다.','그룹장 요청 확정','중복Decision·지연Action 묶음','Decision, Action, Dependency','Owner·Due·기한 필수','보고본과 요청 연결'),
('PLN-06','PLANNING',6,'그룹장 보고 확정','approve','QA결과와 예외를 확인해 그룹장보고를 확정한다.','그룹장 보고 확정 요청','최종변경·Risk·예외 요약','GroupReport, QA, Approval','기획권한·재확인·version lock','READY_FOR_REPORT'),
('PLN-07','PLANNING',7,'보고 이력·Export','export','주차별 확정본과 산출물을 관리한다.','확정본 Export','양식별 재구성·민감정보 후보','ReportVersion, Template, Export','확정 version만 사용','재현가능 산출물 생성');

-- Head screens
INSERT INTO screen_definitions VALUES
('HED-01','HEAD',1,'그룹장 Overview','dashboard','그룹 KPI·대표성과·Risk·Decision을 본다.','담당 상세 확인','관심KPI·Decision 중심요약','GroupReport, KPI, Decision','확정·잠정·기준일·출처 표시','검토대상 선택'),
('HED-02','HEAD',2,'담당별 Drill-down','memberDetail','4개 담당성과와 팀기여를 내려본다.','업무 근거 열기','WorkItem·협업관계 설명','DepartmentReport, WorkItem','권한·등급·승인version','질문·결정대상 확인'),
('HED-03','HEAD',3,'문장·수치 근거','evidence','보고문장을 원천까지 추적한다.','원문 위치 확인','근거관계·freshness 설명','Citation, Evidence, Snapshot','원본hash·ACL·잠정상태','신뢰수준 확인'),
('HED-04','HEAD',4,'보고 Q&A Agent','question','자연어 질문에 근거로 답한다.','근거 기반 질문','답변·불확실성·추가자료','ApprovedReport, Citation','근거없는 단정·권한밖 검색 금지','답변·Citation 확인'),
('HED-05','HEAD',5,'Decision 확정','decision','의사결정을 검토하고 Action으로 연결한다.','결정·Action 확정','선택지·영향·후속조치 초안','Decision, Action, Owner, Due','그룹장 직접확인·AI 자동확정 금지','Decision과 Action 생성'),
('HED-06','HEAD',6,'Action·주차 Trend','trend','Action이행과 KPI 주차변화를 추적한다.','지연 Action 점검','지연원인·영향·질문 추천','Action, Snapshot, History','동일 Metric 정의기준','Action 갱신');

-- Data owner screens
INSERT INTO screen_definitions VALUES
('DAT-01','DATA_OWNER',1,'Snapshot 운영현황','dashboard','Metric별 업로드·검증·승인상태를 본다.','새 Snapshot 업로드','지연·급변·오류 우선순위','Metric, Snapshot, Cycle','담당 Metric만 관리','필수 Snapshot 잠금'),
('DAT-02','DATA_OWNER',2,'KPI 파일 업로드','snapshotUpload','기준일 원천파일을 업로드한다.','파일 업로드 완료','파일명·Header 기반 Metric 후보','File, Hash, Cutoff, Metric','MIME·hash·악성코드·중복','UPLOADED Snapshot 생성'),
('DAT-03','DATA_OWNER',3,'컬럼·차원 매핑','mapping','컬럼을 Metric·공장·라인·제품과 매핑한다.','매핑 저장·검증','Header 매핑 후보·confidence','SourceHeader, TargetField','낮은 confidence 자동확정 금지','MappingVersion 저장'),
('DAT-04','DATA_OWNER',4,'Validation 결과','validation','중복·누락·단위·급변오류를 처리한다.','재검증','오류설명·원본위치','ValidationIssue, SourceRow','Pass/Fail rule engine 결정','BLOCK 0·WARN 사유확인'),
('DAT-05','DATA_OWNER',5,'전주·정정 비교','snapshotCompare','현재와 이전 Snapshot을 비교한다.','변동 사유 기록','급변차원·영향후보','SnapshotValue, Previous','집계범위·단위 동일성','변동확인 또는 재업로드'),
('DAT-06','DATA_OWNER',6,'승인·잠금','snapshotApprove','공식 Snapshot을 최종승인한다.','Snapshot 승인·잠금','오류·잠정·영향요약','Snapshot, Validation, Approval','Data Owner 재확인·정정은 새version','APPROVED/LOCKED'),
('DAT-07','DATA_OWNER',7,'Metric Catalog','catalog','KPI 공식정의와 파일계약을 관리한다.','Metric 정의 저장','정의충돌·약어중복 후보','MetricCode, Formula, Unit, Owner','변경영향·version·승인','새 정의 version 배포');

-- Admin screens
INSERT INTO screen_definitions VALUES
('ADM-01','ADMIN',1,'운영 Dashboard','dashboard','사용현황·오류·마감·연동상태를 본다.','운영 이슈 열기','이상패턴·장애영향 요약','SystemMetric, Job, Cycle','민감payload 미표시','운영이슈 조치'),
('ADM-02','ADMIN',2,'조직·사용자·역할','iam','조직계층과 역할·대리권한을 관리한다.','권한 변경 요청','SoD·만료권한 경고','User, Organization, Role','승인·기간·사유·감사','권한정책 반영'),
('ADM-03','ADMIN',3,'보고 Calendar','calendar','단계별 마감과 휴일예외를 설정한다.','보고주차 개시','이전주기 기반 일정초안','ReportingCycle, Holiday','역순마감·예외승인','OPEN Cycle 생성'),
('ADM-04','ADMIN',4,'Template·Prompt·Model','release','양식과 Prompt/Model을 평가 후 배포한다.','승인 version 배포','변경영향·평가 regression','Template, Prompt, Model, Eval','Gate·2인검토·rollback','배포 version 활성화'),
('ADM-05','ADMIN',5,'권한·보안 Policy','policy','권한정책과 Agent tool allowlist를 관리한다.','정책 변경 검토','충돌·과도권한 분석','Policy, ToolAllowlist, Label','Deny-by-default·negative test','정책 version 배포'),
('ADM-06','ADMIN',6,'Audit Log','audit','조회·AI·제출·승인·권한변경을 추적한다.','감사 이벤트 조회','trace·resource 연쇄묶음','AuditEvent, Trace, Actor','감사원문 수정·삭제 금지','사건흐름 재현'),
('ADM-07','ADMIN',7,'System Health·Feature Flag','health','Portal·DB·LLM·Copilot 상태를 관리한다.','기능 Flag 변경','장애영향·fallback 권고','Health, Queue, FeatureFlag','Agent차단시 수동Workflow 유지','정상 또는 안전 fallback');
