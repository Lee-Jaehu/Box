"use strict";

const $ = (selector, root = document) => root.querySelector(selector);

const state = {
  role: "MEMBER",
  data: null,
  screenIndex: 0,
  generatedDraft: null,
  pendingAction: null,
  lastAnswer: null,
};

const roleColors = {
  COMMON: "#53657d", MEMBER: "#2356a8", LEADER: "#7655a6", DEPT: "#8a5323",
  PLANNING: "#13706c", HEAD: "#9b3e55", DATA_OWNER: "#3c6f3d", ADMIN: "#4b5568",
};

const actionMap = {
  "DAT-04": "VALIDATE_SNAPSHOT", "DAT-06": "APPROVE_SNAPSHOT",
  "MBR-08": "SUBMIT_MEMBER", "LDR-05": "APPROVE_TEAM", "LDR-07": "APPROVE_TEAM",
  "DPT-07": "APPROVE_DEPT", "PLN-02": "RESOLVE_QA", "PLN-06": "APPROVE_PLANNING",
  "HED-05": "RESOLVE_DECISION",
};

const confirmCopy = {
  VALIDATE_SNAPSHOT: ["PD Snapshot 재검증", "중복 Key를 보정한 것으로 가정하고 Rule Engine을 다시 실행합니다."],
  APPROVE_SNAPSHOT: ["Snapshot 승인·잠금", "검증을 통과한 PD Snapshot을 공식값으로 승인하고 변경 불가 상태로 잠급니다."],
  SUBMIT_MEMBER: ["팀원 보고 제출", "현재 Version과 Source Manifest를 고정하여 팀장에게 제출합니다."],
  APPROVE_TEAM: ["팀 보고 승인·제출", "서술형 보고 원문과 ID·근거 연결을 유지한 새 Version을 담당에게 제출합니다."],
  APPROVE_DEPT: ["담당 보고 승인·제출", "승인된 팀 보고를 기준으로 담당 보고를 기획팀에 제출합니다."],
  RESOLVE_QA: ["QA Issue 시연 해소", "그룹 보고의 데모 QA Issue를 해소 상태로 전환합니다."],
  APPROVE_PLANNING: ["그룹장 보고 확정 요청", "BLOCK Issue가 없는지 확인한 뒤 그룹장 검토 상태로 전환합니다."],
  RESOLVE_DECISION: ["Decision 확정", "K12 검증 생산 일정을 우선 배정하고 후속 Action을 생성합니다."],
};

const navTargets = {
  "MBR-01": "MBR-04", "LDR-01": "LDR-02", "DPT-01": "DPT-02", "PLN-01": "PLN-02",
  "HED-01": "HED-02", "DAT-01": "DAT-02", "ADM-01": "ADM-06", "COM-03": "COM-04",
};

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;").replaceAll("'", "&#039;");
}

function formatDate(value, withTime = false) {
  if (!value) return "—";
  const normalized = /T/.test(value) ? value : `${value}T00:00:00+09:00`;
  const date = new Date(normalized);
  if (Number.isNaN(date.getTime())) return escapeHtml(value);
  return new Intl.DateTimeFormat("ko-KR", {
    month: "2-digit", day: "2-digit", ...(withTime ? { hour: "2-digit", minute: "2-digit" } : {}),
  }).format(date);
}

function stateClass(value) {
  const text = String(value ?? "").toUpperCase();
  if (/LOCKED|VERIFIED|APPROVED|ACCEPTED|RESOLVED|REPORTED|CLEAN|SUCCEEDED|PASS|ACTIVE|ON|UP/.test(text)) return "success";
  if (/BLOCK|ERROR|DELAYED|RETURNED|FAILED|NEEDS/.test(text)) return "danger";
  if (/WARN|PROVISIONAL|REQUESTED|DRAFT|OPEN|IN_PROGRESS|READY|OFF|NOT_CONNECTED|DEMO/.test(text)) return "warn";
  return "";
}

function badge(value, label = value) {
  return `<span class="badge ${stateClass(value)}">${escapeHtml(label)}</span>`;
}

function table(headers, rows, empty = "표시할 데이터가 없습니다.") {
  if (!rows.length) return `<div class="empty-state">${escapeHtml(empty)}</div>`;
  return `<div class="table-wrap"><table><thead><tr>${headers.map((h) => `<th>${escapeHtml(h)}</th>`).join("")}</tr></thead><tbody>${rows.join("")}</tbody></table></div>`;
}

function card(title, content, extraClass = "") {
  return `<section class="card ${extraClass}"><h3>${escapeHtml(title)}</h3>${content}</section>`;
}

function metricCard(label, value, context, tone = "") {
  return `<article class="card metric ${tone}"><span class="metric-label">${escapeHtml(label)}</span><strong class="metric-value">${escapeHtml(value)}</strong><span class="metric-context">${escapeHtml(context)}</span></article>`;
}

async function api(path, options = {}) {
  if (window.location.protocol === "file:" && window.demoOfflineApi) {
    return window.demoOfflineApi(path, options);
  }
  try {
    const response = await fetch(path, { headers: { "Content-Type": "application/json", ...(options.headers || {}) }, ...options });
    let payload;
    try { payload = await response.json(); } catch { payload = { message: `HTTP ${response.status}` }; }
    if (!response.ok) throw new Error(payload.message || `HTTP ${response.status}`);
    return payload;
  } catch (error) {
    if (window.demoOfflineApi) {
      $("#runtime-label").textContent = "오프라인 샘플 데이터";
      return window.demoOfflineApi(path, options);
    }
    throw error;
  }
}

function currentScreen() { return state.data?.screens?.[state.screenIndex] || null; }

async function loadRole(role, preferredScreenId = null) {
  state.role = role;
  state.generatedDraft = null;
  state.lastAnswer = null;
  $("#loading").hidden = false;
  $("#screen-body").innerHTML = "";
  try {
    const data = await api(`/api/bootstrap?role=${encodeURIComponent(role)}`);
    state.data = data;
    const target = data.screens.findIndex((screen) => screen.screen_id === preferredScreenId);
    state.screenIndex = target >= 0 ? target : 0;
    renderPrincipal(); renderNavigation(); renderScreen();
  } catch (error) {
    $("#loading").textContent = `데이터를 불러오지 못했습니다: ${error.message}`;
    showToast(error.message, true);
  }
}

function renderPrincipal() {
  const p = state.data.principal;
  $("#principal-name").textContent = p.display_name;
  $("#principal-scope").textContent = `${p.role_label} · ${p.organization_name}`;
  $("#principal-avatar").textContent = p.display_name.slice(0, 1);
  $("#principal-avatar").style.background = roleColors[state.role] || roleColors.COMMON;
  $("#principal-avatar").style.color = "white";
  $("#screen-count").textContent = state.data.screens.length;
  $("#runtime-label").textContent = window.location.protocol === "file:" ? "오프라인 샘플 데이터" : "SQLite 연결됨";
}

function renderNavigation() {
  $("#screen-nav").innerHTML = state.data.screens.map((screen, index) => `
    <button type="button" class="nav-button ${index === state.screenIndex ? "active" : ""}" data-screen-index="${index}">
      <code>${escapeHtml(screen.screen_id)}</code><span>${escapeHtml(screen.title)}</span>
    </button>`).join("");
}

function renderScreen() {
  const screen = currentScreen();
  if (!screen) return;
  $("#loading").hidden = true;
  $("#screen-id").textContent = screen.screen_id;
  $("#screen-kind").textContent = screen.kind;
  $("#screen-title").textContent = screen.title;
  $("#screen-purpose").textContent = screen.purpose;
  const primary = $("#primary-action");
  primary.textContent = screen.primary_action;
  primary.hidden = screen.primary_action === "없음";
  primary.disabled = false;
  $("#screen-body").innerHTML = renderByKind(screen);
  renderNavigation();
  bindScreenForms();
}

function bindScreenForms() {
  const questionForm = $("#question-form");
  if (questionForm) questionForm.addEventListener("submit", handleQuestion);
  const searchForm = $("#search-form");
  if (searchForm) searchForm.addEventListener("submit", (event) => {
    event.preventDefault();
    $("#search-results")?.removeAttribute("hidden");
    showToast("권한 범위 안에서 WorkItem·KPI·보고서를 검색했습니다.");
  });
}

function renderByKind(screen) {
  const renderers = {
    dashboard: () => renderDashboard(screen), login: renderLogin, context: renderContext,
    inbox: renderInbox, search: renderSearch, notifications: renderNotifications,
    worklist: renderWorklist, detail: renderWorkDetail, entry: renderEntry,
    uploadEvidence: renderEvidenceUpload, selection: () => renderSelection(false),
    memberEditor: () => renderEditor("TEAM_MEMBER"), submission: renderSubmission,
    submissionMatrix: renderSubmissionMatrix, memberDetail: renderMemberDetail,
    selectionLeader: () => renderSelection(true), leaderEditor: () => renderEditor("TEAM"),
    compareEvidence: renderEvidenceCompare, approve: renderApproval, history: renderHistory,
    teamMatrix: renderTeamMatrix, collaboration: renderCollaboration, conflict: renderConflict,
    deptEditor: () => renderEditor("DEPARTMENT"), decisionRegister: renderDecisionRegister,
    qa: renderQa, groupEditor: () => renderEditor("GROUP"), redaction: renderRedaction,
    export: renderExport, evidence: renderEvidenceTrace, question: renderQuestion,
    decision: renderDecision, trend: renderTrend, snapshotUpload: renderSnapshotUpload,
    mapping: renderMapping, validation: renderValidation, snapshotCompare: renderSnapshotCompare,
    snapshotApprove: renderSnapshotApprove, catalog: renderMetricCatalog, iam: renderIam,
    calendar: renderCalendar, release: renderRelease, policy: renderPolicy,
    audit: renderAudit, health: renderHealth,
  };
  return (renderers[screen.kind] || (() => renderGeneric(screen)))();
}

function renderWorkflow(activeIndex) {
  const stages = ["팀원 작성", "팀장 검토", "담당 승인", "기획 QA", "그룹장 보고"];
  return `<div class="steps">${stages.map((label, index) => `<div class="step ${index < activeIndex ? "done" : index === activeIndex ? "active" : ""}"><strong>${index + 1}</strong><span>${label}</span></div>`).join("")}</div>`;
}

function renderKpis() {
  return `<div class="metrics kpi-metrics">${state.data.snapshots.slice(0, 4).map((item) => {
    const value = `${Number(item.display_value).toFixed(1)}${item.unit}`;
    const delta = item.previous_value == null ? "전주 없음" : `전주 ${Number(item.previous_value).toFixed(1)}${item.unit}`;
    return metricCard(item.metric_name, value, `${delta} · ${item.verification_state}`, stateClass(item.verification_state));
  }).join("")}</div>`;
}

function reportByLevel(level) {
  return state.data.reports.find((report) => report.report_level === level && report.report_code.includes("W34"));
}

function renderDashboard() {
  const d = state.data;
  const role = state.role;
  let summary;
  let activeStage = 0;
  if (role === "MEMBER") {
    const submission = d.submissions.find((item) => item.member_name === d.principal.display_name);
    summary = [["내 WorkItem", d.counts.work_items, "진행·계획 업무"], ["금주 Worklog", d.worklogs.filter((item) => d.work_items.some((work) => work.id === item.work_item_id)).length, "RESULT·NEXT·RISK"], ["제출 상태", submission?.status || "미작성", `Version ${submission?.version || 0}`]];
  } else if (role === "LEADER") {
    summary = [["팀원 제출", `${d.counts.submitted_members}/${d.counts.members_total}`, "금주 제출 현황"], ["검토 WorkItem", d.counts.work_items, "RSND자동보정팀"], ["팀 보고", reportByLevel("TEAM")?.status || "DRAFT", "서술형 원문 유지"]]; activeStage = 1;
  } else if (role === "DEPT") {
    summary = [["하위 팀", 4, "자동보정담당"], ["협업 안건", d.collaborations.length, "중복은 1회 집계"], ["미결 Decision", d.counts.open_decisions, "Owner·Due 확인"]]; activeStage = 2;
  } else if (role === "PLANNING") {
    summary = [["담당 보고", 4, "승인본 기준"], ["Open QA", d.counts.open_qa, "BLOCK 우선"], ["그룹 보고", reportByLevel("GROUP")?.status || "DRAFT", "그룹장 관점 재구성"]]; activeStage = 3;
  } else if (role === "HEAD") {
    summary = [["대표 KPI", d.snapshots.length, "기준시각·상태 표시"], ["결정 요청", d.counts.open_decisions, "이번 주 검토"], ["지연 Action", d.action_items.filter((item) => item.status === "DELAYED").length, "담당 확인 필요"]]; activeStage = 4;
  } else if (role === "DATA_OWNER") {
    summary = [["공식 Snapshot", `${d.counts.snapshots_locked}/${d.counts.snapshots_total}`, "승인·잠금"], ["검증 오류", d.qa_issues.filter((item) => item.resource_type === "METRIC_SNAPSHOT" && item.status === "OPEN").length, "PD 파일 확인"], ["Cut-off", "08/23", "23:59 기준"]];
  } else if (role === "ADMIN") {
    summary = [["Portal", "정상", "127.0.0.1"], ["SQLite", "정상", "Foreign key ON"], ["감사 이벤트", d.audit_events.length, "최근 50건"]];
  } else {
    summary = [["처리할 업무", 5, "역할 범위 기준"], ["알림", 3, "마감·반려·오류"], ["보고 주차", "W34", "진행 중"]];
  }
  const itemRows = d.work_items.slice(0, 5).map((item) => `<tr><td><code>${escapeHtml(item.work_item_code)}</code><br><span class="small muted">${escapeHtml(item.organization_name)}</span></td><td>${escapeHtml(item.title)}</td><td>${badge(item.state)}</td><td>${formatDate(item.target_date)}</td></tr>`);
  return `<div class="hero-strip"><div><span class="eyebrow-text">2026 W34</span><h2>${escapeHtml(d.principal.role_label)} 업무 공간</h2><p>${escapeHtml(d.principal.organization_name)} 범위의 기준 데이터와 승인 상태입니다.</p></div><div class="hero-code"><span>Portal 기준</span><strong>${escapeHtml(d.cycle.cycle_code)}</strong><small>${escapeHtml(d.cycle.state)}</small></div></div><div class="metrics">${summary.map(([a, b, c]) => metricCard(a, b, c)).join("")}</div>${role !== "ADMIN" ? renderKpis() : ""}${card("주간보고 진행 단계", renderWorkflow(activeStage))}${card("우선 검토 업무", table(["Code / 조직", "업무", "상태", "목표일"], itemRows))}`;
}

function renderLogin() {
  return `<div class="login-layout"><section class="login-panel"><div class="brand-mark large">DX</div><h2>Manufacturing DX Weekly</h2><p>회사 계정으로 로그인하면 역할·조직·보고주차에 맞는 업무 공간을 생성합니다.</p><button class="button primary wide" data-demo="login">회사 SSO로 로그인</button><div class="small muted">시연에서는 인증을 생략하고 역할 선택기로 전환합니다.</div></section>${card("인증 통제", `<ul class="list"><li><strong>OIDC Claim 검증</strong><span>Issuer · Audience · MFA · 계정 활성 여부</span></li><li><strong>Principal 생성</strong><span>User · RoleAssignment · Organization Scope</span></li><li><strong>Deny by default</strong><span>권한이 없는 보고·파일·AI 도구는 노출하지 않음</span></li></ul>`)}</div>`;
}

function renderContext() {
  const options = [["팀원", "RSND자동보정팀", "본인 WorkItem 작성·제출"], ["팀장", "RSND자동보정팀", "팀원 검토·팀 보고 승인"], ["담당", "자동보정담당", "4개 팀 종합·기획 제출"]];
  return `${card("현재 업무 범위 선택", `<div class="context-grid">${options.map(([r, o, x], i) => `<label class="context-card"><input type="radio" name="context" ${i === 0 ? "checked" : ""}><span>${badge(r)}<strong>${escapeHtml(o)}</strong><small>${escapeHtml(x)}</small></span></label>`).join("")}</div><div class="button-row"><button class="button primary" data-demo="context">선택 범위로 시작</button></div>`)}${card("적용 원칙", `<div class="notice"><strong>역할과 조직 범위는 모든 조회·Agent 검색·승인의 기준입니다.</strong>복수 역할 사용자는 업무 시작 전에 하나의 Context를 명시적으로 선택합니다.</div>`)}`;
}

function renderInbox() {
  const tasks = [["KPI 검증 오류", "SNP-PD-2026-W34-004", "오늘 10:00", "BLOCK"], ["팀원 제출 검토", "SUB-RSND-2026-W34-002", "오늘 12:00", "OPEN"], ["Decision 요청", "DEC-RSND-2026-0008", "08/25", "REQUESTED"], ["지연 Action", "ACT-SOL-2026-0031", "08/26", "DELAYED"]];
  return `${card("내가 처리할 업무", table(["업무", "Resource", "마감", "상태"], tasks.map((row) => `<tr><td><strong>${escapeHtml(row[0])}</strong></td><td><code>${escapeHtml(row[1])}</code></td><td>${escapeHtml(row[2])}</td><td>${badge(row[3])}</td></tr>`)))}${card("Agent 우선순위 설명", `<div class="notice"><strong>1순위: 보고를 차단하는 KPI 중복 Key</strong>마감 영향, BLOCK 여부, 후속 단계 수를 기준으로 정렬했습니다. Agent는 상태를 자동 변경하지 않습니다.</div>`)}`;
}

function renderSearch() {
  const rows = state.data.work_items.slice(0, 4).map((item) => `<tr><td>${badge("WorkItem", "WORK")}</td><td><code>${escapeHtml(item.work_item_code)}</code></td><td>${escapeHtml(item.title)}</td><td>${escapeHtml(item.organization_name)}</td></tr>`);
  return `${card("권한 기반 통합 검색", `<form id="search-form" class="inline search-bar"><input class="grow" value="Jamming 자동보정 PD Loss" aria-label="검색어"><button class="button primary">검색</button></form><p class="small muted">자연어를 WorkItem·KPI·Evidence·Report ID와 연결합니다. 권한 밖 문서는 존재 여부도 노출하지 않습니다.</p>`)}<section id="search-results" class="card"><h3>검색 결과</h3>${table(["구분", "Code", "제목", "조직"], rows)}<div class="source-chips">${state.data.snapshots.slice(0, 2).map((s) => `<span class="source-chip">${escapeHtml(s.snapshot_code)}</span>`).join("")}</div></section>`;
}

function renderNotifications() {
  const list = [["BLOCK", "PD Snapshot 중복 Key 1건", "Data Owner · 8분 전"], ["DUE", "팀원 제출 마감까지 1일", "2026-08-25 17:00"], ["RETURN", "수치 근거 보완 요청", "기획팀 · 어제"], ["ACTION", "ACT-SOL-2026-0031 지연", "목표 08/26"]];
  return card("알림·마감", `<ul class="notification-list">${list.map(([type, title, meta], i) => `<li class="${i === 0 ? "unread" : ""}">${badge(type)}<div><strong>${escapeHtml(title)}</strong><span>${escapeHtml(meta)}</span></div><button class="button secondary" data-demo="notification">열기</button></li>`).join("")}</ul>`);
}

function renderWorklist() {
  const rows = state.data.work_items.map((item) => `<tr><td><input class="row-check" type="checkbox" aria-label="${escapeHtml(item.work_item_code)} 선택"></td><td><code>${escapeHtml(item.work_item_code)}</code></td><td><strong>${escapeHtml(item.title)}</strong><br><span class="small muted">${escapeHtml(item.objective)}</span></td><td>${badge(item.state)}</td><td>${escapeHtml(item.metric_code || "—")}</td><td>${escapeHtml(item.collaboration_code || "—")}</td><td>${formatDate(item.target_date)}</td></tr>`);
  return `${card("내 업무 Portfolio", `<div class="toolbar"><div class="inline"><select><option>전체 상태</option><option>진행 중</option><option>계획</option></select><input placeholder="Code 또는 업무명"></div><span class="muted small">${rows.length}건</span></div>${table(["", "WorkItem ID", "업무·목표", "상태", "KPI", "Collaboration", "목표일"], rows)}`)}${card("Code 작성 가이드", `<div class="code-guide"><code>WI-RSND-2026-0032</code><span><b>WI</b> 업무 레코드</span><span><b>RSND</b> 소유 팀</span><span><b>2026</b> 생성 연도</span><span><b>0032</b> 순번</span></div>`)}`;
}

function renderWorkDetail() {
  const item = state.data.work_items[0];
  const logs = state.data.worklogs.filter((log) => log.work_item_id === item.id);
  const ev = state.data.evidence.filter((evidence) => evidence.work_item_id === item.id);
  return `<div class="grid-2"><section class="card"><div class="card-top"><div><code>${escapeHtml(item.work_item_code)}</code><h2>${escapeHtml(item.title)}</h2></div>${badge(item.state)}</div><dl class="detail-grid"><div><dt>업무 목표</dt><dd>${escapeHtml(item.objective)}</dd></div><div><dt>Owner</dt><dd>${escapeHtml(item.owner_name)} · ${escapeHtml(item.organization_name)}</dd></div><div><dt>KPI</dt><dd>${escapeHtml(item.metric_code)}</dd></div><div><dt>Collaboration</dt><dd>${escapeHtml(item.collaboration_code)}</dd></div><div><dt>기간</dt><dd>${formatDate(item.start_date)} – ${formatDate(item.target_date)}</dd></div><div><dt>보안등급</dt><dd>${badge(item.security_label)}</dd></div></dl></section>${card("연결 Resource", `<ul class="list"><li><strong>공통 KPI Snapshot</strong><span>SNP-PD-2026-W34-004 · PROVISIONAL</span></li>${ev.map((x) => `<li><strong>${escapeHtml(x.evidence_code)}</strong><span>${escapeHtml(x.file_name)} · ${escapeHtml(x.locator)}</span></li>`).join("")}<li><strong>협업 안건</strong><span>${escapeHtml(item.collaboration_code)}</span></li></ul>`)}</div>${card("업무 이력", `<div class="timeline">${logs.map((log) => `<article><span>${formatDate(log.occurred_on)}</span><div>${badge(log.entry_type)}<p>${escapeHtml(log.narrative)}</p></div></article>`).join("")}</div>`)}`;
}

function renderEntry() {
  return `<div class="grid-2">${card("Worklog 빠른 기록", `<div class="form-grid"><label class="full">WorkItem<select><option>WI-RSND-2026-0032 · Lami Jamming 자동보정 조건 검증</option></select></label><label>기록 유형<select><option>RESULT · 수행 결과</option><option>FACT · 확인된 사실</option><option>ANALYSIS · 분석/가설</option><option>NEXT · 차주 계획</option><option>RISK · 위험</option></select></label><label>발생일<input type="date" value="2026-08-24"></label><label class="full">메모<textarea>제품 K12의 검증 생산 일정이 미확정되어 재현성 시험 일정이 지연될 수 있음.</textarea></label></div><div class="button-row"><button class="button secondary" data-demo="save-log">임시 저장</button><button class="button primary" data-demo="save-log">기록 저장</button></div>`)}${card("AI 구조화 제안", `<div class="agent-panel"><span class="agent-label">AGENT SUGGESTION</span><p><code>[RISK]</code> 검증용 생산 일정이 미확정되어 K12 재현성 검증 완료가 지연될 수 있다.</p><dl><div><dt>Owner</dt><dd>직접 지정 필요</dd></div><div><dt>Due</dt><dd>직접 지정 필요</dd></div><div><dt>추론 금지</dt><dd>담당자와 기한은 메모에서 임의 생성하지 않음</dd></div></dl><button class="button secondary" data-demo="apply-suggestion">제안 적용</button></div>`)}</div>`;
}

function renderEvidenceUpload() {
  const rows = state.data.evidence.map((item) => `<tr><td><code>${escapeHtml(item.evidence_code)}</code></td><td>${escapeHtml(item.file_name)}</td><td>${escapeHtml(item.locator || "—")}</td><td>${badge(item.scan_status)}</td><td>${badge(item.security_label)}</td></tr>`);
  return `${card("업무파일 등록", `<div class="dropzone"><div class="upload-icon">⇧</div><strong>파일을 끌어놓거나 선택하십시오</strong><span>xlsx · csv · pdf · pptx · 최대 50 MB</span><button class="button primary" data-demo="upload-evidence">샘플 파일 선택</button></div><div class="form-grid compact"><label>연결 WorkItem<select><option>WI-RSND-2026-0032</option></select></label><label>보안등급<select><option>CONFIDENTIAL</option><option>INTERNAL</option></select></label></div>`)}${card("등록된 Evidence", table(["Evidence ID", "파일", "Locator", "검사", "등급"], rows))}`;
}

function renderSelection(leaderMode) {
  const rows = state.data.work_items.map((item, index) => `<tr><td><input class="row-check" type="checkbox" ${index < 3 ? "checked" : ""}></td><td><code>${escapeHtml(item.work_item_code)}</code></td><td>${escapeHtml(item.title)}</td><td>${badge(item.state)}</td><td>${escapeHtml(item.owner_name)}</td><td>${index < 3 ? badge("RECOMMENDED", "추천") : badge("NO_RESULT", "금주 결과 없음")}</td></tr>`);
  const title = leaderMode ? "팀 보고 포함·제외" : "금주 실적 선택";
  return `${card(title, `<div class="notice"><strong>AI는 포함 후보와 이유만 제안합니다.</strong>최종 포함·제외는 사람이 결정하며, 제외 시 사유를 기록합니다.</div>${table(["포함", "WorkItem", "업무", "상태", "Owner", "Agent 판단"], rows)}<div class="button-row"><button class="button secondary" data-demo="selection">선택 저장</button><button class="button primary" data-generate-draft>선택항목으로 초안 생성</button></div>`)}${card("Source Manifest 미리보기", `<pre class="manifest">WI-RSND-2026-0032\nSNP-PD-2026-W34-004\nEVD-RSND-2026-W34-028\nCOL-YIELD-2026-0014</pre>`)}`;
}

function editorLevel(level) {
  if (level === "TEAM_MEMBER") return { title: "팀원 주간실적", report: reportByLevel("TEAM") };
  if (level === "TEAM") return { title: "RSND자동보정팀 팀장 서술형 보고", report: reportByLevel("TEAM") };
  if (level === "DEPARTMENT") return { title: "자동보정담당 주간보고", report: reportByLevel("DEPARTMENT") };
  return { title: "제조DX그룹 주간보고", report: reportByLevel("GROUP") };
}

function renderEditor(level) {
  const config = editorLevel(level);
  const content = state.generatedDraft || config.report?.content || "선택한 업무를 기준으로 Agent 초안을 생성하십시오.";
  const sources = state.generatedDraft
    ? ["WI-RSND-2026-0032", "SNP-PD-2026-W34-004", "EVD-RSND-2026-W34-028", "COL-YIELD-2026-0014"]
    : String(config.report?.source_manifest || "").split(",").filter(Boolean);
  return `<div class="editor-layout"><section class="card editor-main"><div class="card-top"><div><span class="small muted">${escapeHtml(config.report?.report_code || "SUB-RSND-2026-W34-001")}</span><h2>${escapeHtml(config.title)}</h2></div>${badge(config.report?.status || "AI_DRAFTED")}</div><div class="notice"><strong>서술형 원문은 유지합니다.</strong>Agent는 의미를 축약하지 않고 문단 앞에 WorkItem·KPI·협업·Decision ID와 검증 상태를 보강합니다.</div><textarea id="report-editor" class="report-editor" spellcheck="false">${escapeHtml(content)}</textarea><div class="button-row"><button class="button secondary" data-demo="save-version">Version 저장</button><button class="button secondary" data-generate-draft>AI 초안 다시 생성</button></div></section><aside class="stack">${card("AI Readable 검사", `<ul class="check-list"><li class="pass">✓ 문장 유형 태그</li><li class="pass">✓ 숫자·단위 대조</li><li class="pass">✓ 근거 Citation</li><li class="warn">! PD Snapshot 잠정 상태</li><li class="pass">✓ 협업 가설 분리</li></ul>`)}${card("Source Manifest", `<div>${sources.map((source) => `<span class="source-chip">${escapeHtml(source)}</span>`).join("") || "—"}</div><p class="small muted">보고 Version과 함께 불변 저장됩니다.</p>`)}</aside></div>`;
}

function renderSubmission() {
  const mine = state.data.submissions.find((item) => item.member_name === state.data.principal.display_name) || state.data.submissions[0];
  return `${card("제출 상태", `<div class="submission-hero"><div><span class="small muted">${escapeHtml(mine.submission_code)}</span><h2>${escapeHtml(mine.member_name)} · W34</h2><p>현재 Version ${mine.version} · ${mine.submitted_at ? formatDate(mine.submitted_at, true) : "아직 제출하지 않음"}</p></div>${badge(mine.status)}</div>${renderWorkflow(mine.status === "SUBMITTED" ? 1 : 0)}<div class="button-row"><button class="button secondary" data-demo="preview">제출본 미리보기</button><button class="button primary" data-action="SUBMIT_MEMBER">팀장에게 제출</button></div>`)}${card("Version 이력", table(["Version", "생성 주체", "상태", "시각"], [`<tr><td>v${mine.version}</td><td>MEMBER + AGENT</td><td>${badge(mine.status)}</td><td>${mine.submitted_at ? formatDate(mine.submitted_at, true) : "임시 저장"}</td></tr>`, `<tr><td>v1</td><td>MEMBER</td><td>${badge("DRAFT")}</td><td>08.23 16:42</td></tr>`]))}`;
}

function renderSubmissionMatrix() {
  const rows = state.data.submissions.map((item) => `<tr><td><strong>${escapeHtml(item.member_name)}</strong><br><span class="small muted">${escapeHtml(item.organization_name)}</span></td><td><code>${escapeHtml(item.submission_code)}</code></td><td>${badge(item.status)}</td><td>v${item.version}</td><td>${item.submitted_at ? formatDate(item.submitted_at, true) : "—"}</td><td><button class="button secondary" data-demo="open-submission">검토</button></td></tr>`);
  return `${card("RSND자동보정팀 제출 현황", `<div class="metrics compact-metrics">${metricCard("제출 완료", state.data.counts.submitted_members, `전체 ${state.data.counts.members_total}명`)}${metricCard("미검토", 2, "오늘 12:00까지")}${metricCard("반려", 0, "보완 요청 없음")}</div>${table(["팀원", "Submission", "상태", "Version", "제출시각", ""], rows)}`)}${card("검토 순서 제안", `<div class="notice"><strong>1. 김현수 — 잠정 KPI와 Decision 요청 포함</strong>2. 박은지 — 정량 효과 근거 확인<br>3. 이정훈 — 협업 가설이 확정 사실과 분리됐는지 확인</div>`)}`;
}

function renderMemberDetail() {
  const sub = state.data.submissions[0];
  const report = reportByLevel("TEAM");
  return `<div class="grid-2">${card("제출 원문", `<div class="card-top"><div><code>${escapeHtml(sub.submission_code)}</code><h2>${escapeHtml(sub.member_name)}</h2></div>${badge(sub.status)}</div><div class="report-preview">${escapeHtml(report?.content || "").replaceAll("\n", "<br>")}</div><div class="button-row"><button class="button danger" data-demo="return">보완 요청</button><button class="button primary" data-demo="include">팀 보고에 포함</button></div>`)}${card("근거 연결", `<ul class="list"><li><strong>WI-RSND-2026-0032</strong><span>Owner · 상태 · 목표일 확인</span></li><li><strong>SNP-PD-2026-W34-004</strong><span>1.2% · PROVISIONAL · Cut-off 08/23 23:59</span></li><li><strong>EVD-RSND-2026-W34-028</strong><span>Jamming_보정조건_검증표.xlsx · Result!B4:H18</span></li><li><strong>COL-YIELD-2026-0014</strong><span>FDC·자동보정·품질DX·솔루션 협업</span></li></ul>`)}</div>`;
}

function renderEvidenceCompare() {
  const report = reportByLevel("TEAM");
  return `${card("문장–근거 대조", `<div class="compare-grid"><div><span class="pane-title">보고 문장</span><p><mark>W34 PD Loss는 1.2%</mark>로 전주 1.5% 대비 감소했으나 Data Owner 승인 전 잠정값이다.</p></div><div><span class="pane-title">공식 Resource</span><dl class="detail-grid"><div><dt>Snapshot</dt><dd>SNP-PD-2026-W34-004</dd></div><div><dt>값</dt><dd>1.2%</dd></div><div><dt>전주</dt><dd>1.5%</dd></div><div><dt>상태</dt><dd>${badge("PROVISIONAL")}</dd></div><div><dt>Cut-off</dt><dd>2026-08-23 23:59</dd></div><div><dt>일치</dt><dd>${badge("MATCH", "일치")}</dd></div></dl></div></div>`)}${card("검사 결과", `<div class="metrics compact-metrics">${metricCard("숫자", "4/4", "Exact match")}${metricCard("Citation", "4/4", "Resource 존재")}${metricCard("주의", "1", "잠정 상태 유지")}</div><div class="source-chips">${String(report?.source_manifest || "").split(",").map((x) => `<span class="source-chip">${escapeHtml(x)}</span>`).join("")}</div>`)}`;
}

function renderApproval() {
  const role = state.role;
  const level = role === "LEADER" ? "TEAM" : role === "DEPT" ? "DEPARTMENT" : "GROUP";
  const report = reportByLevel(level);
  const next = role === "LEADER" ? "자동보정담당" : role === "DEPT" ? "제조DX기획팀" : "그룹장";
  return `${card("승인 Action Preview", `<div class="approval-preview"><div><span>대상 Report</span><strong>${escapeHtml(report?.report_code || "RPT-GROUP-DX-2026-W34")}</strong></div><div><span>현재 상태</span><strong>${badge(report?.status || "DRAFT")}</strong></div><div><span>다음 수신</span><strong>${escapeHtml(next)}</strong></div><div><span>고정 Version</span><strong>v${report?.current_version || 1}</strong></div></div><div class="notice warn"><strong>승인 후 원문을 덮어쓰지 않습니다.</strong>정정이 필요하면 새 Version을 만들고 승인 이력을 다시 남깁니다.</div><div class="button-row"><button class="button danger" data-demo="return-report">반려·보완 요청</button><button class="button primary" data-action="${escapeHtml(actionMap[currentScreen().screen_id] || "APPROVE_TEAM")}">${escapeHtml(currentScreen().primary_action)}</button></div>`)}${card("승인 체크", `<ul class="check-list"><li class="pass">✓ 하위 제출·승인 상태 확인</li><li class="pass">✓ 숫자와 Snapshot 일치</li><li class="pass">✓ Evidence 연결</li><li class="warn">! 잠정 KPI 라벨 유지</li><li class="pass">✓ Owner·Due 누락 없음</li></ul>`)}`;
}

function renderHistory() {
  const report = reportByLevel("TEAM");
  return `${card("Report Version 비교", `<div class="version-tabs"><button class="active">v${report?.current_version || 1} · 현재</button><button>v1 · Agent</button><button>원문</button></div><div class="diff-view"><div><span class="pane-title">이전 Version</span><p>Jamming 보정조건 검증 완료. K12 추가 확인 필요.</p></div><div><span class="pane-title">현재 승인 후보</span><p><ins>[WI-RSND-2026-0032][RESULT]</ins> Jamming 자동보정 조건을 검증하였다. 대상 3개 제품 중 2개는 반복 경향을 확인했고 <ins>K12는 추가 검증이 필요하다.</ins></p></div></div>`)}${card("변경 이력", table(["Version", "생성 주체", "변경 요약", "시각"], [`<tr><td>v2</td><td>팀장</td><td>ID·잠정상태·Decision 보강</td><td>08.24 10:12</td></tr>`, `<tr><td>v1</td><td>LEADER_AGENT</td><td>팀원 제출 3건 종합</td><td>08.24 09:40</td></tr>`]))}`;
}

function renderTeamMatrix() {
  const teams = [["RSND자동보정팀", "RPT-TEAM-RSND-2026-W34", "DRAFT", "3/3", "PD Loss · Jamming"], ["전극자동보정팀", "RPT-TEAM-ELC-2026-W34", "TEAM_APPROVED", "4/4", "BM Loss · 로딩량"], ["조립자동보정팀", "RPT-TEAM-ASM-2026-W34", "TEAM_APPROVED", "5/5", "PD Loss · 주액기"], ["활성화자동보정팀", "RPT-TEAM-ACT-2026-W34", "NEEDS_EVIDENCE", "3/4", "CTQ · Evidence 누락"]];
  return `${card("팀 보고 Matrix", table(["팀", "Report", "상태", "제출", "핵심 안건"], teams.map((r) => `<tr><td><strong>${r[0]}</strong></td><td><code>${r[1]}</code></td><td>${badge(r[2])}</td><td>${r[3]}</td><td>${r[4]}</td></tr>`)))}${card("담당 관점 Agent 요약", `<div class="notice"><strong>우선 검토: 활성화자동보정팀 Evidence 누락</strong>미승인 팀 원문은 담당 보고의 확정 사실로 집계하지 않습니다. RSND·FDC의 Jamming 안건은 Collaboration ID로 한 번만 묶습니다.</div>`)}`;
}

function renderCollaboration() {
  const participants = state.data.participants;
  return `<div class="collab-grid">${state.data.collaborations.map((c) => {
    const people = participants.filter((p) => p.collaboration_id === c.id);
    return `<section class="card"><div class="card-top"><code>${escapeHtml(c.collaboration_code)}</code>${badge(c.status)}</div><h2>${escapeHtml(c.title)}</h2><p>${escapeHtml(c.goal)}</p><div class="collab-flow"><span>${escapeHtml(c.lead_organization)} · 주관</span>${people.map((p) => `<span>${escapeHtml(p.organization_name)}</span>`).join("")}</div><ul class="list">${people.map((p) => `<li><strong>${escapeHtml(p.organization_name)}</strong><span>${escapeHtml(p.contribution)}</span></li>`).join("")}</ul><p class="small muted">목표일 ${formatDate(c.target_date)}</p></section>`;
  }).join("")}</div>`;
}

function renderConflict() {
  return `${card("KPI·주장 충돌", `<div class="conflict-row"><div>${badge("PROVISIONAL")}<h3>PD Loss 값 상태</h3><p>팀 보고는 1.2%를 확정값처럼 기술했으나 Snapshot은 Data Owner 승인 전입니다.</p></div><div class="conflict-arrow">→</div><div><strong>권고 처리</strong><p>값은 유지하고 문장에 <code>[PROVISIONAL]</code>과 Cut-off를 표시합니다.</p><button class="button secondary" data-demo="conflict">권고 적용</button></div></div><div class="conflict-row"><div>${badge("ANALYSIS")}<h3>Jamming 원인 해석</h3><p>FDC 장력 편차와 발생 시점의 상관성을 원인으로 표현한 팀이 있습니다.</p></div><div class="conflict-arrow">→</div><div><strong>권고 처리</strong><p>팀별 가설을 병렬 유지하고 공동 검증 중으로 표시합니다.</p><button class="button secondary" data-demo="conflict">병렬 표기</button></div></div>`)}${card("충돌 처리 원칙", `<ol class="principles"><li>최신값을 임의 선택하지 않습니다.</li><li>Snapshot Version·집계범위·기준시각을 먼저 대조합니다.</li><li>확정 사실과 팀별 분석·가설을 분리합니다.</li><li>해결 방식과 승인자를 감사 이력에 남깁니다.</li></ol>`)}`;
}

function renderDecisionRegister() {
  const decisions = state.data.decisions.map((d) => `<tr><td><code>${escapeHtml(d.decision_code)}</code></td><td><strong>${escapeHtml(d.title)}</strong><br><span class="small muted">${escapeHtml(d.request)}</span></td><td>${escapeHtml(d.decision_maker || "미지정")}</td><td>${formatDate(d.due_date)}</td><td>${badge(d.status)}</td></tr>`);
  const actions = state.data.action_items.map((a) => `<tr><td><code>${escapeHtml(a.action_code)}</code></td><td>${escapeHtml(a.title)}</td><td>${escapeHtml(a.owner_name || "미지정")}</td><td>${formatDate(a.due_date)}</td><td>${badge(a.status)}</td></tr>`);
  return `${card("Decision 요청", table(["Decision ID", "요청", "결정자", "기한", "상태"], decisions))}${card("후속 Action", table(["Action ID", "조치", "Owner", "Due", "상태"], actions))}`;
}

function issueRows(resourceType = null) {
  return state.data.qa_issues.filter((item) => !resourceType || item.resource_type === resourceType).map((item) => `<article class="qa-item"><span>${badge(item.severity)}</span><div><strong>${escapeHtml(item.rule_code)} · ${escapeHtml(item.message)}</strong><p>${escapeHtml(item.remediation)}</p><code>${escapeHtml(item.resource_id)}</code></div>${badge(item.status)}</article>`).join("") || `<div class="empty-state">열린 Issue가 없습니다.</div>`;
}

function renderQa() {
  const open = state.data.qa_issues.filter((item) => item.status === "OPEN");
  const blocks = open.filter((item) => item.severity === "BLOCK").length;
  return `${renderKpis()}${card("그룹 보고 QA Issue", `<div class="metrics compact-metrics">${metricCard("OPEN", open.length, "전체 미해소")}${metricCard("BLOCK", blocks, "확정 차단")}${metricCard("WARN", open.length - blocks, "사유 확인")}</div><div class="stack">${issueRows()}</div><div class="button-row"><button class="button primary" data-action="RESOLVE_QA">Issue 해소 요청</button></div>`)}${card("결정적 검사 → LLM 설명", `<div class="notice"><strong>Pass/Fail은 Rule Engine이 판단합니다.</strong>LLM은 오류의 의미, 영향 문장, 수정 위치를 사람이 이해하기 쉽게 설명합니다.</div>`)}`;
}

function renderRedaction() {
  const rows = [["설비 상세번호 ESWA-L07-03", "CONFIDENTIAL", "내부 그룹 보고", "유지"], ["제품 K12 시험조건", "CONFIDENTIAL", "외부 공유", "제외 후보"], ["PD Loss 1.2%", "INTERNAL", "외부 공유", "승인 필요"], ["WorkItem·Snapshot Code", "INTERNAL", "내부 그룹 보고", "유지"]];
  return `${card("민감정보 제외 후보", table(["항목", "등급", "대상", "처리"], rows.map((r) => `<tr><td>${escapeHtml(r[0])}</td><td>${badge(r[1])}</td><td>${escapeHtml(r[2])}</td><td>${badge(r[3], r[3])}</td></tr>`)))}${card("공유 Version 원칙", `<div class="notice warn"><strong>Agent가 원본을 자동 삭제하지 않습니다.</strong>원본 Version을 보존하고, 승인된 Redaction 규칙으로 별도 공유 Version을 생성합니다.</div><div class="button-row"><button class="button secondary" data-demo="redaction">제외안 미리보기</button><button class="button primary" data-demo="redaction">공유 Version 생성</button></div>`)}`;
}

function renderExport() {
  const rows = state.data.reports.map((r) => `<tr><td><code>${escapeHtml(r.report_code)}</code></td><td>${escapeHtml(r.report_level)}</td><td>${badge(r.status)}</td><td>v${r.current_version}</td><td><button class="button secondary" data-demo="export">PPTX</button> <button class="button secondary" data-demo="export">JSON</button></td></tr>`);
  return `${card("확정본·산출물", table(["Report", "Level", "상태", "Version", "Export"], rows))}${card("재현 가능한 Export", `<ul class="list"><li><strong>Human-readable</strong><span>PPTX · PDF · 포털 화면</span></li><li><strong>Machine companion</strong><span>JSON · Source Manifest · Citation</span></li><li><strong>감사 정보</strong><span>Template · Prompt · Model · 생성시각 · 승인 Version</span></li></ul>`)}`;
}

function renderEvidenceTrace() {
  const evidence = state.data.evidence[0];
  return `<section class="trace-map card"><h3>문장부터 원천까지 추적</h3><div class="trace-node"><span>보고 문장</span><strong>대상 3개 제품 중 2개 제품에서 동일 경향 확인</strong></div><div class="trace-arrow">↓ Citation</div><div class="trace-node"><span>WorkItem</span><strong>WI-RSND-2026-0032</strong></div><div class="trace-arrow">↓ Evidence</div><div class="trace-node"><span>파일·위치</span><strong>${escapeHtml(evidence.file_name)} · ${escapeHtml(evidence.locator)}</strong></div><div class="trace-arrow">↓ Integrity</div><div class="trace-node"><span>Hash·검사</span><strong>${escapeHtml(evidence.sha256.slice(0, 16))}… · ${escapeHtml(evidence.scan_status)}</strong></div></section>${card("신뢰 상태", `<div class="metrics compact-metrics">${metricCard("원문 Hash", "일치", "SHA-256")}${metricCard("보안 범위", evidence.security_label, "현재 사용자 조회 가능")}${metricCard("Freshness", "W34", "08/23 23:59")}</div>`)}`;
}

function renderQuestion() {
  const answer = state.lastAnswer;
  return `<div class="question-layout"><section class="card"><h3>근거 기반 질문</h3><form id="question-form"><textarea id="question-input" aria-label="질문">자동보정 적용으로 PD Loss가 개선됐다고 확정할 수 있어?</textarea><div class="question-suggestions"><button type="button" data-question="K12 검증이 지연되면 어떤 영향이 있어?">K12 검증 지연 영향</button><button type="button" data-question="이번 주 가장 중요한 Decision은 무엇이야?">중요 Decision</button></div><div class="button-row"><button class="button primary">보고 Q&A Agent에 질문</button></div></form></section><section class="card"><h3>Agent 답변</h3>${answer ? renderAnswer(answer) : `<div class="empty-state">질문하면 승인된 보고와 Citation 범위 안에서 답변합니다.</div>`}</section></div>`;
}

function renderAnswer(answer) {
  return `<div class="answer"><p>${escapeHtml(answer.answer)}</p><div class="notice warn"><strong>불확실성</strong>동일 제품·동일 조건의 적용 전후 승인 데이터가 추가로 필요합니다.</div><h4>근거</h4>${answer.citations.map((c) => `<div class="citation"><code>${escapeHtml(c.code)}</code><span>${escapeHtml(c.detail)}</span></div>`).join("")}<p class="small muted">Freshness ${escapeHtml(answer.freshness)} · Trace ${escapeHtml(answer.trace_id)}</p></div>`;
}

function renderDecision() {
  const rows = state.data.decisions.map((d) => `<section class="card decision-card"><div class="card-top"><code>${escapeHtml(d.decision_code)}</code>${badge(d.status)}</div><h2>${escapeHtml(d.title)}</h2><p>${escapeHtml(d.request)}</p><dl class="detail-grid"><div><dt>결정자</dt><dd>${escapeHtml(d.decision_maker || "그룹장")}</dd></div><div><dt>기한</dt><dd>${formatDate(d.due_date)}</dd></div><div><dt>선택지 A</dt><dd>W35 생산 일정 우선 배정</dd></div><div><dt>선택지 B</dt><dd>W36 정규 일정 수행</dd></div></dl>${d.status === "RESOLVED" ? `<div class="notice"><strong>확정 결과</strong>${escapeHtml(d.resolution)}</div>` : `<div class="button-row"><button class="button secondary" data-demo="decision-detail">추가 근거 요청</button><button class="button primary" data-action="RESOLVE_DECISION">결정·Action 확정</button></div>`}</section>`).join("");
  return `<div class="stack">${rows}</div>`;
}

function renderTrend() {
  const series = [["W30", 1.8], ["W31", 1.7], ["W32", 1.6], ["W33", 1.5], ["W34", 1.2]];
  const chart = `<div class="bar-chart" role="img" aria-label="PD Loss W30부터 W34 추이">${series.map(([week, value]) => `<div class="bar-col"><span>${value}%</span><div class="bar" style="height:${value * 75}px"></div><strong>${week}</strong></div>`).join("")}</div>`;
  const actions = state.data.action_items.map((a) => `<tr><td><code>${escapeHtml(a.action_code)}</code></td><td>${escapeHtml(a.title)}</td><td>${escapeHtml(a.owner_name || "—")}</td><td>${formatDate(a.due_date)}</td><td>${badge(a.status)}</td></tr>`);
  return `<div class="grid-2">${card("PD Loss 주차 Trend", `${chart}<p class="small muted">동일 Metric 정의 v4 기준. W34는 승인 전 Snapshot일 수 있습니다.</p>`)}${card("추이 해석", `<div class="notice"><strong>W30 1.8% → W34 1.2%</strong>감소 경향은 관찰되지만 자동보정 단독 효과를 확정하려면 적용 전후 통제 데이터가 필요합니다.</div><ul class="list"><li><strong>질문 제안</strong><span>제품·라인별 개선 폭은 동일한가?</span></li><li><strong>확인 항목</strong><span>K12 추가 검증 후 경향 유지 여부</span></li></ul>`)}</div>${card("Action 추적", table(["Action", "조치", "Owner", "Due", "상태"], actions))}`;
}

function renderSnapshotUpload() {
  return `<div class="grid-2">${card("KPI 원천파일 업로드", `<div class="dropzone"><div class="upload-icon">⇧</div><strong>정기 다운로드 파일을 업로드</strong><span>메일·분석시스템 API 연계 전 운영 방식</span><button class="button primary" data-demo="snapshot-upload">PD_Loss_2026W34_0823.xlsx 선택</button></div><div class="form-grid compact"><label>Metric<select><option>PD_LOSS · PD Loss</option></select></label><label>기준시각<input value="2026-08-23 23:59"></label><label>보고주차<select><option>2026-W34</option></select></label><label>Source System<input value="분석시스템"></label></div>`)}${card("자동 추출 Preview", `<dl class="detail-grid"><div><dt>파일명 계약</dt><dd>${badge("PASS")}</dd></div><div><dt>SHA-256</dt><dd><code>8ae1…bd42</code></dd></div><div><dt>Sheet</dt><dd>Weekly_Result</dd></div><div><dt>Rows</dt><dd>1,284</dd></div><div><dt>예상 Metric</dt><dd>PD_LOSS · 96%</dd></div><div><dt>상태</dt><dd>UPLOADED 예정</dd></div></dl><div class="notice warn"><strong>96% 제안은 자동확정하지 않습니다.</strong>Data Owner가 Metric과 Cut-off를 확인합니다.</div>`)}</div>`;
}

function renderMapping() {
  const mappings = [["SITE_CD", "site", "ESWA", "100%"], ["PROC_NM", "process", "조립", "98%"], ["LINE_ID", "line", "L07", "100%"], ["MODEL", "product", "M08", "94%"], ["PD_LOSS_RT", "value", "2.4", "99%"], ["BASE_DT", "cutoff_at", "2026-08-23", "92%"]];
  return `${card("Source → 표준 Dimension 매핑", table(["원천 Header", "표준 Field", "Sample", "Confidence"], mappings.map((r) => `<tr><td><code>${r[0]}</code></td><td><select><option>${r[1]}</option></select></td><td>${r[2]}</td><td>${Number(r[3].replace("%", "")) < 95 ? badge("WARN", r[3]) : badge("PASS", r[3])}</td></tr>`)))}${card("Mapping Version", `<div class="approval-preview"><div><span>Metric</span><strong>PD_LOSS v4</strong></div><div><span>File Contract</span><strong>FC-PD-2026-02</strong></div><div><span>현재 Mapping</span><strong>MAP-PD-v7</strong></div><div><span>변경 예정</span><strong>MAP-PD-v8</strong></div></div><div class="button-row"><button class="button primary" data-demo="mapping">매핑 저장·검증</button></div>`)}`;
}

function renderValidation() {
  const snapshot = state.data.snapshots.find((item) => item.id === "snp_pd_w34");
  return `<div class="metrics">${metricCard("검사 상태", snapshot.status, snapshot.snapshot_code)}${metricCard("BLOCK", snapshot.validation_errors, "중복 Key")}${metricCard("WARN", snapshot.validation_warnings, "급변값")}</div>${card("Validation Issue", `<div class="stack">${issueRows("METRIC_SNAPSHOT")}</div><div class="button-row"><button class="button secondary" data-demo="source-row">원본 행 보기</button><button class="button primary" data-action="VALIDATE_SNAPSHOT">재검증</button></div>`)}${card("Rule 실행 순서", `<div class="pipeline"><span>Schema</span><b>→</b><span>Key 중복</span><b>→</b><span>누락</span><b>→</b><span>단위</span><b>→</b><span>급변</span><b>→</b><span>집계 대조</span></div>`)}`;
}

function renderSnapshotCompare() {
  const rows = [["전체", "ALL", "ALL", 1.5, 1.2, -0.3, "정상"], ["조립", "L07", "M08", 0.8, 2.4, 1.6, "급변"], ["조립", "L03", "K12", 1.2, 1.1, -0.1, "중복 Key"]];
  return `${card("W33 ↔ W34 Snapshot 비교", table(["공정", "Line", "제품", "W33", "W34", "차이(%p)", "Flag"], rows.map((r) => `<tr><td>${r[0]}</td><td>${r[1]}</td><td>${r[2]}</td><td class="numeric">${r[3]}%</td><td class="numeric">${r[4]}%</td><td class="numeric">${r[5] > 0 ? "+" : ""}${r[5]}</td><td>${badge(r[6], r[6])}</td></tr>`)))}${card("변동 사유", `<div class="form-grid"><label class="full">ESWA L07 M08 급변 사유<textarea>제품 전환 직후 초기 구간 값이 포함되었는지 원천 파일과 집계 범위를 확인 중.</textarea></label></div><div class="button-row"><button class="button primary" data-demo="save-reason">변동 사유 기록</button></div>`)}`;
}

function renderSnapshotApprove() {
  const s = state.data.snapshots.find((item) => item.id === "snp_pd_w34");
  const canApprove = Number(s.validation_errors) === 0;
  return `${card("PD Loss Snapshot 승인", `<div class="snapshot-header"><div><code>${escapeHtml(s.snapshot_code)}</code><h2>${escapeHtml(s.metric_name)} · ${Number(s.display_value).toFixed(1)}${escapeHtml(s.unit)}</h2><p>Cut-off ${escapeHtml(s.cutoff_at)} · Source ${escapeHtml(s.source_file)}</p></div>${badge(s.status)}</div><div class="approval-preview"><div><span>Verification</span><strong>${badge(s.verification_state)}</strong></div><div><span>Version</span><strong>v${s.version}</strong></div><div><span>BLOCK</span><strong>${s.validation_errors}</strong></div><div><span>WARN</span><strong>${s.validation_warnings}</strong></div></div>${!canApprove ? `<div class="notice danger"><strong>승인 차단</strong>Validation의 BLOCK 오류를 먼저 해소하십시오.</div>` : `<div class="notice"><strong>승인 가능</strong>승인하면 공식 Snapshot으로 잠기며 정정은 새 Version으로만 가능합니다.</div>`}<div class="button-row"><button class="button primary" ${canApprove ? "" : "disabled"} data-action="APPROVE_SNAPSHOT">Snapshot 승인·잠금</button></div>`)}${card("영향 범위", `<ul class="list"><li><strong>팀원 초안</strong><span>잠정 → 검증됨 상태로 표시 변경</span></li><li><strong>팀·담당·그룹 보고</strong><span>동일 Snapshot ID를 참조하는 문장 재검사</span></li><li><strong>Audit</strong><span>Data Owner · 승인시각 · Trace ID 기록</span></li></ul>`)}`;
}

function renderMetricCatalog() {
  const definitions = [["YIELD_RATE", "수율", "정상품 수량 / 전체 투입 수량", "%", "분석시스템", "v3"], ["BM_LOSS", "BM Loss", "설비 기인 Loss 비율", "%", "분석시스템", "v2"], ["PD_LOSS", "PD Loss", "공정 기인 Loss 비율", "%", "분석시스템", "v4"], ["DEFECT_RATE", "불량률", "검사 불량 수량 / 전체 검사 수량", "%", "분석시스템", "v2"]];
  return `${card("Metric Catalog", table(["Metric Code", "표시명", "공식 정의", "단위", "원천", "Version"], definitions.map((r) => `<tr><td><code>${r[0]}</code></td><td><strong>${r[1]}</strong></td><td>${r[2]}</td><td>${r[3]}</td><td>${r[4]}</td><td>${badge(r[5])}</td></tr>`)))}${card("약어 관리 원칙", `<div class="notice"><strong>BM·PD라는 표시명만으로 데이터를 연결하지 않습니다.</strong>Metric Code, 공식 산식, 집계 차원, Owner, Version을 함께 저장합니다.</div>`)}`;
}

function renderIam() {
  const rows = [["김현수", "D1001", "MEMBER", "RSND자동보정팀", "활성"], ["이선우", "D1100", "LEADER", "RSND자동보정팀", "활성"], ["김도윤", "D1200", "DEPT", "자동보정담당", "활성"], ["최은서", "D1300", "PLANNING", "제조DX그룹", "활성"], ["그룹장 사용자", "D1400", "HEAD", "제조DX그룹", "활성"]];
  return `${card("조직·사용자·역할", table(["사용자", "사번", "Role", "Scope", "상태"], rows.map((r) => `<tr><td><strong>${r[0]}</strong></td><td>${r[1]}</td><td>${badge(r[2])}</td><td>${r[3]}</td><td>${badge("ACTIVE", r[4])}</td></tr>`)))}${card("권한 변경 통제", `<div class="notice warn"><strong>역할과 조직 범위 변경은 승인·기간·사유가 필요합니다.</strong>작성과 최종 승인 등 상충 역할은 SoD 규칙으로 경고합니다.</div>`)}`;
}

function renderCalendar() {
  const c = state.data.cycle;
  const dates = [["Snapshot", c.snapshot_due_at, "Data Owner"], ["팀원 제출", c.member_due_at, "팀원"], ["팀장 승인", c.leader_due_at, "팀장"], ["담당 승인", c.department_due_at, "담당"], ["기획 QA", c.planning_due_at, "기획팀"]];
  return `${card("2026 W34 보고 Calendar", `<div class="calendar-strip">${dates.map(([name, date, owner], index) => `<article class="${index === 0 ? "done" : index === 1 ? "active" : ""}"><span>${formatDate(date, true)}</span><strong>${name}</strong><small>${owner}</small></article>`).join("")}</div>`)}${card("주차 개시 설정", `<div class="form-grid"><label>Cycle Code<input value="2026-W35"></label><label>개시일<input type="date" value="2026-08-24"></label><label>휴일 예외<select><option>없음</option></select></label><label>이전주 복사<select><option>마감 규칙만 복사</option></select></label></div><div class="button-row"><button class="button primary" data-demo="calendar">보고주차 개시</button></div>`)}`;
}

function renderRelease() {
  const rows = [["PROMPT-LEADER", "팀장 서술형 초안", "v1.4", "Sonnet 4.5", "PASS", "활성"], ["PROMPT-PLANNING", "그룹 보고 구성", "v2.1", "Opus", "PASS", "활성"], ["TPL-WEEKLY-PPT", "내부 보고 PPT", "v3.2", "—", "PASS", "활성"], ["POLICY-CITATION", "Citation 검사", "v1.7", "Rule", "PASS", "활성"]];
  return `${card("Template · Prompt · Model Release", table(["Artifact", "용도", "Version", "Model", "Eval", "상태"], rows.map((r) => `<tr><td><code>${r[0]}</code></td><td>${r[1]}</td><td>${r[2]}</td><td>${r[3]}</td><td>${badge(r[4])}</td><td>${badge("ACTIVE", r[5])}</td></tr>`)))}${card("배포 Gate", `<div class="pipeline"><span>변경 제안</span><b>→</b><span>Golden Set</span><b>→</b><span>Regression</span><b>→</b><span>2인 검토</span><b>→</b><span>배포</span><b>→</b><span>Rollback</span></div>`)}`;
}

function renderPolicy() {
  const policies = [["POL-ACL-001", "권한 밖 Resource 검색 금지", "ENFORCED"], ["POL-LLM-003", "승인·결정 Tool 자동실행 금지", "ENFORCED"], ["POL-DATA-007", "Snapshot 잠금 후 덮어쓰기 금지", "ENFORCED"], ["POL-EXPORT-004", "외부공유 민감정보 검토", "ENFORCED"]];
  return `${card("권한·보안 Policy", table(["Policy", "규칙", "상태"], policies.map((r) => `<tr><td><code>${r[0]}</code></td><td>${r[1]}</td><td>${badge(r[2])}</td></tr>`)))}${card("Agent Tool Allowlist", `<div class="permission-grid"><div><strong>읽기 허용</strong><span>WorkItem · 승인 Report · Snapshot · Evidence metadata</span></div><div><strong>초안 허용</strong><span>요약 · Citation · QA 설명 · 질문 제안</span></div><div><strong>사람 확인 필수</strong><span>제출 · 승인 · Decision · 권한 변경 · 외부 공유</span></div><div><strong>차단</strong><span>권한 밖 검색 · 원본 삭제 · Snapshot 덮어쓰기</span></div></div>`)}`;
}

function renderAudit() {
  const rows = state.data.audit_events.map((a) => `<tr><td>${formatDate(a.occurred_at, true)}</td><td><code>${escapeHtml(a.trace_id)}</code></td><td>${escapeHtml(a.actor_name || "SYSTEM")}<br><span class="small muted">${escapeHtml(a.actor_role)}</span></td><td>${escapeHtml(a.action)}</td><td>${escapeHtml(a.resource_type)}<br><code>${escapeHtml(a.resource_id || "—")}</code></td><td>${badge(a.result)}</td><td>${escapeHtml(a.detail || "—")}</td></tr>`);
  return card("Audit Log", `<div class="toolbar"><div class="inline"><input placeholder="Trace · Actor · Resource"><select><option>전체 결과</option><option>SUCCEEDED</option><option>WARN</option></select></div><button class="button secondary" data-demo="audit-export">CSV Export</button></div>${table(["시각", "Trace", "Actor", "Action", "Resource", "결과", "상세"], rows)}`);
}

function renderHealth() {
  const services = [["Portal Web", "UP", "18 ms", "Local demo server"], ["SQLite DB", "UP", "4 ms", "Foreign key enabled"], ["LLM Agent", "DEMO", "결정적 응답", "외부 호출 없음"], ["Company Copilot", "NOT_CONNECTED", "—", "향후 사내 연동"], ["Data Analysis API", "NOT_CONNECTED", "—", "정기 파일 업로드 대체"]];
  return `${card("System Health", `<div class="health-grid">${services.map((r) => `<article><span class="status-dot ${r[1] !== "UP" ? "muted-dot" : ""}"></span><div><strong>${r[0]}</strong><span>${r[3]}</span></div><div>${badge(r[1])}<small>${r[2]}</small></div></article>`).join("")}</div>`)}${card("Feature Flag · Fallback", `<div class="permission-grid"><div><strong>agent.draft.enabled</strong><span>${badge("ON")}</span></div><div><strong>copilot.connector.enabled</strong><span>${badge("OFF")}</span></div><div><strong>manual.workflow.enabled</strong><span>${badge("ON")}</span></div><div><strong>snapshot.api.enabled</strong><span>${badge("OFF")}</span></div></div><div class="notice"><strong>Agent 장애 시에도 수동 작성·제출·승인 Workflow는 유지합니다.</strong></div>`)}`;
}

function renderGeneric(screen) {
  return `${card(screen.title, `<div class="empty-state"><strong>${escapeHtml(screen.screen_id)} 시연 화면</strong><p>${escapeHtml(screen.purpose)}</p><button class="button primary" data-demo="generic">${escapeHtml(screen.primary_action)}</button></div>`)}${card("화면 정의", `<dl class="detail-grid"><div><dt>주요 데이터</dt><dd>${escapeHtml(screen.main_data)}</dd></div><div><dt>AI 기능</dt><dd>${escapeHtml(screen.ai_function)}</dd></div><div><dt>검증·통제</dt><dd>${escapeHtml(screen.control_rule)}</dd></div><div><dt>완료조건</dt><dd>${escapeHtml(screen.done_condition)}</dd></div></dl>`)}`;
}

async function generateDraft() {
  const button = $("#primary-action");
  if (button) button.disabled = true;
  showToast("선택한 WorkItem·Snapshot·Evidence로 초안을 생성 중입니다.");
  try {
    const result = await api("/api/agent/draft", { method: "POST", body: JSON.stringify({ role: state.role, screen_id: currentScreen().screen_id }) });
    state.generatedDraft = result.content;
    await refreshCurrent();
    if (state.role === "MEMBER" && currentScreen().screen_id === "MBR-06") navigateTo("MBR-07");
    if (state.role === "LEADER" && currentScreen().screen_id === "LDR-04") navigateTo("LDR-05");
    const editor = $("#report-editor");
    if (editor) editor.value = result.content;
    showToast(`AI 초안을 생성했습니다. Citation ${result.citations.length}건 · ${result.trace_id}`);
  } catch (error) { showToast(error.message, true); }
  finally { if (button) button.disabled = false; }
}

async function handleQuestion(event) {
  event.preventDefault();
  const question = $("#question-input").value.trim();
  if (!question) return;
  showToast("승인 보고와 근거를 검색하고 있습니다.");
  try {
    state.lastAnswer = await api("/api/agent/ask", { method: "POST", body: JSON.stringify({ role: state.role, question }) });
    renderScreen();
  } catch (error) { showToast(error.message, true); }
}

function openConfirmation(action) {
  const [title, message] = confirmCopy[action] || ["상태 변경 확인", "선택한 동작을 실행합니다."];
  state.pendingAction = action;
  $("#confirm-title").textContent = title;
  $("#confirm-message").textContent = message;
  $("#confirm-role").textContent = `${state.data.principal.role_label} · ${state.data.principal.display_name}`;
  $("#confirm-screen").textContent = `${currentScreen().screen_id} · ${currentScreen().title}`;
  $("#confirm-dialog").showModal();
}

async function executePendingAction() {
  const action = state.pendingAction;
  if (!action) return;
  state.pendingAction = null;
  $("#confirm-dialog").close();
  showToast("상태 변경과 감사 기록을 처리 중입니다.");
  try {
    const result = await api("/api/action", { method: "POST", body: JSON.stringify({ action, role: state.role }) });
    await refreshCurrent();
    showToast(`${result.message} · ${result.trace_id}`);
  } catch (error) { showToast(error.message, true); }
}

async function refreshCurrent() {
  const screenId = currentScreen()?.screen_id;
  const draft = state.generatedDraft;
  const answer = state.lastAnswer;
  const data = await api(`/api/bootstrap?role=${encodeURIComponent(state.role)}`);
  state.data = data;
  state.screenIndex = Math.max(0, data.screens.findIndex((screen) => screen.screen_id === screenId));
  state.generatedDraft = draft;
  state.lastAnswer = answer;
  renderPrincipal(); renderScreen();
}

function showToast(message, error = false) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.toggle("error", error);
  toast.hidden = false;
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => { toast.hidden = true; }, 4300);
}

function openSpec() {
  const screen = currentScreen();
  $("#spec-id").textContent = screen.screen_id;
  $("#spec-title").textContent = screen.title;
  $("#spec-purpose").textContent = screen.purpose;
  $("#spec-data").textContent = screen.main_data;
  $("#spec-ai").textContent = screen.ai_function;
  $("#spec-rule").textContent = screen.control_rule;
  $("#spec-done").textContent = screen.done_condition;
  $("#spec-dialog").showModal();
}

function navigateTo(screenId) {
  const index = state.data.screens.findIndex((screen) => screen.screen_id === screenId);
  if (index < 0) return false;
  state.screenIndex = index;
  renderScreen();
  window.scrollTo({ top: 0, behavior: "smooth" });
  return true;
}

function handlePrimaryAction() {
  const screen = currentScreen();
  if (screen.screen_id === "MBR-07") { generateDraft(); return; }
  if (actionMap[screen.screen_id]) { openConfirmation(actionMap[screen.screen_id]); return; }
  if (navTargets[screen.screen_id] && navigateTo(navTargets[screen.screen_id])) return;
  showToast(`${screen.primary_action}: 시연용 화면에서 입력·미리보기를 확인했습니다.`);
}

$("#screen-nav").addEventListener("click", (event) => {
  const button = event.target.closest("[data-screen-index]");
  if (!button) return;
  state.screenIndex = Number(button.dataset.screenIndex);
  state.lastAnswer = null;
  renderScreen();
  window.scrollTo({ top: 0, behavior: "smooth" });
});

$("#screen-body").addEventListener("click", (event) => {
  const draftButton = event.target.closest("[data-generate-draft]");
  if (draftButton) { generateDraft(); return; }
  const actionButton = event.target.closest("[data-action]");
  if (actionButton && !actionButton.disabled) { openConfirmation(actionButton.dataset.action); return; }
  const questionButton = event.target.closest("[data-question]");
  if (questionButton) { const input = $("#question-input"); if (input) input.value = questionButton.dataset.question; return; }
  const demoButton = event.target.closest("[data-demo]");
  if (demoButton) showToast("시연 입력을 반영했습니다. 실제 운영에서는 저장 전 Schema·권한·보안 검사를 수행합니다.");
});

$("#role-select").addEventListener("change", (event) => loadRole(event.target.value));
$("#open-spec").addEventListener("click", openSpec);
$("#primary-action").addEventListener("click", handlePrimaryAction);
$("#confirm-submit").addEventListener("click", (event) => { event.preventDefault(); executePendingAction(); });
$("#reset-demo").addEventListener("click", async () => {
  if (!window.confirm("모든 시연 데이터를 최초 상태로 되돌릴까요?")) return;
  try {
    const result = await api("/api/reset", { method: "POST", body: "{}" });
    state.generatedDraft = null; state.lastAnswer = null;
    await loadRole(state.role, currentScreen()?.screen_id);
    showToast(result.message);
  } catch (error) { showToast(error.message, true); }
});

loadRole(state.role);
