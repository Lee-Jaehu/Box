"use strict";

/* Offline fixture used when index.html is opened directly or the local server is unavailable. */
(function () {
  const clone = (value) => JSON.parse(JSON.stringify(value));
  const screen = (screen_id, role_code, display_order, title, kind, purpose, primary_action) => ({
    screen_id, role_code, display_order, title, kind, purpose, primary_action,
    ai_function: "업무 맥락·근거를 기준으로 요약·추천·검사 결과를 설명한다.",
    main_data: "Role Scope, Reporting Cycle, WorkItem, Snapshot, Evidence, Report Version",
    control_rule: "사람 확인, 권한 범위, 원문 보존, 수치·출처 검증을 적용한다.",
    done_condition: `${title} 처리 결과와 감사 이력을 저장한다.`,
  });

  const screens = [
    screen("COM-01", "COMMON", 1, "SSO 로그인", "login", "회사 계정으로 인증하고 Portal Principal을 생성한다.", "회사 계정으로 로그인"),
    screen("COM-02", "COMMON", 2, "역할·조직 선택", "context", "복수 역할 사용자가 현재 업무 범위를 선택한다.", "선택 범위로 시작"),
    screen("COM-03", "COMMON", 3, "통합 업무함", "inbox", "제출·검토·승인·오류를 한곳에서 확인한다.", "선택 업무 처리"),
    screen("COM-04", "COMMON", 4, "통합 검색", "search", "권한 범위의 업무·보고·KPI·근거를 찾는다.", "검색 결과 열기"),
    screen("COM-05", "COMMON", 5, "알림·마감", "notifications", "마감·반려·정정·Action 지연을 확인한다.", "관련 화면 이동"),

    screen("MBR-01", "MEMBER", 1, "팀원 홈", "dashboard", "이번 주 기록·제출상태와 우선업무를 본다.", "금주 업무 작성"),
    screen("MBR-02", "MEMBER", 2, "내 WorkItem 목록", "worklist", "담당업무 목표·상태·KPI·협업을 관리한다.", "WorkItem 생성"),
    screen("MBR-03", "MEMBER", 3, "WorkItem 상세", "detail", "업무 목표·이력·KPI·협업·Action을 본다.", "상태·계획 수정"),
    screen("MBR-04", "MEMBER", 4, "Worklog 빠른 기록", "entry", "사실·결과·분석·계획·Risk를 기록한다.", "기록 저장"),
    screen("MBR-05", "MEMBER", 5, "Evidence 업로드", "uploadEvidence", "업무파일을 증빙으로 등록한다.", "파일 업로드"),
    screen("MBR-06", "MEMBER", 6, "금주 실적 선택", "selection", "주간보고에 포함할 업무를 선택한다.", "선택항목으로 초안 생성"),
    screen("MBR-07", "MEMBER", 7, "AI 초안 편집", "memberEditor", "구조화된 주간실적 초안을 검토한다.", "AI 초안 생성·확정"),
    screen("MBR-08", "MEMBER", 8, "제출·반려 이력", "submission", "팀장 제출과 반려·재제출 Version을 관리한다.", "팀장에게 제출"),

    screen("LDR-01", "LEADER", 1, "팀장 홈", "dashboard", "팀 제출률·KPI·미검토·마감을 확인한다.", "팀 보고 시작"),
    screen("LDR-02", "LEADER", 2, "팀원 제출 현황", "submissionMatrix", "팀원별 제출·반려·미제출 상태를 관리한다.", "제출본 열기"),
    screen("LDR-03", "LEADER", 3, "팀원 제출 상세", "memberDetail", "팀원 원문·AI초안·Evidence·Snapshot을 검토한다.", "포함 또는 반려"),
    screen("LDR-04", "LEADER", 4, "실적 포함·제외", "selectionLeader", "팀보고에 사용할 업무를 선별한다.", "선택 확정"),
    screen("LDR-05", "LEADER", 5, "팀장 서술형 보고", "leaderEditor", "서술형 설명을 유지하고 ID·근거·상태를 보강한다.", "담당에게 승인 제출"),
    screen("LDR-06", "LEADER", 6, "KPI·근거 대조", "compareEvidence", "보고문장과 Snapshot·Evidence를 대조한다.", "검증결과 반영"),
    screen("LDR-07", "LEADER", 7, "반려·승인 확인", "approve", "반려 또는 담당제출 상태변경을 확인한다.", "반려 또는 승인 제출"),
    screen("LDR-08", "LEADER", 8, "팀 보고 Version 이력", "history", "AI·팀장수정·승인본을 비교한다.", "Version 비교"),

    screen("DPT-01", "DEPT", 1, "담당 홈", "dashboard", "팀별 승인상태·성과·KPI·Risk를 본다.", "담당 보고 시작"),
    screen("DPT-02", "DEPT", 2, "팀 보고 Matrix", "teamMatrix", "하위 팀보고를 비교한다.", "팀 보고 상세 열기"),
    screen("DPT-03", "DEPT", 3, "협업 안건 묶음", "collaboration", "같은 Collaboration과 팀별 기여를 묶는다.", "묶음 확정"),
    screen("DPT-04", "DEPT", 4, "KPI·주장 충돌", "conflict", "Snapshot Version과 해석충돌을 조정한다.", "해결방식 기록"),
    screen("DPT-05", "DEPT", 5, "담당 보고 초안", "deptEditor", "담당 관점의 결과·병목·요청으로 재구성한다.", "담당본 확정"),
    screen("DPT-06", "DEPT", 6, "Risk·Decision Register", "decisionRegister", "담당 Risk·Decision·Action을 관리한다.", "Decision 요청 등록"),
    screen("DPT-07", "DEPT", 7, "기획 제출·승인 이력", "approve", "기획제출 전 QA와 이력을 확인한다.", "기획팀에 승인 제출"),

    screen("PLN-01", "PLANNING", 1, "그룹 보고 준비현황", "dashboard", "4개 담당 승인·보완·지연상태를 본다.", "QA 시작"),
    screen("PLN-02", "PLANNING", 2, "QA Issue 목록", "qa", "KPI·출처·협업·잠정·보안·Action을 점검한다.", "Issue 해소 요청"),
    screen("PLN-03", "PLANNING", 3, "그룹 보고 구성", "groupEditor", "그룹장 관점의 KPI·성과·병목·Decision으로 구성한다.", "그룹 초안 확정"),
    screen("PLN-04", "PLANNING", 4, "민감정보·외부공유", "redaction", "보고대상에 맞게 민감정보 제외후보를 검토한다.", "제외안 적용"),
    screen("PLN-05", "PLANNING", 5, "Decision·Action 통합", "decisionRegister", "Decision과 미종결 Action을 정리한다.", "그룹장 요청 확정"),
    screen("PLN-06", "PLANNING", 6, "그룹장 보고 확정", "approve", "QA결과와 예외를 확인해 그룹장보고를 확정한다.", "그룹장 보고 확정 요청"),
    screen("PLN-07", "PLANNING", 7, "보고 이력·Export", "export", "주차별 확정본과 산출물을 관리한다.", "확정본 Export"),

    screen("HED-01", "HEAD", 1, "그룹장 Overview", "dashboard", "그룹 KPI·대표성과·Risk·Decision을 본다.", "담당 상세 확인"),
    screen("HED-02", "HEAD", 2, "담당별 Drill-down", "memberDetail", "4개 담당성과와 팀기여를 내려본다.", "업무 근거 열기"),
    screen("HED-03", "HEAD", 3, "문장·수치 근거", "evidence", "보고문장을 원천까지 추적한다.", "원문 위치 확인"),
    screen("HED-04", "HEAD", 4, "보고 Q&A Agent", "question", "자연어 질문에 승인 근거로 답한다.", "근거 기반 질문"),
    screen("HED-05", "HEAD", 5, "Decision 확정", "decision", "의사결정을 검토하고 Action으로 연결한다.", "결정·Action 확정"),
    screen("HED-06", "HEAD", 6, "Action·주차 Trend", "trend", "Action 이행과 KPI 주차변화를 추적한다.", "지연 Action 점검"),

    screen("DAT-01", "DATA_OWNER", 1, "Snapshot 운영현황", "dashboard", "Metric별 업로드·검증·승인상태를 본다.", "새 Snapshot 업로드"),
    screen("DAT-02", "DATA_OWNER", 2, "KPI 파일 업로드", "snapshotUpload", "기준일 원천파일을 업로드한다.", "파일 업로드 완료"),
    screen("DAT-03", "DATA_OWNER", 3, "컬럼·차원 매핑", "mapping", "컬럼을 Metric·공장·라인·제품과 매핑한다.", "매핑 저장·검증"),
    screen("DAT-04", "DATA_OWNER", 4, "Validation 결과", "validation", "중복·누락·단위·급변오류를 처리한다.", "재검증"),
    screen("DAT-05", "DATA_OWNER", 5, "전주·정정 비교", "snapshotCompare", "현재와 이전 Snapshot을 비교한다.", "변동 사유 기록"),
    screen("DAT-06", "DATA_OWNER", 6, "승인·잠금", "snapshotApprove", "공식 Snapshot을 최종승인한다.", "Snapshot 승인·잠금"),
    screen("DAT-07", "DATA_OWNER", 7, "Metric Catalog", "catalog", "KPI 공식정의와 파일계약을 관리한다.", "Metric 정의 저장"),

    screen("ADM-01", "ADMIN", 1, "운영 Dashboard", "dashboard", "사용현황·오류·마감·연동상태를 본다.", "운영 이슈 열기"),
    screen("ADM-02", "ADMIN", 2, "조직·사용자·역할", "iam", "조직계층과 역할·대리권한을 관리한다.", "권한 변경 요청"),
    screen("ADM-03", "ADMIN", 3, "보고 Calendar", "calendar", "단계별 마감과 휴일예외를 설정한다.", "보고주차 개시"),
    screen("ADM-04", "ADMIN", 4, "Template·Prompt·Model", "release", "양식과 Prompt·Model을 평가 후 배포한다.", "승인 Version 배포"),
    screen("ADM-05", "ADMIN", 5, "권한·보안 Policy", "policy", "권한정책과 Agent Tool Allowlist를 관리한다.", "정책 변경 검토"),
    screen("ADM-06", "ADMIN", 6, "Audit Log", "audit", "조회·AI·제출·승인·권한변경을 추적한다.", "감사 이벤트 조회"),
    screen("ADM-07", "ADMIN", 7, "System Health·Feature Flag", "health", "Portal·DB·LLM·Copilot 상태를 관리한다.", "기능 Flag 변경"),
  ];

  const principals = {
    COMMON: ["u_member1", "김현수", "공통 사용자", "RSND자동보정팀"],
    MEMBER: ["u_member1", "김현수", "팀원", "RSND자동보정팀"],
    LEADER: ["u_leader", "이선우", "팀장", "RSND자동보정팀"],
    DEPT: ["u_dept", "김도윤", "담당", "자동보정담당"],
    PLANNING: ["u_planning", "최은서", "기획팀", "제조DX기획팀"],
    HEAD: ["u_head", "그룹장 사용자", "그룹장", "제조DX그룹"],
    DATA_OWNER: ["u_data", "데이터 운영자", "KPI Data Owner", "품질DX담당"],
    ADMIN: ["u_admin", "시스템 운영자", "운영자", "제조DX기획팀"],
  };

  const initial = {
    cycle: {
      id: "cycle_w34", cycle_code: "2026-W34", year: 2026, week: 34, state: "OPEN",
      snapshot_due_at: "2026-08-24T10:00:00+09:00", member_due_at: "2026-08-25T17:00:00+09:00",
      leader_due_at: "2026-08-26T12:00:00+09:00", department_due_at: "2026-08-26T17:00:00+09:00",
      planning_due_at: "2026-08-27T12:00:00+09:00",
    },
    snapshots: [
      { id: "snp_yield_w34", snapshot_code: "SNP-YIELD-2026-W34-003", metric_code: "YIELD_RATE", metric_name: "수율", unit: "%", display_value: 92.4, previous_value: 91.8, target_value: 94.0, cutoff_at: "2026-08-23T23:59:00+09:00", status: "LOCKED", verification_state: "VERIFIED", source_file: "Yield_2026W34_0823.xlsx", version: 3, validation_errors: 0, validation_warnings: 0 },
      { id: "snp_bm_w34", snapshot_code: "SNP-BM-2026-W34-002", metric_code: "BM_LOSS", metric_name: "BM Loss", unit: "%", display_value: 6.8, previous_value: 7.0, target_value: 6.0, cutoff_at: "2026-08-23T23:59:00+09:00", status: "LOCKED", verification_state: "VERIFIED", source_file: "BM_Loss_2026W34_0823.xlsx", version: 2, validation_errors: 0, validation_warnings: 0 },
      { id: "snp_pd_w34", snapshot_code: "SNP-PD-2026-W34-004", metric_code: "PD_LOSS", metric_name: "PD Loss", unit: "%", display_value: 1.2, previous_value: 1.5, target_value: 1.0, cutoff_at: "2026-08-23T23:59:00+09:00", status: "VALIDATION_FAILED", verification_state: "PROVISIONAL", source_file: "PD_Loss_2026W34_0823.xlsx", version: 4, validation_errors: 1, validation_warnings: 1 },
      { id: "snp_defect_w34", snapshot_code: "SNP-DEFECT-2026-W34-002", metric_code: "DEFECT_RATE", metric_name: "불량률", unit: "%", display_value: 0.7, previous_value: 0.8, target_value: 0.6, cutoff_at: "2026-08-23T23:59:00+09:00", status: "LOCKED", verification_state: "VERIFIED", source_file: "Defect_2026W34_0823.xlsx", version: 2, validation_errors: 0, validation_warnings: 0 },
    ],
    work_items: [
      { id: "wi_rsnd_32", work_item_code: "WI-RSND-2026-0032", organization_id: "team_rsnd", owner_user_id: "u_member1", collaboration_id: "col_yield", collaboration_code: "COL-YIELD-2026-0014", organization_name: "RSND자동보정팀", owner_name: "김현수", title: "Lami Jamming 자동보정 조건 검증", objective: "제품별 적용 조건과 예외조건 확정", state: "IN_PROGRESS", start_date: "2026-08-03", target_date: "2026-08-27", metric_code: "PD_LOSS", security_label: "CONFIDENTIAL" },
      { id: "wi_rsnd_38", work_item_code: "WI-RSND-2026-0038", organization_id: "team_rsnd", owner_user_id: "u_member2", collaboration_id: "col_yield", collaboration_code: "COL-YIELD-2026-0014", organization_name: "RSND자동보정팀", owner_name: "박은지", title: "ESWA L07 PD Loss 개선 로직 적용", objective: "동일 조건 반복 검증 후 효과 확정", state: "IN_PROGRESS", start_date: "2026-08-10", target_date: "2026-08-28", metric_code: "PD_LOSS", security_label: "CONFIDENTIAL" },
      { id: "wi_rsnd_41", work_item_code: "WI-RSND-2026-0041", organization_id: "team_rsnd", owner_user_id: "u_member3", collaboration_id: "col_yield", collaboration_code: "COL-YIELD-2026-0014", organization_name: "RSND자동보정팀", owner_name: "이정훈", title: "FDC 진단 결과 연계", objective: "장력 편차와 Jamming 발생시점 연계 검증", state: "IN_PROGRESS", start_date: "2026-08-17", target_date: "2026-08-31", metric_code: "PD_LOSS", security_label: "CONFIDENTIAL" },
      { id: "wi_rsnd_45", work_item_code: "WI-RSND-2026-0045", organization_id: "team_rsnd", owner_user_id: "u_member1", collaboration_id: null, collaboration_code: null, organization_name: "RSND자동보정팀", owner_name: "김현수", title: "차주 자동보정 조건 사전 검토", objective: "W35 적용 후보 검토", state: "PLANNED", start_date: "2026-08-24", target_date: "2026-09-04", metric_code: "PD_LOSS", security_label: "INTERNAL" },
      { id: "wi_elc_12", work_item_code: "WI-ELC-2026-0012", organization_id: "team_electrode", owner_user_id: "u_member2", collaboration_id: "col_bm", collaboration_code: "COL-BM-2026-0007", organization_name: "전극자동보정팀", owner_name: "박은지", title: "코터 로딩량 편차 보정 확대", objective: "좌우 편차 보정 대상 확대", state: "IN_PROGRESS", start_date: "2026-08-01", target_date: "2026-08-30", metric_code: "BM_LOSS", security_label: "CONFIDENTIAL" },
      { id: "wi_asm_19", work_item_code: "WI-ASM-2026-0019", organization_id: "team_assembly", owner_user_id: "u_member3", collaboration_id: "col_pd", collaboration_code: "COL-PD-2026-0011", organization_name: "조립자동보정팀", owner_name: "이정훈", title: "주액기 보정 파라미터 적용", objective: "PD Loss 저감 로직 적용", state: "IN_PROGRESS", start_date: "2026-08-05", target_date: "2026-08-29", metric_code: "PD_LOSS", security_label: "CONFIDENTIAL" },
    ],
    worklogs: [
      { id: "wl1", work_item_id: "wi_rsnd_32", author_user_id: "u_member1", author_name: "김현수", work_item_code: "WI-RSND-2026-0032", occurred_on: "2026-08-20", entry_type: "RESULT", narrative: "M08과 M11 제품 반복 시험에서 동일 경향을 확인하였다." },
      { id: "wl2", work_item_id: "wi_rsnd_32", author_user_id: "u_member1", author_name: "김현수", work_item_code: "WI-RSND-2026-0032", occurred_on: "2026-08-21", entry_type: "ANALYSIS", narrative: "K12는 생산 조건이 달라 재현성 검증이 추가로 필요하다." },
      { id: "wl3", work_item_id: "wi_rsnd_32", author_user_id: "u_member1", author_name: "김현수", work_item_code: "WI-RSND-2026-0032", occurred_on: "2026-08-22", entry_type: "NEXT", narrative: "8월 27일까지 K12 재현성 검증 후 적용 여부를 확정한다." },
      { id: "wl4", work_item_id: "wi_rsnd_32", author_user_id: "u_member1", author_name: "김현수", work_item_code: "WI-RSND-2026-0032", occurred_on: "2026-08-23", entry_type: "RISK", narrative: "검증용 생산 일정이 미확정되어 완료 일정이 지연될 수 있다." },
      { id: "wl5", work_item_id: "wi_rsnd_38", author_user_id: "u_member2", author_name: "박은지", work_item_code: "WI-RSND-2026-0038", occurred_on: "2026-08-22", entry_type: "RESULT", narrative: "ESWA L07 적용 구간의 PD Loss 감소 경향을 확인하였다." },
      { id: "wl6", work_item_id: "wi_rsnd_41", author_user_id: "u_member3", author_name: "이정훈", work_item_code: "WI-RSND-2026-0041", occurred_on: "2026-08-23", entry_type: "ANALYSIS", narrative: "FDC 장력 편차 구간과 Jamming 발생 시점의 상관성을 검토 중이다." },
    ],
    evidence: [
      { id: "ev1", evidence_code: "EVD-RSND-2026-W34-028", work_item_id: "wi_rsnd_32", work_item_code: "WI-RSND-2026-0032", file_name: "Jamming_보정조건_검증표.xlsx", content_type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", sha256: "1111111111111111111111111111111111111111111111111111111111111111", locator: "Result!B4:H18", scan_status: "CLEAN", security_label: "CONFIDENTIAL" },
      { id: "ev2", evidence_code: "EVD-RSND-2026-W34-029", work_item_id: "wi_rsnd_32", work_item_code: "WI-RSND-2026-0032", file_name: "K12_시험조건_비교.pdf", content_type: "application/pdf", sha256: "2222222222222222222222222222222222222222222222222222222222222222", locator: "p.3-5", scan_status: "CLEAN", security_label: "CONFIDENTIAL" },
      { id: "ev3", evidence_code: "EVD-RSND-2026-W34-031", work_item_id: "wi_rsnd_38", work_item_code: "WI-RSND-2026-0038", file_name: "ESWA_L07_적용결과.xlsx", content_type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", sha256: "3333333333333333333333333333333333333333333333333333333333333333", locator: "Result!B4:H18", scan_status: "CLEAN", security_label: "CONFIDENTIAL" },
    ],
    submissions: [
      { id: "sub_member1", submission_code: "SUB-RSND-2026-W34-001", member_user_id: "u_member1", member_name: "김현수", organization_name: "RSND자동보정팀", status: "AI_DRAFTED", version: 2, submitted_at: null },
      { id: "sub_member2", submission_code: "SUB-RSND-2026-W34-002", member_user_id: "u_member2", member_name: "박은지", organization_name: "RSND자동보정팀", status: "SUBMITTED", version: 1, submitted_at: "2026-08-24T09:20:00+09:00" },
      { id: "sub_member3", submission_code: "SUB-RSND-2026-W34-003", member_user_id: "u_member3", member_name: "이정훈", organization_name: "RSND자동보정팀", status: "SUBMITTED", version: 1, submitted_at: "2026-08-24T09:32:00+09:00" },
    ],
    reports: [
      { id: "rpt_team", report_code: "RPT-TEAM-RSND-2026-W34", report_level: "TEAM", organization_name: "RSND자동보정팀", status: "DRAFT", current_version: 1, content: "[WI-RSND-2026-0032][RESULT] ESWA L07 Lami Jamming 자동보정 조건을 검증하였다. 대상 3개 제품 중 M08과 M11은 반복 시험에서 동일 경향을 확인했으며 K12는 추가 검증이 필요하다.\n\n[SNP-PD-2026-W34-004][KPI][PROVISIONAL] W34 PD Loss는 1.2%로 전주 1.5% 대비 감소했으나 Data Owner 승인 전 잠정값이다.\n\n[COL-YIELD-2026-0014][ANALYSIS] FDC 장력 편차 구간과 Jamming 발생 시점의 상관성을 공동 검증 중이며 원인으로 확정하지 않았다.\n\n[DEC-RSND-2026-0008][DECISION] K12 검증 생산 일정 우선 배정이 필요하다.", source_manifest: "WI-RSND-2026-0032,SNP-PD-2026-W34-004,EVD-RSND-2026-W34-028,COL-YIELD-2026-0014" },
      { id: "rpt_dept", report_code: "RPT-DEPT-AUTO-2026-W34", report_level: "DEPARTMENT", organization_name: "자동보정담당", status: "DRAFT", current_version: 1, content: "자동보정담당은 Jamming 보정 조건과 코터 로딩량 편차, 주액기 파라미터 적용을 추진하였다. 협업 안건은 COL-YIELD-2026-0014 등 3개로 묶어 관리한다.", source_manifest: "RPT-TEAM-RSND-2026-W34,COL-YIELD-2026-0014" },
      { id: "rpt_group", report_code: "RPT-GROUP-DX-2026-W34", report_level: "GROUP", organization_name: "제조DX그룹", status: "PLANNING_QA", current_version: 1, content: "W34 수율은 92.4%, BM Loss는 6.8%, PD Loss는 1.2% 잠정이다. 자동보정 Jamming 조건은 3개 제품 중 2개 검증을 완료했으며 K12 생산 일정 결정이 필요하다.", source_manifest: "SNP-YIELD-2026-W34-003,SNP-BM-2026-W34-002,SNP-PD-2026-W34-004,DEC-RSND-2026-0008" },
    ],
    collaborations: [
      { id: "col_yield", collaboration_code: "COL-YIELD-2026-0014", title: "Lami Jamming 공동 대응", goal: "FDC 이상감지부터 자동보정·품질검증·추적까지 연결", lead_organization: "FDC DX담당", status: "ACTIVE", target_date: "2026-08-31" },
      { id: "col_bm", collaboration_code: "COL-BM-2026-0007", title: "설비 BM Loss 공동 개선", goal: "상태감지와 보정조건을 연계하여 BM Loss 감소", lead_organization: "FDC DX담당", status: "ACTIVE", target_date: "2026-09-15" },
      { id: "col_pd", collaboration_code: "COL-PD-2026-0011", title: "주액기 PD Loss 개선", goal: "PLC 로직과 자동보정 파라미터 공동 검증", lead_organization: "자동보정담당", status: "ACTIVE", target_date: "2026-09-05" },
    ],
    participants: [
      { collaboration_id: "col_yield", organization_name: "FDC DX담당", contribution: "장력 편차 구간 탐지 및 이상시점 제공" },
      { collaboration_id: "col_yield", organization_name: "자동보정담당", contribution: "제품별 보정 상·하한과 예외조건 검증" },
      { collaboration_id: "col_yield", organization_name: "품질DX담당", contribution: "불량 유형과 품질 판정 결과 검증" },
      { collaboration_id: "col_yield", organization_name: "제조DX솔루션담당", contribution: "Roll·Cell·공정 이력 연결" },
      { collaboration_id: "col_bm", organization_name: "FDC DX담당", contribution: "설비 이상패턴 탐지" },
      { collaboration_id: "col_bm", organization_name: "자동보정담당", contribution: "보정 적용 조건 검증" },
      { collaboration_id: "col_pd", organization_name: "자동보정담당", contribution: "주액기 보정 파라미터 적용" },
      { collaboration_id: "col_pd", organization_name: "품질DX담당", contribution: "PD 효과 판정" },
    ],
    qa_issues: [
      { id: "qa1", resource_type: "METRIC_SNAPSHOT", resource_id: "snp_pd_w34", rule_code: "DUPLICATE_KEY", severity: "BLOCK", message: "ESWA L03 K12 W34 Key가 중복되었습니다.", remediation: "원천 파일의 284행과 285행을 확인한 후 재업로드하십시오.", status: "OPEN" },
      { id: "qa2", resource_type: "METRIC_SNAPSHOT", resource_id: "snp_pd_w34", rule_code: "LARGE_CHANGE", severity: "WARN", message: "ESWA L07 M08 PD Loss가 0.8%에서 2.4%로 급변했습니다.", remediation: "Data Owner가 변동 사유를 확인하십시오.", status: "OPEN" },
      { id: "qa3", resource_type: "REPORT", resource_id: "rpt_group", rule_code: "PROVISIONAL_LABEL", severity: "WARN", message: "잠정 PD Loss가 확정값처럼 표현된 문장 2건이 있습니다.", remediation: "PROVISIONAL 상태를 문장에 표시하십시오.", status: "OPEN" },
      { id: "qa4", resource_type: "REPORT", resource_id: "rpt_group", rule_code: "MISSING_EVIDENCE", severity: "BLOCK", message: "활성화자동보정 CTQ 결과의 Evidence가 없습니다.", remediation: "승인 가능한 Evidence를 연결하거나 보고에서 제외하십시오.", status: "OPEN" },
    ],
    decisions: [
      { id: "dec1", decision_code: "DEC-RSND-2026-0008", title: "K12 검증 생산 일정 배정", request: "K12 제품 자동보정 검증을 위한 생산 일정 우선 배정이 필요하다.", status: "REQUESTED", decision_maker: "그룹장 사용자", due_date: "2026-08-25", resolution: null },
      { id: "dec2", decision_code: "DEC-FDC-2026-0005", title: "품질 판정 연계 우선순위", request: "FDC 결과와 품질 판정 연계 일정 확정이 필요하다.", status: "REQUESTED", decision_maker: "그룹장 사용자", due_date: "2026-08-27", resolution: null },
    ],
    action_items: [
      { id: "act1", action_code: "ACT-FDC-2026-0044", title: "품질 판정 결과 연계", owner_name: "이정훈", due_date: "2026-08-27", status: "IN_PROGRESS", priority: "HIGH" },
      { id: "act2", action_code: "ACT-SOL-2026-0031", title: "Trace 누락 구간 보완", owner_name: "박은지", due_date: "2026-08-26", status: "DELAYED", priority: "MEDIUM" },
    ],
    audit_events: [
      { id: 1, occurred_at: "2026-08-24T08:55:00+09:00", trace_id: "TRACE-SEED-001", actor_name: "데이터 운영자", actor_role: "DATA_OWNER", action: "UPLOAD", resource_type: "METRIC_SNAPSHOT", resource_id: "snp_pd_w34", result: "SUCCEEDED", detail: "PD Loss W34 파일 업로드" },
      { id: 2, occurred_at: "2026-08-24T09:40:00+09:00", trace_id: "TRACE-SEED-002", actor_name: "이선우", actor_role: "LEADER", action: "GENERATE_DRAFT", resource_type: "REPORT", resource_id: "rpt_team", result: "SUCCEEDED", detail: "팀장 서술형 초안 생성" },
      { id: 3, occurred_at: "2026-08-24T10:00:00+09:00", trace_id: "TRACE-SEED-003", actor_name: "최은서", actor_role: "PLANNING", action: "RUN_QA", resource_type: "REPORT", resource_id: "rpt_group", result: "WARN", detail: "그룹 보고 QA 경고 2, 차단 1" },
    ],
  };

  let runtime = clone(initial);

  const draftText = "[WI-RSND-2026-0032][RESULT] ESWA L07 Lami Jamming 자동보정 조건을 검증하였다. 대상 3개 제품 중 M08과 M11은 반복 시험에서 동일 경향을 확인했으며 K12는 추가 검증이 필요하다. [EVD-RSND-2026-W34-028]\n\n[SNP-PD-2026-W34-004][KPI][PROVISIONAL] W34 PD Loss는 1.2%로 전주 1.5% 대비 감소했으나 Data Owner 최종 승인 전 잠정값이다.\n\n[COL-YIELD-2026-0014][ANALYSIS] FDC 장력 편차 구간과 Jamming 발생 시점의 상관성을 공동 검증 중이며 원인으로 확정하지 않았다.\n\n[DEC-RSND-2026-0008][DECISION] K12 검증 생산 일정 우선 배정이 필요하다.";

  function traceId() {
    return `TRACE-OFFLINE-${Math.random().toString(16).slice(2, 12).toUpperCase()}`;
  }

  function addAudit(role, action, resourceType, resourceId, detail) {
    const p = principals[role] || principals.MEMBER;
    runtime.audit_events.unshift({
      id: Date.now(), occurred_at: new Date().toISOString(), trace_id: traceId(), actor_name: p[1], actor_role: role,
      action, resource_type: resourceType, resource_id: resourceId, result: "SUCCEEDED", detail,
    });
  }

  function scopedWork(role) {
    if (role === "MEMBER") return runtime.work_items.filter((item) => item.owner_user_id === "u_member1");
    if (role === "LEADER") return runtime.work_items.filter((item) => item.organization_id === "team_rsnd");
    if (role === "DEPT") return runtime.work_items.filter((item) => ["team_rsnd", "team_electrode", "team_assembly", "team_activation"].includes(item.organization_id));
    return runtime.work_items;
  }

  function bootstrap(role) {
    const selectedRole = principals[role] ? role : "MEMBER";
    const p = principals[selectedRole];
    const items = scopedWork(selectedRole);
    const counts = {
      screens: screens.filter((item) => item.role_code === selectedRole).length,
      snapshots_locked: runtime.snapshots.filter((item) => item.status === "LOCKED").length,
      snapshots_total: runtime.snapshots.length,
      work_items: items.length,
      open_qa: runtime.qa_issues.filter((item) => item.status === "OPEN").length,
      open_decisions: runtime.decisions.filter((item) => item.status !== "RESOLVED").length,
      submitted_members: runtime.submissions.filter((item) => ["SUBMITTED", "ACCEPTED", "LOCKED"].includes(item.status)).length,
      members_total: runtime.submissions.length,
    };
    return clone({
      principal: { id: p[0], display_name: p[1], email: `${p[0]}@example.internal`, role_code: selectedRole, role_label: p[2], organization_name: p[3] },
      cycle: runtime.cycle,
      screens: screens.filter((item) => item.role_code === selectedRole).sort((a, b) => a.display_order - b.display_order),
      snapshots: runtime.snapshots, work_items: items, worklogs: runtime.worklogs, evidence: runtime.evidence,
      submissions: runtime.submissions, reports: runtime.reports, collaborations: runtime.collaborations,
      participants: runtime.participants, qa_issues: runtime.qa_issues, decisions: runtime.decisions,
      action_items: runtime.action_items, audit_events: runtime.audit_events.slice(0, 50), counts,
      role_labels: Object.fromEntries(Object.entries(principals).map(([key, value]) => [key, value[2]])),
    });
  }

  function runAction(action, role) {
    const pd = runtime.snapshots.find((item) => item.id === "snp_pd_w34");
    let message;
    if (action === "VALIDATE_SNAPSHOT") {
      pd.validation_errors = 0; pd.validation_warnings = 0; pd.status = "READY_FOR_APPROVAL";
      runtime.qa_issues.filter((item) => item.resource_id === "snp_pd_w34").forEach((item) => { item.status = "RESOLVED"; });
      message = "PD Snapshot 재검증이 통과했습니다. 승인·잠금할 수 있습니다.";
    } else if (action === "APPROVE_SNAPSHOT") {
      if (pd.validation_errors) throw new Error("BLOCK 오류를 먼저 해소해야 합니다.");
      pd.status = "LOCKED"; pd.verification_state = "VERIFIED";
      message = "PD Snapshot을 승인하고 잠갔습니다.";
    } else if (action === "SUBMIT_MEMBER") {
      runtime.submissions[0].status = "SUBMITTED"; runtime.submissions[0].version += 1; runtime.submissions[0].submitted_at = new Date().toISOString();
      message = "팀원 보고를 팀장에게 제출했습니다.";
    } else if (action === "APPROVE_TEAM") {
      runtime.reports.find((item) => item.id === "rpt_team").status = "TEAM_APPROVED";
      message = "팀 보고를 승인하고 담당에게 제출했습니다.";
    } else if (action === "APPROVE_DEPT") {
      runtime.reports.find((item) => item.id === "rpt_dept").status = "DEPT_APPROVED";
      message = "담당 보고를 승인하고 기획팀에 제출했습니다.";
    } else if (action === "RESOLVE_QA") {
      runtime.qa_issues.filter((item) => item.resource_id === "rpt_group").forEach((item) => { item.status = "RESOLVED"; });
      message = "그룹 보고 QA Issue를 해소했습니다.";
    } else if (action === "APPROVE_PLANNING") {
      if (runtime.qa_issues.some((item) => item.resource_id === "rpt_group" && item.severity === "BLOCK" && item.status === "OPEN")) throw new Error("BLOCK QA Issue를 먼저 해소해야 합니다.");
      runtime.reports.find((item) => item.id === "rpt_group").status = "READY_FOR_REPORT";
      message = "그룹장 보고 확정 요청을 완료했습니다.";
    } else if (action === "RESOLVE_DECISION") {
      const decision = runtime.decisions.find((item) => item.id === "dec1");
      decision.status = "RESOLVED"; decision.resolution = "W35 K12 검증 생산 일정 우선 배정 승인";
      if (!runtime.action_items.some((item) => item.action_code === "ACT-RSND-2026-0052")) runtime.action_items.push({ id: "act3", action_code: "ACT-RSND-2026-0052", title: "K12 재현성 검증 완료", owner_name: "이선우", due_date: "2026-08-27", status: "OPEN", priority: "HIGH" });
      message = "Decision을 확정하고 후속 Action을 만들었습니다.";
    } else {
      throw new Error("지원하지 않는 오프라인 시연 동작입니다.");
    }
    addAudit(role, action, "DEMO_RESOURCE", action, message);
    return { ok: true, message, trace_id: runtime.audit_events[0].trace_id };
  }

  window.demoOfflineApi = async function (path, options = {}) {
    const url = new URL(path, "http://offline.local");
    const payload = options.body ? JSON.parse(options.body) : {};
    if (url.pathname === "/api/health") return { ok: true, database: false, mode: "OFFLINE_FIXTURE", time: new Date().toISOString() };
    if (url.pathname === "/api/bootstrap") return bootstrap(url.searchParams.get("role") || "MEMBER");
    if (url.pathname === "/api/screen-catalog") return clone(screens);
    if (url.pathname === "/api/reset") { runtime = clone(initial); return { ok: true, message: "오프라인 시연 데이터를 최초 상태로 초기화했습니다." }; }
    if (url.pathname === "/api/action") return runAction(payload.action, payload.role || "MEMBER");
    if (url.pathname === "/api/agent/draft") {
      runtime.submissions[0].status = "AI_DRAFTED";
      addAudit(payload.role || "MEMBER", "GENERATE_DRAFT", "SUBMISSION", "sub_member1", "오프라인 Agent 초안 생성");
      return { ok: true, content: draftText, citations: ["WI-RSND-2026-0032", "SNP-PD-2026-W34-004", "EVD-RSND-2026-W34-028", "COL-YIELD-2026-0014"], validation: { schema: true, numbers: true, citations: true, policy: true }, trace_id: runtime.audit_events[0].trace_id, model: "OFFLINE_DETERMINISTIC_AGENT" };
    }
    if (url.pathname === "/api/agent/ask") {
      return { ok: true, question: payload.question || "", answer: "현재 근거만으로 자동보정의 단독 효과를 확정할 수 없습니다. W34 PD Loss 1.2%는 전체 범위의 잠정 Snapshot이며, 동일 제품·동일 조건에서 적용 전후를 분리한 승인 데이터가 추가로 필요합니다.", citations: [{ code: "SNP-PD-2026-W34-004", detail: "PD Loss 1.2% · 기준 2026-08-23 23:59 · PROVISIONAL" }, { code: "WI-RSND-2026-0032", detail: "Jamming 자동보정 조건 검증" }, { code: "EVD-RSND-2026-W34-028", detail: "검증표 Result!B4:H18" }], freshness: "2026-08-23T23:59:00+09:00", trace_id: traceId() };
    }
    throw new Error(`오프라인 API를 찾을 수 없습니다: ${url.pathname}`);
  };
})();
