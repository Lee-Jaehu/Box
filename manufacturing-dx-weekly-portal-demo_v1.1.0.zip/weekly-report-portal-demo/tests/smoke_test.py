#!/usr/bin/env python3
"""End-to-end smoke test for the dependency-free local demo server."""

from __future__ import annotations

import json
import sys
from urllib.error import HTTPError
from urllib.request import Request, urlopen


BASE_URL = sys.argv[1].rstrip("/") if len(sys.argv) > 1 else "http://127.0.0.1:8765"


def request_json(path: str, payload: dict | None = None) -> dict | list:
    body = None if payload is None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
    request = Request(
        BASE_URL + path,
        data=body,
        headers={"Content-Type": "application/json"},
        method="GET" if payload is None else "POST",
    )
    try:
        with urlopen(request, timeout=5) as response:
            return json.loads(response.read().decode("utf-8"))
    except HTTPError as error:
        detail = error.read().decode("utf-8")
        raise AssertionError(f"{path}: HTTP {error.code} {detail}") from error


def assert_equal(actual: object, expected: object, label: str) -> None:
    if actual != expected:
        raise AssertionError(f"{label}: expected {expected!r}, got {actual!r}")


def main() -> None:
    expected_screens = {
        "COMMON": 5,
        "MEMBER": 8,
        "LEADER": 8,
        "DEPT": 7,
        "PLANNING": 7,
        "HEAD": 6,
        "DATA_OWNER": 7,
        "ADMIN": 7,
    }

    health = request_json("/api/health")
    assert health["ok"] and health["database"], "health check failed"

    catalog = request_json("/api/screen-catalog")
    assert_equal(len(catalog), 55, "screen catalog count")
    assert_equal(len({screen["screen_id"] for screen in catalog}), 55, "unique screen IDs")

    for role, count in expected_screens.items():
        bootstrap = request_json(f"/api/bootstrap?role={role}")
        assert_equal(len(bootstrap["screens"]), count, f"{role} screen count")
        assert_equal(bootstrap["principal"]["role_code"], role, f"{role} principal")
        assert bootstrap["cycle"]["cycle_code"] == "2026-W34"

    draft = request_json("/api/agent/draft", {"role": "MEMBER"})
    assert draft["ok"] and len(draft["citations"]) >= 4
    assert "WI-RSND-2026-0032" in draft["content"]

    answer = request_json("/api/agent/ask", {"role": "HEAD", "question": "자동보정 효과를 확정할 수 있어?"})
    assert answer["ok"] and len(answer["citations"]) == 3
    assert "확정할 수 없습니다" in answer["answer"]

    workflow = [
        ("DATA_OWNER", "VALIDATE_SNAPSHOT"),
        ("DATA_OWNER", "APPROVE_SNAPSHOT"),
        ("MEMBER", "SUBMIT_MEMBER"),
        ("LEADER", "APPROVE_TEAM"),
        ("DEPT", "APPROVE_DEPT"),
        ("PLANNING", "RESOLVE_QA"),
        ("PLANNING", "APPROVE_PLANNING"),
        ("HEAD", "RESOLVE_DECISION"),
    ]
    for role, action in workflow:
        result = request_json("/api/action", {"role": role, "action": action})
        assert result["ok"] and result["trace_id"].startswith("TRACE-DEMO-")

    final_data = request_json("/api/bootstrap?role=HEAD")
    pd_snapshot = next(item for item in final_data["snapshots"] if item["id"] == "snp_pd_w34")
    assert_equal(pd_snapshot["status"], "LOCKED", "PD snapshot lock")
    decision = next(item for item in final_data["decisions"] if item["id"] == "dec1")
    assert_equal(decision["status"], "RESOLVED", "decision state")
    assert any(item["action_code"] == "ACT-RSND-2026-0052" for item in final_data["action_items"])

    reset = request_json("/api/reset", {})
    assert reset["ok"]
    reset_data = request_json("/api/bootstrap?role=DATA_OWNER")
    reset_pd = next(item for item in reset_data["snapshots"] if item["id"] == "snp_pd_w34")
    assert_equal(reset_pd["verification_state"], "PROVISIONAL", "reset snapshot state")
    assert_equal(len(reset_data["audit_events"]), 3, "reset audit count")

    print("PASS: health, 55 screens, 8 roles, Agent APIs, workflow transitions, reset")


if __name__ == "__main__":
    main()
