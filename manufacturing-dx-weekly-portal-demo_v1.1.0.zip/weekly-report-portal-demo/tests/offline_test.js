"use strict";

global.window = {};
require("../web/demo-data.js");

async function main() {
  const api = global.window.demoOfflineApi;
  if (typeof api !== "function") throw new Error("offline API was not registered");

  const expected = { COMMON: 5, MEMBER: 8, LEADER: 8, DEPT: 7, PLANNING: 7, HEAD: 6, DATA_OWNER: 7, ADMIN: 7 };
  const catalog = await api("/api/screen-catalog");
  if (catalog.length !== 55) throw new Error(`expected 55 screens, got ${catalog.length}`);

  for (const [role, count] of Object.entries(expected)) {
    const data = await api(`/api/bootstrap?role=${role}`);
    if (data.screens.length !== count) throw new Error(`${role}: expected ${count} screens, got ${data.screens.length}`);
    if (data.principal.role_code !== role) throw new Error(`${role}: principal mismatch`);
  }

  const draft = await api("/api/agent/draft", { body: JSON.stringify({ role: "MEMBER" }) });
  if (!draft.content.includes("WI-RSND-2026-0032") || draft.citations.length !== 4) throw new Error("offline draft failed");

  await api("/api/action", { body: JSON.stringify({ role: "DATA_OWNER", action: "VALIDATE_SNAPSHOT" }) });
  await api("/api/action", { body: JSON.stringify({ role: "DATA_OWNER", action: "APPROVE_SNAPSHOT" }) });
  const after = await api("/api/bootstrap?role=DATA_OWNER");
  const pd = after.snapshots.find((item) => item.id === "snp_pd_w34");
  if (pd.status !== "LOCKED" || pd.verification_state !== "VERIFIED") throw new Error("offline snapshot workflow failed");

  await api("/api/reset", { body: "{}" });
  const reset = await api("/api/bootstrap?role=DATA_OWNER");
  const resetPd = reset.snapshots.find((item) => item.id === "snp_pd_w34");
  if (resetPd.status !== "VALIDATION_FAILED") throw new Error("offline reset failed");

  console.log("PASS: offline 55 screens, 8 roles, Agent draft, state transition, reset");
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
