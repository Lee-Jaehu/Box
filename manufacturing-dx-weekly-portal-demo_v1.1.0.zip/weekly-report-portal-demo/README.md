# 제조DX 주간업무 AI Portal 시연 패키지

설계된 역할별 화면과 주요 업무 흐름을 로컬 PC에서 시연하기 위한 데모입니다.

## 빠른 실행

### Windows

1. ZIP 압축을 풉니다.
2. Python 3가 설치되어 있는지 확인합니다.
3. `run-demo.bat`을 더블클릭합니다.
4. 브라우저가 열리지 않으면 `http://127.0.0.1:8080`에 접속합니다.

BAT는 `py -3`, `python`, `python3` 순서로 Python을 자동 탐색합니다. Python이 없거나 실행이 차단된 경우 `web/index.html` 오프라인 시연 화면을 자동으로 엽니다.

### macOS / Linux

```bash
chmod +x run-demo.sh
./run-demo.sh
```

외부 패키지를 설치하지 않습니다. Python 표준 라이브러리와 SQLite만 사용합니다.

## 포함 내용

```text
web/index.html       역할별 화면과 시연 UI
web/styles.css       화면 스타일
web/app.js           화면 전환·API 호출·시연 동작
web/demo-data.js     서버 없이 실행할 오프라인 샘플 데이터
server.py            정적 화면 + SQLite API 서버
db/demo.db           즉시 실행 가능한 샘플 DB
db/schema.sql        DB 스키마
db/seed.sql          샘플 데이터
build_db.py          DB 재생성 도구
DEMO_GUIDE.md        15분 시연 순서
DATA_DICTIONARY.md   테이블·샘플데이터 설명
WINDOWS_QUICK_START.md Windows 실행·오류 확인
```

## 사용자 역할

상단 역할 선택에서 다음 화면을 전환할 수 있습니다.

- 공통 사용자: 로그인, 역할 선택, 통합 업무함, 검색, 알림
- 팀원: WorkItem·Worklog·Evidence·주간 초안·제출
- 팀장: 팀원 제출 검토, 포함/제외, 서술형 보고, 승인/반려
- 담당: 팀 보고 Matrix, 협업 묶음, KPI 충돌, 담당 보고 승인
- 기획팀: 그룹 준비현황, QA, 그룹 보고 구성, 민감정보, 최종 확정
- 그룹장: KPI Overview, 담당 Drill-down, 근거, Q&A, Decision, Action
- KPI Data Owner: 파일 업로드, 매핑, Validation, 비교, 승인·잠금
- 운영자: 사용자/권한, 보고 Calendar, Prompt/Model, Policy, Audit, Health

총 55개 화면이 `screen_definitions` 테이블과 화면 메뉴로 연결됩니다.

## 주요 시연 동작

- KPI Snapshot Validation 및 승인·잠금
- 팀원 AI 초안 생성과 팀장 제출
- 팀장→담당→기획 승인 흐름
- KPI·Evidence Citation 확인
- 그룹장 근거 기반 질문과 Decision 확정
- 역할별 상태 변경 감사로그
- 데모 데이터 초기화

## 데모 데이터 초기화

화면 우측 상단의 `데모 초기화`를 누르거나 다음 명령을 실행합니다.

```bash
python build_db.py
```

기존 `db/demo.db`를 샘플 초기 상태로 다시 생성합니다.

## 실행이 되지 않을 때

1. ZIP 안에서 바로 실행하지 말고 먼저 압축을 완전히 풉니다.
2. `run-demo.bat` 실행 후 검은 창을 닫지 않습니다. 창이 닫히면 접속 주소도 종료됩니다.
3. 포트 8080이 사용 중이면 서버가 8081~8089 중 사용 가능한 주소로 자동 전환하고 화면에 표시합니다.
4. Python 실행이 불가능하면 `web/index.html`을 더블클릭합니다. 이 모드는 화면·Agent·상태전환을 브라우저 메모리로 시연하며 SQLite 서버는 사용하지 않습니다.
5. 서버 오류는 BAT 창에 그대로 표시됩니다. 오류 화면을 캡처하면 원인을 추가로 확인할 수 있습니다.

## 주의

- 실제 회사 시스템·LLM·Copilot·메일·분석시스템과 연결되지 않은 시연용입니다.
- 화면의 회사·사이트·수치·사람 이름은 가상 샘플입니다.
- AI 초안과 Q&A는 시연을 위한 결정적 응답이며 실제 모델을 호출하지 않습니다.
- 실제 구축 시 SSO, RBAC/ABAC, Object Storage, LLM Gateway, DLP, 감사정책을 별도로 연결해야 합니다.
