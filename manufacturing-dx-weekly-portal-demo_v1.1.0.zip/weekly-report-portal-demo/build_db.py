#!/usr/bin/env python3
"""Create the SQLite demo database from schema.sql and seed.sql."""

from __future__ import annotations

import os
import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DB_DIR = ROOT / "db"
DB_PATH = DB_DIR / "demo.db"
TEMP_PATH = DB_DIR / "demo.building.db"


def build_database(target: Path = DB_PATH) -> Path:
    DB_DIR.mkdir(parents=True, exist_ok=True)
    temp = TEMP_PATH if target == DB_PATH else target.with_suffix(".building.db")
    if temp.exists():
        temp.unlink()

    connection = sqlite3.connect(temp)
    try:
        connection.executescript((DB_DIR / "schema.sql").read_text(encoding="utf-8"))
        connection.executescript((DB_DIR / "seed.sql").read_text(encoding="utf-8"))
        violations = connection.execute("PRAGMA foreign_key_check").fetchall()
        if violations:
            raise RuntimeError(f"foreign key violations: {violations}")
        connection.commit()
    finally:
        connection.close()

    os.replace(temp, target)
    return target


if __name__ == "__main__":
    built = build_database()
    print(f"Demo database created: {built}")

