PRAGMA foreign_keys = ON;

CREATE TABLE organizations (
  id TEXT PRIMARY KEY,
  org_code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  org_type TEXT NOT NULL,
  parent_id TEXT REFERENCES organizations(id)
);

CREATE TABLE users (
  id TEXT PRIMARY KEY,
  employee_code TEXT NOT NULL UNIQUE,
  display_name TEXT NOT NULL,
  email TEXT NOT NULL,
  organization_id TEXT NOT NULL REFERENCES organizations(id),
  active INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE role_assignments (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id),
  role_code TEXT NOT NULL,
  organization_id TEXT NOT NULL REFERENCES organizations(id),
  valid_from TEXT NOT NULL,
  valid_to TEXT
);

CREATE TABLE reporting_cycles (
  id TEXT PRIMARY KEY,
  cycle_code TEXT NOT NULL UNIQUE,
  year INTEGER NOT NULL,
  week INTEGER NOT NULL,
  state TEXT NOT NULL,
  snapshot_due_at TEXT NOT NULL,
  member_due_at TEXT NOT NULL,
  leader_due_at TEXT NOT NULL,
  department_due_at TEXT NOT NULL,
  planning_due_at TEXT NOT NULL
);

CREATE TABLE metric_definitions (
  id TEXT PRIMARY KEY,
  metric_code TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  definition TEXT NOT NULL,
  unit TEXT NOT NULL,
  source_system TEXT NOT NULL,
  owner_org_id TEXT NOT NULL REFERENCES organizations(id),
  version INTEGER NOT NULL
);

CREATE TABLE metric_snapshots (
  id TEXT PRIMARY KEY,
  snapshot_code TEXT NOT NULL UNIQUE,
  metric_id TEXT NOT NULL REFERENCES metric_definitions(id),
  cycle_id TEXT NOT NULL REFERENCES reporting_cycles(id),
  cutoff_at TEXT NOT NULL,
  status TEXT NOT NULL,
  verification_state TEXT NOT NULL,
  source_file TEXT NOT NULL,
  version INTEGER NOT NULL,
  validation_errors INTEGER NOT NULL DEFAULT 0,
  validation_warnings INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE metric_values (
  id TEXT PRIMARY KEY,
  snapshot_id TEXT NOT NULL REFERENCES metric_snapshots(id),
  site TEXT NOT NULL,
  process TEXT NOT NULL,
  line TEXT NOT NULL,
  product TEXT NOT NULL,
  value REAL NOT NULL,
  previous_value REAL,
  target_value REAL,
  unit TEXT NOT NULL,
  quality_flag TEXT NOT NULL
);

CREATE TABLE collaborations (
  id TEXT PRIMARY KEY,
  collaboration_code TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  goal TEXT NOT NULL,
  lead_org_id TEXT NOT NULL REFERENCES organizations(id),
  status TEXT NOT NULL,
  target_date TEXT
);

CREATE TABLE collaboration_participants (
  collaboration_id TEXT NOT NULL REFERENCES collaborations(id),
  organization_id TEXT NOT NULL REFERENCES organizations(id),
  contribution TEXT NOT NULL,
  PRIMARY KEY (collaboration_id, organization_id)
);

CREATE TABLE work_items (
  id TEXT PRIMARY KEY,
  work_item_code TEXT NOT NULL UNIQUE,
  organization_id TEXT NOT NULL REFERENCES organizations(id),
  owner_user_id TEXT NOT NULL REFERENCES users(id),
  collaboration_id TEXT REFERENCES collaborations(id),
  title TEXT NOT NULL,
  objective TEXT NOT NULL,
  state TEXT NOT NULL,
  start_date TEXT,
  target_date TEXT,
  metric_code TEXT,
  security_label TEXT NOT NULL
);

CREATE TABLE worklogs (
  id TEXT PRIMARY KEY,
  work_item_id TEXT NOT NULL REFERENCES work_items(id),
  author_user_id TEXT NOT NULL REFERENCES users(id),
  occurred_on TEXT NOT NULL,
  entry_type TEXT NOT NULL,
  narrative TEXT NOT NULL
);

CREATE TABLE work_pages (
  id TEXT PRIMARY KEY,
  page_code TEXT NOT NULL UNIQUE,
  cycle_id TEXT NOT NULL REFERENCES reporting_cycles(id),
  organization_id TEXT NOT NULL REFERENCES organizations(id),
  title TEXT NOT NULL,
  site_scope TEXT NOT NULL,
  process_scope TEXT NOT NULL,
  project_scope TEXT NOT NULL,
  objective TEXT NOT NULL,
  primary_owner_user_id TEXT NOT NULL REFERENCES users(id),
  retention_weeks INTEGER NOT NULL DEFAULT 4,
  display_order INTEGER NOT NULL,
  state TEXT NOT NULL
);

CREATE TABLE work_page_contributors (
  work_page_id TEXT NOT NULL REFERENCES work_pages(id),
  user_id TEXT NOT NULL REFERENCES users(id),
  contributor_role TEXT NOT NULL,
  display_order INTEGER NOT NULL,
  PRIMARY KEY (work_page_id, user_id)
);

CREATE TABLE work_page_items (
  work_page_id TEXT NOT NULL REFERENCES work_pages(id),
  work_item_id TEXT NOT NULL REFERENCES work_items(id),
  PRIMARY KEY (work_page_id, work_item_id)
);

CREATE TABLE evidence (
  id TEXT PRIMARY KEY,
  evidence_code TEXT NOT NULL UNIQUE,
  work_item_id TEXT NOT NULL REFERENCES work_items(id),
  file_name TEXT NOT NULL,
  content_type TEXT NOT NULL,
  sha256 TEXT NOT NULL,
  locator TEXT,
  scan_status TEXT NOT NULL,
  security_label TEXT NOT NULL
);

CREATE TABLE submissions (
  id TEXT PRIMARY KEY,
  submission_code TEXT NOT NULL UNIQUE,
  cycle_id TEXT NOT NULL REFERENCES reporting_cycles(id),
  member_user_id TEXT NOT NULL REFERENCES users(id),
  organization_id TEXT NOT NULL REFERENCES organizations(id),
  status TEXT NOT NULL,
  version INTEGER NOT NULL,
  submitted_at TEXT
);

CREATE TABLE submission_pages (
  submission_id TEXT NOT NULL REFERENCES submissions(id),
  work_page_id TEXT NOT NULL REFERENCES work_pages(id),
  included INTEGER NOT NULL,
  inclusion_reason TEXT,
  PRIMARY KEY (submission_id, work_page_id)
);

CREATE TABLE submission_items (
  submission_id TEXT NOT NULL REFERENCES submissions(id),
  work_item_id TEXT NOT NULL REFERENCES work_items(id),
  included INTEGER NOT NULL,
  inclusion_reason TEXT,
  PRIMARY KEY (submission_id, work_item_id)
);

CREATE TABLE submission_versions (
  id TEXT PRIMARY KEY,
  submission_id TEXT NOT NULL REFERENCES submissions(id),
  version_number INTEGER NOT NULL,
  content TEXT NOT NULL,
  source_manifest TEXT NOT NULL,
  generated_by TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE (submission_id, version_number)
);

CREATE TABLE reports (
  id TEXT PRIMARY KEY,
  report_code TEXT NOT NULL UNIQUE,
  cycle_id TEXT NOT NULL REFERENCES reporting_cycles(id),
  organization_id TEXT NOT NULL REFERENCES organizations(id),
  report_level TEXT NOT NULL,
  status TEXT NOT NULL,
  current_version INTEGER NOT NULL,
  security_label TEXT NOT NULL
);

CREATE TABLE report_versions (
  id TEXT PRIMARY KEY,
  report_id TEXT NOT NULL REFERENCES reports(id),
  version_number INTEGER NOT NULL,
  content TEXT NOT NULL,
  source_manifest TEXT NOT NULL,
  generated_by TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE (report_id, version_number)
);

CREATE TABLE approval_events (
  id TEXT PRIMARY KEY,
  resource_type TEXT NOT NULL,
  resource_id TEXT NOT NULL,
  stage TEXT NOT NULL,
  decision TEXT NOT NULL,
  reason TEXT NOT NULL,
  actor_user_id TEXT NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL,
  trace_id TEXT NOT NULL
);

CREATE TABLE decisions (
  id TEXT PRIMARY KEY,
  decision_code TEXT NOT NULL UNIQUE,
  title TEXT NOT NULL,
  request TEXT NOT NULL,
  status TEXT NOT NULL,
  decision_maker_user_id TEXT REFERENCES users(id),
  due_date TEXT,
  resolution TEXT
);

CREATE TABLE action_items (
  id TEXT PRIMARY KEY,
  action_code TEXT NOT NULL UNIQUE,
  decision_id TEXT REFERENCES decisions(id),
  title TEXT NOT NULL,
  owner_user_id TEXT REFERENCES users(id),
  due_date TEXT,
  status TEXT NOT NULL,
  priority TEXT NOT NULL
);

CREATE TABLE qa_issues (
  id TEXT PRIMARY KEY,
  resource_type TEXT NOT NULL,
  resource_id TEXT NOT NULL,
  rule_code TEXT NOT NULL,
  severity TEXT NOT NULL,
  message TEXT NOT NULL,
  remediation TEXT NOT NULL,
  status TEXT NOT NULL
);

CREATE TABLE audit_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  occurred_at TEXT NOT NULL,
  trace_id TEXT NOT NULL,
  actor_user_id TEXT,
  actor_role TEXT NOT NULL,
  action TEXT NOT NULL,
  resource_type TEXT NOT NULL,
  resource_id TEXT,
  result TEXT NOT NULL,
  detail TEXT
);

CREATE TABLE screen_definitions (
  screen_id TEXT PRIMARY KEY,
  role_code TEXT NOT NULL,
  display_order INTEGER NOT NULL,
  title TEXT NOT NULL,
  kind TEXT NOT NULL,
  purpose TEXT NOT NULL,
  primary_action TEXT NOT NULL,
  ai_function TEXT NOT NULL,
  main_data TEXT NOT NULL,
  control_rule TEXT NOT NULL,
  done_condition TEXT NOT NULL
);

CREATE INDEX ix_work_items_owner ON work_items(owner_user_id, state);
CREATE INDEX ix_worklogs_item_date ON worklogs(work_item_id, occurred_on DESC);
CREATE INDEX ix_work_pages_owner ON work_pages(primary_owner_user_id, display_order);
CREATE INDEX ix_work_page_contributors_user ON work_page_contributors(user_id, work_page_id);
CREATE INDEX ix_snapshots_cycle ON metric_snapshots(cycle_id, status);
CREATE INDEX ix_reports_cycle_level ON reports(cycle_id, report_level, status);
CREATE INDEX ix_submission_versions ON submission_versions(submission_id, version_number DESC);
CREATE INDEX ix_audit_time ON audit_events(occurred_at DESC);
CREATE INDEX ix_screens_role ON screen_definitions(role_code, display_order);
