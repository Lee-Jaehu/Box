param(
  [int]$Port = 8080
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$WebRoot = [System.IO.Path]::GetFullPath((Join-Path $Root "web"))

function Send-Bytes {
  param(
    [System.Net.Sockets.NetworkStream]$Stream,
    [int]$StatusCode,
    [string]$StatusText,
    [string]$ContentType,
    [byte[]]$Body
  )
  $Header = "HTTP/1.1 $StatusCode $StatusText`r`nContent-Type: $ContentType`r`nContent-Length: $($Body.Length)`r`nCache-Control: no-store`r`nConnection: close`r`n`r`n"
  $HeaderBytes = [System.Text.Encoding]::ASCII.GetBytes($Header)
  $Stream.Write($HeaderBytes, 0, $HeaderBytes.Length)
  if ($Body.Length -gt 0) {
    $Stream.Write($Body, 0, $Body.Length)
  }
  $Stream.Flush()
}

function Send-Json {
  param(
    [System.Net.Sockets.NetworkStream]$Stream,
    [int]$StatusCode,
    [string]$Json
  )
  $StatusText = if ($StatusCode -eq 200) { "OK" } else { "Not Found" }
  $Body = [System.Text.Encoding]::UTF8.GetBytes($Json)
  Send-Bytes -Stream $Stream -StatusCode $StatusCode -StatusText $StatusText -ContentType "application/json; charset=utf-8" -Body $Body
}

function Get-ContentType {
  param([string]$Path)
  switch ([System.IO.Path]::GetExtension($Path).ToLowerInvariant()) {
    ".html" { return "text/html; charset=utf-8" }
    ".css"  { return "text/css; charset=utf-8" }
    ".js"   { return "application/javascript; charset=utf-8" }
    ".json" { return "application/json; charset=utf-8" }
    ".svg"  { return "image/svg+xml" }
    ".png"  { return "image/png" }
    ".jpg"  { return "image/jpeg" }
    ".jpeg" { return "image/jpeg" }
    ".ico"  { return "image/x-icon" }
    default  { return "application/octet-stream" }
  }
}

$Listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $Port)
$Listener.Start()
$PortalUrl = "http://127.0.0.1:$Port/"

Write-Host "[READY] Manufacturing DX Weekly Portal"
Write-Host "[URL]   $PortalUrl"
Write-Host "[INFO]  Keep this window open. Press Ctrl+C to stop."
Start-Process $PortalUrl

try {
  while ($true) {
    $Client = $Listener.AcceptTcpClient()
    try {
      $Client.ReceiveTimeout = 5000
      $Stream = $Client.GetStream()
      $Reader = [System.IO.StreamReader]::new($Stream, [System.Text.Encoding]::ASCII, $false, 4096, $true)
      $RequestLine = $Reader.ReadLine()
      if ([string]::IsNullOrWhiteSpace($RequestLine)) {
        $Client.Close()
        continue
      }
      while ($true) {
        $HeaderLine = $Reader.ReadLine()
        if ([string]::IsNullOrEmpty($HeaderLine)) { break }
      }

      $Parts = $RequestLine.Split(" ")
      $Method = $Parts[0]
      $RawPath = if ($Parts.Length -gt 1) { $Parts[1].Split("?")[0] } else { "/" }
      $RequestPath = [System.Uri]::UnescapeDataString($RawPath)

      if ($RequestPath -eq "/api/health") {
        Send-Json -Stream $Stream -StatusCode 200 -Json '{"ok":true,"database":false,"mode":"WINDOWS_STATIC"}'
        continue
      }
      if ($RequestPath -eq "/api/agent/status") {
        Send-Json -Stream $Stream -StatusCode 200 -Json '{"ok":true,"mode":"DEMO","configured":true,"provider":"portal_demo_agent","model":"built-in-scenario","message":"Portal demo agent ready"}'
        continue
      }
      if ($RequestPath.StartsWith("/api/")) {
        Send-Json -Stream $Stream -StatusCode 404 -Json '{"message":"Use offline demo data"}'
        continue
      }

      if ($Method -ne "GET" -and $Method -ne "HEAD") {
        Send-Json -Stream $Stream -StatusCode 404 -Json '{"message":"Not found"}'
        continue
      }

      $RelativePath = if ($RequestPath -eq "/") { "index.html" } else { $RequestPath.TrimStart("/").Replace("/", [System.IO.Path]::DirectorySeparatorChar) }
      $FilePath = [System.IO.Path]::GetFullPath((Join-Path $WebRoot $RelativePath))
      if (-not $FilePath.StartsWith($WebRoot, [System.StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path -LiteralPath $FilePath -PathType Leaf)) {
        Send-Json -Stream $Stream -StatusCode 404 -Json '{"message":"Not found"}'
        continue
      }

      $Body = if ($Method -eq "HEAD") { [byte[]]::new(0) } else { [System.IO.File]::ReadAllBytes($FilePath) }
      Send-Bytes -Stream $Stream -StatusCode 200 -StatusText "OK" -ContentType (Get-ContentType $FilePath) -Body $Body
    } catch {
      Write-Host "[WARN] Request failed: $($_.Exception.Message)"
    } finally {
      $Client.Close()
    }
  }
} finally {
  $Listener.Stop()
}
