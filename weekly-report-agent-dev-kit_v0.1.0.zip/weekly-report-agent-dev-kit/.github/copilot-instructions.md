# Repository Instructions for Copilot

- 이 저장소의 기준 문서는 `docs/`와 `api/openapi.yaml`, `schemas/`, `db/schema.sql`이다.
- 신규 기능을 제안하거나 작성할 때 관련 Requirement ID와 Acceptance Criteria를 주석 또는 PR 설명에 연결한다.
- Portal API만 운영 상태를 변경한다. Copilot/LLM에서 DB write나 승인 endpoint 자동 호출 코드를 만들지 않는다.
- KPI 값은 승인된 Metric Snapshot을 조회하고 Snapshot ID, 기준 시각, 단위를 함께 반환한다.
- 모든 endpoint에 인증, 조직 범위 권한, 감사 이벤트, 입력 스키마 검증을 고려한다.
- 생성 코드는 TypeScript strict/Python type hint를 사용하고 unit, integration, authorization negative test를 포함한다.
- secret, 내부 URL, 회사 데이터 예시를 코드에 하드코딩하지 않는다.
- 미결정 제품/API는 `CopilotAdapter`, `LlmGateway`, `ObjectStorage`, `IdentityProvider` interface 뒤에 둔다.
- 문서와 계약이 충돌하면 임의로 선택하지 말고 차이를 지적하고 ADR을 제안한다.

