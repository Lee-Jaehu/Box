---
paths:
  - "db/**"
  - "schemas/**"
  - "services/api/**/models/**"
---

# Data rules

- ID는 UUID를 사용하고 사람이 보는 business code는 별도 unique field로 둔다.
- 삭제 대신 lifecycle status와 retention 정책을 사용한다.
- 운영 레코드에는 created_at/by, updated_at/by, version을 둔다.
- Snapshot과 승인된 보고서 버전은 immutable하다. 정정은 새 버전과 supersedes 관계로 처리한다.
- 측정값은 numeric value, unit, aggregation scope, cutoff_at, verification_state를 분리 저장한다.

