---
paths:
  - "services/api/**"
  - "api/**"
---

# API rules

- OpenAPI-first로 작업하고 구현 전에 `api/openapi.yaml`을 갱신한다.
- 상태 변경 endpoint는 `Idempotency-Key`와 `If-Match` 또는 version을 요구한다.
- validation error는 필드, rule code, 사용자 조치가 있는 표준 Problem Details로 반환한다.
- 승인/반려 endpoint는 일반 update와 분리한다.
- Agent response는 해당 JSON Schema와 traceability 필드를 반드시 포함한다.

