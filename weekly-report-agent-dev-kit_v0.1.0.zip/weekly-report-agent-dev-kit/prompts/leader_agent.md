# Task Prompt — Team Leader Report Draft

Version: `leader-report-0.1.0`

## 목표

그룹장이 주로 검토하는 팀장 보고 페이지를 만든다. 팀원 제출의 서술형 정보량과 논리 흐름을 유지하면서 AI가 읽을 ID, 상태, 태그, 출처를 보강한다.

## 핵심 원칙

- 원문을 한 줄 요약으로 대체하지 않는다.
- 문제 배경 → 금주 활동 → 결과/수치 → 해석 → 차주 계획/요청의 흐름을 유지한다.
- 기술 용어, 공정/라인/설비 범위, 전후 조건, 검증 제약을 삭제하지 않는다.
- 문단 상단 또는 해당 문장에 WorkItem/KPI Snapshot/Collaboration/Decision code를 추가한다.
- 같은 내용을 반복한 문장만 정리하고 새로운 효과나 결론을 만들지 않는다.

## 구성

1. `핵심 진행 현황`: 대표 WorkItem별 서술형 문단.
2. `정량 결과`: 승인 Snapshot만 사용, 기준→현재→목표가 모두 있을 때 병렬 표시.
3. `분석·검증`: 확정 사실과 팀 가설을 구분.
4. `차주 계획`: action, owner, due, dependency.
5. `Risk/Decision`: 그룹장/담당의 판단이 필요한 내용.

## ID 예시

```text
[WI-RSND-2026-0032][RESULT] 서술형 실적...
[MET-PD-01][SNP-PD-2026-W33-017][KPI] PD Loss ...
[COL-YIELD-2026-0014][NEXT] 공동 검증 계획...
[DEC-RSND-2026-0008][DECISION] 지원 요청...
```

## 선별

- 추천 포함/제외를 별도 `selectionSuggestions`로 제안한다.
- 제외를 실제 적용하지 않는다.
- 제외 추천에는 중복, 정보 부족, 해당 주차 변화 없음 등 이유와 원문 link를 제공한다.

## 출력 검증

- 원문 핵심 주장 보존 여부
- 모든 숫자의 Snapshot/Evidence citation
- 팀별 가설을 공통 사실로 바꾸지 않았는지
- 미지정 owner/due를 만들지 않았는지
- 그룹장이 결정해야 할 요청이 숨겨지지 않았는지

