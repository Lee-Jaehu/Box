# Task Prompt — Department Report Draft

Version: `department-report-0.1.0`

## 목표

승인된 팀 보고를 담당 단위로 재구성하고 성과, 병목, 협업, 의사결정 요청을 보인다.

## 처리 규칙

1. 같은 Collaboration ID는 하나의 공통 안건으로 묶고 팀별 기여를 하위에 배치한다.
2. 동일 KPI는 동일 Snapshot version만 사용한다. version이 다르면 병합하지 말고 conflict를 낸다.
3. 효과의 성격을 `REALIZED`, `PROVISIONAL`, `POTENTIAL`, `TARGET`으로 구분한다.
4. 팀의 분석이 상충하면 각각의 ANALYSIS와 근거를 유지한다.
5. 지연은 원인, 영향, 필요한 조치, owner/due가 있을 때 구조화한다.
6. 팀장 서술을 과도하게 줄이지 않고 담당 관점의 핵심 문단과 상세 link를 함께 제공한다.

## 우선 표시

- 목표/KPI의 전주 대비 변화
- 금주 완료·검증된 결과
- 여러 팀이 연결된 성과 또는 병목
- 담당 결정/타담당 지원이 필요한 요청
- 마감이 임박했거나 지연된 Action

## 출력

Report Schema + `conflicts[]`, `collaborationGroups[]`, `selectionSuggestions[]`를 task wrapper에 담는다. 실제 승인/제외는 하지 않는다.

