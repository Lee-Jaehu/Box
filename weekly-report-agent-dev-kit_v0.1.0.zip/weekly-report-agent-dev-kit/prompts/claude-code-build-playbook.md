# Claude Code 개발 프롬프트 Playbook

각 Prompt를 별도 세션/PR로 실행합니다. 한 번에 전체 시스템을 만들도록 요청하지 않습니다. `[]` 부분은 회사 결정값으로 바꿉니다.

## Prompt 0 — 저장소 Bootstrap과 ADR

```text
CLAUDE.md, README.md, docs/00_document_index.md부터 읽어라. docs/10_decisions_and_open_questions.md의 P0를 확인하고, 현재 답을 모르는 값은 추측하지 마라.

목표: 다음 구조로 실행 가능한 monorepo bootstrap을 작성하라.
- apps/web: Next.js TypeScript strict
- services/api: FastAPI Python type hints
- services/worker: background job skeleton
- packages/contracts: OpenAPI/JSON Schema validation
- tests/evals: evaluation runner skeleton
- infra: 환경 인터페이스만, 특정 cloud 자원은 ADR 확정 전 생성 금지

먼저 ADR-004와 기술 선택 ADR 초안을 제시하고 승인을 기다려라. 승인 후 health/readiness, lint/test/build, local container compose, .env.example, CI를 구현하라.

완료 조건: 모든 명령이 clean checkout에서 실행되고 secret scan/SCA/unit test가 통과한다. 변경 파일, 명령 결과, 미결정사항을 보고하라.
```

## Prompt 1 — Domain/IAM 기반

```text
REQ-IAM-001~004, REQ-CYC-001~003과 db/schema.sql, api/openapi.yaml을 읽어라.
OIDC는 interface + local test provider로 구현하고 production issuer/audience는 환경값으로 둬라.
Organization, User, RoleAssignment, ReportingCycle 모델과 migration, repository/service/API를 구현하라.
권한 predicate는 role × org ancestry × state × label을 서버에서 평가한다.
IDOR, 만료 역할, 대리 권한, 다른 조직 접근의 negative test를 포함하라.
OpenAPI 구현 일치와 audit event를 검증하라.
```

## Prompt 2 — KPI Snapshot 수직 기능

```text
REQ-SNP-001~005와 schemas/metric_snapshot.schema.json을 구현하라.
pre-signed upload interface, quarantine 상태, mock malware scanner, CSV/XLSX parser adapter, mapping, deterministic validation, approval/lock/supersede를 하나의 수직 기능으로 완성하라.
원본값 자동 수정은 금지한다. numeric은 Decimal을 사용한다.
중복키, 필수값, unit, range, cutoff, 급변 rule과 오류 행 report를 구현한다.
승인/잠금/정정, 동시성, idempotency, 권한 negative test와 과거 Snapshot 재현 test를 작성하라.
```

## Prompt 3 — WorkItem/Worklog/Evidence

```text
REQ-WRK-001~003과 Evidence 보안 규칙을 구현하라.
WorkItem business code generator, Worklog timeline, Evidence upload/scan/extraction adapter, collaboration/metric 연결을 작성하라.
운영 파일은 Git이나 DB blob에 저장하지 않는다.
파일 확장자/MIME/크기/hash/압축 제한과 추출문을 untrusted로 표시하는 metadata를 테스트하라.
본인/팀장/타팀의 접근 가능·불가능 case를 포함하라.
```

## Prompt 4 — 팀원 Agent 초안과 제출

```text
REQ-WRK-004~006, REQ-AI-001~006, prompts/system_orchestrator.md, prompts/member_agent.md를 구현하라.
LlmGateway는 interface + deterministic fake를 먼저 만든다.
Context Builder는 선택된 WorkItem/Worklog/Evidence와 승인 Snapshot version만 넣는다.
model output을 report schema로 검사한 후 숫자/단위/citation/권한을 결정적으로 검증한다.
AgentRun과 DraftVersion을 저장하고 사용자가 수정·확정·제출하는 UI/API를 완성한다.
hallucinated KPI, missing citation, injection 문장, LLM timeout, 중복 제출 test를 포함하라.
```

## Prompt 5 — 팀장 서술형 보고

```text
REQ-RPT-001~003과 prompts/leader_agent.md를 구현하라.
팀원 제출 원문, AI 초안, 사람 수정, citation을 나란히 볼 수 있는 팀장 화면을 작성하라.
AI는 원문을 축약본으로 대체하지 않고 서술형 내용을 보존하며 WorkItem/KPI Snapshot/Collaboration/Decision code를 보강해야 한다.
포함/제외는 추천과 실제 선택을 분리하고 제외 이유를 저장한다.
원문 핵심 주장 보존 eval과 AI/사람 diff를 구현하라.
```

## Prompt 6 — 담당/기획/그룹장 Workflow

```text
REQ-COL-001~003, REQ-RPT-004~007과 department/planning/head prompt를 구현하라.
협업 중복 묶음, KPI version conflict, 상충 가설 병렬 표시, planning QA, 그룹장 citation drill-down, Decision/Action을 작성하라.
승인/반려는 explicit command, If-Match, Idempotency-Key, confirmation token, audit transaction을 사용한다.
모든 role/state 전이와 우회 차단 E2E test를 작성하라.
```

## Prompt 7 — 내부 Copilot Adapter

```text
REQ-COP-001~005와 docs/05_agent_and_copilot.md를 읽어라.
[COPILOT_TYPE]의 공식 SDK/API 계약을 별도 ADR에 기록하고 CopilotAdapter를 구현하라.
identity mapping, read-only query, citation/freshness/trace, capability health, timeout/circuit breaker를 포함한다.
제출·승인·반려는 절대 실행하지 말고 expiring ActionPreview와 Portal confirmation URL만 반환한다.
다른 조직 질문, 변조된 resource ID, replay/expired preview, Copilot 장애 fallback을 테스트하라.
```

## Prompt 8 — 보안·관측성·평가 Gate

```text
docs/07_security_nfr_operations.md와 docs/08_test_evaluation_rollout.md의 배포 gate를 구현하라.
OpenTelemetry trace, redacted log, security audit, rate limit, upload isolation, DLP interface, prompt injection regression set을 추가하라.
100-case eval dataset을 실제 승인된 비식별 샘플로 채우기 위한 loader와 report를 만들라.
숫자 정확도/권한/허위 ID/injection은 deterministic fail gate로 두고 사람 평가 UI 또는 CSV export를 제공하라.
```

## Prompt 9 — Pilot 준비

```text
RSND자동보정팀의 비식별 2개 주차 sample을 이용해 seed/fixtures를 만들되 실제 회사 정보는 저장소에 커밋하지 마라.
운영자, Data Owner, 팀원, 팀장, 담당, 기획, 그룹장 시나리오를 실행하는 UAT script를 작성하라.
수동 작성 fallback, 장애 runbook, backup/restore drill, feature flag rollback을 검증하라.
문서와 구현 추적성 matrix 및 Go/No-Go report를 생성하라.
```

## 공통 PR 완료 프롬프트

```text
이번 변경을 자체 리뷰하라. 관련 REQ ID와 수용기준을 표로 매핑하고, 권한/데이터/Prompt/API/DB 영향과 breaking change를 설명하라. 실행한 lint, unit, integration, contract, security, eval 결과를 원문 명령과 함께 보고하라. 테스트하지 못한 항목과 rollback 방법을 명시하라. 불필요한 리팩터링은 하지 마라.
```

