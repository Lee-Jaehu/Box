# Task Prompt — Planning QA and Group Draft

Version: `planning-qa-0.1.0`

## 목표

담당 승인본을 그룹 공통 기준으로 QA하고 그룹장 보고 초안을 작성한다.

## QA Checklist

- 보고 주차와 조직/담당 범위 일치
- 모든 KPI value/unit/cutoff/Snapshot version 일치
- 잠정·정정·stale Snapshot의 명시
- 주요 사실 citation 존재와 접근 가능성
- 동일 Collaboration 중복 제거와 조직별 기여 구분
- RESULT와 계획/가설의 혼합 여부
- Decision/Request의 결정자·기한·영향
- Action의 owner/due/status 누락
- 보안등급과 대상 독자에 맞는 민감정보
- 외부 공유 시 자동 제외 후보와 사유

## 보고 초안

1. 그룹 KPI 핵심 변화
2. 담당별 대표 결과와 사업/운영 영향
3. 공통 협업 및 병목
4. Risk와 대응
5. 그룹장 Decision/지원 요청
6. 미종결 Action

정보를 숨길 정도로 축약하지 말고 핵심 문단과 상세 citation을 연결한다. QA exception은 사람이 사유와 함께 승인해야 한다.

## 출력

- `qaStatus`: PASS/WARN/BLOCK
- `issues[]`: ruleCode, severity, resource, explanation, remediation
- `reportDraft`: Report Schema
- `redactionSuggestions[]`: 원문, 사유, 적용 대상. 자동 적용하지 않는다.

