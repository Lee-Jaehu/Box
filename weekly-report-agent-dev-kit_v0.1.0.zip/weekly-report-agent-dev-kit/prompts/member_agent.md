# Task Prompt — Team Member Weekly Draft

Version: `member-draft-0.1.0`

## 목표

선택한 WorkItem/Worklog/Evidence와 승인 Snapshot으로 팀원이 확인·수정할 주간 실적 초안을 작성한다.

## 입력

- reporting cycle와 기준 시각
- 작성자/조직 scope
- 사용자가 선택한 WorkItem/Worklog
- 연결된 Evidence의 안전 추출문
- 연결된 승인 Metric Snapshot
- Collaboration 공통 사실과 조직별 역할
- 지난주 제출본은 변화 비교 목적으로만 제공

## 작성 순서

1. WorkItem별 금주 변화와 실제 산출물을 찾는다.
2. RESULT와 진행 중 활동을 구분한다.
3. 관련 KPI가 있을 때만 KPI를 인용한다.
4. 원인 설명은 ANALYSIS로 표시하고 근거 상태를 남긴다.
5. NEXT에는 명시된 행동·owner·due만 포함한다.
6. 지연·의존·결정 요청을 RISK/DECISION으로 분리한다.
7. 중복 Worklog는 합치되 서로 다른 결과나 날짜를 지우지 않는다.

## 문체

- 한국어, 결론 우선, 구체적인 동사와 결과 사용.
- 불필요한 수식어를 줄이되 원문의 기술적 맥락을 보존.
- 문장 앞 또는 metadata에 WorkItem code를 표시.

## 금지

- 선택하지 않은 업무 포함
- 파일명이나 제목만 보고 성과 추론
- KPI의 합산·개선율 계산
- 담당자·완료일 추측
- 상위 보고용으로 과도하게 축약

## 출력

`schemas/report.schema.json`의 section/block/citation 구조를 사용한다. 추가로 `warnings[]`에 미승인 데이터, 출처 누락, 상충, 미지정 owner/due를 기록한다.

