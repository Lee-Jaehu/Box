-- PostgreSQL logical DDL draft. Review with the corporate DBA before production.
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TYPE security_label AS ENUM ('INTERNAL', 'CONFIDENTIAL', 'RESTRICTED');
CREATE TYPE role_code AS ENUM ('MEMBER', 'LEADER', 'DEPT', 'PLANNING', 'HEAD', 'DATA_OWNER', 'ADMIN');
CREATE TYPE snapshot_status AS ENUM ('UPLOADED', 'VALIDATING', 'VALIDATION_FAILED', 'READY_FOR_APPROVAL', 'APPROVED', 'LOCKED', 'SUPERSEDED');
CREATE TYPE work_state AS ENUM ('PLANNED', 'IN_PROGRESS', 'BLOCKED', 'DELAYED', 'COMPLETED', 'CANCELLED');
CREATE TYPE submission_status AS ENUM ('DRAFT', 'AI_DRAFTED', 'USER_CONFIRMED', 'SUBMITTED', 'RETURNED', 'ACCEPTED', 'LOCKED');
CREATE TYPE report_level AS ENUM ('MEMBER', 'TEAM', 'DEPARTMENT', 'GROUP');
CREATE TYPE report_status AS ENUM ('DRAFT', 'SUBMITTED', 'TEAM_APPROVED', 'DEPT_APPROVED', 'PLANNING_QA', 'READY_FOR_REPORT', 'REPORTED', 'ARCHIVED');
CREATE TYPE approval_decision AS ENUM ('APPROVE', 'RETURN');

CREATE TABLE organization (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  org_code varchar(64) NOT NULL UNIQUE,
  name varchar(200) NOT NULL,
  parent_id uuid REFERENCES organization(id),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1 CHECK (version > 0)
);

CREATE TABLE app_user (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  external_subject varchar(255) NOT NULL UNIQUE,
  employee_code varchar(100) UNIQUE,
  display_name varchar(200) NOT NULL,
  email varchar(320),
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1 CHECK (version > 0)
);

CREATE TABLE role_assignment (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES app_user(id),
  role role_code NOT NULL,
  organization_id uuid NOT NULL REFERENCES organization(id),
  valid_from timestamptz NOT NULL,
  valid_to timestamptz,
  delegated_by uuid REFERENCES app_user(id),
  reason varchar(1000),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role, organization_id, valid_from)
);

CREATE TABLE reporting_cycle (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cycle_code varchar(32) NOT NULL UNIQUE,
  year smallint NOT NULL,
  week smallint NOT NULL CHECK (week BETWEEN 1 AND 53),
  timezone varchar(64) NOT NULL DEFAULT 'Asia/Seoul',
  snapshot_due_at timestamptz NOT NULL,
  member_due_at timestamptz NOT NULL,
  leader_due_at timestamptz NOT NULL,
  department_due_at timestamptz NOT NULL,
  planning_due_at timestamptz NOT NULL,
  state varchar(30) NOT NULL DEFAULT 'OPEN',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1 CHECK (version > 0),
  UNIQUE (year, week)
);

CREATE TABLE metric_definition (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  metric_code varchar(64) NOT NULL UNIQUE,
  name varchar(200) NOT NULL,
  definition text NOT NULL,
  formula text,
  unit varchar(20) NOT NULL,
  aggregation_scope jsonb NOT NULL DEFAULT '{}'::jsonb,
  source_system varchar(100) NOT NULL,
  owner_organization_id uuid NOT NULL REFERENCES organization(id),
  security_label security_label NOT NULL DEFAULT 'CONFIDENTIAL',
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1 CHECK (version > 0)
);

CREATE TABLE evidence (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  evidence_code varchar(80) NOT NULL UNIQUE,
  owner_user_id uuid NOT NULL REFERENCES app_user(id),
  organization_id uuid NOT NULL REFERENCES organization(id),
  file_name varchar(255) NOT NULL,
  content_type varchar(255) NOT NULL,
  size_bytes bigint NOT NULL CHECK (size_bytes > 0),
  sha256 char(64) NOT NULL,
  object_key varchar(1000) NOT NULL,
  object_version varchar(255) NOT NULL,
  security_label security_label NOT NULL,
  scan_status varchar(30) NOT NULL DEFAULT 'PENDING',
  extraction_status varchar(30) NOT NULL DEFAULT 'NOT_STARTED',
  retention_until timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1 CHECK (version > 0)
);
CREATE INDEX ix_evidence_org_created ON evidence(organization_id, created_at DESC);
CREATE UNIQUE INDEX ux_evidence_hash_version ON evidence(sha256, object_version);

CREATE TABLE metric_snapshot (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  snapshot_code varchar(100) NOT NULL UNIQUE,
  metric_definition_id uuid NOT NULL REFERENCES metric_definition(id),
  cycle_id uuid NOT NULL REFERENCES reporting_cycle(id),
  source_evidence_id uuid NOT NULL REFERENCES evidence(id),
  cutoff_at timestamptz NOT NULL,
  snapshot_version integer NOT NULL CHECK (snapshot_version > 0),
  status snapshot_status NOT NULL DEFAULT 'UPLOADED',
  verification_state varchar(20) NOT NULL DEFAULT 'PROVISIONAL',
  supersedes_id uuid REFERENCES metric_snapshot(id),
  approved_by uuid REFERENCES app_user(id),
  approved_at timestamptz,
  locked_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1 CHECK (version > 0),
  UNIQUE (metric_definition_id, cycle_id, snapshot_version)
);

CREATE TABLE metric_snapshot_value (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  snapshot_id uuid NOT NULL REFERENCES metric_snapshot(id),
  dimension_key varchar(500) NOT NULL,
  dimensions jsonb NOT NULL,
  metric_value numeric(24, 8) NOT NULL,
  target_value numeric(24, 8),
  unit varchar(20) NOT NULL,
  quality_flags jsonb NOT NULL DEFAULT '[]'::jsonb,
  source_row_number integer,
  UNIQUE (snapshot_id, dimension_key)
);
CREATE INDEX ix_snapshot_value_dimensions ON metric_snapshot_value USING gin(dimensions);

CREATE TABLE snapshot_validation_issue (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  snapshot_id uuid NOT NULL REFERENCES metric_snapshot(id),
  rule_code varchar(100) NOT NULL,
  severity varchar(20) NOT NULL,
  source_row_number integer,
  field_name varchar(100),
  message text NOT NULL,
  remediation text,
  resolved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE collaboration (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  collaboration_code varchar(80) NOT NULL UNIQUE,
  title varchar(300) NOT NULL,
  goal text NOT NULL,
  lead_organization_id uuid NOT NULL REFERENCES organization(id),
  target_date date,
  status varchar(30) NOT NULL DEFAULT 'ACTIVE',
  security_label security_label NOT NULL DEFAULT 'CONFIDENTIAL',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1 CHECK (version > 0)
);

CREATE TABLE collaboration_participant (
  collaboration_id uuid NOT NULL REFERENCES collaboration(id),
  organization_id uuid NOT NULL REFERENCES organization(id),
  participation_role varchar(30) NOT NULL,
  PRIMARY KEY (collaboration_id, organization_id)
);

CREATE TABLE work_item (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  work_item_code varchar(80) NOT NULL UNIQUE,
  organization_id uuid NOT NULL REFERENCES organization(id),
  owner_user_id uuid NOT NULL REFERENCES app_user(id),
  collaboration_id uuid REFERENCES collaboration(id),
  title varchar(300) NOT NULL,
  objective text NOT NULL,
  state work_state NOT NULL DEFAULT 'PLANNED',
  start_date date,
  target_date date,
  security_label security_label NOT NULL DEFAULT 'CONFIDENTIAL',
  tags jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid NOT NULL REFERENCES app_user(id),
  updated_by uuid NOT NULL REFERENCES app_user(id),
  version integer NOT NULL DEFAULT 1 CHECK (version > 0)
);
CREATE INDEX ix_work_item_owner_state ON work_item(owner_user_id, state);
CREATE INDEX ix_work_item_org_state ON work_item(organization_id, state);

CREATE TABLE work_item_metric (
  work_item_id uuid NOT NULL REFERENCES work_item(id),
  metric_definition_id uuid NOT NULL REFERENCES metric_definition(id),
  PRIMARY KEY (work_item_id, metric_definition_id)
);

CREATE TABLE worklog_entry (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  work_item_id uuid NOT NULL REFERENCES work_item(id),
  author_user_id uuid NOT NULL REFERENCES app_user(id),
  occurred_on date NOT NULL,
  entry_type varchar(30) NOT NULL CHECK (entry_type IN ('FACT', 'RESULT', 'ANALYSIS', 'NEXT', 'RISK', 'DECISION_NOTE')),
  narrative text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1 CHECK (version > 0)
);

CREATE TABLE worklog_evidence (
  worklog_entry_id uuid NOT NULL REFERENCES worklog_entry(id),
  evidence_id uuid NOT NULL REFERENCES evidence(id),
  locator varchar(500),
  PRIMARY KEY (worklog_entry_id, evidence_id)
);

CREATE TABLE weekly_submission (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cycle_id uuid NOT NULL REFERENCES reporting_cycle(id),
  member_user_id uuid NOT NULL REFERENCES app_user(id),
  organization_id uuid NOT NULL REFERENCES organization(id),
  status submission_status NOT NULL DEFAULT 'DRAFT',
  submitted_at timestamptz,
  current_version integer NOT NULL DEFAULT 1 CHECK (current_version > 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1 CHECK (version > 0),
  UNIQUE (cycle_id, member_user_id)
);

CREATE TABLE submission_item (
  submission_id uuid NOT NULL REFERENCES weekly_submission(id),
  work_item_id uuid NOT NULL REFERENCES work_item(id),
  included boolean NOT NULL DEFAULT true,
  inclusion_reason text,
  display_order integer NOT NULL DEFAULT 0,
  PRIMARY KEY (submission_id, work_item_id)
);

CREATE TABLE report (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  report_code varchar(100) NOT NULL UNIQUE,
  cycle_id uuid NOT NULL REFERENCES reporting_cycle(id),
  organization_id uuid NOT NULL REFERENCES organization(id),
  report_level report_level NOT NULL,
  status report_status NOT NULL DEFAULT 'DRAFT',
  current_version integer NOT NULL DEFAULT 1 CHECK (current_version > 0),
  security_label security_label NOT NULL DEFAULT 'CONFIDENTIAL',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid NOT NULL REFERENCES app_user(id),
  updated_by uuid NOT NULL REFERENCES app_user(id),
  version integer NOT NULL DEFAULT 1 CHECK (version > 0),
  UNIQUE (cycle_id, organization_id, report_level)
);

CREATE TABLE report_version (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  report_id uuid NOT NULL REFERENCES report(id),
  version_number integer NOT NULL CHECK (version_number > 0),
  content jsonb NOT NULL,
  content_hash char(64) NOT NULL,
  source_manifest jsonb NOT NULL,
  generated_by_agent_run_id uuid,
  human_edited boolean NOT NULL DEFAULT false,
  created_by uuid NOT NULL REFERENCES app_user(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  locked_at timestamptz,
  UNIQUE (report_id, version_number)
);

CREATE TABLE approval_event (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  resource_type varchar(30) NOT NULL,
  resource_id uuid NOT NULL,
  resource_version integer NOT NULL,
  stage varchar(30) NOT NULL,
  decision approval_decision NOT NULL,
  reason text NOT NULL,
  actor_user_id uuid NOT NULL REFERENCES app_user(id),
  actor_role role_code NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  idempotency_key varchar(200) NOT NULL UNIQUE,
  trace_id varchar(100) NOT NULL
);

CREATE TABLE decision_record (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  decision_code varchar(80) NOT NULL UNIQUE,
  source_report_id uuid REFERENCES report(id),
  title varchar(300) NOT NULL,
  request text NOT NULL,
  status varchar(30) NOT NULL DEFAULT 'REQUESTED',
  decision_maker_user_id uuid REFERENCES app_user(id),
  due_date date,
  resolution text,
  resolved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1 CHECK (version > 0)
);

CREATE TABLE action_item (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  action_code varchar(80) NOT NULL UNIQUE,
  decision_id uuid REFERENCES decision_record(id),
  work_item_id uuid REFERENCES work_item(id),
  owner_user_id uuid REFERENCES app_user(id),
  title varchar(300) NOT NULL,
  due_date date,
  priority varchar(20) NOT NULL DEFAULT 'MEDIUM',
  status varchar(30) NOT NULL DEFAULT 'OPEN',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  version integer NOT NULL DEFAULT 1 CHECK (version > 0)
);

CREATE TABLE agent_run (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  trace_id varchar(100) NOT NULL UNIQUE,
  actor_user_id uuid NOT NULL REFERENCES app_user(id),
  actor_role role_code NOT NULL,
  organization_id uuid NOT NULL REFERENCES organization(id),
  task_type varchar(100) NOT NULL,
  prompt_version varchar(100) NOT NULL,
  model_version varchar(100) NOT NULL,
  input_manifest jsonb NOT NULL,
  output_object_key varchar(1000),
  schema_valid boolean,
  fact_valid boolean,
  policy_valid boolean,
  status varchar(30) NOT NULL,
  latency_ms integer,
  usage jsonb,
  error_code varchar(100),
  created_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz
);

ALTER TABLE report_version
  ADD CONSTRAINT fk_report_version_agent_run
  FOREIGN KEY (generated_by_agent_run_id) REFERENCES agent_run(id);

CREATE TABLE audit_event (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  occurred_at timestamptz NOT NULL DEFAULT now(),
  trace_id varchar(100) NOT NULL,
  actor_user_id uuid REFERENCES app_user(id),
  actor_role role_code,
  organization_id uuid REFERENCES organization(id),
  action varchar(100) NOT NULL,
  resource_type varchar(100) NOT NULL,
  resource_id uuid,
  result varchar(30) NOT NULL,
  policy_code varchar(100),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX ix_audit_time ON audit_event(occurred_at DESC);
CREATE INDEX ix_audit_resource ON audit_event(resource_type, resource_id, occurred_at DESC);
CREATE INDEX ix_audit_actor ON audit_event(actor_user_id, occurred_at DESC);

-- Immutability and authorization are enforced in the application service and
-- should also be reinforced with database roles/RLS or triggers after the
-- corporate DBA selects the production security pattern.

