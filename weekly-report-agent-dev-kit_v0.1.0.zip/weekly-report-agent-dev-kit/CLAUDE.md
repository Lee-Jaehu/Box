# Project Instructions

이 프로젝트는 제조DX 그룹의 AI Readable 주간업무 포털이다. 사용자는 팀원, 팀장, 담당, 기획팀, 그룹장, KPI Data Owner, Admin이다.

## 작업 시작 전

- `README.md`와 `docs/00_document_index.md`를 읽는다.
- 구현 대상과 관련된 요구사항 ID, API, 데이터 엔터티, 권한, 수용기준을 먼저 찾는다.
- 결정되지 않은 사항은 추측하지 말고 `docs/10_decisions_and_open_questions.md`에 질문 또는 ADR로 기록한다.
- 한 번에 하나의 수직 기능 조각만 구현한다.

## 아키텍처 불변조건

- Portal API만 운영 데이터의 System of Record를 변경한다.
- LLM/Copilot은 DB에 직접 쓰거나 승인 상태를 직접 바꾸지 않는다.
- KPI는 승인된 `MetricSnapshot`에서만 인용한다. 값을 계산·보정·추정하지 않는다.
- 보고 문장은 `WorkItem`, `Worklog`, `Evidence`, `MetricSnapshot` ID로 추적 가능해야 한다.
- 상태 변경은 RBAC/ABAC 검사, optimistic lock, idempotency key, audit event를 함께 처리한다.
- 운영 업무파일과 보고 데이터는 Git 저장소에 커밋하지 않는다.
- 모든 외부 연동은 Adapter interface 뒤에 둔다.

## 기본 구현 구조

```text
apps/web/                 Next.js UI
services/api/             FastAPI application
services/worker/          비동기 추출·AI 작업
packages/contracts/       OpenAPI 생성 타입·JSON Schema
packages/prompts/         버전 고정 프롬프트
infra/                    IaC·배포 구성
tests/evals/              Prompt/Agent 평가 데이터
```

실제 프로젝트 구조가 다르면 ADR을 먼저 작성하고 이 문서를 갱신한다.

## 코드 규칙

- TypeScript strict mode, Python type hints를 사용한다.
- API request/response와 Agent output은 스키마로 검증한다.
- 도메인 상태 전이는 service 계층의 명시적 command로만 수행한다.
- 금액·비율·수율은 float 대신 Decimal 또는 고정 정밀 numeric을 사용한다.
- 시간은 DB에서 UTC로 저장하고 화면에서 Asia/Seoul로 표시한다.
- 민감정보, 토큰, 원문 파일 내용, 전체 프롬프트를 로그에 남기지 않는다.
- 에러는 사용자용 메시지와 내부 trace ID를 분리한다.

## 테스트 규칙

- 변경한 기능의 unit, integration, authorization negative test를 작성한다.
- KPI 관련 테스트는 숫자 정확성, 단위, 기준 시각, Snapshot ID를 검증한다.
- 승인 테스트는 무권한, 중복 요청, 동시 수정, 반려 후 재제출을 포함한다.
- Agent 테스트는 hallucinated metric 0, citation coverage, prompt injection 방어를 평가한다.
- 테스트를 실행하지 못했다면 이유와 미검증 범위를 명시한다.

## 변경 완료 보고

- 구현한 요구사항 ID
- 변경 파일
- 마이그레이션/API 영향
- 실행한 테스트와 결과
- 보안·권한 영향
- 남은 위험과 다음 단계

## 금지

- 임시 관리자 우회 권한 추가
- 프론트엔드만의 권한 검사
- 승인 상태를 일반 PATCH로 임의 변경
- 미승인 Snapshot을 확정 수치로 출력
- 출처 없는 서술을 사실로 단정
- 실제 회사 데이터/토큰을 fixture에 포함

