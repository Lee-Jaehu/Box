# Package Manifest

- Package: 제조DX 주간업무 AI Agent 개발 설계 패키지
- Version: 0.1.0
- Baseline date: 2026-08-24
- Status: Development baseline; P0 decisions required before production implementation

## 포함 산출물

- 개발 착수서, 요구사항, 업무 프로세스, 아키텍처
- Agent/Copilot, 데이터/API/UI, 보안/NFR/운영, 시험/전환 설계
- ADR/미결정사항, 공식 참고자료, Claude Code/Copilot 설정 지침
- OpenAPI 3.1 계약, PostgreSQL 논리 DDL, JSON Schema
- 역할별 Runtime Prompt와 Claude Code 10단계 개발 Prompt
- Mermaid 도식, 권한/모델/Copilot 정책 예시, 실무 템플릿

## 사용 전 교체할 Placeholder

- `*.example.internal` endpoint
- IAM issuer/client/audience
- 승인 LLM model ID와 보존 정책
- 회사 내부 Copilot의 제품/API/auth 방식
- Cloud/DB/Object/Queue/Observability 회사 표준
- KPI Metric Catalog, 파일 포맷, validation rule
- 실제 조직/role mapping과 보안등급

