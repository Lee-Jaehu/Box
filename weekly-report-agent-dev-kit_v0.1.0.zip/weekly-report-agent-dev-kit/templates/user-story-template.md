# STORY-AREA-NNN — 제목

## Story

As a [역할], I want [기능], so that [효과].

## Scope

- 포함:
- 제외:
- 관련 REQ/API/Schema:

## Acceptance Criteria

```gherkin
Scenario: 정상
  Given
  When
  Then

Scenario: 권한 없음
  Given
  When
  Then 요청은 거부되고 감사 이벤트가 남는다

Scenario: 동시 수정/중복 요청
  Given
  When
  Then 상태는 정확히 한 번만 전이된다
```

## Definition of Done

- [ ] 코드/문서/API/DB 일치
- [ ] unit/integration/authz negative test
- [ ] security/privacy 검토
- [ ] observability/audit
- [ ] migration/rollback
- [ ] 사용자 문구/접근성

