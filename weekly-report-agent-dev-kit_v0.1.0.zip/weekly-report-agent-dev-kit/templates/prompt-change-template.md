# Prompt Change Request

- Prompt ID/version:
- 변경 이유와 관련 issue/REQ:
- 변경 전/후 요약:
- 영향 역할/보안등급/언어:
- Model/version:

## Risk

- 숫자/ID/citation 영향:
- 의미 보존 영향:
- 권한/민감정보 영향:
- token/latency/cost 영향:

## Evaluation

- Dataset version:
- Baseline vs candidate:
- Deterministic gate:
- Human reviewer/score:
- Regression/failure case:

## Release

- 승인자:
- feature flag/cohort:
- rollout time:
- rollback version/조건:

