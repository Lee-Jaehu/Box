# ADR-NNN — 제목

- 상태: Proposed / Accepted / Superseded / Rejected
- 일자:
- 결정자:
- 관련 요구사항:

## Context

무엇을 결정해야 하고 어떤 제약이 있는가?

## Options

| Option | 장점 | 단점 | 위험/비용 |
|---|---|---|---|
| A | | | |
| B | | | |

## Decision

선택과 이유를 구체적으로 기록한다.

## Consequences

- 긍정:
- 부정/부채:
- 보안·데이터·운영 영향:
- Migration/rollback:
- 재검토 조건:

