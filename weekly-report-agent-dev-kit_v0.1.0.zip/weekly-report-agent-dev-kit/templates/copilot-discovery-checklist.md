# Internal Copilot Integration Discovery

## Product

- 제품명/버전/소유팀:
- 사용자 채널(웹/Teams/IDE 등):
- tenant/environment:
- 운영 SLA/support:

## Identity/Auth

- OAuth2/OIDC/Entra/OBO 지원:
- 사용자 identity claim:
- service-to-service 방식:
- token audience/scope/TTL:
- private network/mTLS:

## API/Agent Capability

- REST/SDK/action/plugin/MCP:
- tool calling/JSON schema:
- citation/deep link:
- streaming/conversation state:
- file attachment:
- max context/payload:
- rate limit/timeout/retry:

## Data/Security

- prompt/response 저장과 보존:
- 모델 학습 사용 여부:
- 데이터 처리 지역:
- security label/DLP:
- 감사로그/trace ID:
- 외부 egress/allowlist:
- prompt injection 지침:

## Decision

- 선택 Adapter:
- 허용 기능: Query / Draft / Action Preview
- 금지 기능:
- technical spike 결과:
- 보안/운영 승인:

