# KPI Data Source Onboarding

## 소유와 범위

- Metric code/name:
- Business owner / Technical owner:
- 공식 정의/산식:
- 단위:
- 집계 주기와 기준 시각:
- 대상 차원(공장/라인/제품/공정 등):
- 원천 시스템/화면:
- 보안등급/외부공유:

## 파일 계약

- 파일 형식/encoding/sheet:
- 파일명 규칙:
- 필수 column과 type:
- unique key:
- null/제외 규칙:
- 예상 행 수/크기:
- 다운로드 담당/일시:
- 샘플 파일 위치(운영 데이터는 Git 금지):

## Validation

- 값 범위:
- 단위 검증:
- 중복/누락:
- 전주 대비 급변 기준:
- 총계 reconciliation:
- 잠정/확정 판단:
- 오류 시 담당/처리시간:

## 승인·정정

- 승인자:
- 마감:
- 정정 사유/절차:
- 과거 보고 재현 요구:

