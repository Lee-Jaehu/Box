# 데이터·API·화면 설계서

## 1. 데이터 저장 원칙

| 저장소 | 저장 대상 | 저장하지 않는 것 |
|---|---|---|
| RDBMS | 사용자/조직, 주기, Metric/Snapshot, WorkItem/Worklog, 보고 version, 승인, audit | 대용량 원본 파일 |
| Object Storage | 업로드 원본, Evidence, 추출 산출물, export | 권한·workflow 기준 상태 |
| Search/Vector | 권한이 부여된 승인 추출문, report index | 기준 수치·승인 상태 |
| GitHub | 코드, schema, prompt, template, IaC | 개인 업무·KPI·보고서 운영 데이터 |

## 2. 핵심 엔터티

| 엔터티 | business key/핵심 필드 | 관계 |
|---|---|---|
| Organization | `org_code`, parent | User/WorkItem/Report scope |
| RoleAssignment | user, role, org, valid_from/to | ABAC context |
| ReportingCycle | year/week, deadlines, state | Snapshot/Submission/Report |
| MetricDefinition | `metric_code`, formula, unit, owner | SnapshotValue |
| MetricSnapshot | `snapshot_code`, cycle, cutoff, version, status | file/value/report reference |
| WorkItem | `work_item_code`, owner, state, objective | Worklog/Evidence/Submission |
| WorklogEntry | occurred_on, type, narrative | WorkItem |
| Evidence | `evidence_code`, object key, hash, label | Worklog/Report citation |
| Collaboration | `collaboration_code`, lead org, goal | participating WorkItems |
| Submission | cycle, member, selected items, version, state | Team report source |
| Report | `report_code`, level, org, cycle, status | ReportVersion/Approval |
| ReportVersion | content JSON, source links, created_by | immutable when approved |
| ApprovalEvent | stage, decision, reason, signer | Report/Submission |
| Decision | `decision_code`, requester, due, status | Report/ActionItem |
| ActionItem | `action_code`, owner, due, status | Decision/WorkItem |
| AgentRun | task, versions, inputs, validation | Draft/ReportVersion |
| AuditEvent | actor, action, resource, result, trace | all sensitive actions |

물리 초안은 `db/schema.sql`, 교환 스키마는 `schemas/`를 참고합니다.

## 3. ID와 Code 규칙

- 내부 PK는 UUID이며 사용자가 직접 입력하지 않습니다.
- 업무에서 읽는 code는 `PREFIX-ORG-YYYY-NNNN` 또는 규격별 형식을 사용합니다.
- 예시: `WI-RSND-2026-0032`, `COL-YIELD-2026-0014`, `DEC-RSND-2026-0008`.
- Snapshot code는 `SNP-{METRIC}-{YYYY}-W{WW}-{NNN}` 예: `SNP-PD-2026-W33-017`.
- Evidence code는 `EVD-{ORG}-{YYYY}-W{WW}-{NNN}`.
- Code는 분류·참조용이며 보안 권한을 뜻하지 않습니다. 모든 조회는 UUID와 authorization으로 검증합니다.
- 삭제된 code를 재사용하지 않습니다.

## 4. API 원칙

- REST/JSON, `/v1`, OpenAPI-first를 사용합니다.
- 모든 요청은 `Authorization`, 상태 변경은 `Idempotency-Key`, version 충돌 방지는 `If-Match`를 사용합니다.
- list API는 cursor pagination과 organization/cycle/state filter를 제공합니다.
- 오류는 RFC 9457 Problem Details 형태와 `code`, `traceId`, `remediation`을 가집니다.
- 파일은 pre-signed URL로 직접 업로드하고 완료 callback에서 hash와 scan을 검증합니다.
- 승인/반려는 일반 update가 아닌 command endpoint입니다.

주요 endpoint는 `api/openapi.yaml`에 정의합니다.

## 5. 화면 구조

### 공통

- 상단: 보고 주차, 역할 전환, 조직 scope, 마감, 알림
- 좌측: 내 업무, 제출함, 팀/담당 보고, KPI Snapshot, Decision/Action, 관리
- 우측/Drawer: AI assistant, 출처, 변경 diff
- 모든 AI 문장에는 출처 열기와 `AI 생성/사람 수정` 표시를 제공합니다.

### UI-01 홈/업무함

- 역할별 해야 할 일, 마감 임박, 반려, 검증 실패를 표시합니다.
- Agent 실행보다 사람이 처리해야 할 상태를 먼저 보여줍니다.

### UI-02 KPI Snapshot 업로드

- 1단계 파일 선택 → 2단계 컬럼 매핑 → 3단계 Validation → 4단계 승인/잠금.
- 오류 행 다운로드와 이전 Snapshot diff를 제공합니다.
- 값, 단위, 차원, 기준 시각, 잠정/확정 상태를 동시에 확인합니다.

### UI-03 내 업무 이력

- WorkItem별 timeline, 빠른 메모, 결과/분석/계획/리스크 분류, 파일 첨부.
- 관련 KPI와 Collaboration을 검색 연결합니다.
- 주간 제출 후보를 checkbox로 선택합니다.

### UI-04 팀원 제출 편집

- 좌: 선택 Worklog/Evidence, 중: AI 초안/편집, 우: 출처/검증.
- `FACT/RESULT/ANALYSIS/NEXT/RISK/DECISION` 블록을 유지합니다.
- 출처 누락·미승인 KPI·민감정보는 제출 전 해결 또는 사유가 필요합니다.

### UI-05 팀장 보고 편집

- 팀원별 제출 원문과 팀장 서술형 초안을 나란히 보여줍니다.
- 서술형 문장을 과도하게 축약하지 않고 문단 상단 또는 margin에 WorkItem/KPI/Collaboration/Decision code를 보강합니다.
- 포함/제외 항목, AI 변경, 팀장 변경, 이전 주 대비를 diff합니다.
- 그룹장 관점의 핵심결과, 이유, 다음조치, 의사결정 요청을 유지합니다.

### UI-06 담당/기획 QA

- 팀/담당 상태 matrix, 동일 협업 묶음, KPI 불일치, 출처 누락, 미결정/지연 Action.
- 승인/반려 사유 template와 일괄 검토 기능을 제공합니다. 일괄 승인은 개별 항목 검증 결과를 기록합니다.

### UI-07 그룹장 보고/Q&A

- 담당별 핵심 변화, KPI, 지연·영향, Decision/Request를 우선 표시합니다.
- 클릭하면 팀원 원문→WorkItem→Evidence/Snapshot으로 drill-down합니다.
- 질문 답변의 citation과 freshness를 표시합니다.

### UI-08 운영 관리

- 조직/role, reporting calendar, prompt/template/model version, Metric Catalog, validation rule, audit search.
- 운영자가 prompt 내용을 바로 고치는 대신 승인된 version을 배포하도록 합니다.

## 6. 접근성·사용성

- 색상만으로 상태를 구분하지 않고 label/icon/text를 함께 씁니다.
- keyboard navigation, focus, contrast, 표 header, screen-reader label을 제공합니다.
- autosave는 draft에만 적용하며 제출/승인은 명시적 확인이 필요합니다.
- 긴 AI 작업은 job 상태와 취소/재시도를 보여줍니다.

