# 보안·비기능·운영 설계서

## 1. 보안 모델

### 인증과 권한

- OIDC SSO, MFA는 사내 정책을 따릅니다.
- Portal API는 access token의 issuer, audience, signature, expiry를 검증합니다.
- 권한은 `role + org ancestry + resource owner + cycle + state + label`로 평가합니다.
- service account는 workload identity와 최소 scope를 사용하고 공유 계정을 금지합니다.
- 승인자는 재인증 또는 step-up 인증 정책을 선택할 수 있습니다.

### 데이터 등급

| 등급 | 예 | AI/Copilot 처리 |
|---|---|---|
| INTERNAL | 일반 업무 계획 | 승인된 사내 endpoint에서 가능 |
| CONFIDENTIAL | 수율, 불량, 설비·공정 상세 | 최소 context, 권한/보존/지역 확인 후 가능 |
| RESTRICTED | 고객식별, 핵심 recipe, 보안 비밀 | 기본 차단; 별도 승인/전용 모델 필요 |

파일과 report에는 security label을 상속하고, 파생 문서는 원천 중 가장 높은 등급을 기본값으로 사용합니다.

### 위협과 대응

| 위협 | 대응 |
|---|---|
| Prompt injection | untrusted delimiter, tool allowlist, server-side argument validation |
| 권한 넘는 검색 | query-time ACL filter, negative tests, no client filter reliance |
| KPI hallucination | approved Snapshot only, deterministic exact-match validator |
| 과도한 Agent 권한 | read/draft only, action preview + portal confirm |
| 파일 악성코드/폭탄 | quarantine, MIME/size/decompression limits, malware scan |
| 데이터 유출 | DLP, redaction, egress allowlist, no secrets, retention contract |
| 승인 우회 | command endpoint, SoD, version/idempotency, immutable audit |
| 공급망 공격 | lockfile, SCA/SAST, SBOM, signed image, protected branch |
| 로그 유출 | structured redaction, payload sampling 금지, restricted audit access |

## 2. 비기능 요구사항

수치는 PoC baseline이며 load test 후 확정합니다.

| ID | 항목 | 목표 |
|---|---|---|
| NFR-AVL-001 | Portal 월 가용성 | 99.5% 이상 |
| NFR-PER-001 | 일반 API p95 | 1초 이내 |
| NFR-PER-002 | 목록/검색 p95 | 2초 이내 |
| NFR-AI-001 | AI draft p95 | 60초 이내, 비동기 진행 표시 |
| NFR-SCL-001 | 동시 사용자 | PoC 100명, 확장 시험 500명 |
| NFR-FIL-001 | 파일 한도 | 기본 50MB, 정책화 |
| NFR-RPO-001 | RPO | 24시간 이하, 승인 주간에는 강화 검토 |
| NFR-RTO-001 | RTO | 4시간 이하 |
| NFR-SEC-001 | 전송/저장 암호화 | TLS 1.2+, 관리형 KMS |
| NFR-AUD-001 | 감사 조회 | trace ID, actor, resource, 기간 검색 |
| NFR-LOC-001 | 시간/언어 | DB UTC, 화면 Asia/Seoul, ko-KR 우선 |

## 3. 관측성

- OpenTelemetry trace로 Browser request → API → Worker → LLM/Copilot 호출을 연결합니다.
- 주요 metric: 로그인 실패, API latency/error, queue depth, file validation failure, Agent success/schema repair, fact validation failure, token/비용, approval lead time.
- log에는 `trace_id`, `actor_pseudonym`, `org_id`, `operation`, `resource_id`, `result`, `policy_code`를 남깁니다.
- 보안 이벤트는 SIEM 연동을 고려하고 반복적인 권한 거부·대량 다운로드·prompt injection을 경보합니다.

## 4. 운영 Runbook

### 일간

- 배치/queue 실패, 저장소 용량, API/LLM/Copilot 오류율 확인
- malware scan 또는 extraction 격리 항목 확인
- 보고 마감 기간에는 제출/승인 backlog와 알림 확인

### 주간

- Snapshot upload/approval 완료와 validation 예외 검토
- Agent 숫자/출처 검증 실패 샘플 검토
- 사용자 반려 사유와 AI 수정률 분석

### 월간

- 권한 재검토, 휴면 계정, 대리 승인 만료
- Prompt/Model 성능·비용·안전성 trend
- 복구 훈련, vulnerability/SBOM, retention job 결과

### 장애 우선순위

| 등급 | 예 | 목표 대응 |
|---|---|---|
| SEV1 | 데이터 유출, 권한 우회, 승인 데이터 손상 | 즉시 Agent/Copilot 차단, 보안/운영 호출 |
| SEV2 | 제출/승인 불가, Snapshot 손상 | 수동 workflow 전환, 1시간 내 대응 |
| SEV3 | AI 초안 실패, Copilot 장애 | Portal 수동 작성 유지, 영업일 대응 |
| SEV4 | UI/개별 데이터 오류 | backlog 처리 |

## 5. Backup/복구

- RDBMS point-in-time recovery, Object Storage versioning, 설정/프롬프트 Git tag를 사용합니다.
- 복구 시 ReportVersion이 참조한 Snapshot/Evidence version의 일관성을 검증합니다.
- Agent index는 RDBMS/Object로 재생성 가능해야 하며 기준 원본이 아닙니다.
- Copilot session은 복구 필수 데이터가 아니며 Portal record와 audit가 기준입니다.

## 6. DevSecOps

- protected branch, PR 2인 검토(보안/Prompt 변경은 지정 reviewer), signed release.
- CI: lint → unit → contract → SAST/SCA/secret scan → image scan → integration → eval gate.
- CD: dev 자동, stage 승인, prod change ticket/승인, canary 또는 blue-green.
- DB migration은 forward/backward compatibility와 rollback/roll-forward 절차를 가집니다.
- Prompt/Model rollout은 feature flag와 cohort로 분리하고 기존 version 즉시 복귀가 가능해야 합니다.

