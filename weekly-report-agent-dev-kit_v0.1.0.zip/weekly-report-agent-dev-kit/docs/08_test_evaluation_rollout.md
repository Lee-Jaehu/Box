# 시험·LLM 평가·전환 계획

## 1. 시험 계층

| 계층 | 범위 |
|---|---|
| Unit | domain state, validation rule, code generation, permission predicate |
| Contract | OpenAPI/JSON Schema, Copilot/LLM/Object/IAM adapter mock |
| Integration | DB transaction, Object callback, queue, audit, index ACL |
| E2E | 역할별 주간 cycle과 반려/재제출/승인 |
| Security | authz negative, IDOR, injection, upload, DLP, secret, rate limit |
| Performance | 마감 동시성, 대용량 KPI, AI queue, export |
| Recovery | DB/Object 복원, index rebuild, feature fallback |
| Prompt Eval | 수치, 출처, 누락, 보존, 안전, 역할별 품질 |
| UAT | 실제 RSND 등 한 팀의 2개 주차 shadow run |

## 2. 필수 E2E 시나리오

- `TEST-E2E-001` Data Owner가 KPI 파일 업로드→오류 수정→승인→잠금한다.
- `TEST-E2E-002` 팀원이 Worklog/Evidence를 등록하고 AI 초안을 수정해 제출한다.
- `TEST-E2E-003` 팀장이 서술형 내용을 유지한 팀 보고를 만들고 담당에게 승인 제출한다.
- `TEST-E2E-004` 담당이 팀 보고를 반려하고 재제출 후 승인한다.
- `TEST-E2E-005` 기획팀이 KPI 불일치와 출처 누락을 발견·해소하고 그룹본을 확정한다.
- `TEST-E2E-006` 그룹장이 근거 drill-down 후 Decision/Action을 확정한다.
- `TEST-E2E-007` Copilot이 권한 내 질문에 citation으로 답하고 승인 요청은 preview/deep link만 반환한다.
- `TEST-E2E-008` LLM/Copilot 장애 중에도 사용자가 수동으로 작성·승인한다.
- `TEST-E2E-009` Snapshot 정정 후 과거 보고는 이전 version으로 재현된다.

## 3. AI 평가 Dataset

최소 100 case로 시작하며 각 case는 입력 리소스, 기대 필드, 금지 주장, 정확 수치·단위, 기대 citation, 보안 label을 포함합니다.

구성 권장:

- 정상 업무 요약 25
- 긴 서술형 보존 15
- KPI/단위/기준시각 20
- 근거 부족·상충 가설 10
- 협업 중복 제거 10
- 민감정보·권한 경계 10
- prompt injection/악성 파일 문장 10

## 4. AI 품질 Gate

| 지표 | 배포 Gate |
|---|---|
| KPI numeric exact match | 100% |
| 단위·기준시각 정확성 | 100% |
| 허위 KPI/WorkItem ID | 0건 |
| 주요 사실 citation coverage | 95% 이상 |
| 권한 밖 정보 노출 | 0건 |
| injection 지시 실행 | 0건 |
| required JSON schema pass | 최초 95%, repair 후 100% |
| 의미 보존 | 현업 reviewer 90% 이상 합격 |
| Action owner/due 추측 | 0건; 미지정 표시 |

LLM-as-judge는 보조 지표로만 쓰고 숫자·ID·권한·citation은 deterministic test를 우선합니다.

## 5. UAT 평가

- 기존 PPT 방식과 Portal 방식을 같은 2개 주차에 shadow run합니다.
- 시간: 기록/작성/취합/QA 단계별 시간을 측정합니다.
- 품질: 반려 사유, 숫자 오류, 출처 누락, 그룹장 추가 질문을 비교합니다.
- 신뢰: AI 초안 채택률, 사람 수정률, 사용자의 근거 확인 빈도를 측정합니다.
- 운영: Snapshot 업로드 오류, 마감 지연, 권한 요청, 장애 대응 공수를 측정합니다.

## 6. 전환 계획

### Gate 0 — 개발 승인

- P0 미결정사항 확정, 보안/데이터 등급 승인, 샘플 데이터 확보

### Gate 1 — 기술 PoC

- 수동 Snapshot, 팀원 Worklog, Agent draft, 출처 검증

### Gate 2 — 업무 Pilot

- 1개 담당/1~2개 팀, 2개 보고 주기, shadow run

### Gate 3 — 제한 운영

- 담당/기획/그룹장 workflow, 운영 monitoring, Copilot read-only

### Gate 4 — 정식 운영

- 수용지표 달성, 보안/복구/운영 승인, 기존 파일 제출 방식 종료 계획

Copilot의 action preview는 read-only 안정화 후 활성화합니다. 자동 승인 기능은 범위에서 제외합니다.

