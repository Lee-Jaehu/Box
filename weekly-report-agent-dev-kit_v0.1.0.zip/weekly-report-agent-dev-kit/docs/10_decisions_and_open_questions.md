# Architecture Decision 및 미결정사항

## 1. 먼저 확정할 P0 질문

개발 착수 전에 아래 질문의 owner와 due date를 지정합니다.

| ID | 질문 | 기본 제안 | 결정 주체 |
|---|---|---|---|
| OQ-001 | 회사 내부 Copilot의 정확한 제품/API는? | Adapter로 개발 후 제품별 구현 | IT/AI 플랫폼 |
| OQ-002 | 사내 LLM Gateway endpoint/model/보존 정책은? | approved model allowlist | AI 플랫폼/보안 |
| OQ-003 | Cloud·region·private network 기준은? | 사내 표준 landing zone | 인프라/보안 |
| OQ-004 | IAM/OIDC claim에 조직·직책이 있는가? | 별도 org sync table 허용 | IAM/HR |
| OQ-005 | KPI 파일 포맷·owner·기준일·단위·차원은? | Metric별 onboarding sheet | Data Owner |
| OQ-006 | 업무파일 허용 형식/크기/보존기간은? | Office/PDF/CSV, 50MB | 보안/운영 |
| OQ-007 | 수율/BM/PD 등 보안등급과 LLM 처리 허용범위는? | CONFIDENTIAL 기본 | Data/보안 |
| OQ-008 | GitHub Enterprise/Actions/Packages 사용 가능한가? | source only, 운영데이터 금지 | DevOps/보안 |
| OQ-009 | 승인에 전자서명/재인증이 필요한가? | 담당 이상 step-up 검토 | 기획/감사 |
| OQ-010 | PPTX export가 MVP 필수인가? | HTML/PDF 우선, PPTX 단계화 | 기획/그룹장 |

## 2. ADR 제안

### ADR-001 Portal 중심 custom orchestration

- 상태: Proposed
- 결정: Copilot 자체를 workflow system으로 쓰지 않고 Portal API와 Agent Orchestrator를 기준으로 한다.
- 이유: 다단계 승인, snapshot immutability, 감사, 제품 독립성이 필요하다.
- 결과: Copilot은 채널/assistant이고 변경은 Portal confirm을 거친다.

### ADR-002 Manual Snapshot First

- 상태: Accepted for MVP
- 결정: KPI는 기준일 파일 업로드와 Data Owner 승인으로 수집한다.
- 이유: 분석 시스템 API 미연계 상태에서 재현성과 통제를 확보한다.
- 결과: 향후 API connector도 동일 Snapshot ingestion contract를 사용한다.

### ADR-003 GitHub is not operational storage

- 상태: Accepted
- 결정: GitHub에는 코드·스키마·프롬프트·템플릿만 둔다.
- 이유: 권한/transaction/retention/대용량 파일과 운영 DB 요구에 부적합하다.
- 결과: 업무 이력은 RDBMS, 파일은 Object Storage에 둔다.

### ADR-004 Modular monolith for PoC

- 상태: Proposed
- 결정: Portal API를 도메인 모듈로 분리하되 PoC는 소수 배포 단위로 시작한다.
- 이유: 팀 규모와 운영 복잡도를 낮추면서 계약 경계는 유지한다.
- 재검토 조건: 독립 확장/배포, 조직 소유권, 장애 격리가 실제 병목이 될 때.

### ADR-005 LLM has no approval tool

- 상태: Accepted
- 결정: LLM/Copilot tool set에서 submit/approve/return을 제외한다.
- 이유: prompt injection, 오동작, 책임소재 위험을 줄인다.
- 결과: action preview와 Portal deep link만 제공한다.

## 3. Copilot 선택 기준

| 기준 | 가중치 | 확인 방법 |
|---|---:|---|
| 사내 인증과 사용자 위임 | 20 | 토큰/claim PoC |
| 보안·보존·데이터 위치 | 20 | 계약/보안 검토 |
| API/tool/MCP와 structured output | 15 | technical spike |
| 권한 기반 citation | 15 | negative test |
| Teams/업무 채널 사용성 | 10 | UAT |
| 감사·trace | 10 | log 연계 PoC |
| 비용·rate limit·운영 | 10 | 부하/비용 추정 |

점수와 무관하게 권한 우회, 데이터 학습 사용 불명확, 감사 불가능이면 탈락 조건으로 둡니다.

