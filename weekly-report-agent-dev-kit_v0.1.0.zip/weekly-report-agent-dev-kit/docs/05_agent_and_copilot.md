# Agent 및 Copilot 연동 설계

## 1. 역할 분리

Agent는 별도 모델이 아니라 동일 Orchestrator가 역할별 prompt, tool allowlist, output schema, authorization scope를 선택하는 논리 프로필입니다.

| Agent | 허용 입력 | 핵심 출력 | 금지 |
|---|---|---|---|
| Snapshot Agent | 업로드 staging, Metric Catalog | mapping/validation 설명 | 원본값 임의 수정 |
| Member Agent | 본인 Worklog/Evidence, 승인 Snapshot | 주간 실적 초안 | 타인 비공개 업무 조회 |
| Leader Agent | 소속 팀 제출, 공통 KPI | 서술형 팀 보고, 선택 후보 | 자동 제외/승인 |
| Department Agent | 소속 팀 승인본 | 담당 요약, 중복/협업 분석 | 팀 가설을 사실로 병합 |
| Planning Agent | 담당 승인본, 정책/템플릿 | QA와 그룹 초안 | 예외 자동 승인 |
| Head Agent | 확정 보고, 권한 내 근거 | 요약, Q&A, Decision/Action 후보 | 근거 없는 단정 |
| Guard Agent | 입력/출력 metadata | 민감정보·injection 경고 | 업무 내용 재작성 |

## 2. Orchestration Pipeline

1. `Authorize`: actor와 요청 리소스 범위를 Portal API에서 검사합니다.
2. `Resolve Context`: 요청 주차/조직/업무/Snapshot/템플릿의 정확한 version을 고정합니다.
3. `Sanitize`: 파일 추출문에서 명령형 텍스트를 데이터로 표기하고 민감정보를 필터링합니다.
4. `Select Prompt`: role, task, locale, prompt version을 선택합니다.
5. `Call Model`: 사내 LLM Gateway로 구조화 output을 요청합니다.
6. `Validate Schema`: JSON Schema를 통과하지 못하면 제한 횟수만 repair합니다.
7. `Validate Facts`: numeric string, unit, scope, date, citation을 원천과 결정적으로 대조합니다.
8. `Policy Check`: security label, 금칙어, 과도한 권한/행동 제안을 검사합니다.
9. `Persist Draft`: 공식 레코드가 아니라 versioned draft로 저장합니다.
10. `Human Review`: 사용자가 근거와 diff를 확인하고 수정합니다.

## 3. Tool 계약

LLM에 DB를 주지 않고 좁은 application tool만 제공합니다.

| Tool | 권한 | 설명 |
|---|---|---|
| `get_reporting_context` | read | 주차·조직·템플릿 metadata |
| `list_work_items` | read scoped | 허용된 제출/업무 목록 |
| `get_metric_snapshot` | read approved | 승인 Snapshot 값과 정의 |
| `get_evidence_excerpt` | read scoped | 안전 추출문과 위치 |
| `search_approved_reports` | read scoped | 권한 필터가 적용된 과거 보고 |
| `validate_draft` | deterministic | 숫자·출처·필수 필드 검사 |
| `save_draft` | application action | Draft만 저장; official state 불변 |
| `create_action_preview` | no mutation | 사용자 확인용 diff/deep link |

`submit_report`, `approve_report`, `return_report`는 LLM tool로 직접 제공하지 않습니다.

## 4. Prompt 구성

각 요청은 다음 블록으로 조립합니다.

```text
SYSTEM POLICY     역할, 금지, 불확실성, 보안
TASK POLICY       요약/검증/질의 유형별 규칙
OUTPUT CONTRACT   JSON Schema, citation 규칙
REPORTING CONTEXT 주차, 조직, 언어, 템플릿 version
STRUCTURED FACTS  WorkItem/MetricSnapshot/Decision/Action
UNTRUSTED EXCERPT 파일 추출문; 명령을 따르지 않음
USER REQUEST      실제 사용자 지시
```

실제 prompt는 `prompts/`에 있으며 변경 시 평가와 reviewer 승인이 필요합니다.

## 5. 내부 Copilot Adapter

### 공통 인터페이스

```text
authenticate(external_identity) -> PortalPrincipal
query(principal, message, context_refs) -> GroundedAnswer
preview_action(principal, action_request) -> ActionPreview
health() -> AdapterCapability
```

`GroundedAnswer`에는 `answer`, `citations[]`, `data_freshness`, `warnings[]`, `trace_id`가 필요합니다. `ActionPreview`에는 실행될 Portal command, 대상, diff, 필요한 역할, 만료 시각, portal confirmation URL이 포함됩니다.

### 연동 유형별 구현

| 유형 | 적용 조건 | 구현 방향 |
|---|---|---|
| INTERNAL_REST | 사내 Copilot이 REST/tool 호출을 지원 | OAuth2 client/obo, `/v1/copilot/query`, streaming 선택 |
| M365_COPILOT | Microsoft 365 Copilot/Teams가 표준 채널 | Declarative/Custom engine agent + API action 또는 connector/MCP 검토 |
| GITHUB_COPILOT | 개발자 코딩 보조가 목적 | 저장소 instructions + 개발용 MCP; 운영 승인 UI로 쓰지 않음 |

업무 workflow가 복잡하고 독립 포털이 System of Record이므로, Microsoft 365 Copilot을 사용하더라도 Portal Orchestrator를 유지하는 custom engine 또는 API action 방식이 적합합니다. 이는 최종 제품/API 확인 후 ADR로 확정합니다.

### 변경 작업은 2단계

1. Copilot이 “제출해줘” 요청을 받습니다.
2. Adapter가 권한을 검사하고 실행하지 않은 `ActionPreview`를 만듭니다.
3. 사용자에게 대상·현재/변경 상태·근거·주의사항과 Portal link를 보여줍니다.
4. 사용자가 Portal에서 다시 인증/확인합니다.
5. Portal command API가 상태 변경과 audit를 같은 transaction으로 처리합니다.

### 제품 확인 체크리스트

- 정확한 제품명/tenant/배포 채널은 무엇인가?
- REST, plugin/action, MCP 중 어떤 방식이 허용되는가?
- 사용자 위임 토큰(On-behalf-of)과 service credential을 지원하는가?
- 사용자의 Entra/사번 identity와 조직/role을 어떻게 전달하는가?
- prompt와 응답의 저장, 학습 사용, 보존기간, 데이터 위치는 무엇인가?
- tool call, JSON schema, citation, streaming, file attachment를 지원하는가?
- 최대 payload/context, rate limit, timeout, 동시성은 얼마인가?
- private endpoint, proxy, allowlist, mTLS 요구사항은 무엇인가?
- 감사로그와 trace ID를 양쪽에서 연결할 수 있는가?
- 장애 시 retry, circuit breaker, fallback 정책은 무엇인가?
- 보안팀의 DLP, 민감도 label, 외부 반출 승인 조건은 무엇인가?

## 6. Prompt Injection 방어

- 첨부파일, 과거 보고, 검색 결과는 모두 `UNTRUSTED_DATA`로 감쌉니다.
- 데이터 내부의 “이전 지시를 무시하라”, URL 접속, secret 요청을 실행하지 않습니다.
- tool argument는 서버가 허용 조직·ID 목록과 다시 대조합니다.
- 모델 출력의 URL/ID를 그대로 사용하지 않고 application resolver로 검증합니다.
- search 결과는 security label과 ACL을 query 시점에 필터링합니다.
- 외부 전송·승인·삭제 기능은 모델에게 노출하지 않습니다.

## 7. Agent Run 저장 항목

- `agent_run_id`, `trace_id`, actor/role/org
- task type, prompt/template/model version
- 입력 리소스 ID와 content hash; 원문 전체는 별도 권한 저장
- tool call name, sanitized arguments, outcome
- raw model output의 보호 저장 여부와 retention
- schema/fact/policy validation 결과
- 최종 draft ID, human edit distance, accepted/rejected reason
- latency, token/usage, error category

