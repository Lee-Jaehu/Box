# 요구사항 정의서

## 1. 역할

| 역할 코드 | 역할 | 핵심 권한 |
|---|---|---|
| MEMBER | 팀원 | 본인 Worklog 작성, 제출 항목 선택, 팀장 제출 |
| LEADER | 팀장 | 소속 팀 제출 열람, 팀 보고 초안·수정·승인/반려 |
| DEPT | 담당 | 소속 팀 보고 검토, 담당 보고 승인/반려 |
| PLANNING | 기획팀 | 전체 담당본 QA, 그룹 보고 초안·승인 요청 |
| HEAD | 그룹장 | 최종 열람, 질문, 결정, 후속조치 지정 |
| DATA_OWNER | KPI Data Owner | Metric 정의·Snapshot 업로드/승인/정정 |
| ADMIN | 운영자 | 조직·권한·주기·템플릿 설정, 운영 감사 |

권한은 역할만으로 결정하지 않고 `Role × Organization Scope × Reporting Cycle × Resource State × Security Label`을 함께 검사합니다.

## 2. 기능 요구사항

### 인증·조직

- `REQ-IAM-001` 사용자는 회사 SSO로 로그인해야 한다.
- `REQ-IAM-002` API는 서버에서 조직 범위와 역할을 검사해야 한다.
- `REQ-IAM-003` 대리 승인과 관리자 권한은 기간·사유·감사 이력을 가져야 한다.
- `REQ-IAM-004` 퇴직·이동·권한 회수는 다음 로그인 이전에 반영되어야 한다.

### 보고 주기

- `REQ-CYC-001` Admin은 주차별 수집 시작, Snapshot 마감, 팀원 제출, 팀장 승인, 담당 승인, 기획 확정 시각을 설정한다.
- `REQ-CYC-002` 마감 후 변경은 권한과 사유가 필요하며 모두 기록한다.
- `REQ-CYC-003` 휴일 또는 특별 주차는 별도 calendar policy를 적용한다.

### KPI Snapshot

- `REQ-SNP-001` Data Owner는 CSV/XLSX를 업로드하고 Metric, 기간, 조직/라인/제품 차원을 매핑한다.
- `REQ-SNP-002` 시스템은 파일 형식, 필수 컬럼, 중복키, 단위, 값 범위, 기준 시각, 전주 급변을 검증한다.
- `REQ-SNP-003` 승인된 Snapshot은 잠기며 수정 대신 새 버전으로 정정한다.
- `REQ-SNP-004` 보고서에서 사용한 Snapshot 버전은 이후 정정되어도 재현 가능해야 한다.
- `REQ-SNP-005` `PROVISIONAL` 값은 잠정으로 표시하고 그룹 보고 확정 정책에 따라 차단 또는 경고한다.

### 업무 이력·증빙

- `REQ-WRK-001` 팀원은 업무를 WorkItem으로 만들고 매일 Worklog를 기록할 수 있다.
- `REQ-WRK-002` WorkItem은 business code, 제목, 목표, 상태, owner, 기간, KPI, collaboration, 보안등급을 가진다.
- `REQ-WRK-003` 파일을 Evidence로 업로드하고 검사·추출 결과와 원본 hash를 보존한다.
- `REQ-WRK-004` 팀원은 주차에 포함할 실적을 선택하고 AI 초안을 생성한다.
- `REQ-WRK-005` AI 초안은 FACT/RESULT/ANALYSIS/NEXT/RISK/DECISION을 구분하고 출처 ID를 표시한다.
- `REQ-WRK-006` 팀원은 초안을 수정·확정하고 팀장에게 제출한다.

### 협업 업무

- `REQ-COL-001` 여러 팀이 참여하는 안건은 하나의 Collaboration ID로 연결한다.
- `REQ-COL-002` 공통 목표·KPI·결정은 공유 레코드에, 조직별 기여는 각 WorkItem에 저장한다.
- `REQ-COL-003` 팀장 이상 요약에서는 같은 협업 안건을 중복 출력하지 않고 조직별 기여를 하위에 표시한다.

### 팀장·담당·기획·그룹장

- `REQ-RPT-001` 팀장은 제출된 항목을 선택·제외하고 이유를 기록할 수 있다.
- `REQ-RPT-002` 팀장 AI 초안은 기존 서술형 정보량을 보존하고 ID·근거·상태를 보강해야 한다.
- `REQ-RPT-003` 보고서 편집 시 AI 작성문과 사람 수정 내용을 version diff로 남긴다.
- `REQ-RPT-004` 각 승인자는 승인 또는 반려 사유를 기록하며 하위 승인 상태를 우회할 수 없다.
- `REQ-RPT-005` 기획팀은 KPI 불일치, 출처 누락, 중복 협업, 미종결 Decision/Action을 QA한다.
- `REQ-RPT-006` 그룹장은 보고 문장별 근거를 열람하고 질문·결정·Action을 기록할 수 있다.
- `REQ-RPT-007` 확정 보고서는 불변 버전으로 보관하고 권한에 따라 export한다.

### Agent/LLM

- `REQ-AI-001` 모든 Agent run은 actor, role, organization, input reference, prompt/model version, output, 검증결과, latency, cost/usage, trace ID를 기록한다.
- `REQ-AI-002` Agent는 허용된 주차·조직·문서 범위만 조회한다.
- `REQ-AI-003` 수치 문장은 승인 Snapshot의 value/unit/scope/cutoff와 정확히 일치해야 한다.
- `REQ-AI-004` 근거가 없으면 `근거 부족` 또는 `확인 필요`로 출력하고 내용을 만들지 않는다.
- `REQ-AI-005` 초안 저장은 별도 draft이며 공식 제출/승인으로 간주하지 않는다.
- `REQ-AI-006` 프롬프트와 output schema는 버전 관리하고 배포 전 평가를 통과해야 한다.

### Copilot

- `REQ-COP-001` Copilot Adapter는 제품별 인증과 payload를 공통 계약으로 변환한다.
- `REQ-COP-002` Copilot은 사용자 권한으로 조회하고 출처 링크를 반환한다.
- `REQ-COP-003` 제출·승인·반려 요청은 실행하지 않고 action preview와 포털 deep link를 반환한다.
- `REQ-COP-004` 포털에서 사용자 재확인 후에만 상태 변경 API를 호출한다.
- `REQ-COP-005` Copilot 연동 장애가 포털의 기본 보고 업무를 중단시키면 안 된다.

### 감사·관리

- `REQ-AUD-001` 조회, 다운로드, AI 실행, 제출, 승인, 반려, 권한 변경을 감사 기록한다.
- `REQ-AUD-002` 운영자는 Prompt/Model/Template 버전과 배포 상태를 조회하고 rollback할 수 있다.
- `REQ-AUD-003` 데이터 보존·폐기 정책을 리소스 유형과 보안등급별로 적용한다.

## 3. 업무 규칙

1. 승인되지 않은 Snapshot은 확정 KPI로 사용하지 않습니다.
2. 보고서가 참조한 Snapshot과 Evidence는 보고서 lifecycle 동안 삭제할 수 없습니다.
3. 팀원이 제출한 원문은 보존하고 상위 보고에서 포함 여부만 선택합니다.
4. AI가 원문의 의미를 바꾸거나 수치를 합산하려면 명시된 rule/Metric 정의가 있어야 합니다.
5. 같은 사용자가 제출자와 동일 단계 승인자를 겸하지 못하도록 separation-of-duties 정책을 설정할 수 있어야 합니다.
6. 반려 시 보고 상태와 대상 version, 사유, 반려자가 기록됩니다.
7. 모든 state transition은 version check를 사용해 동시 수정 손실을 막습니다.

## 4. 상태 모델

### Metric Snapshot

`UPLOADED → VALIDATING → VALIDATION_FAILED | READY_FOR_APPROVAL → APPROVED → LOCKED → SUPERSEDED`

### WorkItem 주간 제출

`DRAFT → AI_DRAFTED → USER_CONFIRMED → SUBMITTED → RETURNED | ACCEPTED → LOCKED`

### Report

`DRAFT → SUBMITTED → TEAM_APPROVED → DEPT_APPROVED → PLANNING_QA → READY_FOR_REPORT → REPORTED → ARCHIVED`

반려는 승인 단계별 이전 작성 단계로 돌아가며 기존 version을 보존합니다.

