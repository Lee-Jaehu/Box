# Claude Code 및 내부 Copilot 개발환경 설정

## 1. Claude Code 사용 모델

Claude Code는 구현 도구이고 운영 Agent와 분리합니다. 개발자는 저장소의 `CLAUDE.md`, `.claude/rules/`, 설계 계약을 읽고 코드/테스트/문서를 함께 변경합니다.

### 저장소에 포함할 항목

- `CLAUDE.md`: 모든 세션의 상시 프로젝트 지침
- `.claude/rules/`: 경로별 보안/API/Data 규칙
- `prompts/claude-code-build-playbook.md`: 단계별 copy-paste 개발 프롬프트
- `config/claude-settings.example.json`: 최소 허용 명령 예시
- `config/mcp.example.json`: 검토된 개발 도구 MCP 예시

실제 settings와 MCP는 회사 endpoint/정책 확정 후 `.claude/settings.json`, `.mcp.json` 등 공식 위치에 적용합니다. secret을 저장소에 넣지 않습니다.

## 2. 개발 PC/Runner 사전조건

- 회사가 승인한 OS/VDI와 Claude Code 사용 정책
- GitHub Enterprise 접근과 branch protection
- Node/Python/container runtime의 승인 version
- 사내 package proxy/registry
- dev SSO, DB, Object Storage, LLM Gateway의 비운영 sandbox
- secret manager와 short-lived credential
- outbound allowlist와 proxy

## 3. Claude Code 보안 적용

1. 조직 공통 `CLAUDE.md`에 보안·개발 표준을 둡니다.
2. 프로젝트 `CLAUDE.md`는 200줄 이내의 검증 가능한 규칙을 유지하고 상세 절차는 rules/docs로 분리합니다.
3. Claude의 지침 준수에만 의존하지 않고 CI, server authorization, hook/permission으로 위험 명령을 차단합니다.
4. `.env`, secret, 운영 데이터, 고객/공정 민감 파일의 읽기를 허용하지 않습니다.
5. MCP server는 조직 정책 승인을 받고 project scope 설정을 code review합니다.
6. Claude Code가 생성한 변경은 사람의 PR review와 자동 test를 통과해야 합니다.

## 4. 개발용 Copilot과 운영용 Copilot 구분

| 구분 | GitHub Copilot | 회사 내부 업무 Copilot |
|---|---|---|
| 목적 | 코드 제안·리뷰·개발 지식 | 주간보고 조회·초안·Action Preview |
| Context | 저장소 코드/문서 | 사용자 권한의 Portal 데이터 |
| 지침 | `.github/copilot-instructions.md` | `prompts/copilot_router.md` + Adapter |
| MCP | 개발 도구만, 조직 정책 필요 | 제품이 지원하고 보안 승인 시 Portal read tool |
| 상태 변경 | 코드 PR로만 | Portal 재확인 후 API command |

## 5. 내부 Copilot 연동 Spike

제품을 확정한 뒤 3~5일 technical spike로 다음만 검증합니다.

1. 사용자를 Portal principal로 안전하게 매핑.
2. “내 팀 W33 주요 결과”를 권한 범위에서 조회.
3. 각 답변에 Portal citation/deep link 표시.
4. 다른 조직 resource ID를 넣었을 때 정보 비노출.
5. “승인해줘”에 실행이 아닌 expiring preview 반환.
6. timeout/rate limit 시 Portal fallback 안내.
7. Copilot과 Portal의 trace ID 연결.

Spike 통과 전에는 Copilot Adapter를 `MOCK`으로 두고 Portal 개발을 계속합니다.

## 6. M365/GitHub/사내 REST 선택

- Microsoft 365 Copilot이면 단순 지식·action은 declarative agent, 독자 orchestrator/복잡한 workflow는 custom engine 연동을 비교합니다.
- 사내 Copilot이 REST/OAuth2를 제공하면 `INTERNAL_REST` Adapter가 가장 직접적입니다.
- GitHub Copilot은 개발 생산성에 사용하며 운영 보고 승인 채널로 간주하지 않습니다.
- federated/MCP connector는 원천 데이터를 복제하지 않고 질의 시점에 가져와야 할 때 후보지만, 현재 수동 Snapshot 단계에서는 Portal API가 기준입니다.

## 7. 운영 전 승인자료

- 아키텍처/데이터 흐름/Trust Boundary
- 제품별 인증·권한·보존·학습사용·데이터 위치
- API/tool allowlist와 action preview demo
- 권한 negative/injection/DLP/감사 test 결과
- Prompt/Model evaluation과 비용/성능
- 장애/fallback/rollback/kill switch
- 책임자와 운영 SLA

