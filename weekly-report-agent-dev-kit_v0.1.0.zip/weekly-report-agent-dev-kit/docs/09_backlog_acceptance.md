# 구현 Backlog와 수용기준

## Epic 0. Foundation

### STORY-FND-001 저장소·CI·환경

As a 개발팀, 환경별로 동일한 품질검사를 거쳐 배포하고 싶다.

수용기준:

- monorepo, lint/test/build, secret/SCA/SAST scan이 CI에서 실행된다.
- `.env.example`에는 변수명만 있고 실제 secret이 없다.
- dev/test/stage/prod configuration과 feature flag가 분리된다.
- API와 DB migration의 기본 health/readiness가 있다.

### STORY-FND-002 SSO/RBAC

- SSO principal을 Portal User/Organization/RoleAssignment에 매핑한다.
- 권한 없는 조직의 resource ID를 직접 요청하면 404 또는 정책화된 403과 audit를 남긴다.
- role/org/state/label 조합의 negative test가 통과한다.

## Epic 1. KPI Snapshot

### STORY-SNP-001 파일 업로드/검사

- CSV/XLSX가 quarantine에 업로드되고 hash, MIME, size, scan 결과가 기록된다.
- 실패한 파일은 parsing/승인되지 않으며 사용자 조치가 표시된다.

### STORY-SNP-002 매핑·Validation

- Data Owner가 header와 Metric/차원을 매핑한다.
- 중복키, missing, unit, range, cutoff, 급변 rule 결과를 행 단위로 본다.
- 원본값은 자동 수정되지 않는다.

### STORY-SNP-003 승인·잠금·정정

- Data Owner만 READY Snapshot을 승인할 수 있다.
- 잠긴 Snapshot은 update할 수 없다.
- 정정은 새 version과 supersedes link를 만들며 과거 보고가 바뀌지 않는다.

## Epic 2. Worklog와 팀원 제출

### STORY-WRK-001 WorkItem/Worklog/Evidence

- 팀원은 본인 업무에 기록/파일/KPI/협업을 연결한다.
- Evidence는 hash/label/추출상태와 함께 저장된다.
- 타팀 비공개 정보는 조회되지 않는다.

### STORY-WRK-002 팀원 Agent 초안

- 선택된 주차/업무만 사용한다.
- output schema와 숫자/citation validation을 통과한 draft만 저장한다.
- 근거 없는 owner/date/KPI를 추측하지 않는다.

### STORY-WRK-003 제출·반려·재제출

- 사용자가 draft를 수정·확정한 후 명시적으로 제출한다.
- 반려 전후 version과 사유를 볼 수 있다.
- 중복 클릭/동시 수정에서 한 번만 상태가 전이된다.

## Epic 3. 팀장/담당/기획/그룹장

### STORY-RPT-001 팀장 보고

- 원문 서술형 정보량을 유지하고 code/태그/근거를 보강한다.
- 팀장은 포함/제외 이유, AI/사람 diff, citation을 검토한다.
- 하위 제출 미완료가 있으면 경고 또는 정책에 따른 차단이 된다.

### STORY-RPT-002 담당 보고

- 팀별 승인본을 집계하고 협업 중복을 묶는다.
- 상충 가설을 별도 표기하고 임의로 사실화하지 않는다.
- 반려/승인 chain이 감사된다.

### STORY-RPT-003 기획 QA와 그룹장 보고

- KPI 불일치, 출처 누락, 잠정값, Decision/Action 누락을 QA한다.
- 그룹장은 근거까지 drill-down하고 Decision/Action을 확정한다.
- 확정 report version은 immutable하다.

## Epic 4. Copilot

### STORY-COP-001 Adapter capability/identity

- 선택한 제품의 identity가 Portal principal로 매핑된다.
- Adapter health에서 query/citation/action-preview/file/streaming capability를 표시한다.
- 제품 장애가 Portal 기능에 영향을 주지 않는다.

### STORY-COP-002 Grounded query

- 사용자 권한 범위의 승인 보고와 Snapshot에만 답한다.
- 답변은 citation, freshness, warning, trace ID를 가진다.
- 권한 밖 질문은 존재 여부를 노출하지 않고 거절한다.

### STORY-COP-003 Action preview

- 제출/승인 요청은 상태를 바꾸지 않는다.
- 대상·diff·필요 권한·만료가 있는 preview와 Portal deep link를 반환한다.
- 실제 상태 변경은 Portal 재확인 후에만 일어난다.

## Epic 5. 운영·품질

### STORY-OPS-001 Agent eval gate

- golden dataset과 deterministic validator가 CI/stage에서 실행된다.
- `docs/08_test_evaluation_rollout.md`의 gate 미달 시 prompt/model 배포를 막는다.

### STORY-OPS-002 Audit/관측성

- trace ID로 사용자 요청부터 Agent/LLM까지 연결된다.
- 조회/다운로드/제출/승인/권한 변경을 검색 가능하다.
- 민감 payload와 secret은 로그에서 제외된다.

## 권장 Sprint 순서

1. Sprint 0: P0 결정, Foundation, IAM mock, sample data, eval skeleton
2. Sprint 1: Snapshot upload/validation/approval
3. Sprint 2: WorkItem/Worklog/Evidence + 팀원 draft
4. Sprint 3: 팀원 제출 + 팀장 서술형 report
5. Sprint 4: 담당/기획/그룹장 workflow + audit
6. Sprint 5: Copilot read-only Adapter + citation
7. Sprint 6: action preview, export, performance/security/UAT 보완

