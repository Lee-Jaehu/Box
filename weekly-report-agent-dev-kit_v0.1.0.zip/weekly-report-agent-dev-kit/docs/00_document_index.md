# 문서 체계와 추적성

## 1. 기준 문서

| ID | 문서 | 목적 | 주요 독자 |
|---|---|---|---|
| DOC-01 | `01_project_charter.md` | 목표, 범위, 성공조건 | Sponsor, PO, PM |
| DOC-02 | `02_requirements.md` | 기능·역할·업무 규칙 | PO, BA, 개발, QA |
| DOC-03 | `03_business_process.md` | As-Is/To-Be와 역할별 흐름 | 현업, BA, UX |
| DOC-04 | `04_system_architecture.md` | Context/Container/배포 구조 | Architect, 개발, 보안 |
| DOC-05 | `05_agent_and_copilot.md` | Agent와 Copilot 연동 계약 | AI, Backend, 보안 |
| DOC-06 | `06_data_api_ui.md` | 데이터·API·화면 명세 | 개발, DBA, UX, QA |
| DOC-07 | `07_security_nfr_operations.md` | 보안·비기능·운영 기준 | 보안, 운영, 개발 |
| DOC-08 | `08_test_evaluation_rollout.md` | 시험·LLM 평가·전환 | QA, PO, 운영 |
| DOC-09 | `09_backlog_acceptance.md` | Epic/Story/수용기준 | PM, 개발, QA |
| DOC-10 | `10_decisions_and_open_questions.md` | ADR와 사전 확인사항 | 전체 |
| DOC-11 | `11_official_references.md` | 공식 제품 문서와 적용 근거 | 개발, 보안 |
| DOC-12 | `12_claude_code_and_copilot_setup.md` | 개발환경·연동 착수 지침 | 개발, IT/AI 플랫폼 |

## 2. 계약 문서

| 유형 | 위치 | 역할 |
|---|---|---|
| API | `api/openapi.yaml` | Portal, Agent, Copilot 공통 HTTP 계약 |
| DB | `db/schema.sql` | PostgreSQL 기준 논리 DDL |
| JSON Schema | `schemas/*.schema.json` | Snapshot, WorkItem, Report, Agent output 검증 |
| Runtime Prompt | `prompts/*.md` | 역할·단계별 Agent 지시문 |
| Dev Prompt | `prompts/claude-code-build-playbook.md` | Claude Code 단계별 구현 지시문 |
| Policy | `config/*.yaml` | 역할 권한과 모델 사용 정책 |

## 3. 요구사항 추적 규칙

`REQ-{영역}-{번호}` → `API operationId` → `DB table` → `TEST-{종류}-{번호}`로 연결합니다.

예시:

```text
REQ-SNP-003 Snapshot 승인/잠금
  -> approveMetricSnapshot
  -> metric_snapshot.status, approval_event
  -> TEST-INT-012 / TEST-AUTH-007 / TEST-E2E-003
```

코드와 PR에는 최소 하나의 REQ ID를 기록합니다. 요구사항 없이 구현된 기능은 범위 변경으로 처리합니다.

## 4. 변경 관리

- 기준 문서와 구현이 바뀌면 같은 PR에서 함께 갱신합니다.
- API/DB/Prompt의 breaking change는 ADR과 migration/rollback 계획이 필요합니다.
- Prompt는 코드와 동일하게 version, reviewer, evaluation 결과를 관리합니다.
- 승인된 업무 규칙은 회의 메모가 아니라 이 저장소에 반영되어야 효력이 있습니다.
