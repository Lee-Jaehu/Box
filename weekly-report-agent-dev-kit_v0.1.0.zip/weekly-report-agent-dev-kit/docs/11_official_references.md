# 공식 참고자료

확인일: 2026-08-24. 구현 전에 사내 계약과 최신 공식 문서를 다시 확인합니다.

## Claude Code

- [Claude Code: project memory and CLAUDE.md](https://code.claude.com/docs/en/memory)
- [Claude Code: hooks](https://code.claude.com/docs/en/hooks)
- [Claude Code: security](https://code.claude.com/docs/en/security)
- [Claude Code: MCP](https://docs.anthropic.com/en/docs/claude-code/mcp)

적용한 원칙: 프로젝트 상시 지침은 `CLAUDE.md`, 코드로 강제할 정책은 hooks/CI/server-side authorization, 외부 도구는 검토된 MCP/Adapter로 연결합니다.

## GitHub Copilot

- [Adding repository custom instructions for GitHub Copilot](https://docs.github.com/en/copilot/how-tos/copilot-on-github/customize-copilot/add-custom-instructions/add-repository-instructions)
- [About Model Context Protocol in GitHub Copilot](https://docs.github.com/en/copilot/concepts/context/mcp)
- [Customize Copilot](https://docs.github.com/en/copilot/how-tos/copilot-on-github/customize-copilot)

적용한 원칙: `.github/copilot-instructions.md`로 개발 규칙을 공유하고, MCP는 조직 정책과 보안 검토 후 개발 도구에만 연결합니다.

## Microsoft 365 Copilot

- [Agents for Microsoft 365 Copilot](https://learn.microsoft.com/en-us/microsoft-365/copilot/extensibility/agents-overview)
- [Microsoft 365 Copilot connectors overview](https://learn.microsoft.com/en-us/microsoft-365-copilot/extensibility/overview-copilot-connector)

적용한 원칙: 단순 지식/행동 확장은 declarative agent 후보, 복잡한 승인 workflow와 독자 orchestrator는 custom engine/API 연동 후보입니다. Connector는 동기화형과 질의 시점의 federated/MCP 방식 중 데이터 이동·규제·최신성 요구에 따라 선택합니다.

