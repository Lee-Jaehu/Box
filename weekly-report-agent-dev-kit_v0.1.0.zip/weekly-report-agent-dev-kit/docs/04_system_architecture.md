# 시스템 아키텍처 정의서

## 1. Architecture Decision Summary

- PoC는 분산 마이크로서비스가 아니라 `modular monolith + background worker`로 시작합니다.
- Web, Portal API, Agent Orchestrator, Worker를 논리적으로 분리하되 배포 단위는 환경에 맞게 합칠 수 있습니다.
- RDBMS는 업무 상태와 version, Object Storage는 원본 파일, Search/Vector는 승인된 추출문 검색에 사용합니다.
- LLM Gateway와 Copilot은 외부 의존성이며 Adapter로 교체합니다.
- GitHub는 운영 DB가 아니라 개발·구성 변경의 기준 저장소입니다.

## 2. System Context

원본: `diagrams/context.mmd`

```mermaid
flowchart LR
  Users[팀원·팀장·담당·기획·그룹장] --> Portal[주간업무 AI Portal]
  DataOwner[KPI Data Owner] -->|정기 파일 업로드| Portal
  Portal --> IdP[사내 SSO/IAM]
  Portal --> LLM[사내 LLM Gateway]
  Copilot[회사 내부 Copilot] <--> Adapter[Copilot Adapter]
  Adapter <--> Portal
  Portal --> Store[(RDBMS / Object / Search)]
  Dev[Claude Code·개발자] <--> GitHub[GitHub: 코드·스키마·프롬프트]
  GitHub --> CICD[CI/CD]
  CICD --> Portal
```

## 3. Container Architecture

원본: `diagrams/container.mmd`

| Container | 책임 | 저장/상태 |
|---|---|---|
| Web Portal | 역할별 업무함, 편집, 승인, 근거 drill-down | 브라우저 세션만 |
| Portal API | 도메인 규칙, 권한, 상태 전이, transaction | RDBMS |
| Agent Orchestrator | context 구성, prompt 선택, tool 호출, output validation | AgentRun metadata |
| Worker | 파일 추출, malware scan callback, AI batch, export | Queue/Job state |
| Snapshot Validator | 컬럼 매핑, 규칙 검증, 정규화, diff | staging + RDBMS |
| Report Composer | 문단 구성, citation, template rendering | ReportVersion |
| Copilot Adapter | 제품별 인증/메시지/streaming/tool mapping | 최소 session mapping |
| RDBMS | 정형 업무·권한·workflow·audit | PostgreSQL 권장 |
| Object Storage | KPI 원본, Evidence, export | versioning/WORM 옵션 |
| Search/Vector | 권한 필터가 적용된 검색 | 승인 추출물만 |
| LLM Gateway | 승인 모델, usage, content policy | 사내 정책 |

## 4. 주요 데이터 흐름

### Snapshot 업로드

`Browser → pre-signed upload → Object Storage → scan/extract job → staging validation → Data Owner approval → immutable Snapshot → search/index metadata`

### 주간 초안

`User selection → Portal authorization → structured context builder → LLM Gateway → JSON Schema validation → deterministic number/citation validation → DraftVersion → user edit`

### 승인

`User confirmation → Portal command API → RBAC/ABAC + state/version check → transaction → ApprovalEvent + AuditEvent → next inbox`

### Copilot 질의

`Copilot → Adapter authentication → user identity mapping → read-only Portal query/tool → grounded answer + citations + optional action preview → Portal deep link`

## 5. Trust Boundary

| 경계 | 신뢰 수준 | 통제 |
|---|---|---|
| Browser ↔ Web/API | 비신뢰 네트워크 | OIDC, CSRF, rate limit, validation |
| Uploaded files | 비신뢰 콘텐츠 | quarantine, malware/MIME/size, parser isolation |
| Portal ↔ LLM | 외부 처리 경계 | 최소 context, label filter, no secret, contract |
| Portal ↔ Copilot | 별도 제품 경계 | OAuth2/OIDC, audience, scope, audit |
| Worker ↔ DB/Object | privileged backend | workload identity, network allowlist |
| CI/CD ↔ Runtime | supply-chain 경계 | signed artifact, SBOM, approvals |

## 6. 배포 토폴로지

원본: `diagrams/deployment.mmd`

- `dev`, `test`, `stage`, `prod`를 분리합니다.
- production ingress는 WAF/Reverse Proxy 뒤에 두고, API/Worker/DB/Object/LLM endpoint는 private network를 우선합니다.
- LLM/Copilot egress는 도메인 allowlist와 proxy log를 적용합니다.
- DB backup, Object versioning, prompt/config version을 묶어 복구 시점을 정의합니다.
- Agent 기능은 feature flag로 끌 수 있어야 하며 Portal 수동 workflow는 계속 동작해야 합니다.

## 7. 기준 기술 스택과 이유

| 계층 | PoC 권장 | 이유 |
|---|---|---|
| UI | Next.js/TypeScript | 역할별 웹·SSR/API client 생태계 |
| API | FastAPI/Python | schema 중심, 파일/AI 처리 라이브러리 |
| Worker | Celery/RQ 또는 사내 Queue | 긴 파일/LLM 작업 분리 |
| DB | PostgreSQL | transaction, JSONB, FTS, pgvector 선택 가능 |
| Object | S3-compatible | 원본/버전/보존정책 분리 |
| Observability | OpenTelemetry | trace ID로 Web→API→Agent→LLM 연결 |

회사 표준과 충돌하면 기술만 교체하고 논리 경계와 계약은 유지합니다.

