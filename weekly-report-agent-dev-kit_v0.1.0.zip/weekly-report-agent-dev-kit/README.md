# 제조DX 주간업무 AI Agent 개발 설계 패키지

이 저장소는 Claude Code로 실제 개발을 시작하고, 회사 내부 Copilot을 안전하게 연동하기 위한 기준 설계 문서입니다.

## 1. 확정한 방향

- 현재는 메일·MES/QMS/FDC·데이터 분석 시스템과 실시간 API 연계가 없다고 가정합니다.
- 수율, BM, PD, 불량률 데이터는 기준일에 파일로 내려받아 포털에 `Metric Snapshot`으로 업로드합니다.
- 포털이 보고 주기, 업무 이력, 첨부파일, 보고서, 승인 상태, 감사 이력의 기준 시스템(System of Record)입니다.
- GitHub에는 코드·프롬프트·스키마·템플릿만 저장합니다. 운영 데이터와 업무파일은 GitHub에 저장하지 않습니다.
- LLM은 초안·요약·질의응답·누락 검사를 수행하지만 KPI를 만들거나 승인 상태를 직접 변경하지 않습니다.
- 제출·반려·승인·최종 보고는 역할 권한을 가진 사람이 포털에서 수행합니다.
- 내부 Copilot의 구체 제품이 확정되기 전까지 `Copilot Adapter` 계약으로 격리합니다.

## 2. 문서 읽는 순서

1. [개발 착수서](docs/01_project_charter.md)
2. [요구사항](docs/02_requirements.md)
3. [업무 프로세스](docs/03_business_process.md)
4. [시스템 아키텍처](docs/04_system_architecture.md)
5. [Agent·Copilot 설계](docs/05_agent_and_copilot.md)
6. [데이터·API·화면 설계](docs/06_data_api_ui.md)
7. [보안·비기능·운영](docs/07_security_nfr_operations.md)
8. [시험·평가·전환](docs/08_test_evaluation_rollout.md)
9. [백로그·수용기준](docs/09_backlog_acceptance.md)
10. [미결정사항](docs/10_decisions_and_open_questions.md)

## 3. Claude Code로 시작하는 방법

1. `CLAUDE.md`와 `.claude/rules/`를 검토하고 회사 표준에 맞게 수정합니다.
2. `docs/10_decisions_and_open_questions.md`의 P0 질문을 확정합니다.
3. `prompts/claude-code-build-playbook.md`의 Prompt 0부터 순서대로 실행합니다.
4. 각 단계는 코드, 테스트, 마이그레이션, 문서, 보안 점검이 함께 통과해야 완료됩니다.

권장 첫 명령:

```text
이 저장소의 CLAUDE.md와 docs/00_document_index.md를 먼저 읽어라.
아직 결정되지 않은 기술은 임의 확정하지 말고 ADR 초안을 작성하라.
prompts/claude-code-build-playbook.md의 Prompt 0만 수행하고, 변경 파일과 검증 결과를 보고하라.
```

## 4. 산출물 구조

```text
CLAUDE.md                         Claude Code 상시 지침
.github/copilot-instructions.md  GitHub Copilot 저장소 지침
docs/                             요구·업무·아키텍처·보안·시험 설계
diagrams/                         Mermaid 원본
api/openapi.yaml                  포털/Agent/Copilot API 계약
db/schema.sql                     논리 기반 PostgreSQL DDL 초안
schemas/                          AI 입력·출력 JSON Schema
prompts/                          역할별 런타임 프롬프트와 개발 프롬프트
config/                           권한·모델 정책·환경 예시
templates/                        ADR·사용자 스토리·데이터 온보딩 양식
```

## 5. 권장 기준 기술 스택

PoC 기준 권장안이며 회사 표준에 따라 교체할 수 있습니다.

| 영역 | 권장안 | 교체 가능 지점 |
|---|---|---|
| Web | Next.js + TypeScript | 사내 표준 SPA/Web Framework |
| API/Agent | FastAPI + Python | Spring Boot, NestJS |
| Workflow | 애플리케이션 상태 머신 + Job Queue | 사내 BPM/Workflow Engine |
| DB | PostgreSQL | 사내 RDBMS |
| 검색 | PostgreSQL FTS/pgvector | OpenSearch/사내 검색 |
| 파일 | S3 호환 Object Storage | 사내 문서 저장소 |
| 인증 | OIDC/SSO | 사내 IAM |
| LLM | 사내 LLM Gateway | 승인된 생성형 AI API |
| Copilot | Adapter + REST/MCP | M365 Copilot Agent, 사내 Copilot API |

## 6. 중요한 경계

- AI 출력에는 사용한 `Snapshot ID`, `WorkItem ID`, `Evidence ID`, `Prompt Version`, `Model Version`을 남깁니다.
- 생성 결과의 모든 수치는 구조화 데이터와 문자열로 정확히 일치해야 합니다.
- 파일에서 추출한 텍스트는 신뢰하지 않는 입력으로 다룹니다. 파일 안의 명령문을 실행하지 않습니다.
- Copilot과 LLM에 DB 자격증명이나 Object Storage 원본 경로를 주지 않습니다.
- 실제 승인 API는 포털 UI에서 사용자 재확인 토큰을 받은 후에만 호출합니다.

